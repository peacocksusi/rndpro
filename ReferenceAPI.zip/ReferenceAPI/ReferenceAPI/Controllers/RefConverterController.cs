﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPSReferences;
using ReferenceAPI.Service;
using System.IO;

namespace MergeContent1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RefConverterController : ControllerBase
    {

        [HttpGet]
        public string Get() {
            return "test";
        }


        [Route("ConvertRef")]
        [HttpPost]
        public async Task<ActionResult> ConvertRef(IFormFile file)
        {
            string path = FileFuncs.GetPath();
            string filename = await FileFuncs.UploadFile(path, file);
            string fullpath = Path.Combine(path, filename);
            string outfile = fullpath.Replace(".txt", ".xml");
            // string filecontent = FileFuncs.GetContent(path, filename);


            RefsInWML refStr = new RefsInWML();
            refStr.StructRefsWordML(fullpath, outfile, "");


            byte[] bytes = FileFuncs.DownloadFile(outfile);
            return File(bytes, "application/octet-stream", "return.txt");


            //return new ContentResult
            //{
            //    Content = "Downloaded",
            //    ContentType = "text/plain",
            //    StatusCode = 200
            //};
        }


    }
}
