﻿using System.Text.RegularExpressions;
using System.Drawing;
using System.IO;
using System.Xml;
using System.Threading;
using System.Data;
using System.Collections;
using System.Net;
using System;
using System.Collections.Generic;
using ReferenceAPI.Service;

namespace MPSReferences
{
    public class RefsInWML
    {
        ArrayList RefIdentificationSplit = new ArrayList();
        public static string mlUrl = "http://192.168.60.45:8070", roboUrl = "http://10.66.13.155:146";
        int RefIdentificationSplitNo;
        //System.Threading.ThreadStart IdentifyRefMEPThreadStart = new System.Threading.ThreadStart(new RefIdentifyThread);
        refModule refMd = new refModule();
        public bool StructRefsWordML(string fPath, string outfile, string api)
        {
            string str = "", taggedReferenceStr = "",stime=  DateTime.Now.ToString();
            try
            {
                if (api == "")
                    api = "crossref|pubmed|ml|robo|local";
                //Delete the crossrefpubmed file
                XmlDocument xdoc = new XmlDocument();
                xdoc.PreserveWhitespace = true;
                try
                {
                    xdoc.Load(AppDomain.CurrentDomain.BaseDirectory + "\\Url.config");
                    if (xdoc.SelectSingleNode("//ml") != null)
                        mlUrl = xdoc.SelectSingleNode("//ml").Attributes.GetNamedItem("url").Value;
                    if (xdoc.SelectSingleNode("//robo") != null)
                        roboUrl = xdoc.SelectSingleNode("//robo").Attributes.GetNamedItem("url").Value;
                }
                catch { }
                str = GetXmlContentFromFile(fPath);
                string[] arr;
                str = str.Replace("\r\n", "\n").Trim('\n');
                str = str.Replace("\r", "\n").Trim('\r');
                arr = str.Split('\n');
                //if (api.ToLower() == "ml")
                //    IdentifyReferenceAllML(str);
                if (arr.Length > 12)
                    StructRefsWordML_MT(arr, outfile, api);
                else
                {
                    for (int i = 0; i < arr.Length; i++)
                    {
                        Console.WriteLine("Processing " + (i + 1) + "/" + arr.Length);
                        taggedReferenceStr = taggedReferenceStr + IdentifyReferenceSingle(arr[i].ToString(), (i + 1).ToString(), api);
                    }
                    taggedReferenceStr = "<ref>" + GetInformation("<ref>" + taggedReferenceStr + "</ref>", stime) + taggedReferenceStr + " </ref>";
                    StreamWriter sw = new StreamWriter(outfile);
                    sw.WriteLine(taggedReferenceStr.Replace("&amp;amp;", "&amp;"));
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        public string GetInformation(string tagRefs,string stime)
        {
            int cr = 0, pm = 0, ml = 0, robo = 0, other = 0;
            string info = "<Info startTime=\"" + stime + "\" endtime=\"" + DateTime.Now + "\"";
            try
            {
                XmlDocument rDoc = new XmlDocument();
                rDoc.LoadXml(tagRefs.Replace("&","#amp;"));
                cr=rDoc.SelectNodes("//cr").Count;
                pm = rDoc.SelectNodes("//pm").Count;
                ml = rDoc.SelectNodes("//ml").Count;
                robo = rDoc.SelectNodes("//robo").Count;
                other = rDoc.SelectNodes("//bib-reference").Count;
                other = other - cr - pm - ml - robo;
                info = info + " cr=\"" + cr + "\" pm=\"" + pm + "\" ml=\"" + ml + "\" robo=\"" + robo + "\" other=\""+other+"\"/>";
            }
            catch(Exception e)
            {
                info = info + "/>";
            }
            return info;
        }
        public string IdentifyReferenceAllML(string currentReference)
        {
            SearchAPI sAPI = new SearchAPI();
            string XmlQueryString = "",eDoi="";
            if (sAPI.Search_in_Grobid(ref XmlQueryString,eDoi, currentReference.Replace("&", "and"),"") == true)
            {
                //oTmp = GetGrobidValues(XmlQueryString);
                //ApplyElementsInRef(ref currentReference, ref au);
                //FillElements(ref currentReference, ref au);
                currentReference = currentReference.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>") + "<ml/>";
                if (Regex.IsMatch(currentReference, "<(publisher|editor)>", RegexOptions.IgnoreCase) == true)
                    currentReference = "<Book>" + currentReference + "</Book>";
            }
            string refId = "",seqid="";
            RefIdentify rf = new RefIdentify();
            Console.WriteLine("Identifying reference: " + seqid);
            currentReference = currentReference.Replace("\r\n", "").Replace("\n", "");
            MatchCollection individualRefs = Regex.Matches(currentReference, "^((((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?\b[A-Z]?[0-9][0-9A-Za-z]*[\\.\\(\\)\\[\\]]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?[0-9]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\[\\(]+(</?[i|b|u]>)?)[0-9][ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+\\ ?[ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+((</?[i|b|u]>)?[\\s\\t\\]\\)\\.]+(</?[i|b|u]>)?)|([\\s\\t]+)?))?(.*?)$", RegexOptions.Singleline);
            if (individualRefs.Count > 0 && individualRefs[0].Groups[1].Value.Length > 0)
                currentReference = "<id>" + individualRefs[0].Groups[1].Value + "</id>" + individualRefs[0].Groups[22].Value;
            if (Regex.Match(currentReference, "<id>([^<>]+)</id>").Success)
            {
                refId = Regex.Match(currentReference, "<id>([^<>]+)</id>").Groups[0].Value;
                currentReference = Regex.Replace(currentReference, "<id>([^<>]+)</id>", "");
            }
            currentReference = refId + rf.IdentifyElements(currentReference, seqid, "");
            return "<bib-reference id=\"" + seqid + "\">" + currentReference + "</bib-reference>";
        }
        public string IdentifyReferenceSingle(string currentReference, string seqid, string API)
        {
            MatchCollection pMatSub;
            int intLen = 0;
            string refId = "";
            RefIdentify rf = new RefIdentify();
            Console.WriteLine("Identifying reference: " + seqid);
            currentReference = currentReference.Replace("\r\n", "").Replace("\n", "");
            MatchCollection individualRefs = Regex.Matches(currentReference, "^((((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?\b[A-Z]?[0-9][0-9A-Za-z]*[\\.\\(\\)\\[\\]]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?[0-9]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\[\\(]+(</?[i|b|u]>)?)[0-9][ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+\\ ?[ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+((</?[i|b|u]>)?[\\s\\t\\]\\)\\.]+(</?[i|b|u]>)?)|([\\s\\t]+)?))?(.*?)$", RegexOptions.Singleline);
            if (individualRefs.Count > 0 && individualRefs[0].Groups[1].Value.Length > 0)
                currentReference = "<id>" + individualRefs[0].Groups[1].Value + "</id>" + individualRefs[0].Groups[22].Value;
            if (Regex.Match(currentReference, "<id>([^<>]+)</id>").Success)
            {
                refId = Regex.Match(currentReference, "<id>([^<>]+)</id>").Groups[0].Value;
                currentReference = Regex.Replace(currentReference, "<id>([^<>]+)</id>", "");
            }
            pMatSub = rf.getthesubReferences(currentReference);
            if (pMatSub.Count > 1)
            {
                string left, right, middle, tempRefs, TaggedRefs = "";
                string[] splittedReferences = new string[pMatSub.Count - 1];
                for (int tmpCnt = pMatSub.Count - 1; tmpCnt >= 0; tmpCnt--)
                {
                    left = currentReference.Substring(0, pMatSub[tmpCnt].Groups[0].Index);
                    middle = currentReference.Substring(left.Length, pMatSub[tmpCnt].Groups[0].ToString().Length);
                    right = currentReference.Substring(left.Length + middle.Length, currentReference.Length - (left.Length + middle.Length + intLen));
                    if (Regex.IsMatch(right, "</bib-reference>"))
                        splittedReferences[tmpCnt] = right.Trim();
                    else
                        splittedReferences[tmpCnt] = right.Trim();
                    intLen = intLen + right.Length + middle.Length;
                    tempRefs = rf.IdentifyElements(splittedReferences[tmpCnt], seqid, API);
                    if (right.EndsWith(" "))
                        tempRefs = tempRefs + " ";
                    TaggedRefs = "<subid>" + middle + "</subid>" + tempRefs + TaggedRefs;
                }
                currentReference = refId + "<SubRef>" + TaggedRefs + "</SubRef>";
                if (Regex.IsMatch(currentReference, "<subid>[^<>]*</subid>[^<>]*<Journal>", RegexOptions.IgnoreCase) == true)
                {
                    currentReference = Regex.Replace(currentReference, "<subid>([^<>]*)</subid>([^<>]*)<Journal>", "<JournalSubRef>$1</JournalSubRef>$2");
                    currentReference = currentReference.Replace("</Journal>", "");
                }
                if (Regex.IsMatch(currentReference, "<subid>[^<>]*</subid>[^<>]*<Other>", RegexOptions.IgnoreCase) == true)
                {
                    currentReference = Regex.Replace(currentReference, "<subid>([^<>]*)</subid>([^<>]*)<Other>", "<OtherSubRef>$1</OtherSubRef>$2");
                    currentReference = currentReference.Replace("</Other>", "");
                }
            }
            else
                currentReference = refId + rf.IdentifyElements(currentReference, seqid, API);
            return "<bib-reference id=\"" + seqid + "\">" + currentReference + "</bib-reference>";
        }
        public string GetXmlContentFromFile(string sfileName)
        {
            StreamReader sr = new StreamReader(sfileName, System.Text.Encoding.UTF8);
            string str = sr.ReadToEnd();
            sr.Close();
            return str;
        }
        public bool StructRefsWordML_MT(string[] arr, string outfile, string api)
        {
            XmlDocument refDoc = new XmlDocument();
            try
            {
                refMd.etime = DateTime.Now.ToString();
                refMd.taggedReferenceStr = "";
                refMd.APIOrder = api;
                refMd.outFile = outfile;
                refMd.refCount = arr.Length;
                refMd.allReferences = new string[arr.Length];
                refMd.taggedReferences = new string[arr.Length];
                for (int i = 0; i < arr.Length; i++)
                {
                    refMd.allReferences.SetValue(arr[i], i);
                }
                InitializingThreads(refMd.refCount);
            }
            catch { }
            return true;
        }
        void RefIdentifyThread()
        {
        }
        public bool InitializingThreads(int refCount)
        {
            int RefsPerThread = 1;
            double tmp = 0.0;
            if (refCount > 0 && refCount <= 200)
                RefsPerThread = 10;
            else if (refCount > 200 && refCount <= 300)
                RefsPerThread = 15;
            else if (refCount > 300 && refCount <= 400)
                RefsPerThread = 20;
            else if (refCount > 400 && refCount <= 500)
                RefsPerThread = 25;
            else if (refCount > 500)
            {
                tmp = refCount / 100;
                tmp = tmp + 0.49;
                RefsPerThread = int.Parse(tmp.ToString());
            }
            if (RefsPerThread < 1)
                return true;
            RefIdentificationSplit.Clear();
            for (int i = 1; i <= refCount; i = i + RefsPerThread)
            {
                if (refCount < (i + RefsPerThread))
                    RefIdentificationSplit.Add(i + "-" + refCount);
                else
                    RefIdentificationSplit.Add(i + "-" + (i + (RefsPerThread - 1)));
            }
            RefIdentificationSplitNo = 0;
            RunRefIdenThreads(RefIdentificationSplit.Count);
            return true;
        }
        public List<Thread> RunRefIdenThreads(int count)
        {
            List<Thread> list = new List<Thread>();
            RefIdentify[] refIden = new RefIdentify[count];
            refModule[] refmdthrd = new refModule[count];
            System.Threading.ThreadStart[] IdentifyRefMEPThreadStart = new System.Threading.ThreadStart[count];
            for (int i = 0; i < count; i++)
            {
                try
                {
                    refmdthrd[i] = new refModule();
                    //string[refMd.refCount] refmdthrd[i].allReferences;
                    //string[refMd.refCount] refmdthrd[i].taggedReferences;
                    refmdthrd[i].APIOrder = refMd.APIOrder;
                    refmdthrd[i].allReferences = (Array)refMd.allReferences.Clone();
                    refmdthrd[i].taggedReferences = (Array)refMd.taggedReferences.Clone();
                    refIden[i] = new RefIdentify(refmdthrd[i]);
                    IdentifyRefMEPThreadStart[i] = new System.Threading.ThreadStart(refIden[i].IdentifyReference);
                    refIden[i].startrefNo = int.Parse(RefIdentificationSplit[RefIdentificationSplitNo].ToString().Split('-')[0]) - 1;
                    refIden[i].endrefNo = int.Parse(RefIdentificationSplit[RefIdentificationSplitNo].ToString().Split('-')[1]) - 1;
                    refIden[i].threadId = i + 1;
                    if (i == count - 1)
                    {
                        if (refIden[i].endrefNo > refmdthrd[i].allReferences.Length - 1)
                            refIden[i].endrefNo = refmdthrd[i].allReferences.Length - 1;
                    }
                    RefIdentificationSplitNo += 1;
                    Thread thread = new Thread(IdentifyRefMEPThreadStart[i]);
                    thread.Start();
                    list.Add(thread);
                }
                catch { }
            }
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Total refs count: " + refMd.refCount + "\t\t Waiting for thread: " + (i + 1) + " of " + count+" to complete");
                 list[i].Join();
            }
            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < refMd.taggedReferences.Length; j++)
                {
                    try
                    {
                        if (refmdthrd[i].taggedReferences.GetValue(j) != null)
                            refMd.taggedReferenceStr = refMd.taggedReferenceStr + refmdthrd[i].taggedReferences.GetValue(j);
                    }
                    catch { }
                }
            }
            //refMd.taggedReferenceStr = "<ref><time start='" + refMd.etime + "' end='" + DateTime.Now + "'/>" + refMd.taggedReferenceStr + "</ref>";

            refMd.taggedReferenceStr = "<ref>" + GetInformation("<ref>" + refMd.taggedReferenceStr + "</ref>", refMd.etime) + refMd.taggedReferenceStr + " </ref>";
            StreamWriter sw = new StreamWriter(refMd.outFile, false, System.Text.Encoding.UTF8);
            sw.WriteLine(refMd.taggedReferenceStr.Replace("&amp;amp;", "&amp;"));
            sw.Close();
            return list;
        }
    }
}
