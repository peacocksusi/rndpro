﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Net;
using System.Text.RegularExpressions;
using System.Data;

namespace MPSReferences
{
    public class SearchAPI
    {
        string eSearchLink = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi";
        string eSummaryLink = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi";
        public struct eSummaryItem
        {
            public string Name;
            public string Text;
        }
        public struct eSummaryResult
        {
            public List<DocSumItem> DocSum;
        }
        public struct DocSumItem
        {
            public int Id;
            public List<eSummaryItem> Item, AuthorList;
            //Dim AuthorList As List(Of eSummaryItem)
        }
        public struct eSearchResult
        {
            public int Count, RetMax, RetStart;
            public List<int> IdList;
            public string QueryTranslation;
        }
        public Boolean Search_in_Grobid(ref string refDetails, string DBDoi, string inpStr, string refid)
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(RefsInWML.mlUrl + "/api/processCitationList");
                //var request = (HttpWebRequest)WebRequest.Create("http://192.168.60.45:8070/api/processCitationList");
                if (inpStr.Contains("\n")==true)
                {
                    inpStr = inpStr.Replace("\n", "&citations=");
                }
                var data = System.Text.Encoding.ASCII.GetBytes("citations=" + inpStr);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                var response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                responseString = responseString.Replace("\r\n", "").Replace("\n", "");
                responseString = Regex.Replace(responseString, "[\\s]{2,}", " ");
                if (responseString.IndexOf("<biblStruct xml", 0) >= 0)
                {
                    responseString = responseString.Substring(responseString.IndexOf("<biblStruct xml", 0));
                    refDetails = responseString.Substring(0, responseString.LastIndexOf("</biblStruct>") + 13);
                    return true;
                }
                else
                {
                    refDetails = "";
                    return false;
                }
            }
            catch (WebException e)
            {
                if (e.Status == WebExceptionStatus.ProtocolError)
                {
                    string error = new System.IO.StreamReader(e.Response.GetResponseStream()).ReadToEnd();
                    Console.WriteLine(error);
                }
            }
            return false;
        }
        public Boolean Search_in_Local(ref string refDetails, string DBDoi, string inpStr)
        {
            string rFile;
            rFile = AppDomain.CurrentDomain.BaseDirectory + "\\Refs.xml";
            DataSet dSet=new DataSet();
            DataTable temp_DataTable; 
            try
            {
                dSet.ReadXml(rFile);
            }
            catch { }
            inpStr = Regex.Replace(inpStr, "<id>[^!=]+</id>", "");
            inpStr = inpStr.Replace("<doi></doi>", "");
            try
            {
                if (DBDoi != "")
                {
                    dSet.Tables[0].DefaultView.RowFilter = "doi like'%" + DBDoi + "%'";
                temp_DataTable = dSet.Tables[0].DefaultView.ToTable();
                }
                else
                {
                    inpStr = inpStr.Trim(';');
                    inpStr = inpStr.Trim('.');
                    dSet.Tables[0].DefaultView.RowFilter = "RefText like'%" + inpStr + "%'";
                    temp_DataTable = dSet.Tables[0].DefaultView.ToTable();
                    //ds = SqlHelper.ExecuteDataset(sqlStr, CommandType.Text, "select * from RefDatabase where RefText like '%" + inpStr + "%' for XML path");
                    if (dSet.Tables[0].Rows.Count == 0)
                    {
                        string tmp = "";
                        string[] arr;
                        inpStr = Regex.Replace(inpStr, "[\\.,:;\\(\\)\\[\\]]+", "");
                        arr = inpStr.Split(' ');
                        for (int i = 0; i < arr.Length; i++)
                        {
                            if (arr[i].Length > 3)
                                tmp = tmp + " RefText like '%" + arr[i] + "%' and";
                        }
                        tmp = tmp.Substring(0, tmp.Length - 3).Trim();
                        dSet.Tables[0].DefaultView.RowFilter = tmp;
                        temp_DataTable = dSet.Tables[0].DefaultView.ToTable();
                    }
                }
                if (dSet != null)
                {
                    if (dSet.Tables[0].Rows.Count > 0)
                    {
                        DataSet dss = new DataSet();
                        dss.Tables.Add(temp_DataTable);
                        refDetails = dss.GetXml();
                        refDetails = refDetails.Replace("<NewDataSet>", "").Replace("</NewDataSet>", "").Trim();
                        refDetails = refDetails.Replace("[au]", "<au>").Replace("[fnm]", "<fnm>").Replace("[snm]", "<snm>").Replace("[/au]", "</au>").Replace("[/fnm]", "</fnm>").Replace("[/snm]", "</snm>");
                        return true;
                    }
                }
            }
            catch { }

            return false;
        }
        public Boolean Search_in_PubMed(string DBDoi, string inpStr, ref eSummaryResult eSumRes)
        {
            try
            {
                //Fetch the doi value from the crossref information
                eSearchResult res = new eSearchResult();
                string ReTVal;
                if (DBDoi != "")
                {
                    res = GetPubmedESearch("pubmed", DBDoi);
                    if (res.IdList != null && res.IdList.Count == 1)
                    {
                        ReTVal = res.IdList[0].ToString();
                        if (ReTVal != "")
                        {
                            eSummaryResult res1 = new eSummaryResult();
                            try
                            {
                                res1 = GetESummaryResult("pubmed", ReTVal);
                            }
                            catch { }
                            if (res1.DocSum != null && res1.DocSum.Count > 0)
                            {
                                eSumRes = res1;
                                return true;
                            }
                        }
                    }
                }
                inpStr = inpStr.Replace(Convert.ToChar(147).ToString(), "");
                inpStr = Regex.Replace(inpStr, "[&:\\,]", "");
                res = GetPubmedESearch("pubmed", inpStr);
                if (res.IdList != null && res.IdList.Count == 1)
                {
                    ReTVal = res.IdList[0].ToString();
                    if (ReTVal != "")
                    {
                        eSummaryResult res1 = new eSummaryResult();
                        try
                        {
                            res1 = GetESummaryResult("pubmed", ReTVal);
                        }
                        catch { }
                        if (res1.DocSum != null && res1.DocSum.Count > 0)
                        {
                            eSumRes = res1;
                            return true;
                        }
                    }
                }
            }
            catch { }
            return false;
        }
        public eSearchResult GetPubmedESearch(string pubmed, string input)
        {
            string str = "";
            Stream data = null;
            WebClient client;
            try
            {
                string URL = eSearchLink + "?db=" + pubmed + "&api_key=be544e2e80e3fedb54a910aa254826f1f608&term=" + input;
                client = new WebClient();
                try
                {
                    data = client.OpenRead(URL);
                }
                catch { }
                //AddToErrorList(ex.Message, "GetPubmedESearch")
                StreamReader reader = new StreamReader(data);
                str = reader.ReadToEnd();
                reader.Close();
            }
            catch { }
            if (str != null)
                return GetESearch(str);
            return new eSearchResult();
        }
        public eSummaryResult GetESummaryResult(string pubmed, string retVal)
        {
            string Url = eSummaryLink + "?db=" + pubmed + "&api_key=be544e2e80e3fedb54a910aa254826f1f608&id=" + retVal;
            string SummRes = "";
            //WebClient client;
            Stream data = null;
            try
            {
                WebClient client = new WebClient();
                try
                {
                    data = client.OpenRead(Url);
                }
                catch { }
                //AddToErrorList(ex.Message, "GetESummaryResult")

                StreamReader reader = new StreamReader(data);
                SummRes = reader.ReadToEnd();
                reader.Close();
            }
            catch { }
            return GetEsummary(SummRes);
        }
        public eSummaryResult GetEsummary(string summRslt)
        {
            eSummaryItem summItemObj;
            if (!(Regex.Match(summRslt, "</eSummaryResult>", RegexOptions.IgnoreCase).Success))
                summRslt = summRslt + "</eSummaryResult>";
            XmlDocument Xdoc = new XmlDocument();
            Xdoc.LoadXml(summRslt);
            eSummaryResult SummRsltobj = new eSummaryResult();
            //SummRsltobj.DocSum = new List<DocSumItem>;
            XmlNodeList DocSumNode = Xdoc.SelectNodes("//DocSum");
            foreach (XmlNode DocNode in DocSumNode)
            {
                DocSumItem docObj = new DocSumItem();
                //docObj.Item = new List<eSummaryItem>;
                //docObj.AuthorList = new List<eSummaryItem>;
                docObj.Id = int.Parse(DocNode.SelectSingleNode(".//Id").InnerText);
                XmlNodeList ItemNodes = DocNode.SelectNodes("./Item");
                foreach (XmlNode Item in ItemNodes)
                {
                    try
                    {
                        if (Item.Attributes.GetNamedItem("Type").Value != "List")
                        {
                            summItemObj.Name = Item.Attributes.GetNamedItem("Name").Value;
                            summItemObj.Text = Item.InnerText;
                            docObj.Item.Add(summItemObj);
                        }
                        else if (Item.Attributes.GetNamedItem("Type").Value.Equals("List") && Item.Attributes.GetNamedItem("Name").Value.Equals("AuthorList"))
                        {
                            XmlNodeList ItNode = Item.SelectNodes("./Item");
                            foreach (XmlNode iNd in ItNode)
                            {
                                summItemObj.Name = iNd.Attributes.GetNamedItem("Name").Value;
                                summItemObj.Text = iNd.InnerText;
                                docObj.AuthorList.Add(summItemObj);
                            }
                        }
                    }
                    catch { }
                }
                SummRsltobj.DocSum.Add(docObj);
            }
            return SummRsltobj;
        }
        public eSearchResult GetESearch(string srchRslt)
        {
            eSearchResult SrchObj = new eSearchResult();
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(srchRslt);
            if (xDoc.SelectSingleNode("//ErrorList") != null)
                return SrchObj;
            if (xDoc.SelectSingleNode("//Count") != null)
                SrchObj.Count = int.Parse(xDoc.SelectSingleNode("//Count").InnerText);
            else
                SrchObj.Count = 0;
            if (xDoc.SelectSingleNode("//RetMax") != null)
                SrchObj.RetMax = int.Parse(xDoc.SelectSingleNode("//RetMax").InnerText);
            else
                SrchObj.RetMax = 0;
            if (xDoc.SelectSingleNode("//RetStart") != null)
                SrchObj.RetStart = int.Parse(xDoc.SelectSingleNode("//RetStart").InnerText);
            else
                SrchObj.RetStart = 0;
            if (xDoc.SelectSingleNode("//IdList") != null)
            {
                XmlNode idlst = xDoc.SelectSingleNode("//IdList");
                // SrchObj.IdList = new List<int>;
                SrchObj.IdList = new List<int>();
                for (int index = 0; index < idlst.ChildNodes.Count - 1; index++)
                {
                    SrchObj.IdList.Add(int.Parse(idlst.ChildNodes[index].InnerText));
                }
            }
            if (xDoc.SelectSingleNode("//QueryTranslation") != null)
                SrchObj.QueryTranslation = xDoc.SelectSingleNode("//QueryTranslation").InnerText;
            else
                SrchObj.QueryTranslation = "";

            return SrchObj;
        }
        public Boolean SearchInCrossref(ref string url, string sDoi,string refText)
        {
            try
            {
                if (sDoi == "" && refText != "")
                {
                    url = "<?xml version=\"1.0\"?><query_batch version=\"2.0\" xsi:schemaLocation=\"http://www.crossref.org/qschema/2.0 http://www.crossref.org/qschema/crossref_query_input2.0.xsd\" xmlns=\"http://www.crossref.org/qschema/2.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"> <head> <email_address>support@crossref.org</email_address> <doi_batch_id>01032012</doi_batch_id> </head><body> <query key=\"q1\" enable-multiple-hits=\"true\" forward-match=\"true\">";
                    url = url + "<unstructured_citation>" + refText + "</unstructured_citation></query></body></query_batch>";
                }
                else if (sDoi != "")
                {
                    url = "<?xml version=\"1.0\"?><query_batch version=\"2.0\" xsi:schemaLocation=\"http://www.crossref.org/qschema/2.0 http://www.crossref.org/qschema/crossref_query_input2.0.xsd\" xmlns=\"http://www.crossref.org/qschema/2.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"> <head> <email_address>support@crossref.org</email_address> <doi_batch_id>ABC_123_fff</doi_batch_id> </head><body> <query key=\"1178517\" enable-multiple-hits=\"false\" forward-match=\"false\">";
                    url = url + "<doi>" + sDoi + "</doi></query></body></query_batch>";
                }
                else
                    return false;
                // Cross Ref Data Reterives
                string inpstr = "http://doi.crossref.org/servlet/query?pid=iop:crpw054&format=unixref&qdata=" + url.Replace("#amp;", "&amp;").Replace("#amp;", "&amp;");
                WebRequest request = WebRequest.Create(inpstr);
                // If required by the server, set the credentials.
                request.Credentials = CredentialCache.DefaultCredentials;
                // Get the response.
                WebResponse response = request.GetResponse();
                // Get the stream containing content returned by the server.
                System.IO.Stream dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                string responseFromServer = reader.ReadToEnd();
                // Clean up the streams and the response.
                reader.Close();
                response.Close();
                url = responseFromServer;
                if (Regex.IsMatch(url, "<error>") == false && Regex.IsMatch(url, "<journal>|</proceedings_metadata>|</book>") == true)
                    return true;
                else
                    return false;
            }
            catch
            {
                url = "<error>Gateway Timeout</error> when connecting: ";
            }
            return false;
        }
        public Boolean Search_in_Robo(ref string refDetails, string inpstr)
        {
            try
            {
                string url = RefsInWML.roboUrl + "/?ref=";
                inpstr = inpstr.Replace("%", "%25").Replace("#","%23");
                inpstr = inpstr.Replace("$", "%24").Replace("&", "%26").Replace("=", "%3D");
                inpstr = url + inpstr;
                System.Net.WebRequest request = System.Net.WebRequest.Create(inpstr);
                System.Net.WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseFromServer = reader.ReadToEnd();
                reader.Close();
                response.Close();
                if (Regex.IsMatch(url, "<error>") == false)
                {
                    refDetails = responseFromServer;
                    return true;
                }
                else
                    return false;
            }
            catch { }
            return false;
        }
    }
}
