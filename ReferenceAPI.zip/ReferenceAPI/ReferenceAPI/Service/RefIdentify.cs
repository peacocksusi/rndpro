﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Text.RegularExpressions;
using System.Collections;
using ReferenceAPI.Service;

namespace MPSReferences
{
    public class RefIdentify
    {
        public int startrefNo, endrefNo,threadId;
        public refModule refMod;
        public string eAug, eYear, eSubtitle, eMainTitle, eAbbrTtl, eVol, eIssue, eDoi, eFpage, eLpage, eLoc, epubid, etal,eSeries;
        public string acc, eEdg, ePname, ePloc, eEdn, eFnm, strOnline, issn;
        public RefIdentify(refModule refmd)
        {
            refMod = refmd;
        }
        public RefIdentify()
        {
            refMod = new refModule();
        }
        public void IdentifyReference()
        {
            MatchCollection pMatSub = null;
            int intLen = 0;
            string refId = "", currentReference, seqid;
            for (refMod.curRefProcessing = this.startrefNo; refMod.curRefProcessing <= this.endrefNo; refMod.curRefProcessing++)
            {
                // lock (this)
                // {
                    seqid = (refMod.curRefProcessing + 1).ToString();
                    Console.WriteLine("Processing thread: "+this.threadId +" of reference: " + seqid);
                    currentReference = refMod.allReferences.GetValue(refMod.curRefProcessing).ToString().Replace("\r\n", "\n").Replace("\n", "");
                    MatchCollection individualRefs = System.Text.RegularExpressions.Regex.Matches(currentReference, "^((((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?\\b[A-Z]?[0-9][0-9A-Za-z]*[\\.\\(\\)\\[\\]]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\ *\\t*\\[\\(]*(</?[i|b|u]>)?[0-9]+((</?[i|b|u]>)?[\\ *\\t*\\]\\)\\.]*(</?[i|b|u]>)?))|((</?[i|b|u]>)?[\\[\\(]+(</?[i|b|u]>)?)[0-9][ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+\\ ?[ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+((</?[i|b|u]>)?[\\s\\t\\]\\)\\.]+(</?[i|b|u]>)?)|([\\s\\t]+)?))?(.*?)$", RegexOptions.Singleline);
                    if (individualRefs.Count > 0 && individualRefs[0].Groups[1].Value.Length > 0)
                        currentReference = "<id>" + individualRefs[0].Groups[1].Value + "</id>" + individualRefs[0].Groups[22].Value;
                    if (System.Text.RegularExpressions.Regex.Match(currentReference, "<id>([^!=]+)</id>").Success)
                    {
                        refId = System.Text.RegularExpressions.Regex.Match(currentReference, "<id>([^!=]+)</id>").Groups[0].Value;
                        currentReference = System.Text.RegularExpressions.Regex.Replace(currentReference, "<id>([^!=]+)</id>", "");
                    }
                    pMatSub = getthesubReferences(currentReference);
                    if (pMatSub.Count > 1)
                    {
                        string left, right, middle, tempRefs, TaggedRefs = "";
                        string[] splittedReferences = new string[pMatSub.Count - 1];
                        for (int tmpCnt = pMatSub.Count - 1; tmpCnt >= 0; tmpCnt--)
                        {
                            left = currentReference.Substring(0, pMatSub[tmpCnt].Groups[0].Index);
                            middle = currentReference.Substring(left.Length, pMatSub[tmpCnt].Groups[0].ToString().Length);
                            right = currentReference.Substring(left.Length + middle.Length, currentReference.Length - (left.Length + middle.Length + intLen));
                            if (Regex.IsMatch(right, "</bib-reference>"))
                                splittedReferences[tmpCnt] = right.Trim();
                            else
                                splittedReferences[tmpCnt] = right.Trim();
                            intLen = intLen + right.Length + middle.Length;
                            tempRefs = IdentifyElements(splittedReferences[tmpCnt], seqid,refMod.APIOrder);
                            if (right.EndsWith(" "))
                                tempRefs = tempRefs + " ";
                            TaggedRefs = "<subid>" + middle + "</subid>" + tempRefs + TaggedRefs;
                        }
                        currentReference = refId + "<SubRef>" + TaggedRefs + "</SubRef>";
                        if (Regex.IsMatch(currentReference, "<subid>[^!=]*</subid>[^!=]*<Journal>", RegexOptions.IgnoreCase) == true)
                        {
                            currentReference = Regex.Replace(currentReference, "<subid>([^!=]*)</subid>([^!=]*)<Journal>", "<JournalSubRef>$1</JournalSubRef>$2");
                            currentReference = currentReference.Replace("</Journal>", "");
                        }
                        if (Regex.IsMatch(currentReference, "<subid>[^!=]*</subid>[^!=]*<Other>", RegexOptions.IgnoreCase) == true)
                        {
                            currentReference = Regex.Replace(currentReference, "<subid>([^!=]*)</subid>([^!=]*)<Other>", "<OtherSubRef>$1</OtherSubRef>$2");
                            currentReference = currentReference.Replace("</Other>", "");
                        }
                    }
                    else
                        currentReference = refId + IdentifyElements(currentReference, seqid, refMod.APIOrder);
                    refMod.taggedReferences.SetValue("<bib-reference id=\"" + seqid + "\">" + currentReference + "</bib-reference>",refMod.curRefProcessing);
                // } // lock
            }
            //return ""; //"<bib-reference id=""" & seqid & """>" & currentReference & "</bib-reference>"
        }
        public string IdentifyElements(string currentReference, string seqid, string API)
        {
            Match pMat;
            Hashtable au = new Hashtable();
            eAug = "";
            eYear = "";
            eSubtitle = "";
            eMainTitle = "";
            eSeries = "";
            eAbbrTtl = "";
            eVol = "";
            eIssue = "";
            eDoi = "";
            eFpage = "";
            eLpage = "";
            eLoc = "";
            epubid = "";
            etal = "";
            eEdg = "";
            ePname = "";
            ePloc = "";
            eEdn = "";
            eFnm = "";
            acc = "";
            if (au != null)
                au.Clear();
            issn = "";
            if (Regex.Match(currentReference, "DOI([\\s*:?\\s|\\s*:\\s*])(DOI(\\s)?)", RegexOptions.IgnoreCase).Success)
            {
                eDoi = Regex.Match(currentReference, "DOI([\\s*:?\\s|\\s*:\\s*])(DOI(\\s)?)", RegexOptions.IgnoreCase).Groups[2].Value;
                currentReference = Regex.Replace(currentReference, eDoi, "###");
            }
            pMat = Regex.Match(currentReference, "(?<![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž\\/0-9])([\\(\\[]*)(DOI|###:###)([\\s*:?\\s|\\s*:\\s*])(.(/ |[^\\s])*)(?:</bib-reference>)?(?![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž’\\/0-9])", RegexOptions.IgnoreCase);
            if (pMat.Success)
            {
                currentReference = Regex.Replace(currentReference, Regex.Escape(pMat.Groups[0].ToString()), "<doi>" + pMat.Groups[0].ToString() + "</doi>");
                currentReference = Regex.Replace(currentReference, "([\\.\\+\\s,:;'\"]*)</doi>", "</doi>$1");
                if (eDoi != "")
                {
                    currentReference = currentReference.Replace("###", eDoi);
                    eDoi = "";
                }
            }
            else if (Regex.Match(currentReference, "((https?://(www.)?(dx.?)?\\s*)?doi.org/)((/ |[^\\s])*)").Success == true)
                currentReference = Regex.Replace(currentReference, "((https?://(www.)?(dx.?)?\\s*)?doi.org/)((/ |[^\\s])*)", "<doi>$0</doi>");
            else if (Regex.Match(currentReference, "\\b((https?://?)?(doi[:/\\s\\.]*)?10[.][^\\s/]+/[^\\s!=]+)\\b").Success && Regex.Match(currentReference, "\\b((https?://?)?(doi[:/\\s\\.]*)?10[.][^\\s/]+/[^\\s!=]+)\\b").Value.Length > 6)
                currentReference = Regex.Replace(currentReference, "((https?://?)?(doi[:/\\s\\.]*)?10[.][^\\s/]+/[^\\s!=]+)", "<doi>$1</doi>", RegexOptions.IgnoreCase);
            else if (Regex.Match(currentReference, "(10.[0-9]{4}/[Ss](([0-9-]{13,16})|([0-9]{4}-[0-9]{4}\\([0-9]{2}\\)[0-9]{5}-[0-9])))").Success)
                currentReference = Regex.Replace(currentReference, "(10.[0-9]{4}/[Ss](([0-9-]{13,16})|([0-9]{4}-[0-9]{4}\\([0-9]{2}\\)[0-9]{5}-[0-9])))", "<doi>$1</doi>");
            if (Regex.Match(currentReference, "<doi>([^!=]+)</doi>").Success)
            {
                currentReference = currentReference.Replace(".</doi>", "</doi>.");
                eDoi = Regex.Match(currentReference, "<doi>([^!=]+)</doi>").Groups[1].Value;
                currentReference = Regex.Replace(currentReference, "<doi>([^!=]+)</doi>", "<doi></doi>");
            }
            else
                eDoi = "";
            if (Regex.IsMatch(currentReference, "\\(acces(sed)?\\s*[^\\)]*\\)") == true)
            {
                acc = Regex.Match(currentReference, "\\(acces(sed)?\\s*[^\\)]*\\)").Groups[0].Value;
                currentReference = Regex.Replace(currentReference, "\\(acces(sed)?\\s*[^\\)]*\\)", "<acc>");
            }
            if (NewProcess(ref currentReference, seqid, ref au, API) == true)
            {
                if (Regex.IsMatch(currentReference, "<(journal|book|other)>", RegexOptions.IgnoreCase) == false)
                    currentReference = "<Journal>" + currentReference + "</Journal>";
            }
            else
                currentReference = "<Other>" + currentReference + "</Other>";
            try
            {
                XmlDocument xdoc = new XmlDocument();
                xdoc.LoadXml(currentReference.Replace("&", "&amp;"));
            }
            catch
            {
                currentReference = "<Other>" + Regex.Replace(currentReference, "\\</?[^!=>]+\\>", "") + "</Other>";
            }
            return currentReference;
        }
        public MatchCollection getthesubReferences(string Str)
        {
            string strIDs = "";
            int subId = 0;
            MatchCollection subMat;
            try
            {
                MatchCollection temp_subMat = Regex.Matches(Str, "(((\\s*)(((\\(\\))|(\\[\\])))(\\s*))|((\\s*)(([\\(\\[\\{])(<[^>]+>)*([0-9])(<[^>]+>)*([\\)\\]\\}]))(\\s*)))");
                subMat = Regex.Matches(Str, "(?<=[^A-Za-z0-9]|^)(((\\s*)(([\\(\\[\\{])?(<[^>]+>)*([a-z])(<[^>]+>)*([\\)\\]\\}]))(\\s*))|((\\s*)(((\\(\\))|(\\[\\])))(\\s*)))");
                strIDs = "";
                if (temp_subMat.Count>0)
                {
                    if (subMat.Count>0)
                    {
                        if (temp_subMat.Count >= subMat.Count)
                        {
                            strIDs = "";
                            for (subId = 0; subId < temp_subMat.Count; subId++)
                            {
                                strIDs = strIDs + "<ID>" + temp_subMat[subId].Groups[1].ToString().Trim() + "</ID>";
                            }
                            if (CheckforValidSubIDs(strIDs) == true)
                                return temp_subMat;
                            else
                            {
                                strIDs = "";
                                for (subId = 0; subId < temp_subMat.Count; subId++)
                                {
                                    strIDs = strIDs + "<ID>" + subMat[subId].Groups[1].ToString().Trim() + "</ID>";
                                }
                                if (CheckforValidSubIDs(strIDs) == true)
                                    return subMat;
                            }
                        }
                        else
                        {
                            strIDs = "";
                            for (subId = 0; subId < temp_subMat.Count; subId++)
                            {
                                strIDs = strIDs + "<ID>" + subMat[subId].Groups[1].ToString().Trim() + "</ID>";
                            }
                            if (CheckforValidSubIDs(strIDs) == true)
                                return subMat;
                            else
                            {
                                strIDs = "";
                                for (subId = 0; subId < temp_subMat.Count; subId++)
                                {
                                    strIDs = strIDs + "<ID>" + temp_subMat[subId].Groups[1].ToString().Trim() + "</ID>";
                                }
                                if (CheckforValidSubIDs(strIDs) == true)
                                    return temp_subMat;
                            }
                        }
                    }
                }
            }
            catch { }
            return Regex.Matches("abc","123");
        }
        public Boolean CheckforValidSubIDs(string subIDs)
        {
            string Lalpha = "abcdefghijklmnopqrstuvwxyz", Calpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", Numbers = "123456789", idValue = "";
            int tmp = 0;
            MatchCollection validMat = Regex.Matches(subIDs, "<ID>([\\(\\[\\{]+)?([A-Za-z0-9]{1})([\\)\\]\\}]+)</ID>");
            try
            {
                if (validMat.Count > 0)
                {
                    for (tmp = 0; tmp < validMat.Count; tmp++)
                    {
                        idValue = idValue + (validMat[tmp].Groups[2].ToString()).Trim();
                    }
                }
                idValue = Regex.Replace(idValue, "([a-zA-Z])\\1", "$1");
                if (Lalpha.Substring(0, idValue.Length) == idValue)
                    return true;
                else if (Calpha.Substring(0, idValue.Length) == idValue)
                    return true;
                else if (Numbers.Substring(0, idValue.Length) == idValue)
                    return true;
            }
            catch { }
            return false;
        }
        public Boolean NewProcess(ref string currentReference, string seqid, ref Hashtable au,string API)
        {
            string DBDoi = "", refText = "", XmlQueryString = "", oTmp = "";
            SearchAPI.eSummaryResult eSumRes = new SearchAPI.eSummaryResult();
            Boolean retval = false;
            SearchAPI sAPI = new SearchAPI();
            string[] APIPriority = API.Split('|');
            try
            {
                if (eDoi != "")
                {
                    refText = currentReference;
                    DBDoi = eDoi.Replace("#amp;", "&"); //System.Web.HttpUtility.HtmlDecode(eDoi.Replace("#amp;", "&"));
                    DBDoi = Regex.Replace(DBDoi, "(https?://(www.)?(dx.?)?doi.org/)", "", RegexOptions.IgnoreCase);
                    DBDoi = Regex.Replace(DBDoi, "(https?://)?doi[:/\\s\\.]+", "", RegexOptions.IgnoreCase);
                }
                else
                    refText = currentReference;
                if (Regex.IsMatch(refText, "^[^a-z0-9]*<[^!=]+>[^a-z0-9]*$", RegexOptions.IgnoreCase) == true)
                {
                    currentReference = refText.Replace("<", "&lt;").Replace(">", "&gt;");
                    retval = false;
                }
                for (int i = 0; i < APIPriority.Length; i++)
                {
                    if (APIPriority[i].ToLower() == "crossref")
                    {
                        if (sAPI.SearchInCrossref(ref XmlQueryString, DBDoi, refText) == true)
                        {
                            oTmp = GetCrossrefValues(XmlQueryString);
                            ApplyElementsInRef(ref refText, ref au);
                            FillElements(ref refText, ref au);
                            currentReference = refText.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>") + "<cr/>";
                            retval = true;
                            break;
                        }
                    }
                    else if (APIPriority[i].ToLower() == "pubmed")
                    {
                        if (sAPI.Search_in_PubMed(DBDoi, refText, ref eSumRes) == true)
                        {
                            oTmp = GetPubMedValues(eSumRes);
                            ApplyElementsInRef(ref refText, ref au);
                            FillElements(ref refText, ref au);
                            currentReference = refText.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>") + "<pm/>";
                            retval = true;
                            break;
                        }
                    }
                    else if (APIPriority[i].ToLower() == "local")
                    {
                        if (sAPI.Search_in_Local(ref XmlQueryString, DBDoi, refText) == true)
                        {
                            oTmp = GetLocalValues(XmlQueryString);
                            ApplyElementsInRef(ref refText, ref au);
                            FillElements(ref refText, ref au);
                            currentReference = refText.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>") + "<ld/>";
                            if (Regex.IsMatch(currentReference, "<(publisher|editor)>", RegexOptions.IgnoreCase) == true)
                                currentReference = "<Book>" + currentReference + "</Book>";
                            retval = true;
                            break;
                        }
                    }
                    else if (APIPriority[i].ToLower() == "ml")
                    {
                        if (sAPI.Search_in_Grobid(ref XmlQueryString,eDoi, refText.Replace("&", "and"),seqid) == true)
                        {
                            oTmp = GetGrobidValues(XmlQueryString);
                            if (eSubtitle == "" && eMainTitle == "" && eYear == "")
                            {
                                //currentReference = StructureReference(refText.Replace("<doi></doi>", "<doi>" & eDoi & "</doi>"))
                                currentReference = refText;
                                if (Regex.IsMatch(currentReference, "\\<(author|maintitle|subtitle|yr)\\>", RegexOptions.IgnoreCase) == false)
                                    currentReference = "<Other>" + currentReference + "</Other>";
                            }
                            else
                            {
                                ApplyElementsInRef(ref refText, ref au);
                                FillElements(ref refText, ref au);
                                currentReference = refText.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>") + "<ml/>";
                                if (Regex.IsMatch(currentReference, "<(publisher|editor)>", RegexOptions.IgnoreCase) == true)
                                    currentReference = "<Book>" + currentReference + "</Book>";
                            }
                            retval = true;
                            break;
                        }
                    }
                    else if (APIPriority[i].ToLower() == "robo")
                    {
                        if (sAPI.Search_in_Robo(ref XmlQueryString,  refText) == true)
                        {
                            oTmp = XmlQueryString;
                            currentReference = XmlQueryString;
                            currentReference = Regex.Replace(currentReference, "<AuthGrp type=\"([^<>]+)\">", "<AuthGrp>");
                            currentReference = Regex.Replace(currentReference, "<EditGrp type=\"([^<>]+)\">", "<EditGrp>");
                            currentReference =currentReference.Insert(currentReference.LastIndexOf("</"),"<robo/>");
                            retval = true;
                            break;
                        }
                    }
                }
                strOnline = strOnline + "<ref id=\"" + seqid + "\">" + oTmp + "</ref>\n";
            }
            catch(Exception ex)
            {
                currentReference = currentReference.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>");
            }
            return retval;
        }
        public Boolean FillElements(ref string refText, ref Hashtable au)
        {
            string tmp = "";
            try
            {
                if (eEdg != "" || eAug != "")
                    refText = IdentifyingInitialsInReference(refText);
                refText = refText.Replace("<subtitle>", "<subtitle>" + eSubtitle + "</subtitle>");
                refText = refText.Replace("<subtitlel>", "<subtitlel>" + eSubtitle + "</subtitlel>");
                refText = refText.Replace("<subtitler>", "<subtitler>" + eSubtitle + "</subtitler>");
                refText = refText.Replace("<maintitle>", "<maintitle>" + eMainTitle + "</maintitle>");
                refText = refText.Replace("<series>", "<Series>" + eSeries + "</Series>");
                refText = refText.Replace("<year>", "<yr>" + eYear + "</yr>");
                refText = refText.Replace("<vol>", "<vol>" + eVol + "</vol>");
                refText = refText.Replace("<issue>", "<issue>" + eIssue + "</issue>");
                refText = refText.Replace("<eloc>", "<Elocation-id>" + eLoc + "</Elocation-id>");
                if (refText.IndexOf("</fpage>", 0) < 0)
                {
                    refText = refText.Replace("<fpage>", "<fpage>" + eFpage + "</fpage>");
                    refText = refText.Replace("<lpage>", "<lpage>" + eLpage + "</lpage>");
                }
                refText = refText.Replace("<etal>", "<et-al>" + etal + "</et-al>");
                refText = refText.Replace("<publisher>", "<publisher>" + ePname + "</publisher>");
                refText = refText.Replace("<location>", "<location>" + ePloc + "</location>");
                refText = refText.Replace("<acc>", "<comment>" + acc + "</comment>");
                refText = refText.Replace("<pubid>", "<comment>" + epubid + "</comment>");
                refText = refText.Replace("<issn>", "<issn>" + issn + "</issn>");
                string[] arr = eAug.Split('|');
                MatchCollection pMatch;
                pMatch = Regex.Matches(refText, "<au([0-9]+)>");
                for (int i = 0; i < pMatch.Count; i++)
                {
                    tmp = "";
                    if (au.ContainsKey("au" + pMatch[i].Groups[1].Value) == true)
                        tmp = au["au" + pMatch[i].Groups[1].Value].ToString();
                    refText = refText.Replace("<au" + pMatch[i].Groups[1].Value + ">", "<au>" + tmp + "</au>");
                }
                refText = Regex.Replace(refText, "([Tt]he\\s)(<au[0-9]*>)", "$2$1");
                refText = Regex.Replace(refText, "([,\\s]*)([A-Z]+)</in><au>(['’])", "</in>$1<au>$2$3");
                refText = refText.Replace("<in></in>", "");
                if (eEdg != "")
                {
                    arr = eEdg.Split('|');
                    pMatch = Regex.Matches(refText, "<eau([0-9]+)>");
                    for (int i = 0; i < pMatch.Count; i++)
                    {
                        refText = refText.Replace("<eau" + pMatch[i].Groups[1].Value + ">", "<eau>" + arr[int.Parse(pMatch[i].Groups[1].Value)] + "</eau>");
                    }
                    if (refText.IndexOf("<eau>", 0) >= 0 || refText.IndexOf("<publisher>", 0) >= 0)
                    {
                        MatchCollection eKwd = Regex.Matches(refText, "(?<![à-ža-zÀ-ŽA-Z])\\(?([V|v]ol.?|[S|s]eries.?)?\\s*([e|E]d(?:itor)?s?|([c|C])oord\\.|([T|t])rans(lators?|lated?)\\.?\\+?)\\.?\\+?\\)?(?![à-ža-zÀ-ŽA-Z>])");
                        if (eKwd.Count > 0)
                        {
                            refText = TaggingContents(refText, "edkw", eKwd[0].Groups[0].ToString(), eKwd[0].Groups[0].Index);
                            refText = Regex.Replace(refText, "</edkw>(\\s+[bB]y)(?![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž’\\/0-9])", "$1</edkw>");
                        }
                        eKwd = Regex.Matches(refText, "(?<![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Z0-9])((\\s*(</?in?>)*\\b\\s*[iI]n[\\.:]\\s*(</?in?>)?\\s+)|(\\s*(</?in?>)*\\b\\s*[iI]n\\s*(</?in?>)?[\\.:]\\s+))(?=[\\<ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z])", RegexOptions.Singleline);
                        if (eKwd.Count > 0)
                            refText = TaggingContents(refText, "inkw", eKwd[0].Groups[0].ToString(), eKwd[0].Groups[0].Index);
                    }
                }
                if (Regex.IsMatch(refText, "((Available|Retrieved) (from|at):?\\s?)\\<?https?://(www.)?[^ ]+", RegexOptions.IgnoreCase) == true)
                {
                    refText = Regex.Replace(refText, "((Available|Retrieved) (from|at):?\\s?)(\\<?https?://(www.)?[^ ]+)", "<comment>$1</comment><e-link>$4</e-link>", RegexOptions.IgnoreCase);
                    refText = refText.Replace("<doi></doi></e-link>", "</e-link><doi></doi>");
                    refText = refText.Replace("<e-link><", "<e-link>#lt;").Replace("></e-link>", "#gt;</e-link>");
                }
                else if (Regex.IsMatch(refText, "\\<?https?://(www.)?[^ ]+", RegexOptions.IgnoreCase) == true)
                {
                    refText = Regex.Replace(refText, "(\\<?https?://(www.)?[^ ]+)", "<e-link>$1</e-link>", RegexOptions.IgnoreCase);
                    refText = refText.Replace("<doi></doi></e-link>", "</e-link><doi></doi>");
                    //refText = refText.Replace("<e-link><", "<e-link>#lt;").Replace("></e-link>", "#gt;</e-link>");
                }
                else if (Regex.IsMatch(refText, "s?ftp://[^ ]+", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(s?ftp://[^ ]+)", "<e-link>$1</e-link>", RegexOptions.IgnoreCase);
                else if (Regex.IsMatch(refText, "Available (from|at):?\\s?file:[^\\.]+\\.[^\\s]+", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(Available (from|at):?\\s?)(file:[^\\.]+\\.[^\\s]+)", "<comment>$1</comment><e-link>$3</e-link>", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "Available (from|at):?\\s?<doi>", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(Available (from|at):?\\s?)(<doi>)", "<comment>$1</comment><doi>", RegexOptions.IgnoreCase);
                refText = refText.Replace("<doi></doi>", "<doi>" + eDoi + "</doi>");
                refText = refText.Replace("</au> <au>", " ").Replace("</eau> <eau>", " ");
                int pos = refText.IndexOf("<e-link>", 0);
                if(pos>=0)
                {
                    tmp = refText.Substring(pos + 8);
                    if(tmp.IndexOf("</e-link>",0)>=0)
                    {
                        tmp = tmp.Substring(0, tmp.IndexOf("</e-link>", 0));
                        string tmp1 = tmp;
                         if (tmp1.StartsWith("<") == true)
                            tmp1 = "#lt;"+tmp1.Substring(1);
                       tmp1 = Regex.Replace(tmp1, "</?[^<>/]+>", "");
                        if (tmp1.EndsWith(">") == true)
                            tmp1 = tmp1.Substring(0, tmp1.Length - 1) + "#gt;";
                        tmp1 = tmp1.Replace("<", "#lt;").Replace(">", "#gt;");
                        refText = refText.Replace(tmp, tmp1);
                        refText = refText.Replace(".</e-link>", "</e-link>.");
                    }
                }
                if (refText.IndexOf("<eau>", 0) >= 0)
                    refText = MarkEditorGroup(refText);
                refText = MarkAuthorGroup(refText);
                refText = IdentifyLeftEle(refText);
                refText = IdentifyLeftText(refText);
            }
            catch { }
            return true;
        }
        public string IdentifyLeftEle(string refText)
        {
            string tmp = "";
            try
            {
                if (Regex.IsMatch(refText, "</(maintitle|subtitle)>\\s*[\\[\\(][A-Zo]+(\\s?[A-Za-z0-9,\\.:;\\s]+)*[\\)\\]]") == true)
                    refText = Regex.Replace(refText, "(</(maintitle|subtitle)>)(\\s*[\\[\\(][A-Zo]+(\\s?[A-Za-z0-9,\\.:;\\s]+)*[\\)\\]])", "$3$1");
                if (Regex.IsMatch(refText, "[\\[\\(]</maintitle>\\s*[A-Z]+(\\s?[A-Z0-9,\\.:;\\s]+)*[\\)\\]]", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "([\\[\\(])</maintitle>(\\s*[A-Z]+(\\s?[A-Z0-9,\\.:;\\s]+)*[\\)\\]])", "$1$2</maintitle>", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "U</maintitle>[\\.\\s]*(S|K)[\\.\\s]*(A[\\.]*)?", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(U)</maintitle>([\\.\\s]*(S|K)[\\.\\s]*(A[\\.]*)?)", "$1$2</maintitle>", RegexOptions.IgnoreCase);
                refText = refText.Replace("</maintitle>)", ")</maintitle>");
                if (Regex.IsMatch(refText, "</maintitle>\\s" + Regex.Replace(eMainTitle, "[-a-z\\s\\.,&\\(\\)\\[\\]]+", "") + "\\b") == true)
                    refText = Regex.Replace(refText, "</maintitle>(\\s" + Regex.Replace(eMainTitle, "[-a-z\\s\\.,&]+", "") + ")\\b", "$1</maintitle>");
                if (Regex.IsMatch(refText, "</maintitle>\\.?\\s?([p|P]art\\s)?[A-Z]\\b") == true)
                    refText = Regex.Replace(refText, "</maintitle>(\\.?\\s?([Pp]art\\s)?[A-Z])\\b", "$1</maintitle>");
                if (Regex.IsMatch(refText, "</subtitle(l|r)?>\\s*\\(in eng(lish)?\\)", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(</subtitle(l|r)?>)(\\s*\\(in eng(lish)?\\))", "$3$1", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "</subtitle(l|r)?>[\\!\\?]+", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(</subtitle(l|r)?>)([\\!\\?]+)", "$3$1", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "(</(in|au)></Author>)(\\s+[a-z]+)[;,]\\s<Author>") == true)
                    refText = Regex.Replace(refText, "(</(in|au)></Author>)(\\s+[a-z]+)([;,]\\s<Author>)", "$3$1$4");
                if (eIssue != "" && eIssue == eVol && refText.IndexOf("<issue>", 0) < 0 && Regex.IsMatch(refText, "</vol> \\(<vol>[0-9]+</vol>\\)") == true)
                    refText = Regex.Replace(refText, "(</vol>\\s*\\()<vol>([0-9]+)</vol>(\\))", "$1<issue>$2</issue>$3");
                if (eIssue != "" && refText.IndexOf("<issue>", 0) < 0)
                    if (Regex.IsMatch(refText, "</vol>\\s*\\([^\\)<>]+\\)") == true)
                        refText = Regex.Replace(refText, "(</vol>\\s*\\()([^\\)<>]+)(\\))", "$1<issue>$2</issue>$3");
                if (eLpage == "" && refText.IndexOf("<fpage>", 0) >= 0 && Regex.IsMatch(refText, "</fpage>\\s*[\\-\\—\\-\\-\\–]\\s*e?[0-9][0-9,]*", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(</fpage>\\s*[\\-\\—\\-\\-\\–]\\s*)(e?[1-9][0-9,]*)(,?)", "$1<lpage>$2</lpage>$3");
                else if (eLpage != "" && refText.IndexOf("<lpage>", 0) < 0 && refText.IndexOf("<fpage>", 0) >= 0 && Regex.IsMatch(refText, "</fpage>\\s*[\\-\\—\\-\\-\\–]\\s*e?[1-9][0-9,]*", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(</fpage>\\s*[\\-\\—\\-\\-\\–]\\s*)(e?[1-9][0-9,]*)(,?)", "$1<lpage>$2</lpage>$3");
                else if (eLpage != "" && refText.IndexOf("<lpage>", 0) < 0 && refText.IndexOf("<fpage>", 0) >= 0 && Regex.IsMatch(refText, "\\s*e?[0-9]+\\s*[\\-\\—\\-\\-\\–]\\s*<fpage>", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(e?[0-9]+)(\\s*[\\-\\—\\-\\-\\–]\\s*)<fpage>([^!=]+)</fpage>", "<fpage>$1</fpage>$2<lpage>$3</lpage>");
                if (refText.IndexOf("<fpage>", 0) < 0 && Regex.IsMatch(refText, "</(vol|issue)>[^0-9A-Za-z]*((e|s)?[0-9]+)[\\-\\—\\-\\-\\–]\\s*((e|s)?[0-9]+)", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(</(vol|issue)>[^0-9A-Za-z]*)((e|s)?[0-9]+)([\\-\\—\\-\\-\\–]\\s*)((e|s)?[0-9]+)", "$1<fpage>$3</fpage>$5<lpage>$6</lpage>", RegexOptions.IgnoreCase);
                refText = Regex.Replace(refText, "</maintitle>([,:;\\.\\s]*)<maintitle>", "$1");
                refText = refText.Replace("</maintitle>)", ")</maintitle>");
                refText = refText.Replace("</maintitle>s", "s</maintitle>");
                refText = Regex.Replace(refText, "\\b(issn[\\s:]+)<issn>", "<issn>$1", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "<issue>([^!=]+)</issue> \\(<vol>([^!=]+)</vol>\\)") == true)
                    refText = Regex.Replace(refText, "<issue>([^!=]+)</issue>( \\()<vol>([^!=]+)</vol>(\\))", "<vol>$1</vol>$2<issue>$3</issue>$4");
                if (Regex.IsMatch(refText, "In <maintitle>Proceeding", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(In )<maintitle>Proceeding", "<maintitle>$1Proceeding", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "</publisher>\\s*(press|co|ltd|limited)", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "</publisher>(\\s*(press|co|ltd|limited))", "$1</publisher>", RegexOptions.IgnoreCase);
                refText = Regex.Replace(refText, "([Tt]he\\s)<maintitle>", "<maintitle>$1");
                if (Regex.IsMatch(refText, "In ((<yr>)?" + eYear + "(</yr>)? )?<maintitle>Conference") == true)
                    refText = Regex.Replace(refText, "(In )((<yr>)?(" + eYear + ")(</yr>)?( ))?<maintitle>(Conference)", "<maintitle>$1$4$6$7");
                if (refText.IndexOf("<fpage>", 0) < 0 && Regex.IsMatch(refText, " pp?\\.?\\s?e?[0-9]+", RegexOptions.IgnoreCase))
                {
                    refText = Regex.Replace(refText, "( pp?\\.?\\s?)(e?[0-9]+)([\\-\\—\\-\\-\\–])(e?[0-9]+)?", "$1<fpage>$2</fpage>$3<lpage>$4</lpage>");
                    refText = refText.Replace("<lpage></lpage>", "");
                }
                if (Regex.IsMatch(refText, "( p\\.?p?\\.?\\s?)|(pages?)<fpage>")==true)
                    refText = Regex.Replace(refText, "\\s((p\\.?p?\\.?\\s?)|(pages?\\s?))<fpage>", " <misc>$1</misc><fpage>");
                if (Regex.IsMatch(refText, "\\sV[a-z]*\\.?\\s<vol>", RegexOptions.IgnoreCase))
                    refText = Regex.Replace(refText, "\\s(V[a-z]*\\.?\\s)<vol>", " <vol>$1");
                if (Regex.IsMatch(refText, "[\\s\\(](Issue|suppl|pt)\\.?\\s<issue>", RegexOptions.IgnoreCase))
                    refText = Regex.Replace(refText, "([\\s\\(])((suppl|Issue|pt)\\.?\\s)<issue>", "$1<issue>$2", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "\\(<issue>[^!=]+</issue>\\sissue\\)", RegexOptions.IgnoreCase))
                    refText = Regex.Replace(refText, "(\\(<issue>[^!=]+)</issue>(\\sissue)\\)", "$1$2</issue>)", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "\\s(Jan\\.?(uary)?|Feb\\.?(ruary)?|Mar\\.?(ch)?|Apr\\.?(il)?|May|Jun\\.?e?|Jul\\.?y?|Aug\\.?(ust)?|Sept?\\.?(ember)?|Oct\\.?(ober)?|Nov\\.?(ember)?|Dec\\.?(ember)?)\\s<yr>", RegexOptions.IgnoreCase))
                    refText = Regex.Replace(refText, "\\s(Jan\\.?(uary)?|Feb\\.?(ruary)?|Mar\\.?(ch)?|Apr\\.?(il)?|May|Jun\\.?e?|Jul\\.?y?|Aug\\.?(ust)?|Sept?\\.?(ember)?|Oct\\.?(ober)?|Nov\\.?(ember)?|Dec\\.?(ember)?)\\s<yr>", " <yr>$1 ", RegexOptions.IgnoreCase);
                else if (Regex.IsMatch(refText, "</yr>\\s(Jan\\.?(uary)?|Feb\\.?(ruary)?|Mar\\.?(ch)?|Apr\\.?(il)?|May|Jun\\.?e?|Jul\\.?y?|Aug\\.?(ust)?|Sept?\\.?(ember)?|Oct\\.?(ober)?|Nov\\.?(ember)?|Dec\\.?(ember)?)(\\s[0-3]?[0-9]\\b)?", RegexOptions.IgnoreCase))
                    refText = Regex.Replace(refText, "</yr>\\s((Jan\\.?(uary)?|Feb\\.?(ruary)?|Mar\\.?(ch)?|Apr\\.?(il)?|May|Jun\\.?e?|Jul\\.?y?|Aug\\.?(ust)?|Sept?\\.?(ember)?|Oct\\.?(ober)?|Nov\\.?(ember)?|Dec\\.?(ember)?)(\\s[0-3]?[0-9]\\b)?)", " $1</yr>", RegexOptions.IgnoreCase);
                if (refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<fpage>", 0) > 0 && Regex.Matches(refText, "<yr>").Count == 2 && eYear == eVol)
                {
                    int pos;
                    pos = refText.LastIndexOf("<yr>");
                    if (pos >= 0)
                    {
                        tmp = refText.Substring(pos);
                        refText = refText.Substring(0, pos);
                        tmp = tmp.Replace("<yr>", "<vol>").Replace("</yr>", "</vol>");
                        refText = refText + tmp;
                    }
                }
                if (refText.IndexOf("<issue>", 0) < 0 && Regex.IsMatch(refText, "</vol>\\s?\\([^\\)!=<>]+\\)") == true)
                    refText = Regex.Replace(refText, "(</vol>\\s?\\()([^\\)!=<>]+)\\)", "$1<issue>$2</issue>)");
                if (refText.IndexOf("(<issue>", 0) >= 0 && refText.IndexOf("</issue>)", 0) < 0 && Regex.IsMatch(refText, "</issue>[^\\)!=]+\\)") == true)
                    refText = Regex.Replace(refText, "</issue>([^\\)!=]+)\\)", "$1</issue>)");
                if (Regex.IsMatch(refText, " (and|&)</maintitle>\\s[^\\s,.]+[\\s,.]", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, " (and|&)</maintitle>(\\s[^\\s,.]+)[\\s,.]", " $1$2</maintitle>");
            }
            catch { }
            return refText;
        }
        public string IdentifyLeftText(string refText)
        {
            XmlDocument xdoc = new XmlDocument();
            XmlElement ele;
            XmlNodeList ndl;
            string tmp = "";
            xdoc.PreserveWhitespace = true;
            try
            {
                if (Regex.IsMatch(refText, "http://<doi>") == true)
                    refText = Regex.Replace(refText, "http://<doi>", "<doi>http://");
                xdoc.LoadXml("<ref>" + refText.Replace("&", "&amp;") + "</ref>");
                ndl = xdoc.SelectNodes("//ref/text()");
                for (int i = ndl.Count - 1; i >= 0; i--)
                {
                    tmp = ndl[i].InnerText;
                    if (Regex.IsMatch(tmp.Trim(), "^[^a-z0-9]*In:?$", RegexOptions.IgnoreCase) == true)
                    {
                        ele = xdoc.CreateElement("inkw");
                        ele.InnerXml = tmp;
                        ndl[i].ParentNode.ReplaceChild(ele.Clone(), ndl[i]);
                    }
                    else if (Regex.IsMatch(tmp.Trim(), "^[^a-z0-9]*pp?(ages?)?\\.?\\s?$", RegexOptions.IgnoreCase) == true)
                    {
                        ele = xdoc.CreateElement("misc");
                        ele.InnerXml = tmp;
                        ndl[i].ParentNode.ReplaceChild(ele.Clone(), ndl[i]);
                    }
                    else if (Regex.Replace(tmp, "[^a-z0-9]+", "", RegexOptions.IgnoreCase) != "" && Regex.IsMatch(tmp.Trim(), "^(ra|ps|and)$", RegexOptions.IgnoreCase) == false)
                    {
                        ele = xdoc.CreateElement("unidentified");
                        ele.InnerXml = tmp;
                        ndl[i].ParentNode.ReplaceChild(ele.Clone(), ndl[i]);
                    }
                }
                refText = xdoc.SelectSingleNode("//ref").InnerXml;
                refText = Regex.Replace(refText, "([^a-z0-9\\.]+)</misc>", "</misc>$1", RegexOptions.IgnoreCase);
                refText = Regex.Replace(refText, "([^a-z0-9:]+)</inkw>", "</inkw>$1", RegexOptions.IgnoreCase);
                refText = Regex.Replace(refText, "<(misc|inkw)>([^a-z0-9]+)", "$2<$1>", RegexOptions.IgnoreCase);
                refText = Regex.Replace(refText, "([\\.,\\s]+)</maintitle>", "</maintitle>$1");
                if (refText.IndexOf("<unidentified>", 0) >= 0)
                {
                    refText = Regex.Replace(refText, "<unidentified>([\\-\\—\\-\\-\\–\\(\\)\\.,\\s\\[\\]:;]+)", "$1<unidentified>");
                    refText = Regex.Replace(refText, "([\\-\\—\\-\\-\\–\\(\\)\\.,\\s\\[\\]:;]+)</unidentified>", "</unidentified>$1");
                    if (Regex.IsMatch(refText, "</Author></AuthGrp>[,\\s]+<unidentified>[JS]r</unidentified>\\.?\\s") == true)
                        refText = Regex.Replace(refText, "(</Author></AuthGrp>)([,\\s]+)<unidentified>([JS]r)</unidentified>(\\.?)\\s", "$2<suffix>$3$4</suffix>$1 ");
                    if (Regex.IsMatch(refText, "<unidentified>((To be published)|(Print in)|(in press)|(Accessed|Received))([^!=]*)</unidentified>", RegexOptions.IgnoreCase) == true)
                        refText = Regex.Replace(refText, "<unidentified>((To be published)|(Print in)|(in press)|(Accessed|Received))([^!=]*)</unidentified>", "<comment>$1$6</comment>", RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(refText, "<unidentified>[^!=]+</unidentified>:\\s?<subtitle>") == true)
                        refText = Regex.Replace(refText, "<unidentified>([^!=]+)</unidentified>(:\\s?)(<subtitle>)", "$3$1$2");
                    if (Regex.IsMatch(refText, "<unidentified>(e-?pub|online) ahead of print\\s*[^!=]+</unidentified>", RegexOptions.IgnoreCase) == true)
                        refText = Regex.Replace(refText, "<unidentified>((e-?pub|online) ahead of print\\s*[^!=]+)</unidentified>", "<comment>$1</comment>", RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(refText, "<unidentified>e[-0-9]+</unidentified>") == true)
                        refText = Regex.Replace(refText, "<unidentified>(e[-0-9]+)</unidentified>", "<Elocation-id>$1</Elocation-id>");
                    if (Regex.IsMatch(refText, "<unidentified>(epub|cited|Published)\\s[^!=]+</unidentified>", RegexOptions.IgnoreCase) == true)
                        refText = Regex.Replace(refText, "<unidentified>((epub|cited|Published)\\s[^!=]+)</unidentified>", "<comment>$1</comment>", RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(refText, "<unidentified>[^!=]+</unidentified>[^0-9A-Za-z]*<subtitler>") == true)
                        refText = Regex.Replace(refText, "<unidentified>([^!=]+)</unidentified>([^0-9A-Za-z]*)<subtitler>", "<subtitler>$1$2");
                    if (Regex.IsMatch(refText, "</subtitlel>[^0-9A-Za-z]*<unidentified>[^!=]+</unidentified>") == true)
                        refText = Regex.Replace(refText, "</subtitlel>([^0-9A-Za-z]*)<unidentified>([^!=]+)</unidentified>", "$1$2</subtitlel>");
                    if (refText.IndexOf("<yr>", 0) < 0)
                    {
                        xdoc.LoadXml("<ref>" + refText + "</ref>");
                        ndl = xdoc.SelectNodes("//unidentified");
                        for (int i = 0; i < ndl.Count; i++)
                        {
                            tmp = ndl[i].InnerText.Replace("in press", "");
                            tmp = Regex.Replace(tmp, "^[^a-z0-9]+", "", RegexOptions.IgnoreCase);
                            tmp = Regex.Replace(tmp, "[^a-z0-9]+$", "", RegexOptions.IgnoreCase);
                            if ((tmp.Length == 4 || tmp.Length == 5) && Regex.IsMatch(tmp, "^[1-2][0-9]{3}[a-z]?$") == true)
                            {
                                ele = xdoc.CreateElement("yr");
                                ele.InnerXml = ndl[i].InnerText;
                                ndl[i].ParentNode.ReplaceChild(ele.Clone(), ndl[i]);
                                break;
                            }
                            else if (Regex.IsMatch(tmp, "\\b[1-2][0-9]{3}[a-z]?$") == true && eDoi != "")
                            {
                                tmp = ndl[i].InnerText;
                                if (Regex.IsMatch(eDoi, Regex.Match(tmp, "\\b([1-2][0-9]{3}[a-z]?)$").Groups[1].Value) == true)
                                {
                                    tmp = "<unidentified>" + Regex.Replace(tmp, "(\\s?)\\b([1-2][0-9]{3}[a-z]?)$", "</unidentified>$1<yr>$2</yr>");
                                    ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                    break;
                                }
                            }
                            else if (Regex.IsMatch(ndl[i].InnerText, "^[1-2][0-9]{3}[a-z]?[,:;\\.]+\\s[0-9]+$") == true && refText.IndexOf("<vol>", 0) < 0)
                            {
                                tmp = ndl[i].InnerText;
                                tmp = Regex.Replace(tmp, "^([1-2][0-9]{3}[a-z]?)([,:;\\.]+\\s)([0-9]+)$", "<yr>$1</yr>$2<vol>$3</vol>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                break;
                            }
                        }
                        refText = xdoc.SelectSingleNode("//ref").InnerXml;
                    }
                    if (Regex.IsMatch(refText, "\\s[1-9][0-9]{0,2}\\s\\([0-9]+</unidentified>[\\),\\s:;]+<fpage>") == true && refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<issue>", 0) < 0)
                        refText = Regex.Replace(refText, "\\s([1-9][0-9]{0,2})(\\s?\\()([0-9]+)</unidentified>([\\),\\s:;]+<fpage>)", "</unidentified> <vol>$1</vol>$2<issue>$3</issue>$4");
                    if (Regex.IsMatch(refText, "<unidentified>[1-9][0-9]{0,2}\\s\\([0-9]+</unidentified>[\\),\\s:;]+<fpage>") == true && refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<issue>", 0) < 0)
                        refText = Regex.Replace(refText, "<unidentified>([1-9][0-9]{0,2})(\\s?\\()([0-9]+)</unidentified>([\\),\\s:;]+<fpage>)", "<vol>$1</vol>$2<issue>$3</issue>$4");
                    if (Regex.IsMatch(refText, "\\s[1-9][0-9]{0,2}</unidentified>[,\\s:;]+<fpage>") == true && refText.IndexOf("<vol>", 0) < 0)
                        refText = Regex.Replace(refText, "\\s([1-9][0-9]{0,2})</unidentified>([,\\s:;]+<fpage>)", "</unidentified> <vol>$1</vol>$2");
                    if (refText.IndexOf("<maintitle>", 0) < 0 && eMainTitle != "")
                    {
                        xdoc.LoadXml("<ref>" + refText + "</ref>");
                        ndl = xdoc.SelectNodes("//unidentified");
                        for (int i = 0; i < ndl.Count; i++)
                        {
                            tmp = ndl[i].InnerText;
                            Boolean flg = false;
                            string[] arr = tmp.Split(' ');
                            for (int j = 0; j < arr.Length; j++)
                            {
                                flg = true;
                                if (Regex.IsMatch(eMainTitle, Regex.Escape(arr[j]), RegexOptions.IgnoreCase) == false)
                                {
                                    flg = false;
                                    break;
                                }
                            }
                            if (flg == true)
                            {
                                ele = xdoc.CreateElement("maintitle");
                                ele.InnerXml = tmp;
                                ndl[i].ParentNode.ReplaceChild(ele.Clone(), ndl[i]);
                                break;
                            }
                        }
                        refText = xdoc.SelectSingleNode("//ref").InnerXml;
                    }
                    if (refText.IndexOf("<unidentified>", 0) >= 0 && refText.IndexOf("<yr>", 0) < 0 && refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<fpage>", 0) < 0 && Regex.IsMatch(refText, "([0-9]{4}[a-z]?)[,\\s:;]([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)") == true)
                    {
                        xdoc.LoadXml("<ref>" + refText + "</ref>");
                        ndl = xdoc.SelectNodes("//unidentified");
                        for (int i = 0; i < ndl.Count; i++)
                        {
                            tmp = ndl[i].InnerText;
                            if (Regex.IsMatch(tmp, "([0-9]{4}[a-z]?)([,\\s:;])([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)"))
                            {
                                if (Regex.Match(tmp, "([0-9]{4}[a-z]?)([,\\s:;])([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)").Groups[5].Value != "")
                                    tmp = Regex.Replace(tmp, "([0-9]{4}[a-z]?)([,\\s:;])([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)", "<yr>$1</yr>$2<vol>$3</vol>$4<issue>$5</issue>$6<fpage>$7</fpage>$8<lpage>$9</lpage>");
                                else
                                    tmp = Regex.Replace(tmp, "([0-9]{4}[a-z]?)([,\\s:;])([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)", "<yr>$1</yr>$2<vol>$3</vol>$4$6<fpage>$7</fpage>$8<lpage>$9</lpage>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                //ndl(i).InnerXml = tmp;
                                break;
                            }
                        }
                        refText = xdoc.SelectSingleNode("//ref").InnerXml;
                    }
                    if (refText.IndexOf("<unidentified>", 0) >= 0 && refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<fpage>", 0) < 0 && Regex.IsMatch(refText, "([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)") == true)
                    {
                        xdoc.LoadXml("<ref>" + refText + "</ref>");
                        ndl = xdoc.SelectNodes("//unidentified");
                        for (int i = 0; i < ndl.Count; i++)
                        {
                            tmp = ndl[i].InnerText;
                            if (Regex.IsMatch(tmp, "([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)"))
                            {
                                if (Regex.Match(tmp, "([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)").Groups[3].Value != "")
                                    tmp = Regex.Replace(tmp, "([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)", "<vol>$1</vol>$2<issue>$3</issue>$4<fpage>$5</fpage>$6<lpage>$7</lpage>");
                                else
                                    tmp = Regex.Replace(tmp, "([0-9]+)([,\\s\\(]+)([0-9]+)?([\\),\\s:;]+)([0-9]+)([\\-\\—\\-\\-\\–])([0-9]+)", "<vol>$1</vol>$2$4<fpage>$5</fpage>$6<lpage>$7</lpage>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                //ndl(i).InnerXml = tmp;
                                break;
                            }
                        }
                        refText = xdoc.SelectSingleNode("//ref").InnerXml;
                    }
                    if (refText.IndexOf("<unidentified>", 0) >= 0 && (refText.IndexOf("<vol>", 0) < 0 || refText.IndexOf("<fpage>", 0) < 0))
                    {
                        xdoc.LoadXml("<ref>" + refText + "</ref>");
                        ndl = xdoc.SelectNodes("//unidentified");
                        for (int i = 0; i < ndl.Count; i++)
                        {
                            tmp = ndl[i].InnerText;
                            if (Regex.IsMatch(tmp, "^[0-9]+$"))
                            {
                                if (refText.IndexOf("<vol>", 0) < 0)
                                    tmp = "<vol>" + tmp + "</vol>";
                                else if (refText.IndexOf("<fpage>", 0) < 0)
                                    tmp = "<fpage>" + tmp + "</fpage>";
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                break;
                            }
                            else if (Regex.IsMatch(tmp, "^([A-Z])[0-9]+[\\-\\—\\-\\-\\–]+\\1[0-9]+$"))
                            {
                                tmp = Regex.Replace(tmp, "^(([A-Z])[0-9]+)([\\-\\—\\-\\-\\–]+)(\\2[0-9]+)$", "<fpage>$1</fpage>$3<lpage>$4</lpage>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                break;
                            }
                            else if (Regex.IsMatch(tmp, "^[0-9]+[\\-\\—\\-\\-\\–]+[0-9]+$"))
                            {
                                tmp = Regex.Replace(tmp, "^([0-9]+)([\\-\\—\\-\\-\\–]+)([0-9]+)$", "<fpage>$1</fpage>$2<lpage>$3</lpage>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                                break;
                            }
                            else if (refText.IndexOf("<fpage>", 0) < 0 && refText.IndexOf("<lpage>", 0) < 0 && refText.IndexOf("<eloc>", 0) < 0 && Regex.IsMatch(tmp, "e[0-9]{4,}$") == true)
                            {
                                tmp = "<unidentified>" + Regex.Replace(tmp, "(e[0-9]{4,})$", "</unidentified><Elocation-id>$1</Elocation-id>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                            }
                            else if (refText.IndexOf("<fpage>", 0) < 0 && refText.IndexOf("<vol>", 0) < 0 && refText.IndexOf("<lpage>", 0) < 0 && Regex.IsMatch(tmp, "^([0-9]+)[:\\s,;]+([0-9]+)([\\-\\—\\-\\-\\–]+)([0-9]+)$") == true)
                            {
                                tmp =  Regex.Replace(tmp, "^([0-9]+)([:\\s,;]+)([0-9]+)([\\-\\—\\-\\-\\–]+)([0-9]+)$", "<vol>$1</vol>$2<fpage>$3</fpage>$4<lpage>$5</lpage>");
                                ndl[i].ParentNode.InnerXml = ndl[i].ParentNode.InnerXml.Replace(ndl[i].OuterXml, tmp);
                            }
                        }
                        refText = xdoc.SelectSingleNode("//ref").InnerXml;
                    }
                    if (Regex.IsMatch(refText, "</vol>\\s*\\(<unidentified>[0-9]+</unidentified>\\)[:;,\\s]*<fpage>") == true)
                        refText = Regex.Replace(refText, "(</vol>\\s*\\()<unidentified>([0-9]+)</unidentified>(\\)[:;,\\s]*<fpage>)", "$1<issue>$2</issue>$3");
                    if (Regex.IsMatch(refText, "</vol>\\s*\\(?<unidentified>(suppl\\s*)?[0-9]+</unidentified>\\)?[:;,\\s]*<fpage>", RegexOptions.IgnoreCase) == true)
                        refText = Regex.Replace(refText, "(</vol>\\s*\\(?)<unidentified>((suppl\\s*)?[0-9]+)</unidentified>(\\)?[:;,\\s]*<fpage>)", "$1<issue>$2</issue>$4", RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(refText, "</in>[,\\s\\.\\;]+<unidentified>[^\\s]+</unidentified>[,\\s\\.\\;]+<in>") == true)
                    {
                        refText = Regex.Replace(refText, "(</in>[,\\s\\.\\;]+)<unidentified>([^\\s]+)</unidentified>([,\\s\\.\\;]+<in>)", "$1<au>$2</au>$3");
                        refText = MarkAuthorGroup(refText);
                    }
                    if (refText.IndexOf("<subtitle>", 0) < 0 && refText.IndexOf("<maintitle>", 0) >= 0 && Regex.Matches(refText, "<unidentified>").Count == 1)
                        if (refText.IndexOf("<unidentified>", 0) < refText.IndexOf("<maintitle>", 0))
                            refText = refText.Replace("<unidentified>", "<subtitle>").Replace("</unidentified>", "</subtitle>");
                    if (Regex.Matches(refText, "<unidentified>").Count == 1)
                    {
                        tmp = Regex.Match(refText, "<unidentified>([^!=]+)</unidentified>").Groups[1].Value;
                        if (Regex.IsMatch(tmp, "Consortium$") == true)
                            refText = refText.Replace("<unidentified>" + tmp + "</unidentified>", "<AuthGrp><Author><au>" + tmp + "</au></Author></AuthGrp>");
                        else if (Regex.IsMatch(tmp, "[0-9]") == false)
                        {
                            if (refText.IndexOf("<subtitle>", 0) >= 0 && refText.IndexOf("<maintitle>", 0) < 0)
                                refText = refText.Replace("unidentified>", "maintitle>");
                            else if (refText.IndexOf("<subtitle>", 0) < 0 && refText.IndexOf("<maintitle>", 0) >= 0)
                                refText = refText.Replace("unidentified>", "subtitle>");
                            else if (Regex.IsMatch(refText, "</subtitle>\\s*[\\-:]\\s*<unidentified>[^!=]+</unidentified>[\\.,]\\s+<maintitle>") == true)
                                refText = Regex.Replace(refText, "</subtitle>(\\s*[\\-:]\\s*)<unidentified>([^!=]+)</unidentified>([\\.,]\\s+<maintitle>)", "$1$2</subtitle>$3");
                        }
                    }
                }
                if (refText.IndexOf("<maintitle>", 0) >= 0)
                {
                    xdoc.LoadXml("<ref>" + refText + "</ref>");
                    ndl = xdoc.SelectNodes("//maintitle");
                    for (int i = 0; i < ndl.Count; i++)
                    {
                        tmp = ndl[i].InnerText;
                        if (tmp.IndexOf(".", 0) >= 0 && refText.IndexOf("</maintitle>.", 0) >= 0)
                            refText = refText.Replace("</maintitle>.", ".</maintitle>");
                    }
                }
                if (refText.IndexOf("<e-link>", 0) >= 0)
                {
                    xdoc.LoadXml("<ref>" + refText + "</ref>");
                    ndl = xdoc.SelectNodes("//e-link");
                    for (int i = 0; i < ndl.Count; i++)
                    {
                        tmp = ndl[i].InnerText;
                        tmp = tmp.Replace("<", "&lt;").Replace(">", "&gt;");
                        if (tmp != ndl[i].InnerXml)
                            refText = refText.Replace(ndl[i].InnerXml, tmp);
                    }
                }
                refText = Regex.Replace(refText, "</comment>([\\-\\—\\-\\-\\–\\(\\)\\.,\\s\\[\\]:;]+)", "$1</comment>");
                if (refText.IndexOf("<fpage>") < 0 && Regex.IsMatch(refText, "</vol>[\\-\\—\\-\\-\\–]<issue>") == true)
                    refText = Regex.Replace(refText, "<vol>([^!=]+)</vol>([\\-\\—\\-\\-\\–])<issue>([^!=]+)</issue>", "<fpage>$1</fpage>$2<lpage>$3</lpage>");
                if (refText.IndexOf("<fpage>") < 0 && Regex.IsMatch(refText, "</issue>[\\-\\—\\-\\-\\–]|ra<lpage>") == true)
                    refText = Regex.Replace(refText, "<issue>([^!=]+)</issue>([\\-\\—\\-\\-\\–]|ra)<lpage>", "<fpage>$1</fpage>$2<lpage>");
                if (Regex.IsMatch(refText, "</maintitle>\\s+<unidentified>(of )?the\\s[^!=]+</unidentified>") == true)
                    refText = Regex.Replace(refText, "</maintitle>(\\s+)<unidentified>((of )?the\\s[^!=]+)</unidentified>", "$1$2</maintitle>");
                if (Regex.IsMatch(refText, "</fpage>\\s*\\(<unidentified>[0-9]+pp?</unidentified>\\.\\)") == true)
                    refText = Regex.Replace(refText, "</fpage>(\\s*\\()<unidentified>([0-9]+pp?)</unidentified>(\\.\\))", "$1$2$3</fpage>");
                if (Regex.IsMatch(refText, "</Elocation-id>\\s*\\(<unidentified>[0-9]+pp?</unidentified>\\.\\)") == true)
                    refText = Regex.Replace(refText, "</Elocation-id>(\\s*\\()<unidentified>([0-9]+pp?)</unidentified>(\\.)(\\))", "</Elocation-id>$1<fpage>$2$3</fpage>$4");
                if (refText.IndexOf("</issue>)", 0) < 0 && Regex.IsMatch(refText, "\\(<unidentified>[0-9]+</unidentified>\\)") == true && eIssue != "")
                    refText = Regex.Replace(refText, "\\(<unidentified>([0-9]+)</unidentified>\\)", "(<issue>$1</issue>)");
                refText = refText.Replace("</subtitlel>", "</subtitle>").Replace("<subtitlel>", "<subtitle>");
                refText = refText.Replace("</subtitler>", "</subtitle>").Replace("<subtitler>", "<subtitle>");
                if (Regex.IsMatch(refText, "</subtitle>\\s<unidentified>[a-z]+") == true)
                    refText = Regex.Replace(refText, "</subtitle>(\\s+)<unidentified>([a-z][^!=]+)</unidentified>", "$1$2</subtitle>");
                if (Regex.IsMatch(refText, "</subtitle>\\s?:\\s*<unidentified>") == true)
                    refText = Regex.Replace(refText, "</subtitle>(\\s?:\\s*)<unidentified>([^!=]+)</unidentified>", "$1$2</subtitle>");
                if (Regex.IsMatch(refText, "</maintitle><unidentified>") == true)
                    refText = Regex.Replace(refText, "</maintitle><unidentified>([^!=]+)</unidentified>", "$1</maintitle>");
                if (Regex.IsMatch(refText, "</maintitle>:\\s*<unidentified>") == true)
                    refText = Regex.Replace(refText, "</maintitle>(:\\s*)<unidentified>([^!=]+)</unidentified>", "$1$2</maintitle>");
                refText = refText.Replace("</subtitle>)", ")</subtitle>");
                if (Regex.IsMatch(refText, "</in></Author></AuthGrp> <unidentified>A</unidentified>,") == true)
                    refText = Regex.Replace(refText, "</in></Author></AuthGrp> <unidentified>A</unidentified>,", " A</in></Author></AuthGrp>,");
                if (Regex.IsMatch(refText, "[^\\.]</maintitle><unidentified>[^\\.\\s\\<]+[\\.\\s]",RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "([^\\.])</maintitle><unidentified>([^\\.\\s\\<]+)([\\.\\s]+)", "$1$2</maintitle>$3<unidentified>");
                if (Regex.IsMatch(refText, "[^\\.\\s]+</unidentified>: <publisher>", RegexOptions.IgnoreCase) == true && refText.IndexOf("<location>", 0)<0)
                    refText = Regex.Replace(refText, "([^\\.\\s]+)</unidentified>: <publisher>", "</unidentified><location>$1</location>: <publisher>");
                if (Regex.IsMatch(refText, "</(au|in)></Author>\\s(1st|2nd|3rd|[4-9]th|jr\\.|sr\\.)", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "</(au|in)></Author>\\s(1st|2nd|3rd|[4-9]th|jr\\.|sr\\.)", "</$1> <deg>$2</deg></Author>", RegexOptions.IgnoreCase);
                if (Regex.IsMatch(refText, "((van den)|(van der)|(Van Der)|vander|sainte|(de la)|della|saint|ste.|v.d.|dela|rem|mac|jan|van|ten|ter|thi|sen|st.|den|der|dos|del|dan|das|ben|bin|zum|zur|von|vu|d'|da|de|du|el|il|di|do|te|l'|la|le|mc|o')\\s<au>") ==true)
                    refText = Regex.Replace(refText, "((van den)|(van der)|(Van Der)|vander|sainte|(de la)|della|saint|ste.|v.d.|dela|rem|mac|jan|van|ten|ter|thi|sen|st.|den|der|dos|del|dan|das|ben|bin|zum|zur|von|vu|d'|da|de|du|el|il|di|do|te|l'|la|le|mc|o')\\s<au>","<au>$1 ");
            }
            catch { }
            return refText;
        }
        public string MarkEditorGroup(string wholeString)
        {
            int pos = 0;
            string tmp = "";
            if (Regex.IsMatch(wholeString, "</EditGrp>") == true)
                return wholeString;
            if (Regex.IsMatch(wholeString, "(</eau>[,\\s]+)([A-Z][a-z]+\\.)(\\s<eau>)") == true)
                wholeString = Regex.Replace(wholeString, "(</eau>[,\\s]+)([A-Z][a-z]+\\.)(\\s<eau>)", "$1<in>$2</in>$3");
            if (Regex.Matches(wholeString, "<eau>").Count >= 0)
            {
                pos = wholeString.LastIndexOf("</edkw>");
                if (pos >= 0)
                    wholeString = wholeString.Insert(pos + 7, "</EditGrp>");
                else
                {
                    pos = wholeString.LastIndexOf("</in>");
                    wholeString = wholeString.Insert(pos + 5, "</EditGrp>");
                }
                pos = wholeString.IndexOf("<eau>", 0);
                if (pos >= 0)
                {
                    wholeString = wholeString.Insert(pos, "<EditGrp>");
                    tmp = wholeString.Substring(pos);
                    wholeString = wholeString.Substring(0, pos);
                    tmp = tmp.Replace("<in>", "<ein>").Replace("</in>", "</ein>");
                    wholeString = wholeString + MarkingEditor(tmp);
                }
                return wholeString;
            }
            return wholeString;
        }
        public string MarkAuthorGroup(string wholeString)
        {
            int pos = 0;
            string tmp = "";
            if (Regex.IsMatch(wholeString, "</AuthGrp>") == true)
                return wholeString;
            wholeString = Regex.Replace(wholeString, "<in>([^!=]+)</in><au>([^!=]+</au>)", "<au>$1$2");
            if (Regex.IsMatch(wholeString, "</in>\\s*(&|and),?\\s*[A-Z][a-z'’]+(\\s[A-Z][a-z'’]+)*[\\s,]+<in>") == true)
                wholeString = Regex.Replace(wholeString, "(</in>\\s*(&|and),?\\s*)([A-Z][a-z'’]+)((\\s[A-Z][a-z'’]+)*)([\\s,]+<in>)", "$1<au>$3$4</au>$6");
            if (Regex.IsMatch(wholeString, "</au>\\s[A-Z]+[a-z]+[A-Z]+[a-z]*,\\s<au>", RegexOptions.IgnoreCase) == true)
                wholeString = Regex.Replace(wholeString, "(</au>\\s)([A-Z]+[a-z]+[A-Z]+[a-z]*)(,\\s<au>)", "$1<in>$2</in>$3");
            if (Regex.IsMatch(wholeString, "</au>,\\s+<au>[^!=]+</au>\\.<in>") == true)
                wholeString = Regex.Replace(wholeString, "(</au>,\\s+)<au>([^!=]+)</au>\\.<in>", "$1<in>$2.");
            if (Regex.IsMatch(wholeString, "[A-Z][a-zA-Z]*\\-<au>") == true)
                wholeString = Regex.Replace(wholeString, "([A-Z][a-zA-Z]*\\-)<au>", "<au>$1");
            if (Regex.IsMatch(wholeString, ",\\s<au>[^<>]+</au>-[^<>\\s]+\\s<au>") == true)
                wholeString = Regex.Replace(wholeString, "(,\\s)<au>([^<>]+)</au>(-[^<>\\s]+)(\\s<au>)", "$1<in>$2$3</in>$4");
            if (Regex.IsMatch(wholeString, "^<au>[^<>]+</au>-[^<>\\s]+\\s<au>") == true)
                wholeString = Regex.Replace(wholeString, "^<au>([^<>]+)</au>(-[^<>\\s]+)(\\s<au>)", "<in>$1$2</in>$3");
            if (Regex.IsMatch(wholeString, "</in>\\s<au>[^<>]+</au>,\\s<au>[^<>\\s]+\\s+[^<>]+</au>,\\s<in>") == true)
                wholeString = Regex.Replace( wholeString, "(</in>\\s<au>[^<>]+</au>,\\s)<au>([^<>\\s]+)\\s+([^<>]+)(</au>,\\s<in>)", "$1<in>$2</in> <au>$3$4");
            if (Regex.IsMatch(wholeString, ", <au>[^<>]+</au>-<in>[^<>]+</in> <au>") == true)
                wholeString = Regex.Replace(wholeString, ", <au>([^<>]+)</au>-<in>([^<>]+</in> <au>)", ", <in>$1-$2");
            wholeString = wholeString.Replace("<in>URL</in>", "URL");
            if (Regex.Matches(wholeString, "(\\<(au|in)\\>)", RegexOptions.IgnoreCase).Count == 1)
            {
                if (wholeString.IndexOf("<au>", 0) >= 0)
                {
                    tmp = Regex.Match(wholeString, "<au>([^!=]+)</au>").Groups[1].Value;
                    if (tmp.ToLower().IndexOf("consortium", 0) >= 0)
                        wholeString = wholeString.Replace("</au>", "</au><in></in>");
                    else if (tmp.IndexOf(" ", 0) >= 0 && tmp.Contains(",") && tmp.Split(' ').Length == 2)
                        wholeString = Regex.Replace(wholeString, "<au>([^!=\\s]+)([,\\s])([^!=]+)</au>", "<au>$1</au>$2<in>$3</in>");
                    else if (tmp.IndexOf(" ", 0) >= 0)
                        wholeString = wholeString.Replace("</au>", "</au><in></in>");
                }
                else
                {
                    if (Regex.IsMatch(wholeString, "^[A-Z][a-z][A-Za-z]*[,\\s]+<in>") == true)
                        wholeString = Regex.Replace(wholeString, "^([A-Z][a-z][A-Za-z]*)([,\\s]+<in>)", "<au>$1</au>$2");
                    else
                        wholeString = Regex.Replace(wholeString, "(</?(au|in)>)", "");
                }
            }
            if (Regex.IsMatch(wholeString, "(</au>[,\\s]+)([A-Z][a-z]+\\.)(\\s<au>)") == true)
                wholeString = Regex.Replace(wholeString, "(</au>[,\\s]+)([A-Z][a-z]+\\.)(\\s<au>)", "$1<in>$2</in>$3");
            if (Regex.IsMatch(wholeString, "(</in>[,\\s]+[A-Z][^\\s,]+[,\\s]+<in>)") == true)
                wholeString = Regex.Replace(wholeString, "(</in>[,\\s]+)([A-Z][^\\s,]+)([,\\s]+<in>)", "$1<au>$2</au>$3");
            if (wholeString.IndexOf("<et-al>", 0) >= 0 && (wholeString.LastIndexOf("<au>") > wholeString.IndexOf("<et-al>", 0) || wholeString.LastIndexOf("<in>") > wholeString.IndexOf("<et-al>", 0)))
            {
                tmp = wholeString.Substring(wholeString.IndexOf("<et-al>", 0));
                tmp = tmp.Replace("<in>", "").Replace("</in>", "");
                tmp = tmp.Replace("<au>", "").Replace("</au>", "");
                wholeString = wholeString.Substring(0, wholeString.IndexOf("<et-al>", 0));
                wholeString = wholeString + tmp;
            }
            else if (wholeString.IndexOf("<subtitle", 0) >= 0 && (wholeString.LastIndexOf("<au>") > wholeString.IndexOf("<subtitle", 0) || wholeString.LastIndexOf("<in>") > wholeString.IndexOf("<subtitle", 0)))
            {
                tmp = wholeString.Substring(wholeString.IndexOf("<subtitle", 0));
                tmp = tmp.Replace("<in>", "").Replace("</in>", "");
                tmp = tmp.Replace("<au>", "").Replace("</au>", "");
                wholeString = wholeString.Substring(0, wholeString.IndexOf("<subtitle", 0));
                wholeString = wholeString + tmp;
            }
            if (Regex.Matches(wholeString, "<au>").Count < Regex.Matches(wholeString, "<in>").Count && wholeString.IndexOf("<maintitle>", 0) < 0 && wholeString.IndexOf("<subtitle", 0) > 0)
            {
                tmp = wholeString.Substring(wholeString.IndexOf("<subtitle", 0));
                tmp = tmp.Replace("<in>", "").Replace("</in>", "");
                wholeString = wholeString.Substring(0, wholeString.IndexOf("<subtitle", 0));
                wholeString = wholeString + tmp;
            }
            else if (Regex.Matches(wholeString, "<au>").Count < Regex.Matches(wholeString, "<in>").Count && (wholeString.IndexOf("<maintitle>", 0) < wholeString.LastIndexOf("<in>") || wholeString.IndexOf("<subtitle", 0) < wholeString.LastIndexOf("<in>")))
            {
                pos = wholeString.IndexOf("<maintitle>", 0);
                if (pos < 0)
                    pos = wholeString.IndexOf("<subtitle", 0);
                if (pos < 0)
                    pos = wholeString.IndexOf("<yr>", 0);
                if (pos >= 0)
                {
                    tmp = wholeString.Substring(pos);
                    tmp = tmp.Replace("<in>", "").Replace("</in>", "");
                    wholeString = wholeString.Substring(0, pos);
                    wholeString = wholeString + tmp;
                }
                else
                {
                    pos = wholeString.LastIndexOf("</in>");
                    if (pos >= 0)
                        wholeString = wholeString.Remove(pos, 5);
                    pos = wholeString.LastIndexOf("<in>");
                    if (pos >= 0)
                        wholeString = wholeString.Remove(pos, 4);
                }
            }
            if (Regex.Matches(wholeString, "<au>").Count + 1 == Regex.Matches(wholeString, "<in>").Count && wholeString.IndexOf("</et-al>") < 0)
            {
                if (Regex.IsMatch(wholeString, "^[A-Z][a-z][A-Za-z]*[,\\s]+<in>") == true)
                    wholeString = Regex.Replace(wholeString, "^([A-Z][a-z][A-Za-z]*)([,\\s]+<in>)", "<au>$1</au>$2");
                else
                {
                    wholeString = wholeString.Remove(wholeString.LastIndexOf("</in>"), 5);
                    wholeString = wholeString.Remove(wholeString.LastIndexOf("<in>"), 4);
                }
            }
            if (Regex.Matches(wholeString, "<au>").Count  == Regex.Matches(wholeString, "<in>").Count + 1 && wholeString.IndexOf("</et-al>") < 0)
            {
                if (Regex.IsMatch(wholeString, "</au>, <au>") == true)
                    wholeString = Regex.Replace(wholeString, "</au>, <au>", "</au><in></in>, <au>");
            }
            if (Regex.Matches(wholeString, "<au>").Count == Regex.Matches(wholeString, "<in>").Count && Regex.Matches(wholeString, "<in>").Count > 0)
            {
                wholeString = MarkingAuthor(wholeString);
                pos = wholeString.LastIndexOf("</et-al>");
                if (pos >= 0)
                    wholeString = wholeString.Insert(pos + 8, "</AuthGrp>");
                else
                {
                    if (pos < 0)
                    {
                        pos = wholeString.LastIndexOf("</Author>");
                        wholeString = wholeString.Insert(pos + 9, "</AuthGrp>");
                    }
                }
                if (pos > 0)
                {
                    pos = wholeString.IndexOf("<Author>", 0);
                    if (pos >= 0)
                        wholeString = wholeString.Insert(pos, "<AuthGrp>");
                }
                return wholeString.Replace("<in></in>", "");
            }
            else if (wholeString.IndexOf("</et-al>") >= 0)
            {
                wholeString = MarkingAuthor(wholeString);
                pos = wholeString.LastIndexOf("</et-al>");
                if (pos >= 0)
                {
                    wholeString = wholeString.Insert(pos + 8, "</AuthGrp>");
                    pos = Regex.Match(wholeString, "<(in|Author|au)>").Index;
                    if (pos >= 0)
                        wholeString = wholeString.Insert(pos, "<AuthGrp>");
                }
                return wholeString.Replace("<in></in>", "");
            }
            return wholeString;
        }
        public string IdentifyingInitialsInReference(string str)
        {
            int j;
            string AuthorInitials = "(?<![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞLŠŸŽ\\-A-Za-zà-ž0-9])([R?ÀÁÂÃÄÅÆÇSÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞŠŸŽZLßIA-ZΑ-Χ][ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝLÞŠŸŽ\\-A-Z’Α-Χ\\.\\s\\-\\—\\-\\-\\–]*)(?![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞLŠŸŽ\\-A-Za-zà-ž’\\/0-9])";
            MatchCollection matInitial = Regex.Matches(str, AuthorInitials, RegexOptions.Singleline);
            if (matInitial.Count > 0)
            {
                for (j = matInitial.Count - 1; j >= 0; j--)
                {
                    string cleanInitials = matInitial[j].Groups[0].ToString();
                    cleanInitials = Regex.Replace(cleanInitials, "([.,\\s><\\/ib]+)", "");
                    if (cleanInitials.Length > 4)
                    {
                        string InitialCk = matInitial[j].Groups[0].ToString();
                        MatchCollection matInit = Regex.Matches(InitialCk.ToString(), "([R?ÀÁÂÃÄÅÆÇSÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽZßIA-Z]+)([\\.\\-|\\.|\\.\\s|\\.,\\s?]+)", RegexOptions.Singleline);
                        if (matInit.Count > 1)
                        {
                            foreach (Match InTst in matInit)
                            {
                                InitialCk = Regex.Replace(InitialCk.ToString(), Regex.Escape(InTst.Groups[0].ToString()), "<in>" + InTst.Groups[0].ToString() + "</in>");
                            }
                            str = Regex.Replace(str.ToString(), Regex.Escape(matInitial[j].Groups[0].ToString()), InitialCk.ToString());
                        }
                        else if (matInit.Count == 1)
                        {
                            InitialCk = Regex.Replace(InitialCk.ToString(), Regex.Escape(matInit[0].Groups[0].ToString()), "<in>" + matInit[0].Groups[0].ToString() + "</in>");
                            str = Regex.Replace(str.ToString(), Regex.Escape(matInitial[j].Groups[0].ToString()), InitialCk.ToString());
                        }
                    }
                    else if (cleanInitials.Length <= 4)
                    {
                        if (!(Regex.IsMatch(str.ToString(), Regex.Escape(matInitial[j].Groups[0].ToString()) + "([\\.\\-,\\+][0-9])", RegexOptions.Singleline)))
                        {
                            if (Regex.Matches(Regex.Escape(matInitial[j].Groups[0].ToString()), "([\\.])", RegexOptions.Singleline).Count >= 1 &&
                           Regex.Matches(Regex.Escape(matInitial[j].Groups[0].ToString()), "([\\-])", RegexOptions.Singleline).Count == 0 &&
                           matInitial[j].Groups[0].ToString().Substring(matInitial[j].Groups[0].ToString().Length - 1) == "A")
                                str = TaggingContents(str, "in", matInitial[j].Groups[0].ToString(), matInitial[j].Groups[0].Index - 1);
                            else
                                str = TaggingContents(str, "in", matInitial[j].Groups[0].ToString(), matInitial[j].Groups[0].Index);
                        }
                    }
                }
                eFnm = Regex.Replace(eFnm, "\\|[A-Z\\.]+\\|([A-Z\\.]+\\|)?", "|");
                eFnm = Regex.Replace(eFnm, "\\|[A-Z\\.]+\\|([A-Z\\.]+\\|)?", "|");
                eFnm = Regex.Replace(eFnm, "\\|[A-Z]\\.?$", "", RegexOptions.IgnoreCase);
                eFnm = Regex.Replace(eFnm, "^[A-Z]\\.?\\|", "");
                eFnm = Regex.Replace(eFnm, "\\|[A-Z]\\|", "|", RegexOptions.IgnoreCase);
                eFnm = eFnm.Trim('|');
                string[] arr = eFnm.Split('|');
                SortArray(ref arr);
                eFnm = string.Join("|", arr);
                if (eFnm != "")
                {
                    matInitial = Regex.Matches(str, eFnm.Trim('|'), RegexOptions.Singleline);
                    if (matInitial.Count > 0)
                        for (j = matInitial.Count - 1; j >= 0; j--)
                        {
                            str = TaggingContents(str, "in", matInitial[j].Groups[0].ToString(), matInitial[j].Groups[0].Index);
                        }
                }
            }
            else if (matInitial.Count == 0)
            {
                eFnm = Regex.Replace(eFnm, "\\|[A-Z]\\.?\\|([A-Z]\\.?\\|)?", "|");
                eFnm = Regex.Replace(eFnm, "\\|[A-Z]\\.?$", "", RegexOptions.IgnoreCase);
                eFnm = Regex.Replace(eFnm, "^[A-Z]\\.?\\|", "");
                eFnm = Regex.Replace(eFnm, "\\|[A-Z]\\|", "|", RegexOptions.IgnoreCase);
                eFnm = eFnm.Replace("‐", "-").Trim('|');
                string[] arr = eFnm.Split('|');
                SortArray(ref arr);
                eFnm = string.Join("|", arr);
                if (eFnm != "")
                {
                    matInitial = Regex.Matches(str, "(\\b" + eFnm.Trim('|')+"\\b)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                    if (matInitial.Count > 0)
                        for (j = matInitial.Count-1; j >=0; j--)
                        {
                            str = TaggingContents(str, "in", matInitial[j].Groups[0].ToString(), matInitial[j].Groups[0].Index);
                        }
                }
            }
            if (Regex.IsMatch(str, "^<in>[A-Z][A-Za-z]+</in>, <in>") == true)
                str = Regex.Replace(str, "^<in>([A-Z][A-Za-z]+)</in>(, <in>)", "<au>$1</au>$2");
            if (Regex.IsMatch(str, "\\.</in>[A-Z],") == true)
                str = Regex.Replace(str, "(\\.)</in>([A-Z]),", "$1$2</in>,");
            if (Regex.IsMatch(str, "<in>[^!=]+</in>\\.[A-Z][A-Za-z]*\\.") == true)
                str = Regex.Replace(str, "(<in>[^!=]+)</in>(\\.[A-Z][A-Za-z]*\\.)", "$1$2</in>");
            MatchCollection IntRechk = Regex.Matches(str.ToString(), "(?<![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9])([R?ÀÁÂÃÄÅÆÇSÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽZßIA-Z])([\\+\\-|\\.\\-|\\.|\\.\\s|\\+\\s|\\.,\\s?|\\+,\\s?]+)([a-z])([\\+\\-|\\.\\-|\\.|\\.\\s|\\+\\s|\\.,\\s?|\\+,\\s?]+)(\\s)(?![ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž’\\/0-9])", RegexOptions.Singleline);
            if (IntRechk.Count > 0)
                foreach (Match irk in IntRechk)
                {
                    str = Regex.Replace(str.ToString(), Regex.Escape(irk.Groups[0].ToString()), "<in>" + irk.Groups[1].ToString() + irk.Groups[2].ToString() + irk.Groups[3].ToString() + "</in>" + irk.Groups[4].ToString() + irk.Groups[5].ToString(), RegexOptions.Singleline);
                }
            if (Regex.IsMatch(str, "<au[0-9]+>,?\\sCh\\.,\\s*<au[0-9]>") == true)
                str = Regex.Replace(str, "(<au[0-9]+>,?\\s)(Ch\\.)(,?\\s*<au[0-9]>)", "$1<in>$2</in>$3");
            //Str = Regex.Replace(Str, "</in>-<in>", "-");
            //str = Regex.Replace(str, "([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9])<in>([^!=]*)</in>", "$1$2");
            //str = Regex.Replace(str, "<i><in>([A-Z\\.\\s]+)</in>([,\\s\\.;:]+)([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+)", "<i>$1$2$3");
            str = Regex.Replace(str, "<in>([A-Z\\.\\s]+[\\-\\—\\-\\-\\–]\\s*)</in>([,\\s\\.;:]+)([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Za-zà-ž0-9]+)", "$1$2$3");
            str = Regex.Replace(str, "(<in>[A-Z\\.\\s]+[\\-\\—\\-\\-\\–]\\s*)</in>([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽ\\-A-Z]+)", "$1$2</in>");
            str = InitialAndAuthorNextWordCheck(str, "in");
            //str = Regex.Replace(str, "<in>([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z])([a-z])</in>([\\.\\+\\s:\\-\\—\\-\\-\\–]+)<in>([^!=]*)</in>", "$1$2$3<in>$4</in>");
            //str = Regex.Replace(str, "([,\.;:]*)(\s+[ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z]+)</in>(\s+[a-z]+)", "$1</in>$2$3")
            str = Regex.Replace(str, "(<i>|<b>)<in>", "<in>$1");
            str = Regex.Replace(str.ToString(), "<in?></?in?>([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z])</?in?></?in?>([\\.\\+\\s:\\-\\—\\-\\-\\–]+)<i>", "<i>$1$2", RegexOptions.Singleline);
            str = Regex.Replace(str, "</in>(</i>|</b>)([\\.\\+\\s]*)<in>", "$1$2");
            str = Regex.Replace(str, "</in>(</i>|</b>)", "$1</in>");
            str = Regex.Replace(str, "</in><in>", "");
            str = Regex.Replace(str, "</in>\\s<in>", " ");
            str = Regex.Replace(str, "</in>(\\s*\\(\\s*)<in>", "$1");
            //Checking Nested <in> tags and Inserting the Number to in tags according to a sibling...
            int SpanCnt = 0;
            Match SpanMat = Regex.Match(str, "<(/)?in");

            while (SpanMat.Success)
            {
                if (SpanMat.Groups[1].ToString() == "")
                {
                    SpanCnt += 1;
                    str = str.Replace("<in", "<" + SpanCnt + "in");
                }
                else if (SpanMat.Groups[1].ToString() == "/")
                {
                    str = str.Replace("</in", "</" + SpanCnt + "in");
                    SpanCnt -= 1;
                }
                SpanMat = Regex.Match(str, "<(/)?in");
            }
            str = Regex.Replace(str, "<(/)?(2|3|4|5|6)in>", "");
            str = Regex.Replace(str, "<(/)?1in>", "<$1in>");
            str = Regex.Replace(str, "<(/)?1inkw>", "<$1inkw>");
            str = Regex.Replace(str, "<in>([^<]+)</in>([\\s]?[ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z][^ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Zà-ža-z][\\.]?)([\\s\\,]*)([Ii][Nn]:?)([\\s\\,]*)", "<in>$1$2</in>$3<inkw>$4</inkw>$5");
            if (Regex.Matches(str, "<in>").Count > Regex.Matches(str, "<au[0-9]+>").Count && Regex.IsMatch(str, "<in>[^!=,]+</in> <in>") == true)
                str = Regex.Replace(str, "(<in>[^!=,]+)</in> <in>", "$1, ");
            return str;
        }
        public string TaggingContents(string referenceText, string tagName, string groupValue, int index)
        {
            string left = referenceText.Substring(0, index);
            string middle = referenceText.Substring(left.Length, groupValue.Length);
            string right = referenceText.Substring(left.Length + middle.Length, referenceText.Length - (left.Length + middle.Length));
            referenceText = left + "<" + tagName + ">" + middle + "</" + tagName + ">" + right;
            if (tagName.ToLower() != "dl")
            {
                referenceText = Regex.Replace(referenceText, "<" + tagName + ">(\\s)", "$1" + "<" + tagName + ">");
                referenceText = Regex.Replace(referenceText, "(\\s)</" + tagName + ">", "</" + tagName + ">" + "$1");
            }

            return referenceText;
        }
        public static string InitialAndAuthorNextWordCheck(string _strContent, string _regexPattern)
        {
            if (Regex.IsMatch(_strContent, "<" + _regexPattern + ">([^!=]*)</" + _regexPattern + ">\\s([a-z]+)", RegexOptions.Singleline))
            {
                MatchCollection fineTun = Regex.Matches(_strContent.ToString(), "<" + _regexPattern + ">([^!=]*)</" + _regexPattern + ">(\\s+[a-z]+)", RegexOptions.Singleline);
                foreach (Match ft in fineTun)
                {
                    if (!(Regex.IsMatch(ft.Groups[2].ToString().Trim(), "^[a-z]$|and|&amp;|&amp;amp;", RegexOptions.Singleline))) // ' Or Regex.IsMatch(ft.Groups(2).ToString(), "([\+\-|\.\-|\.|\.\s|\+\s|\.,\s?|\+,\s?]+)", RegexOptions.Singleline)) Then
                    {
                        Match InitialSplit = Regex.Match(ft.Groups[0].ToString(), "^<" + _regexPattern + ">([^!=]*)([\\+\\-|\\.\\-|\\.|\\.\\s|\\+\\s|\\.,\\s?|\\+,\\s?]+)([ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßÞŠŸŽA-Z]\\.?\\+?)</" + _regexPattern + ">(\\s+[a-z]+)", RegexOptions.Singleline);
                        if (InitialSplit.Success)
                        {
                            _strContent = Regex.Replace(_strContent, Regex.Escape(InitialSplit.Groups[0].ToString()), "<" + _regexPattern + ">" + InitialSplit.Groups[1].ToString() + InitialSplit.Groups[2].ToString() + "</" + _regexPattern + ">" + InitialSplit.Groups[3].ToString() + InitialSplit.Groups[4].ToString(), RegexOptions.Singleline);
                            _strContent = Regex.Replace(_strContent, "(\\s+)</" + _regexPattern + ">", "</" + _regexPattern + ">$1", RegexOptions.Singleline);
                        }
                    }
                }
            }
            return _strContent;
        }
        public string MarkingAuthor(string AuthGrp)
        {
            MatchCollection mTag = Regex.Matches(AuthGrp, "<(b|in|au|dl|deg|fp|et-al)>(.*?)</\\1>", RegexOptions.Singleline);
            Boolean auover = false, inover = false;
            int pg, inIndex = 0, auIndex = 0;
            if (mTag.Count <= 0)
                return AuthGrp;
            if ((mTag[0].Groups[1].ToString() == "au" || mTag[0].Groups[1].ToString() == "in"))
            {
                for (pg = mTag.Count - 1; pg >= 0; pg--)
                {
                    if (mTag[pg].Groups[1].ToString() == "in")
                    {
                        inover = true;
                        inIndex = mTag[pg].Index;
                        if (auover == false)
                            inIndex = inIndex + mTag[pg].Length;
                    }
                    if (mTag[pg].Groups[1].ToString() == "au")
                    {
                        auover = true;
                        auIndex = mTag[pg].Index;
                        if (inover == false)
                            auIndex = auIndex + mTag[pg].Length;
                    }
                    if (inover == true && auover == true)
                    {
                        inover = false;
                        auover = false;
                        if (auIndex < inIndex)
                        {
                            AuthGrp = AuthGrp.Insert(inIndex, "</Author>");
                            AuthGrp = AuthGrp.Insert(auIndex, "<Author>");
                        }
                        else
                        {
                            AuthGrp = AuthGrp.Insert(auIndex, "</Author>");
                            AuthGrp = AuthGrp.Insert(inIndex, "<Author>");
                        }
                    }
                }
            }
            return AuthGrp;
        }
        public string MarkingEditor(string AuthGrp)
        {
            MatchCollection mTag = Regex.Matches(AuthGrp, "<(b|ein|eau|deg|fp|et-al)>(.*?)</\\1>", RegexOptions.Singleline);
            Boolean auover = false, inover = false;
            int pg, inIndex = 0, auIndex = 0;
            if ((mTag[0].Groups[1].ToString() == "eau" || mTag[0].Groups[1].ToString() == "ein"))
            {
                for (pg = mTag.Count - 1; pg >= 0; pg--)
                {
                    if (mTag[pg].Groups[1].ToString() == "ein")
                    {
                        inover = true;
                        inIndex = mTag[pg].Index;
                        if (auover == false)
                            inIndex = inIndex + mTag[pg].Length;
                    }
                    if (mTag[pg].Groups[1].ToString() == "eau")
                    {
                        auover = true;
                        auIndex = mTag[pg].Index;
                        if (inover == false)
                            auIndex = auIndex + mTag[pg].Length;
                    }
                    if (inover == true && auover == true)
                    {
                        inover = false;
                        auover = false;
                        if (auIndex < inIndex)
                        {
                            AuthGrp = AuthGrp.Insert(inIndex, "</Editor>");
                            AuthGrp = AuthGrp.Insert(auIndex, "<Editor>");
                        }
                        else
                        {
                            AuthGrp = AuthGrp.Insert(auIndex, "</Editor>");
                            AuthGrp = AuthGrp.Insert(inIndex, "<Editor>");
                        }
                    }
                }
            }
            return AuthGrp;
        }
        public Boolean ApplyElementsInRef(ref string refText, ref Hashtable au)
        {
            string tmp = "";
            if (eSubtitle.Contains("(") == true)
                eSubtitle = eSubtitle.Replace("(", "\\(").Replace(")", "\\)").Replace("[", "\\[").Replace("]", "\\]");
            eSubtitle = eSubtitle.Replace("α", "(α|(alpha))").Replace("ß", "(ß|(beta))").Replace("γ", "(γ|(gamma))").Replace("?", "(?|(II))").Replace("?", "\\?").Replace("+", "\\+");
            eSubtitle = eSubtitle.Replace("]\\?", "]?");
            if (eSubtitle != "" && Regex.IsMatch(refText, eSubtitle, RegexOptions.IgnoreCase) == true)
                eSubtitle = TagElement(ref refText, eSubtitle, "subtitle", false);
            else if (eSubtitle != "" && Regex.IsMatch(refText, eSubtitle.Replace(":", ".?"), RegexOptions.IgnoreCase) == true)
                eSubtitle = TagElement(ref refText, eSubtitle.Replace(":", ".?"), "subtitle", false);
            else if (eSubtitle != "" && Regex.IsMatch(refText, eSubtitle.Replace("-", ".?"), RegexOptions.IgnoreCase) == true)
                eSubtitle = TagElement(ref refText, eSubtitle.Replace("-", ".?"), "subtitle", false);
            else if (eSubtitle != "" && Regex.IsMatch(refText, eSubtitle.Replace("-", "\\-"), RegexOptions.IgnoreCase) == true)
                eSubtitle = TagElement(ref refText, eSubtitle.Replace("-", "\\-"), "subtitle", false);
            else if (eSubtitle != "" && Regex.IsMatch(refText, Regex.Replace(eSubtitle, "[^A-Za-z0-9\\[\\]\\(\\)\\\\?\\s\\.;:]", ".?"), RegexOptions.IgnoreCase) == true)
                eSubtitle = TagElement(ref refText, Regex.Replace(eSubtitle, "[^A-Za-z0-9\\[\\]\\(\\)\\\\?\\s\\.;:]", ".?"), "subtitle", false);
            else if (eSubtitle.Contains(": ") == true && Regex.IsMatch(refText, eSubtitle.Substring(0, eSubtitle.IndexOf(": ", 0)), RegexOptions.IgnoreCase) == true && eSubtitle.Substring(0, eSubtitle.IndexOf(": ", 0)).Trim().IndexOf(" ", 0) > 0)
                eSubtitle = TagElement(ref refText, eSubtitle.Substring(0, eSubtitle.IndexOf(": ", 0)), "subtitle", false);
            else if (eSubtitle != "" && Regex.IsMatch(refText, eSubtitle.Replace(" ", ".?")) == true)
                eSubtitle = TagElement(ref refText, eSubtitle.Replace(" ", ".?"), "subtitle", false);
            if (refText.IndexOf("<subtitle>", 0) < 0 && eSubtitle.IndexOf(" ", 0) > 0)
            {
                string pat = "";
                string[] arr = eSubtitle.Split(' ');
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].Length > 1)
                        pat = pat + arr[i][0] + "[^ ]+ ";
                    else
                        pat = pat + arr[i] + " ";
                }
                try
                {
                    //Regex.Match(eMainTitle, " ")
                    if (eSubtitle != "" && Regex.IsMatch(refText, pat.Trim()) == true)
                        eSubtitle = TagElement(ref refText, pat.Trim(), "subtitle", false);
                    else
                    {
                        tmp = "";
                        for (int i = 0; i < arr.Length; i++)
                        {
                            tmp = tmp + " " + arr[i];
                            if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false)
                            {
                                tmp = tmp.Substring(0, tmp.LastIndexOf(arr[i])).Trim();
                                break;
                            }
                        }
                        if (tmp.Split(' ').Length > 2)
                            eSubtitle = TagElement(ref refText, tmp, "subtitlel", false);
                        tmp = "";
                        for (int i = arr.Length - 1; i >= 0; i--)
                        {
                            tmp = arr[i] + " " + tmp;
                            if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false)
                            {
                                tmp = tmp.Substring(tmp.LastIndexOf(arr[i]) + arr[i].Length).Trim();
                                break;
                            }
                        }
                        if (((tmp.Split(' ').Length > 1 && refText.IndexOf("<subtitlel>", 0) >= 0) || tmp.Split(' ').Length > 2) && refText.ToLower().IndexOf(tmp.ToLower(), 0) >= 0)
                        {
                            int pos = refText.ToLower().IndexOf(tmp.ToLower(), 0);
                            if (refText.IndexOf("<subtitlel>", 0) >= 0)
                            {
                                tmp = refText.Substring(refText.IndexOf("<subtitlel>", 0) + 11, pos + tmp.Length - 11 - refText.IndexOf("<subtitlel>", 0));
                                refText = Regex.Replace(refText, Regex.Escape(tmp), "", RegexOptions.IgnoreCase);
                                eSubtitle = eSubtitle + tmp;
                                refText = refText.Replace("<subtitlel>", "<subtitle>");
                            }
                            else
                                eSubtitle = TagElement(ref refText, tmp, "subtitler", false);
                        }
                    }
                }
                catch (Exception ex) { }
            }
            eMainTitle = Regex.Replace(eMainTitle, "<[^!=]+>", "");
            tmp = Regex.Replace(eMainTitle, "[-a-z\\s\\.,&]+", "");
            eMainTitle = Regex.Replace(eMainTitle, "^\\bthe\\b\\s*", "", RegexOptions.IgnoreCase).Trim();
            eMainTitle = Regex.Replace(eMainTitle, " (and|&amp;|&) ", " (and|&|&amp;) ", RegexOptions.IgnoreCase).Trim();
            eMainTitle = eMainTitle.Replace(" �", "\\s?.?").Replace("�", ".?");
            if (eAbbrTtl.Contains(" ") == false && eLoc != "" && eLoc.Length > eAbbrTtl.Length)
            {
                if (eLoc != "" && Regex.IsMatch(refText, eLoc, RegexOptions.IgnoreCase) == true)
                    eLoc = TagElement(ref refText, eLoc, "eloc", false);
                else if (eLoc != "" && eLoc.Contains("/") == true)
                {
                    if (Regex.IsMatch(refText, eLoc.Substring(eLoc.IndexOf("/", 0) + 1), RegexOptions.IgnoreCase) == true)
                        eLoc = TagElement(ref refText, eLoc.Substring(eLoc.IndexOf("/", 0) + 1), "eloc", false);
                }
            }
            if (eMainTitle != "" && Regex.IsMatch(refText, eMainTitle + "[\\s,\\.\\(]*" + tmp + "[\\)]*\\b", RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, eMainTitle + "[\\s,\\.\\(]*" + tmp + "[\\)]*\\b", "maintitle", false);
            else if (eMainTitle != "" && Regex.IsMatch(refText, Regex.Escape(eMainTitle), RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, Regex.Escape(eMainTitle), "maintitle", true);
            else if (eMainTitle != "" && Regex.IsMatch(refText, eMainTitle, RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, eMainTitle, "maintitle", false);
            else if (eAbbrTtl != "" && Regex.IsMatch(refText, eAbbrTtl.Replace(" ", "[\\.]? ") + "[\\s,\\.\\(]*" + tmp + "[\\)]*\\b", RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, eAbbrTtl.Replace(" ", "[\\.]? ") + "[\\s,\\.\\(]*" + tmp + "[\\)]*\\b", "maintitle", false);
            else if (eAbbrTtl != "" && Regex.IsMatch(refText, eAbbrTtl.Replace(" ", "[\\.]? "), RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, eAbbrTtl.Replace(" ", "[\\.]? "), "maintitle", false);
            else if (eAbbrTtl != "" && Regex.IsMatch(refText, eAbbrTtl.Replace(".", "[\\.\\s]*"), RegexOptions.IgnoreCase) == true)
                eMainTitle = TagElement(ref refText, eAbbrTtl.Replace(".", "[\\.\\s]*"), "maintitle", false);
            else if (eMainTitle.Contains(": ") == true && Regex.IsMatch(refText, eMainTitle.Substring(0, eMainTitle.IndexOf(": ", 0)), RegexOptions.IgnoreCase) == true && eMainTitle.Substring(0, eMainTitle.IndexOf(": ", 0)).Trim().IndexOf(" ", 0) > 0)
                eMainTitle = TagElement(ref refText, eMainTitle.Substring(0, eMainTitle.IndexOf(": ", 0)), "maintitle", false);
            else if (eMainTitle != "")
            {
                tmp = eMainTitle.Replace(" ", "[\\.:,;\\s\\-]+");
                if (eMainTitle != "" && Regex.IsMatch(refText, tmp, RegexOptions.IgnoreCase) == true)
                    eMainTitle = TagElement(ref refText, tmp, "maintitle", false);
            }
            if (refText.IndexOf("<maintitle>", 0) < 0 && eMainTitle.IndexOf(" ", 0) > 0)
            {
                string pat = "", pat1 = "";
                string[] arr = eMainTitle.Replace("-", " ").Split(' ');
                for (int i = 0; i < arr.Length; i++)
                {
                    if (Regex.Replace(arr[i], "^[^A-Z]+", "") == "" && arr.Length <= 3)
                        arr[i] = arr[i][0].ToString().ToUpper() + arr[i].Substring(1);
                    arr[i] = Regex.Replace(arr[i], "^[^A-Z]+", "");
                    tmp = arr[i].Replace("(", "\\(").Replace(")", "\\)").Replace("[", "\\[").Replace("]", "\\]");
                    if (tmp != "")
                    {
                        if ((tmp == "IEEE" || (tmp == tmp.ToUpper() && Regex.IsMatch(tmp, "[^A-Za-z0-9]+") == false)))
                        {
                            pat = pat + tmp + " ";
                            pat1 = pat1 + tmp + " ";
                        }
                        else if (tmp[0].ToString() == tmp[0].ToString().ToUpper() && tmp != "and" && tmp != "&" && tmp.ToLower() != "the")
                        {
                            pat = pat + tmp[0].ToString() + "[^A-Z!= ]* ";
                            pat1 = pat1 + "(" + tmp[0].ToString() + "|" + tmp[0].ToString().ToLower() + ")[^A-Z!= ]* ";
                        }
                    }
                }
                if (eMainTitle != "" && Regex.IsMatch(refText, pat.Trim()) == true)
                    eMainTitle = TagMainTitle(ref refText, pat.Trim(),eMainTitle); //TagElement(ref refText, pat.Trim(), "maintitle", false);
                else if (eMainTitle != "" && Regex.IsMatch(refText, pat1.Trim()) == true)
                    eMainTitle = TagMainTitle(ref refText, pat1.Trim(), eMainTitle); //TagElement(ref refText, pat1.Trim(), "maintitle", false);
                else
                {
                    tmp = "";
                    arr = eMainTitle.Replace("-", " ").Split(' ');
                    for (int i = 0; i < arr.Length; i++)
                    {
                        tmp = tmp + " " + arr[i];
                        if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false && arr[i] != "the")
                        {
                            tmp = tmp.Substring(0, tmp.LastIndexOf(arr[i])).Trim();
                            break;
                        }
                        if (arr[i] == "the" && Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false)
                            tmp = tmp.Substring(0, tmp.LastIndexOf(" ")).Trim();
                    }
                    if (tmp.Split(' ').Length > 2)
                        eMainTitle = TagElement(ref refText, tmp, "maintitle", false);
                }
            }
            if (refText.IndexOf("<maintitle>", 0) < 0 && eAbbrTtl.IndexOf(" ", 0) > 0)
            {
                string pat = "";
                string[] arr = eAbbrTtl.Split(' ');
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] == "IEEE" || (arr[i] == arr[i].ToUpper() && Regex.IsMatch(arr[i], "[^A-Za-z0-9]+") == false))
                        pat = pat + arr[i].Replace("(", "\\(").Replace(")", "\\)").Replace("[", "\\[").Replace("]", "\\]") + " ";
                    else if (arr[i][0].ToString() == arr[i][0].ToString().ToUpper() && arr[i] != "&")
                        pat = pat + arr[i][0].ToString().Replace("(", "\\(").Replace(")", "\\)").Replace("[", "\\[").Replace("]", "\\]") + "[^A-Z ]* ";
                }
                if (eMainTitle != "" && Regex.IsMatch(refText, pat.Trim()) == true)
                    eMainTitle = TagElement(ref refText, pat.Trim(), "maintitle", false);
                else
                {
                    tmp = "";
                    for (int i = 0; i < arr.Length; i++)
                    {
                        tmp = tmp + " " + arr[i];
                        if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false && arr[i] != "the")
                        {
                            tmp = tmp.Substring(0, tmp.LastIndexOf(arr[i])).Trim();
                            break;
                        }
                        if (arr[i] == "the")
                            tmp = tmp.Substring(0, tmp.LastIndexOf(" ")).Trim();
                    }
                    if (tmp.Split(' ').Length > 2)
                        eMainTitle = TagElement(ref refText, tmp, "maintitle", false);
                }
            }
            if (refText.IndexOf("<maintitle>", 0) < 0 && eMainTitle.IndexOf(" ", 0) > 0)
            {
                tmp = "";
                string[] arr = eMainTitle.Split(' ');
                for (int i = 0; i < arr.Length; i++)
                {
                    tmp = tmp + " " + arr[i];
                    if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false)
                    {
                        tmp = tmp.Substring(0, tmp.LastIndexOf(arr[i])).Trim();
                        break;
                    }
                }
                if (tmp.Split(' ').Length > 1)
                    eMainTitle = TagElement(ref refText, tmp, "maintitlel", false);
                tmp = "";
                for (int i = arr.Length - 1; i >= 0; i--)
                {
                    tmp = arr[i] + " " + tmp;
                    if (Regex.IsMatch(refText, tmp.Trim(), RegexOptions.IgnoreCase) == false)
                    {
                        tmp = tmp.Substring(tmp.LastIndexOf(arr[i]) + arr[i].Length).Trim();
                        break;
                    }
                }
                if (((tmp.Split(' ').Length > 1 && refText.IndexOf("<maintitlel>", 0) >= 0) || tmp.Split(' ').Length > 2) && refText.ToLower().IndexOf(tmp.ToLower(), 0) >= 0)
                {
                    int pos = refText.ToLower().IndexOf(tmp.ToLower(), 0);
                    if (refText.IndexOf("<maintitlel>", 0) >= 0)
                    {
                        tmp = refText.Substring(refText.IndexOf("<maintitlel>", 0) + 12, pos + tmp.Length - 12 - refText.IndexOf("<maintitlel>", 0));
                        refText = Regex.Replace(refText, Regex.Escape(tmp), "", RegexOptions.IgnoreCase);
                        eMainTitle = eMainTitle + tmp;
                        refText = refText.Replace("<maintitlel>", "<maintitle>");
                    }
                    else
                        eMainTitle = TagElement(ref refText, tmp, "maintitler", false);
                }
                refText = refText.Replace("<maintitlel>", "<maintitle>").Replace("<maintitler>", "<maintitle>");
            }
            if (Regex.Matches(refText, "<maintitle>").Count == 2)
            {
                refText = refText.Insert(refText.LastIndexOf("<maintitle>") + 11, eMainTitle);
                refText = refText.Remove(refText.LastIndexOf("<maintitle>"), 11);
            }
            if (eSeries != "" && Regex.IsMatch(refText, Regex.Escape(eSeries), RegexOptions.IgnoreCase) == true)
                eSeries = TagElement(ref refText, Regex.Escape(eSeries), "series", false);
            if (etal == "" && Regex.IsMatch(refText, "\\b(et al)\\b", RegexOptions.IgnoreCase) == true)
                etal = TagElement(ref refText, "\\b(et al)(\\.?)\\b", "etal", true);
            if (eAug != "")
            {
                eAug = Regex.Replace(eAug, "^for the\\b", "", RegexOptions.IgnoreCase).Trim();
                eAug = Regex.Replace(eAug, "^the\\b", "", RegexOptions.IgnoreCase).Trim();
                eAug = Regex.Replace(eAug, "\\|for the\\b", "", RegexOptions.IgnoreCase).Trim();
                eAug = Regex.Replace(eAug, "\\|the\\b", "", RegexOptions.IgnoreCase).Trim();
                eAug = eAug.Replace("||", "|").Replace("| ", "|").Replace(" |", "|").Replace("\\b\\b","\\b");
                string[] arr = eAug.Split('|');
                SortArray(ref arr);
                for (int i = 0; i < arr.Length; i++)
                {
                    arr[i] = arr[i].Replace("(", ".?").Replace("[", ".?").Replace(")", ".?").Replace("]", ".?");
                    if (arr[i] != "")
                    {
                        if (Regex.IsMatch(refText, "\\b" + arr[i] + "\\b", RegexOptions.IgnoreCase) == true && arr[i] != "and" && arr[i] != "of")
                        {
                            tmp = TagElement(ref refText, "\\b" + arr[i] + "\\b", "au" + i, false);
                            if(tmp=="" || tmp.Contains("\\b"))
                                tmp = TagElement(ref refText, "\\b" + arr[i] + "\\b", "au" + i, true);
                            if (tmp != arr[i])
                                eAug = eAug.Replace(arr[i], tmp);
                            if (au.ContainsKey("au" + i) == false)
                                au.Add("au" + i, tmp);
                        }
                        else if (Regex.IsMatch(refText, "\\b" + arr[i].Replace("-", " ") + "\\b", RegexOptions.IgnoreCase) == true && arr[i] != "and" && arr[i] != "of")
                        {
                            tmp = TagElement(ref refText, "\\b" + arr[i].Replace("-", " ") + "\\b", "au" + i, false);
                            if (tmp != arr[i])
                                eAug = eAug.Replace(arr[i], tmp);
                            if (au.ContainsKey("au" + i) == false)
                                au.Add("au" + i, tmp);
                        }
                        else if (Regex.IsMatch(arr[i], "[^\\-A-Za-z0-9]") == true && arr[i] != "and" && arr[i] != "of")
                        {
                            tmp = Regex.Replace(arr[i], "[^\\-A-Za-z0-9]", ".?");
                            if (Regex.IsMatch(refText, tmp, RegexOptions.IgnoreCase) == true)
                            {
                                tmp = TagElement(ref refText, "\\b" + tmp + "\\b", "au" + i, false);
                                eAug = eAug.Replace(arr[i], tmp);
                                if (au.ContainsKey("au" + i) == false)
                                    au.Add("au" + i, tmp);
                            }
                        }
                        else if (arr[i].Length > 3 && Regex.IsMatch(refText, arr[i].Substring(0, arr[i].Length - 1) + ".?") == true && arr[i] != "and" && arr[i] != "of")
                        {
                            tmp = arr[i].Substring(0, arr[i].Length - 1) + ".?";
                            if (Regex.IsMatch(refText, tmp, RegexOptions.IgnoreCase) == true)
                            {
                                tmp = TagElement(ref refText, "\\b" + tmp + "\\b", "au" + i, false);
                                eAug = eAug.Replace(arr[i], tmp);
                                if (au.ContainsKey("au" + i) == false)
                                    au.Add("au" + i, tmp);
                            }
                        }
                    }
                }
                if (Regex.IsMatch(refText, "<au[0-9]+>") == false && Regex.IsMatch(refText, "Collaborators?", RegexOptions.IgnoreCase) == true)
                    refText = Regex.Replace(refText, "(Collaborators?)", "<au>$1</au>", RegexOptions.IgnoreCase);
            }
            if (eEdg != "")
            {
                eEdg = eEdg.Replace(" ", "|");
                string[] arr = eEdg.Split('|');
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] != "" && Regex.IsMatch(refText, arr[i], RegexOptions.IgnoreCase) == true)
                    {
                        tmp = TagElement(ref refText, arr[i], "eau" + i, false);
                        if (tmp != arr[i])
                            eEdg = eEdg.Replace(arr[i], tmp);
                    }
                    else if (arr[i] != "" && Regex.IsMatch(arr[i], "[^\\-A-Za-z0-9]") == true)
                    {
                        tmp = Regex.Replace(arr[i], "[^\\-A-Za-z0-9]", ".?");
                        if (Regex.IsMatch(refText, tmp, RegexOptions.IgnoreCase) == true)
                        {
                            tmp = TagElement(ref refText, tmp, "eau" + i, false);
                            eEdg = eEdg.Replace(arr[i], tmp);
                        }
                    }
                    else if (arr[i].Length > 3 && Regex.IsMatch(refText, arr[i].Substring(0, arr[i].Length - 1) + ".?") == true)
                    {
                        tmp = arr[i].Substring(0, arr[i].Length - 1) + ".?";
                        if (Regex.IsMatch(refText, tmp, RegexOptions.IgnoreCase) == true)
                        {
                            tmp = TagElement(ref refText, tmp, "eau" + i, false);
                            eEdg = eEdg.Replace(arr[i], tmp);
                        }
                    }
                }
            }
            if (eAbbrTtl != "" && Regex.IsMatch(refText, eAbbrTtl.Replace(" ", "[\\.]? ").Replace("'", "’"), RegexOptions.IgnoreCase) == true && Regex.Matches(refText, "<maintitle>").Count > 0)
            {
                tmp = TagElement(ref refText, eAbbrTtl.Replace(" ", "[\\.]? ").Replace("'", "’"), "amaintitle", false);
                if (refText.IndexOf("<amaintitle>", 0) > refText.IndexOf("<maintitle>", 0))
                {
                    tmp = Regex.Match(refText, "<maintitle>([^!=]+)<amaintitle>").Groups[1].Value + tmp;
                    eMainTitle = eMainTitle + tmp;
                    refText = Regex.Replace(refText, "<maintitle>([^!=]+)<amaintitle>", "<maintitle>");
                }
                else if (refText.IndexOf("<amaintitle>", 0) < refText.IndexOf("<maintitle>", 0))
                {
                    tmp = Regex.Match(refText, "<amaintitle>([^!=]+)<maintitle>").Groups[1].Value + tmp;
                    eMainTitle = tmp + eMainTitle;
                    refText = Regex.Replace(refText, "<amaintitle>([^!=]+)<maintitle>", "<maintitle>");
                }
            }
            if (Regex.IsMatch(refText, "e?[0-9]+(ra|ps)e?[0-9]+", RegexOptions.IgnoreCase) == true)
                refText = Regex.Replace(refText, "(e?[0-9]+)(ra|ps)(e?[0-9]+)", "<fpage>$1</fpage>$2<lpage>$3</lpage>");
            if (epubid != "" && Regex.IsMatch(refText, Regex.Escape(epubid), RegexOptions.IgnoreCase) == true)
                epubid = TagElement(ref refText, epubid, "pubid", true);
            if (eYear != "" && Regex.IsMatch(refText, "\\(" + eYear + "\\)", RegexOptions.IgnoreCase) == true)
            {
                tmp = Regex.Match(refText, "\\((" + eYear + ")\\)", RegexOptions.IgnoreCase).Groups[1].Value;
                refText = Regex.Replace(refText, "\\((" + eYear + ")\\)", "(<year>)");
                eYear = tmp;
                if (Regex.Matches(refText, "<year>").Count > 1)
                    RemoveOtherInstance(ref refText, "<year>", eYear);
            }
            else if (eYear != "" && Regex.IsMatch(refText, eYear, RegexOptions.IgnoreCase) == true)
            {
                eYear = TagElement(ref refText, eYear, "year", false);
                if (Regex.Matches(refText, "<year>").Count > 1)
                    RemoveOtherInstance(ref refText, "<year>", eYear);
            }
            if (eVol != "" && Regex.IsMatch(refText, "(?<![au]+)" + "[vV]?[oO]?[lL]?\\.?\\s?"+eVol, RegexOptions.IgnoreCase) == true)
            {
                eVol = TagElement(ref refText, "(?<![au]+)" + "[vV]?[oO]?[lL]?\\.?\\s?" + eVol, "vol", false);
                if (Regex.Matches(refText, "<vol>").Count > 1)
                    RemoveOtherInstance(ref refText, "<vol>", eVol);
                if (eVol.StartsWith(". ") == true)
                {
                    refText = refText.Replace("<vol>", ". <vol>");
                    eVol = eVol.Remove(0, 2);
                }
                else if (eVol.StartsWith(".") == true)
                {
                    refText = refText.Replace("<vol>", ".<vol>");
                    eVol = eVol.Remove(0, 1);
                }
            }
            else if (eVol != "" && Regex.IsMatch(refText, "(?<![au]+)" + eVol, RegexOptions.IgnoreCase) == true)
            {
                eVol = TagElement(ref refText, "(?<![au]+)" + eVol, "vol", false);
                if (Regex.Matches(refText, "<vol>").Count > 1)
                    RemoveOtherInstance(ref refText, "<vol>", eVol);
            }
            else if (eVol != "" && Regex.IsMatch(refText, "(?<![au]+)" + Regex.Replace(eVol, "[a-z\\s]+", "", RegexOptions.IgnoreCase), RegexOptions.IgnoreCase) == true)
            {
                eVol = TagElement(ref refText, "(?<![au]+)" + Regex.Replace(eVol, "[a-z\\s]+", "", RegexOptions.IgnoreCase), "vol", false);
                if (Regex.Matches(refText, "<vol>").Count > 1)
                    RemoveOtherInstance(ref refText, "<vol>", eVol);
            }
            if (eIssue != "" && Regex.IsMatch(refText, "\\(" + eIssue + "\\)", RegexOptions.IgnoreCase) == true)
            {
                tmp = Regex.Match(refText, "\\((" + eIssue + ")\\)", RegexOptions.IgnoreCase).Groups[1].Value;
                refText = Regex.Replace(refText, "\\((" + eIssue + ")\\)", "(<issue>)");
                eIssue = tmp;
            }
            else if (eIssue != "" && Regex.IsMatch(refText, "(?<![au]+)" + eIssue, RegexOptions.IgnoreCase) == true)
            {
                eIssue = TagElement(ref refText, "(?<![au]+)" + eIssue, "issue", false);
                if (Regex.Matches(refText, "<issue>").Count > 1)
                    RemoveOtherInstance(ref refText, "<issue>", eIssue);
            }
            else if (eIssue != "" && Regex.IsMatch(eIssue, "s[0-9]+", RegexOptions.IgnoreCase) == true)
            {
                if (Regex.IsMatch(refText, eIssue.Insert(1, "[a-z]*\\s?"), RegexOptions.IgnoreCase) == true)
                    eIssue = TagElement(ref refText, eIssue.Insert(1, "[a-z]*\\s?"), "issue", false);
            }
            if (eLoc != "" && Regex.IsMatch(refText, eLoc, RegexOptions.IgnoreCase) == true)
                eLoc = TagElement(ref refText, eLoc, "eloc", false);
            else if (eLoc != "" && eLoc.Contains("/") == true)
            {
                if (Regex.IsMatch(refText, "e?" + eLoc.Substring(eLoc.LastIndexOf("/") + 1), RegexOptions.IgnoreCase) == true)
                    eLoc = TagElement(ref refText, "e?" + eLoc.Substring(eLoc.LastIndexOf("/") + 1), "eloc", false);
            }
            if (eFpage != "" && refText.IndexOf("<fpage>", 0) < 0 && Regex.IsMatch(refText, "(?<![au]+)" + eFpage, RegexOptions.IgnoreCase) == true)
            {
                tmp = TagElement(ref refText, "(?<![au]+)" + eFpage, "fpage", false);
                if (tmp == "")
                    eFpage = TagElement(ref refText, "[a-z]*" + eFpage+ "[a-z]*", "fpage", false);
                else
                    eFpage = tmp;
            }
            if (eLpage != "" && refText.IndexOf("<lpage>", 0) < 0 && Regex.IsMatch(refText, "(?<![au]+)" + eLpage, RegexOptions.IgnoreCase) == true)
                eLpage = TagElement(ref refText, "(?<![au]+)" + eLpage, "lpage", false);
            if (ePname != "" && Regex.IsMatch(refText, ePname, RegexOptions.IgnoreCase) == true)
                ePname = TagElement(ref refText, ePname, "publisher", false);
            if (ePloc != "" && Regex.IsMatch(refText, ePloc, RegexOptions.IgnoreCase) == true)
                ePloc = TagElement(ref refText, ePloc, "location", false);
            if (issn != "" && Regex.IsMatch(refText, "(issn:?\\s?)?" + issn, RegexOptions.IgnoreCase) == true)
                issn = TagElement(ref refText, "(issn:?\\s?)?" + issn, "issn", false);
            else if (issn != "" && issn.Length >= 8)
            {
                issn = issn.Insert(4, "\\-");
                if (Regex.IsMatch(refText, "(issn:?\\s?)?" + issn, RegexOptions.IgnoreCase) == true)
                    issn = TagElement(ref refText, "(issn:?\\s?)?" + issn, "issn", true);
            }
            return true;
        }
        public string TagMainTitle(ref string refText,string pattern,string title)
        {
            //string title = "";
            try
            {
                MatchCollection pMatch = Regex.Matches(refText, pattern);
                if (pMatch.Count>1)
                {
                    refText=TaggingContents(refText, "maintitle", pMatch[pMatch.Count - 1].Value, pMatch[pMatch.Count - 1].Index);
                    refText = Regex.Replace(refText, "<maintitle>[^<>]+</maintitle>", "<maintitle>");
                    title = pMatch[pMatch.Count - 1].Value;
                }
                else if(pMatch.Count==1)
                {
                    refText = TaggingContents(refText, "maintitle", pMatch[0].Value, pMatch[0].Index);
                    refText = Regex.Replace(refText, "<maintitle>[^<>]+</maintitle>", "<maintitle>");
                    title = pMatch[0].Value;
                }
            }
            catch { }
            return title;
        }
        public Boolean SortArray(ref string[] arr)
        {
            int intCnt, intCnt1;
            string tmp;
            for (intCnt = 0; intCnt < arr.Length - 1; intCnt++)
            {
                for (intCnt1 = intCnt + 1; intCnt1 < arr.Length; intCnt1++)
                {
                    if (arr[intCnt].Trim().Length < 2)
                        arr[intCnt] = "";
                    if (arr[intCnt].Length < arr[intCnt1].Length)
                    {
                        tmp = arr[intCnt];
                        arr[intCnt] = arr[intCnt1];
                        arr[intCnt1] = tmp;
                    }
                }
            }
            return true;
        }
        public Boolean RemoveOtherInstance(ref string refText, string tag, string tagval)
        {
            int pos;
            string tmp = "";
            pos = refText.IndexOf(tag, 0);
            if (pos >= 0)
            {
                pos = refText.IndexOf(tag, pos + 1);
                if (pos >= 0)
                {
                    tmp = refText.Substring(pos);
                    refText = refText.Substring(0, pos);
                    tmp = tmp.Replace(tag, tagval);
                    refText = refText + tmp;
                }
            }
            return true;
        }
        public string GetPubMedValues(SearchAPI.eSummaryResult PubMedValue)
        {
            string tmp = "", oTmp = "<pubmed><authors>";
            //Get the Authors list
            for (int i = 0; i < PubMedValue.DocSum[0].AuthorList.Count; i++)
            {
                tmp = PubMedValue.DocSum[0].AuthorList[i].Text;
                oTmp = oTmp + "<author>" + tmp + "</author>";
                tmp = Regex.Replace(tmp, "\\b[A-Z]+\\b", "").Trim();
                if (tmp.Contains("Collaboration"))
                {
                    tmp = Regex.Replace(tmp, "\\s*Collaboration\\.?", "", RegexOptions.IgnoreCase);
                    tmp = tmp.Replace(" ", "-");
                    eAug = eAug + tmp + "|";
                    //ElseIf tmp.IndexOf(" ", 0) = tmp.LastIndexOf(" ") And tmp.IndexOf(" ", 0) >= 0 Then
                    //    eAug = eAug & tmp.Substring(0, tmp.LastIndexOf(" ")) & "|"
                }
                else if (Regex.IsMatch(tmp, "\\s") && Regex.IsMatch(tmp, "\\s+[a-z]+") == false)
                    eAug = eAug + tmp.Replace(" ", "|") + "|" + tmp + "|";
                else
                    eAug = eAug + tmp + "|";
            }
            oTmp = oTmp + "</authors>";
            eAug = eAug.Trim('|');
            for (int i = 0; i < PubMedValue.DocSum[0].Item.Count; i++)
            {
                if (String.IsNullOrEmpty(PubMedValue.DocSum[0].Item[i].Name))
                    break; //If node is empty exit for
                tmp = PubMedValue.DocSum[0].Item[i].Text;
                //Get Pubmed elements
                oTmp = oTmp + "<" + PubMedValue.DocSum[0].Item[i].Name.ToLower() + ">" + tmp + "</" + PubMedValue.DocSum[0].Item[i].Name.ToLower() + ">";
                switch (PubMedValue.DocSum[0].Item[i].Name.ToLower())
                {
                    case "source":
                        eMainTitle = tmp;
                        eAbbrTtl = tmp;
                        break;
                    case "fulljournalname":
                        eMainTitle = tmp;
                        if (Regex.IsMatch(eMainTitle, "^the\\s+", RegexOptions.IgnoreCase) == true)
                            eMainTitle = Regex.Replace(eMainTitle, "^the\\s+", "", RegexOptions.IgnoreCase);
                        break;
                    case "title":
                        tmp = Regex.Replace(tmp, "\\p{P}$", "");
                        eSubtitle = Regex.Replace(tmp, "^\\p{P}", "");
                        break;
                    case "volume":
                        eVol = tmp;
                        break;
                    case "issue":
                        eIssue = tmp;
                        break;
                    case "pages":
                        tmp = Regex.Replace(tmp, "[\\-\\—\\-\\-\\–]+", "|");
                        if (tmp.IndexOf("|", 0) >= 0)
                        {
                            eFpage = tmp.Substring(0, tmp.IndexOf("|", 0));
                            eLpage = tmp.Substring(tmp.IndexOf("|", 0) + 1);
                        }
                        else
                            eFpage = tmp;
                        break;
                    case "pubdate":
                        if (tmp.IndexOf(" ", 0) >= 0)
                            eYear = tmp.Substring(0, tmp.IndexOf(" ", 0));
                        else
                            eYear = tmp;
                        break;
                    case "doi":
                        if (eDoi == "")
                            eDoi = tmp;
                        break;
                    case "elocationid":
                        if (tmp.Contains("pii:") && tmp.Contains("doi:"))
                        {
                            tmp = tmp.Substring(0, tmp.IndexOf("doi:", 0));
                            eLoc = tmp.Replace("pii:", "").Trim();
                            eLoc = eLoc.Trim('.');
                        }
                        break;
                }
            }
            return oTmp + "</pubmed>";
        }
        public string GetGrobidValues(string LocalrefValue)
        {
            XmlDocument xDom = new XmlDocument();
            //XmlNode xNod;
            string Author = "", tmp = "";
            xDom.PreserveWhitespace = true;
            LocalrefValue = LocalrefValue.Replace(" ", " ").Replace(" ", " ").Replace(" ", " ");
            xDom.LoadXml(LocalrefValue);
            //Get the Authors list
            foreach (XmlNode xNod1 in xDom.SelectNodes("//author/persName"))
            {
                if (xNod1.SelectSingleNode(".//surname") != null)
                {
                    tmp = xNod1.SelectSingleNode(".//surname").InnerText;
                    tmp = Regex.Replace(tmp, "^[:;\\s\\.,]+", "");
                    tmp = Regex.Replace(tmp, "[:;\\s\\.,]+$", "");
                    tmp = Regex.Replace(tmp, "\\s[A-Z]\\s", " ");
                    tmp = Regex.Replace(tmp, "^[A-Z]\\s", "");
                    if (tmp.Length > 1)
                    {
                        if (Regex.IsMatch(tmp, "[^-a-z0-9!=\"/=\\.]", RegexOptions.IgnoreCase) == true)
                        {
                            tmp = Regex.Replace(tmp, "[^-a-z0-9!=\"/=\\.\\s]", "\\.", RegexOptions.IgnoreCase);
                            tmp = tmp.Replace(" ", "\\s*");
                        }
                        Author = Author + tmp + "|";
                    }
                }
                if (xNod1.SelectSingleNode(".//forename[@type='first']") != null)
                {
                    tmp = xNod1.SelectSingleNode(".//forename[@type='first']").InnerText;
                    if (tmp.Length > 2 && tmp != tmp.ToUpper())
                        Author = Author + tmp + "|";
                }
            }
            foreach (XmlNode xNod1 in xDom.SelectNodes("//orgName"))
            {
                if (xNod1 != null)
                {
                    tmp = xNod1.InnerText;
                    tmp = tmp.Replace(" ?", "\\s?.").Replace("?", ".");
                    Author = Author + tmp + "|";
                }
            }
            eAug = Author.TrimEnd('|').Trim();
            Author = "";
            foreach (XmlNode xNod1 in xDom.SelectNodes("//editor/persName"))
            {
                if (xNod1.SelectSingleNode(".//surname") != null)
                {
                    tmp = xNod1.SelectSingleNode(".//surname").InnerText;
                    if (Regex.IsMatch(tmp, "[^-a-z0-9!=\"/=\\.]", RegexOptions.IgnoreCase) == true)
                    {
                        tmp = tmp.Replace(" ", "");
                        tmp = Regex.Replace(tmp, "[^-a-z0-9!=\"/=\\.]", "\\.", RegexOptions.IgnoreCase);
                    }
                    Author = Author + tmp + "|";
                }
            }
            eEdg = Author.TrimEnd('|').Trim();
            if (xDom.SelectSingleNode(".//title[@level='a']") != null)
            {
                if (Regex.IsMatch(xDom.SelectSingleNode(".//title[@level='a']").InnerXml, "<[^!=]+>") == true)
                {
                    eSubtitle = xDom.SelectSingleNode(".//title[@level='a']").InnerXml;
                    eSubtitle = Regex.Replace(eSubtitle, "(<[^!=]+>)", "$1[\\s]?");
                    eSubtitle = Regex.Replace(eSubtitle, "(</[^!=]+>)", "[\\s]?$1");
                    eSubtitle = Regex.Replace(eSubtitle, "(</?[^!=]+>)", "");
                    eSubtitle = Regex.Replace(eSubtitle, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                    eSubtitle = eSubtitle.Replace("[\\s]?[\\s]?", "[\\s]?").Trim();
                }
                else
                    eSubtitle = Regex.Replace(xDom.SelectSingleNode(".//title[@level='a']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            eSubtitle = eSubtitle.Replace(" �", "\\s?.?").Replace("�", ".?");
            
            if (xDom.SelectSingleNode(".//title[@level='j']|.//title[@level='m']") != null)
                eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//title[@level='j']|.//title[@level='m']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//title[@level='s']") != null)
                eSeries = Regex.Replace(xDom.SelectSingleNode(".//title[@level='s']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//date[@type='published']") != null)
            {
                eYear = Regex.Replace(xDom.SelectSingleNode(".//date[@type='published']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (Regex.Matches(eYear, "([0-9]{4})").Count > 1)
                    eYear = Regex.Matches(eYear, "([1-2][0-9]{3})", RegexOptions.RightToLeft)[0].Value;
            }
            if (xDom.SelectSingleNode(".//biblScope[@unit='issue']") != null)
                eIssue = Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='issue']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//biblScope[@unit='volume']") != null)
                eVol = Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='volume']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//biblScope[@unit='page']") != null)
            {
                if (Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='page']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim() == "")
                {
                    if (xDom.SelectSingleNode(".//biblScope[@unit='page']").Attributes.GetNamedItem("from") != null)
                        eFpage = Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='page']").Attributes.GetNamedItem("from").Value, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                    if (xDom.SelectSingleNode(".//biblScope[@unit='page']").Attributes.GetNamedItem("to") != null)
                        eLpage = Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='page']").Attributes.GetNamedItem("to").Value, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                }
                else
                    eFpage = Regex.Replace(xDom.SelectSingleNode(".//biblScope[@unit='page']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (eFpage != "" && Regex.IsMatch(eFpage, "[a-z]+$", RegexOptions.IgnoreCase) == true)
                    eFpage = Regex.Replace(eFpage, "[a-z]+$", "", RegexOptions.IgnoreCase);
            }
            if (xDom.SelectSingleNode(".//publisher") != null)
                ePname = Regex.Replace(xDom.SelectSingleNode(".//publisher").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//idno") != null)
                epubid = Regex.Replace(xDom.SelectSingleNode(".//idno").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            //If xDom.SelectSingleNode(".//DOI") !=null And eDoi = "" Then eDoi = Regex.Replace(xDom.SelectSingleNode(".//DOI").InnerText, "(([\r\n\t])+|\s{2,})", " ").Replace("  ", "").Trim()
            if (xDom.SelectSingleNode(".//pubPlace") != null)
                ePloc = Regex.Replace(xDom.SelectSingleNode(".//pubPlace").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (ePloc == "" && xDom.SelectSingleNode(".//meeting/address/addrLine") != null)
                ePloc = Regex.Replace(xDom.SelectSingleNode(".//meeting/address/addrLine").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            return LocalrefValue;
        }
        public string GetLocalValues(string LocalrefValue)
        {
            XmlDocument xDom = new XmlDocument();
            string Author = "";
            xDom.PreserveWhitespace = true;
            LocalrefValue = LocalrefValue.Replace(" ", " ").Replace(" ", " ").Replace(" ", " ");
            xDom.LoadXml(LocalrefValue);
            //Get the Authors list
            foreach (XmlNode xNod in xDom.SelectNodes("//au"))
            {
                if (xNod.SelectSingleNode(".//snm") !=null)
                    Author = Author + xNod.SelectSingleNode(".//snm").InnerText + "|";
            }
            Author = Author.TrimEnd('|').Trim();
            eAug = Author;
            if (xDom.SelectSingleNode(".//ArtTitle") != null)
            {
                if (Regex.IsMatch(xDom.SelectSingleNode(".//ArtTitle").InnerXml, "<[^!=]+>") == true)
                {
                    eSubtitle = xDom.SelectSingleNode(".//ArtTitle").InnerXml;
                    eSubtitle = Regex.Replace(eSubtitle, "(<[^!=]+>)", "$1[\\s]?");
                    eSubtitle = Regex.Replace(eSubtitle, "(</[^!=]+>)", "[\\s]?$1");
                    eSubtitle = Regex.Replace(eSubtitle, "(</?[^!=]+>)", "");
                    eSubtitle = Regex.Replace(eSubtitle, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                    eSubtitle = eSubtitle.Replace("[\\s]?[\\s]?", "[\\s]?").Trim();
                }
                else
                    eSubtitle = Regex.Replace(xDom.SelectSingleNode(".//ArtTitle").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            if (xDom.SelectSingleNode(".//JTitle") != null ) eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//JTitle").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//AbbrTitle") != null ) eAbbrTtl = Regex.Replace(xDom.SelectSingleNode(".//AbbrTitle").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//Year") != null )
                eYear = Regex.Replace(xDom.SelectSingleNode(".//Year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//Issue") != null ) eIssue = Regex.Replace(xDom.SelectSingleNode(".//Issue").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//Volume") != null ) eVol = Regex.Replace(xDom.SelectSingleNode(".//Volume").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//FPage") != null ) eFpage = Regex.Replace(xDom.SelectSingleNode(".//FPage").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//LPage") != null ) eLpage = Regex.Replace(xDom.SelectSingleNode(".//LPage").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//ArtNumber") != null) eLoc = Regex.Replace(xDom.SelectSingleNode(".//ArtNumber").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//DOI") != null && eDoi == "") eDoi = Regex.Replace(xDom.SelectSingleNode(".//DOI").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            return LocalrefValue;
        }
        public string GetCrossrefValues(string RunCrossrefValue)
        {
            //Variable Declaration
            XmlDocument xDom = new XmlDocument();
            string tmp = "", Author = "";
            // Dim xNod As XmlNode,  As String = "";
            xDom.PreserveWhitespace = true;
            RunCrossrefValue = RunCrossrefValue.Replace(" ", " ").Replace(" ", " ").Replace(" ", " ");
            xDom.LoadXml(RunCrossrefValue);
            //Get the Authors list
            foreach (XmlNode xNod1 in xDom.SelectNodes("//person_name"))
            {
                if (xNod1.SelectSingleNode(".//surname") != null)
                {
                    tmp = xNod1.SelectSingleNode(".//surname").InnerText;
                    tmp = Regex.Replace(tmp, "\\b[A-Z]+\\.?\\b", "").Trim('.').Trim();
                    if (tmp.Trim() == "")
                        tmp = xNod1.SelectSingleNode(".//surname").InnerText;
                    if (Regex.IsMatch(tmp, "\\s"))
                        Author = Author + tmp.Replace(" ", "|") + "|" + tmp + "|";
                    else
                        Author = Author + tmp + "|";
                }
                if (xNod1.SelectSingleNode(".//given_name") != null)
                {
                    if (xNod1.SelectSingleNode(".//given_name").InnerText.Length > 1 && Regex.IsMatch(xNod1.SelectSingleNode(".//given_name").InnerText, "[A-ZĀ-ƵÀ-Ý][a-zĀ-ƶà-ý]+") == true)
                        eFnm = eFnm + xNod1.SelectSingleNode(".//given_name").InnerText.Replace(" ", "|") + "|";
                }
            }
            foreach (XmlNode xNod1 in xDom.SelectNodes("//organization[@contributor_role='author']"))
            {
                if (xNod1 != null)
                {
                    tmp = xNod1.InnerText;
                    if (tmp.ToLower().Contains("collaboration") || tmp.ToLower().Contains("consortium"))
                        tmp = Regex.Replace(tmp, "\\s*(collaboration|consortium)\\s*", "", RegexOptions.IgnoreCase) + "|" + tmp;
                    if (tmp.IndexOf("(", 0) >= 0)
                        tmp = tmp + "|" + Regex.Match(tmp, "\\(([^\\)]+)\\)").Groups[1].Value.Trim() + "|" + Regex.Replace(tmp, "\\(([^\\)]+)\\)", "").Trim();
                    Author = Author + tmp + "|";
                }
            }
            eFnm = eFnm.TrimEnd('|').Trim();
            Author = Author.TrimEnd('|').Trim();
            eAug = Author;
            if (xDom.SelectSingleNode(".//book") != null)
            {
                if (xDom.SelectSingleNode(".//content_item/titles/title") != null)
                    eSubtitle = Regex.Replace(xDom.SelectSingleNode(".//content_item/titles/title").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            else if (xDom.SelectSingleNode(".//titles/title") != null)
            {
                if (xDom.SelectSingleNode(".//titles/title") != null)
                {
                    tmp = xDom.SelectSingleNode(".//titles/title").InnerXml;
                    if (tmp.IndexOf("<![CDATA[", 0) >= 0)
                        tmp = tmp.Replace("<![CDATA[", "").Replace("]]>", "");
                    if (Regex.IsMatch(tmp, "<[^!=]+>") == true)
                    {
                        eSubtitle = tmp.Replace("\r\n","").Trim();
                        eSubtitle = eSubtitle.Replace("<i>", "").Replace("</i>", "");
                        eSubtitle = eSubtitle.Replace("<b>", "").Replace("</b>", "");
                        eSubtitle = Regex.Replace(eSubtitle, "(<[^!=]+>)", "$1[\\s]?");
                        eSubtitle = Regex.Replace(eSubtitle, "(</[^!=]+>)", "[\\s]?$1");
                        eSubtitle = Regex.Replace(eSubtitle, "(</?[^!=]+>)", "");
                        eSubtitle = Regex.Replace(eSubtitle, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                        eSubtitle = eSubtitle.Replace("[\\s]?[\\s]?", "[\\s]?");
                    }
                    else
                        eSubtitle = Regex.Replace(tmp, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                }
                if (xDom.SelectSingleNode(".//titles/subtitle") != null)
                    eSubtitle = eSubtitle + ": " + Regex.Replace(xDom.SelectSingleNode(".//titles/subtitle").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                eSubtitle = Regex.Replace(eSubtitle, "\\p{P}$", "");
                eSubtitle = Regex.Replace(eSubtitle, "^\\p{P}", "");
                if (eSubtitle.EndsWith("[\\s]") == true)
                    eSubtitle = Regex.Replace(eSubtitle, "\\[\\s\\]$", "");
            }
            //If xDom.SelectSingleNode(".//journal_title") !=null Then eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//journal_title").InnerText, "(([\r\n\t])+|\s{2,})", " ").Replace("  ", "").Trim()
            if (xDom.SelectSingleNode(".//full_title") != null)
                eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//full_title").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//abbrev_title") != null)
                eAbbrTtl = Regex.Replace(xDom.SelectSingleNode(".//abbrev_title").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (eMainTitle == "" && xDom.SelectSingleNode(".//proceedings_metadata/proceedings_title") != null)
            {
                eMainTitle = xDom.SelectSingleNode(".//proceedings_metadata/proceedings_title").InnerText;
                eMainTitle = Regex.Replace(eMainTitle, "^[0-9]{4}", "");
                eMainTitle = Regex.Replace(eMainTitle, "\\([a-zA-Z]+\\)$", "");
            }
            if (eAbbrTtl == "" && xDom.SelectSingleNode(".//event_metadata/conference_acronym") != null)
            {
                eAbbrTtl = xDom.SelectSingleNode(".//event_metadata/conference_acronym").InnerText;
                eAbbrTtl = Regex.Replace(eAbbrTtl, "^[0-9]{4}", "");
                eAbbrTtl = Regex.Replace(eAbbrTtl, "\\([a-zA-Z]+\\)$", "");
            }
            if (eMainTitle.ToLower() == eAbbrTtl.ToLower())
                eAbbrTtl = "";
            if (eMainTitle == "" && eAbbrTtl == "" && xDom.SelectSingleNode(".//series_metadata/titles/title") !=null)
                eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//series_metadata/titles/title").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            else if (eMainTitle == "" && eAbbrTtl == "" && xDom.SelectSingleNode(".//book_metadata/titles/title")!=null)
                eMainTitle = Regex.Replace(xDom.SelectSingleNode(".//book_metadata/titles/title").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectNodes(".//journal_article/publication_date").Count > 1)
            {
                if (xDom.SelectSingleNode(".//journal_article/publication_date[@media_type='print']/year") != null)
                    eYear = Regex.Replace(xDom.SelectSingleNode(".//journal_article/publication_date[@media_type='print']/year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (xDom.SelectSingleNode(".//journal_article/publication_date[@media_type='online']/year") != null)
                {
                    if (eYear != Regex.Replace(xDom.SelectSingleNode(".//journal_article/publication_date[@media_type='online']/year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim())
                        eYear = eYear + "|" + Regex.Replace(xDom.SelectSingleNode(".//journal_article/publication_date[@media_type='online']/year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                }
            }
            else if (xDom.SelectSingleNode(".//journal_article/publication_date/year") != null)
                eYear = Regex.Replace(xDom.SelectSingleNode(".//journal_article/publication_date/year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            else if (xDom.SelectSingleNode(".//proceedings_metadata/publication_date/year") != null)
                eYear = Regex.Replace(xDom.SelectSingleNode(".//proceedings_metadata/publication_date/year").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            else if (xDom.SelectSingleNode(".//content_item/publication_date/year") != null)
                eYear = Regex.Replace(xDom.SelectSingleNode(".//content_item/publication_date/year").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            else if (xDom.SelectSingleNode(".//book_metadata/publication_date/year") != null)
                eYear = Regex.Replace(xDom.SelectSingleNode(".//book_metadata/publication_date/year").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//journal_issue/issue") != null)
                eIssue = Regex.Replace(xDom.SelectSingleNode(".//journal_issue/issue").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//journal_issue/journal_volume/volume") != null)
                eVol = Regex.Replace(xDom.SelectSingleNode(".//journal_issue/journal_volume/volume").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//journal_article/pages/first_page") != null)
                eFpage = Regex.Replace(xDom.SelectSingleNode(".//journal_article/pages/first_page").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//journal_article/pages/last_page") != null)
                eLpage = Regex.Replace(xDom.SelectSingleNode(".//journal_article/pages/last_page").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (eLoc == "" && xDom.SelectSingleNode(".//journal_article/publisher_item/item_number[@item_number_type='article_number']") != null)
                eLoc = Regex.Replace(xDom.SelectSingleNode(".//journal_article/publisher_item/item_number[@item_number_type='article_number']").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (eLoc == "" && xDom.SelectSingleNode(".//journal_article/publisher_item/identifier") != null)
                eLoc = Regex.Replace(xDom.SelectSingleNode(".//journal_article/publisher_item/identifier").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (eFpage == "" && xDom.SelectSingleNode(".//journal_article/publisher_item/item_number") != null)
            {
                eFpage = Regex.Replace(xDom.SelectSingleNode(".//journal_article/publisher_item/item_number").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (eFpage == eLoc)
                    eFpage = "";
            }
            else if (xDom.SelectSingleNode(".//conference_paper/pages/first_page") != null)
            {
                eFpage = Regex.Replace(xDom.SelectSingleNode(".//conference_paper/pages/first_page").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (eLpage == "" && xDom.SelectSingleNode(".//conference_paper/pages/last_page") != null)
                    eLpage = Regex.Replace(xDom.SelectSingleNode(".//conference_paper/pages/last_page").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            if (eFpage == "" && eLoc == "" && xDom.SelectSingleNode(".//content_item/pages") != null)
            {
                if (xDom.SelectSingleNode(".//content_item/pages/first_page") != null)
                    eFpage = Regex.Replace(xDom.SelectSingleNode(".//content_item/pages/first_page").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (eLpage == "" && xDom.SelectSingleNode(".//content_item/pages/last_page") != null)
                    eLpage = Regex.Replace(xDom.SelectSingleNode(".//content_item/pages/last_page").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            else if (eFpage == "" && eLoc == "" && xDom.SelectSingleNode(".//book_metadata/pages") != null)
            {
                if (xDom.SelectSingleNode(".//book_metadata/pages/first_page") != null)
                    eFpage = Regex.Replace(xDom.SelectSingleNode(".//book_metadata/pages/first_page").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
                if (eLpage == "" && xDom.SelectSingleNode(".//book_metadata/pages/last_page") != null)
                    eLpage = Regex.Replace(xDom.SelectSingleNode(".//book_metadata/pages/last_page").InnerText, "(([\\r\\n\\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            }
            if (xDom.SelectSingleNode(".//publisher/publisher_name") != null)
                ePname = Regex.Replace(xDom.SelectSingleNode(".//publisher/publisher_name").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//publisher/publisher_place") != null)
                ePloc = Regex.Replace(xDom.SelectSingleNode(".//publisher/publisher_place").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            if (xDom.SelectSingleNode(".//journal_metadata/issn") != null)
                issn = Regex.Replace(xDom.SelectSingleNode(".//journal_metadata/issn").InnerText, "(([\r\n\t])+|\\s{2,})", " ").Replace("  ", "").Trim();
            XmlNodeList xndl;
            xndl = xDom.SelectNodes(".//crossmark|.//citation_list|.//abstract|.//affiliation");
            for (int i = xndl.Count - 1; i >= 0; i--)
            {
                xndl[i].ParentNode.RemoveChild(xndl[i]);
            }
            RunCrossrefValue = xDom.OuterXml;
            RunCrossrefValue = Regex.Replace(RunCrossrefValue, "\\s*\r\n\\s*", "");
            RunCrossrefValue = Regex.Replace(RunCrossrefValue, "<\\?xml version[^!=]+\\?>", "");
            return RunCrossrefValue;
        }
        public string TagElement(ref string refText, string title, string tag, Boolean igcase)
        {
            string oTitle = title;
            if (title.Contains(".?") == false && title.Contains("\\.")==false)
                title = title.Replace(".", "\\.");
            Match m;
            if (title.Contains(" "))
            {
                if (igcase == true)
                    m = Regex.Match(refText, title, RegexOptions.IgnoreCase);
                else
                    m = Regex.Match(refText, title);
                if (m.Value != "")
                {
                    refText = Regex.Replace(refText, Regex.Escape(m.Value), "<" + tag + ">", RegexOptions.IgnoreCase);
                    return m.Value;
                }
                else
                {
                    m = Regex.Match(refText, title);
                    if (m.Value != "")
                    {
                        refText = Regex.Replace(refText, title, "<" + tag + ">");
                        return m.Value;
                    }
                    else
                    {
                        m = Regex.Match(refText, title, RegexOptions.IgnoreCase);
                        if (m.Value != "")
                        {
                            refText = Regex.Replace(refText, title, "<" + tag + ">", RegexOptions.IgnoreCase);
                            return m.Value;
                        }
                    }
                }
            }
            else
            {
                if (igcase == true)
                    m = Regex.Match(refText, "\\b" + title + "\\b", RegexOptions.IgnoreCase);
                else
                    m = Regex.Match(refText, "\\b" + title + "\\b");
                if (m.Value != "")
                {
                    refText = Regex.Replace(refText, "\\b" + Regex.Escape(m.Value) + "\\b", "<" + tag + ">", RegexOptions.IgnoreCase);
                    return m.Value;
                }
                else
                {
                    if (igcase == true)
                        m = Regex.Match(Regex.Replace(refText, "</?[^!=]+>", ""), "\\b" + title + ".?\b", RegexOptions.IgnoreCase);
                    else
                        m = Regex.Match(Regex.Replace(refText, "</?[^!=]+>", ""), "\\b" + title + ".?\b");
                    if (m.Value != "")
                    {
                        refText = Regex.Replace(refText, "\\b" + Regex.Escape(m.Value) + "\\b", "<" + tag + ">", RegexOptions.IgnoreCase);
                        return m.Value;
                    }
                }
            }
            return oTitle;
        }
    }
}
