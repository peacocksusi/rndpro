﻿namespace ReferenceAPI.Service
{
    public class refModule
    {
        public string taggedReferenceStr = "", outFile = "", etime = "", APIOrder = "";
        public int refCount, curRefProcessing;
        public Array allReferences, taggedReferences;
    }

}
