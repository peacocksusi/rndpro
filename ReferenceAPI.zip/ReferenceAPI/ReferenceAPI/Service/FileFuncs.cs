﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Reflection.Metadata.Ecma335;

namespace ReferenceAPI.Service
{
    public class FileFuncs
    {
        public static async Task<String> UploadFile(string path, IFormFile file)
        {
            string fileName = "test.txt";
            if (file.Length > 0)
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                using (var fileStream = new FileStream(Path.Combine(path, fileName != "" ? fileName : file.FileName), FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
            }
            return fileName;
        }

        public static string GetContent(string path, string filename)
        {
            string filestr = File.ReadAllText(Path.Combine(path, filename));
            return filestr;
        }

        public static byte[] DownloadFile(string outfile)
        {
            byte[] bytes = File.ReadAllBytes(outfile);
            return bytes;
        }

        public static string GetPath()
        {
            return Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, "UploadedFiles"));
        }




    }
    }