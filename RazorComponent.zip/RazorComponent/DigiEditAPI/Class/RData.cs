﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigiEditAPI.Class
{
    public class RData
    {
        public int StatusCode;
        public string Result;
        public string Message;

       public List<RData> getAll() {
            List<RData> ls = new List<RData>();

            return ls;
       }
    }
}
