﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DigiEditAPI.Class;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using DigiEditAPI.Models;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using YamlDotNet.Core;
using System.IO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DigiEditAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]

    public class EditorController : ControllerBase
    {
        // GET: api/<EditorController>
        [HttpGet]
        public string Get()
        {
            DIGIServe.SqlHelper serve = new DIGIServe.SqlHelper();
            serve.strDBConnection = "";

            string helpResult = @"
             DIGIEDIT API
             ============
             Method: ReadXml
             Parameters: xmlPath (Host Location of XML File)   
        ";

            return helpResult;
        }

        [Route("ReadXml")]
        [HttpPost()]
        public ActionResult readXML(string xmlPath, string fileKey, string repCode)
        {

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.read(xmlPath);

            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);
            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("ReadXMLByProject")]
        [HttpPost()]
        public ActionResult readXMLByProject(string xmlPath, string fileKey, string repCode)
        {

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.read(xmlPath);

            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);
            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("DownloadFile")]
        [HttpPost()]
        public async Task<IActionResult> downloadFile(string fileId, string fileKey, string repositoryCode)
        {

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();
            string result = await DIGIServe.AWSRequest.downloadToLocal(fileId, fileKey, repositoryCode);
            
            return new ContentResult
            {
                Content = objResult["xml"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };

        }



        [Route("ReadFile")]
        [HttpPost()]
        public ActionResult readFile(string xPath)
        {

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.readFile(xPath);
            return new ContentResult
            {
                Content = objResult["xml"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }





        [Route("WriteXml")]
        [HttpPost()]
        public ActionResult writeXml(IFormCollection formCollection)
        {


            string xmlPath = formCollection["xmlPath"].ToString();
            string json = formCollection["josn"].ToString();

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.saveXML(xmlPath, json);
            return new ContentResult
            {
                Content = objResult["msg"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("SaveXml")]
        [HttpPost()]
        public ActionResult saveXml(IFormCollection formCollection)
        {


            string xmlPath = formCollection["xmlPath"].ToString();
            string json = formCollection["josn"].ToString();

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.saveXML(xmlPath, json);
            return new ContentResult
            {
                Content = objResult["msg"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("SaveAllContent")]
        [HttpPost()]
        public ActionResult saveAllContent(DIGIServe.SaveAllContentModel saveAllContent)
        {

            string xmlAutoSavePath = Regex.Replace(saveAllContent.xmlPath, ".xhtml", "_AutoSave.xhtml");
            string xmlContent = saveAllContent.xmlContent;
            int version = DIGIServe.AppManage.getLastVersion(saveAllContent.processFile);
            string backupFileName = "";

            DIGIServe.AppManage.checkAndUpdateAuthorResponse(saveAllContent, version.ToString());

            if (saveAllContent.isSubmitted)
            {
                IDictionary<string, Object> backupInfo = DIGIServe.AppManage.manageVersionBackup(saveAllContent.processFile, saveAllContent.xmlContent, saveAllContent.role, saveAllContent.uid, saveAllContent.stage);
                version = Convert.ToInt32(backupInfo["version"].ToString());
                backupFileName = backupInfo["file"].ToString();
            }

            if (saveAllContent.role == "rv")
            {
                DIGIServe.AppManage.insertComment(saveAllContent.processFile, saveAllContent.uid, saveAllContent.commentToAuthor, saveAllContent.commentToEditor, version.ToString(), backupFileName);
            }

            IDictionary<string, Object> objResultXml = null;
            if (saveAllContent.isAutoSave && saveAllContent.isAutoSaveBackup)
            {

                objResultXml = DIGIServe.XMLUtil.saveContent(xmlAutoSavePath, xmlContent, true);
            }
            else if (saveAllContent.isAutoSave)
            {
                objResultXml = DIGIServe.XMLUtil.saveContent(xmlAutoSavePath, xmlContent);

            }



            /*if (objResultXml.ContainsKey("ErrStatus"))
            {
                return new ContentResult
                {
                    Content = "Auto Save Error",
                    ContentType = "text/plain",
                    StatusCode = 401
                };
            }*/

            //Log needs to include
            if (saveAllContent.isSubmitted == true && saveAllContent.role == "au")
            {
                xmlContent = DIGIServe.XMLUtil.cleanAnnotation(xmlContent);
            }

            objResultXml = DIGIServe.XMLUtil.saveContent(saveAllContent.xmlPath, xmlContent, true);




            if (objResultXml.ContainsKey("ErrStatus"))
            {
                return new ContentResult
                {
                    Content = "save unsuccessfully",
                    ContentType = "text/plain",
                    StatusCode = 401
                };
            }

            //IDictionary<string, Object> objResultAuthorNotes = DIGIServe.XMLUtil.saveContent(authorNotesFile, authorNotes);
            //IDictionary<string, Object> objResultEditorNotes = DIGIServe.XMLUtil.saveContent(editorNotesFile, editorNotes);

            return new ContentResult
            {
                Content = "Success",
                ContentType = "text/plain",
                StatusCode = 200
            };
        }



        [Route("SaveDecision")]
        [HttpPost()]
        public ActionResult saveDecision(IFormCollection formCollection)
        {
            string xmlPath = formCollection["xmlPath"].ToString();
            string json = formCollection["json"].ToString();

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.saveDecision(xmlPath, json);
            return new ContentResult
            {
                Content = objResult["msg"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("writeFullNote")]
        [HttpPost()]
        public ActionResult writeFullNote(IFormCollection formCollection)
        {
            string xmlPath = formCollection["processFile"].ToString();
            string xmlContent = formCollection["xmlContent"].ToString();
            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.saveNotes(xmlPath, xmlContent);
            return new ContentResult
            {
                Content = objResult["msg"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("ReadFullNote")]
        [HttpPost()]
        public ActionResult readFullNote(string processFile)
        {

            IDictionary<string, Object> objResult = DIGIServe.XMLUtil.readNote(processFile);
            return new ContentResult
            {
                Content = objResult["xml"].ToString(),
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("GetLastVersion")]
        [HttpPost()]
        public ActionResult getLastVersion(string processFile)
        {

            int version = DIGIServe.AppManage.getLastVersion(processFile);
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            objResult.Add("version", version);

            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("UpdateAuthorResponse")]
        [HttpPost()]
        public ActionResult updateAuthorResponse(string processFile, string auhtorId, string reviwerId, string authorResponse, string version)
        {


            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            objResult = DIGIServe.AppManage.updateAuthorResponse(processFile, auhtorId, reviwerId, authorResponse, version);

            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }




        [Route("rx")]
        [HttpPost()]
        public ActionResult<IEnumerable<RData>> rx()
        {
            RData rData = new RData();

            return rData.getAll();
        }


        [Route("GetPreviousVersionList")]
        [HttpPost()]
        public ActionResult getPreviousVersionList(string processFile, string uid)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.getPreviousVersion(processFile, uid);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("GetReviewerComment")]
        [HttpPost()]
        public ActionResult getReviewerComment(string processFile, string reviewby, string version)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.getReviewerComments(processFile, reviewby, version);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("GetAllReviewerComment")]
        [HttpPost()]
        public ActionResult getAllReviewerComment(string processFile, string version)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.getReviewerCommentsByVersion(processFile, version);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        /*[HttpPost]
        public IEnumerable<RData> readXML1(string xmlPath)
        {
            IDictionary<string, Object> objResult =  DIGIServe.XMLUtil.read(xmlPath) ;
            var convertedDictionary = objResult.ToDictionary(item => item.Key.ToString(), item => item.Value.ToString()

             IEnumerable < RData > testc = new Enumerable<RData>();
            //return new Enumerable<new RData(StatusCode:1, )>;
        }*/


        [Route("[controller]/ReadXMLContent")]
        [HttpPost]
        public IDictionary<string, Object> readXMLContent()
        {
            return DIGIServe.XMLUtil.read("");
        }

        // GET api/<EditorController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<EditorController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<EditorController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<EditorController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
