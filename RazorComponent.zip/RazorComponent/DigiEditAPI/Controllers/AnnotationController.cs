﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigiEditAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AnnotationController : Controller
    {
        [Route("insertAnnotation")]
        [HttpPost()]
        public ActionResult insertAnnotation(string processFile, string id, string position, string comment, string name, string refId, string info)
        {

            IDictionary<string, Object> objResult = DIGIServe.Annotation.insert(processFile, id, position, comment, name, refId, info);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("deleteAnnotation")]
        [HttpPost()]
        public ActionResult deleteAnnotation(string processFile, string id)
        {

            IDictionary<string, Object> objResult = DIGIServe.Annotation.delete(processFile, id);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }



        [Route("insertAnnotPlaceHolder")]
        [HttpPost()]
        public ActionResult insertAnnotPlaceHolder(string processFile, string id, string position, string comment, string name, string refId, string info)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.insertAnnotPlaceHolder(processFile, id, position, comment, name, refId, info);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("deleteAnnotPlaceHolder")]
        [HttpPost()]
        public ActionResult deleteAnnotPlaceHolder(string processFile, string spanId)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.deleteAnnotPlaceHolderBySpanId(processFile, spanId);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }



        [Route("getAnnotationById")]
        [HttpPost()]
        public ActionResult getAnnotationById(string processFile, string id)
        {

            IDictionary<string, Object> objResult = DIGIServe.Annotation.getById(processFile, id);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

        [Route("getAnnotationAll")]
        [HttpPost()]
        public ActionResult getAnnotationAll(string processFile)
        {

            IDictionary<string, Object> objResult = DIGIServe.Annotation.getAll(processFile);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("getAnnotPHAll")]
        [HttpPost()]
        public ActionResult getAnnotPHAll(string processFile, string user_id, string version)
        {

            IDictionary<string, Object> objResult = DIGIServe.AppManage.getAllAnnotPlaceHolder(processFile, user_id, version);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }
    }
}
