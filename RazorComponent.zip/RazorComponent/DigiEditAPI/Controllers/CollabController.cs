﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DigiEditAPI.Class;
using Microsoft.AspNetCore.Cors;
using Newtonsoft.Json;

namespace DigiEditAPI.Controllers
{

    [Route("[controller]")]
    [ApiController]
    public class CollabController : Controller
    {
        [Route("collabStart")]
        [HttpPost()]
        public ActionResult collabStart(string processFile, string nodeId, string name)
        {

            string ip = Request.Host.Value;

            IDictionary<string, Object> objResult = DIGIServe.Collab.insertNode(processFile, nodeId, name);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("collabEnd")]
        [HttpPost()]
        public ActionResult collabEnd(string processFile, string nodeId, string name)
        {

            IDictionary<string, Object> objResult = DIGIServe.Collab.closeNode(processFile, nodeId);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }


        [Route("getCollabSessions")]
        [HttpPost()]
        public ActionResult getActiveCollabSessions(string processFile)
        {

            IDictionary<string, Object> objResult = DIGIServe.Collab.getActiveNodes(processFile);


            string jsonResult = JsonConvert.SerializeObject(objResult, Formatting.Indented);

            return new ContentResult
            {
                Content = jsonResult,
                ContentType = "text/plain",
                StatusCode = 200
            };
        }

    }
}
