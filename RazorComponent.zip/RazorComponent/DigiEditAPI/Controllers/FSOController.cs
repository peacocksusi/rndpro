﻿using DigiEditAPI.Class;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;


namespace DigiEditAPI.Controllers
{
	[Route("[controller]")]
	[ApiController]
	public class FSOController : ControllerBase
	{
		[Route("uploadFile")]
		[HttpPost()]
		public ActionResult uploadFile(IFormCollection formCollection)
		{
			string result = "";
			string path = "";
			try
			{
				if (formCollection.Files.Count > 0)
				{
					IFormFile file = formCollection.Files[0];
					string fileName = "test.txt";
					if (file.Length > 0)
					{
						path = Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, "UploadedFiles", DateTime.Now.ToString("dd/MM/yyyy hh_mm_ss")));
						if (!Directory.Exists(path))
						{
							Directory.CreateDirectory(path);
						}
						using (var fileStream = new FileStream(Path.Combine(path, fileName != "" ? fileName : file.FileName), FileMode.Create))
						{
							file.CopyToAsync(fileStream);
						}
						result = path;
					}
				}
				else
				{
					result = "file not received";
				}

			}
			catch (Exception ex)
			{
				result = ex.Message;
			}

			return new ContentResult
			{
				Content = result,
				ContentType = "text/plain",
				StatusCode = 200
			};

		}

		
		[HttpGet]
		[Route("GetFileNamesByDirectoryPath")]
		public ActionResult GetFileNamesByDirectoryPath(string processFile, string baseDirName)
		{
			string fileList = DIGIServe.IOUtil.getFilesFormDir(processFile, baseDirName);

            return new ContentResult
            {
                Content = fileList,
                ContentType = "text/plain",
                StatusCode = 200
            };



        }


		//[HttpPost]
		//[Route("download")]
		//public IActionResult Download([FromBody] FileNamesModel fileNameModel)
		//{
		//	try
		//	{

		//		string path = fileNameModel.fileFullPath;
		//		if (System.IO.File.Exists(path))
		//		{

		//			byte[] bytes = System.IO.File.ReadAllBytes(path);
		//			return File(bytes, "application/octet-stream", fileNameModel.fileName);
		//		}
		//		else
		//		{
		//			return new ContentResult
		//			{
		//				Content = "Directory path is empty or doesn't exist",
		//				ContentType = "text/plain",
		//				StatusCode = 401
		//			};


		//		}



		//	}
		//	catch (Exception ex)
		//	{

		//		return new ContentResult
		//		{
		//			Content = ex.Message,
		//			ContentType = "text/plain",
		//			StatusCode = 401
		//		};
		//	}

		//}
	}
}
