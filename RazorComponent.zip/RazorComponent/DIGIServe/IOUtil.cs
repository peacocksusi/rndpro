﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.IO;
using Newtonsoft.Json;

namespace DIGIServe
{
    public class IOUtil
    {


        public static string getDBConnection(string processFile)
        {
            string dbCon = "";

            Config _config = new Config();

            string dbFile = _config.getValueFor("DbFile"); //"sync.db";
            string productionFolder = _config.getValueFor("ProductionFolder"); //"Production";
            string rootFolder = _config.getValueFor("RootFolder"); //@"D:\MahadevanM\01_Host\wwwroot\DigiEditAPI";

            dbCon = "data source=" + rootFolder + @"\" + processFile + @"\" + dbFile;

            return dbCon;
        }

        public static string getFilesFormDir(string processFile, string baseDirName)
        {
            string resultString = String.Empty;

            Config _config = new Config();

            string directoryPath = Path.Combine(_config.getValueFor("RootFolder"), processFile, _config.getValueFor(baseDirName));


            string hostPath = _config.getValueFor("XMLHost");

            List<FileNamesModel> namesModels = new List<FileNamesModel>();
          
            try
            {
                if (directoryPath != "" && Directory.Exists(directoryPath))
                {
                    string[] files = Directory.GetFiles(directoryPath);
                    foreach (var item in files)
                    {
                        FileNamesModel nameModel = new FileNamesModel();

                        nameModel.fileName = Path.GetFileName(item);


                        nameModel.fileFullPath = hostPath  + processFile + "/" +  _config.getValueFor(baseDirName) + "/" + nameModel.fileName;
                        namesModels.Add(nameModel);
                    }
                }
            }
            catch (Exception)
            {
                resultString = "";
            }
            resultString = JsonConvert.SerializeObject(namesModels.ToArray());
            return resultString;
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
    }
}
