﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DIGIServe
{
    public class Collab
    {
        public static IDictionary<string, Object> getActiveNodes(string processFile)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from nodes where status = 0";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex) { 
            
            }

            return objResult;
        }

        public static IDictionary<string, Object> insertNode(string processFile, string nodeId, string name)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string insertQuery = @"insert into nodes";
            insertQuery += " ( ";
            insertQuery += "refid, ";
            insertQuery += "name, ";
            insertQuery += "status, ";
            insertQuery += "createtime ";
            insertQuery += ")";
            insertQuery += " values ";
            insertQuery += " ( ";
            insertQuery += "'" + nodeId + "', ";
            insertQuery += "'" + name + "', ";
            insertQuery += "'0', ";
            insertQuery += "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "'";
            insertQuery += " ) ";

            try
            {
                objResult = SQLLite.executeWithRowId(insertQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> closeNode(string processFile, string nodeId)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string updateQuery = @"update nodes ";
            updateQuery += "set ";
            updateQuery += "status=1, ";
            updateQuery += "closetime='" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "' ";
            updateQuery += "where ";
            updateQuery += "refid = " + "'" + nodeId + "'";

            try
            {
                objResult = SQLLite.select(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }


            return objResult;
        }
    }
}
