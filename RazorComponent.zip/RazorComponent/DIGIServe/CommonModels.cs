﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DIGIServe
{
    public class CommonModels
    {



    }

    public class FileNamesModel
    {
        public string fileName { get; set; }
        public string fileFullPath { get; set; }


    }
}
