﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DIGIServe
{
    public class Config
    {

        private readonly IConfiguration _configuration;
        public Config()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddNewtonsoftJsonFile("appSettings.json", optional: true, reloadOnChange: true)
            .AddNewtonsoftJsonFile("appSettings.Development.json", optional: true, reloadOnChange: true);
            _configuration = builder.Build();
            
        }

        public string getValueFor(string key) {
            return _configuration.GetSection(key).Value;
        } 

    }
}
