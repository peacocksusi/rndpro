﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks.Sources;

namespace DIGIServe
{
    public class AppManage
    {
        public static IDictionary<string, Object> insertComment(string processFile, string reviewby, string commenttoauthor, string commenttoeditor, string version, string filename)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string insertQuery = "insert into jobtrans ";
            insertQuery += "(";
            insertQuery += "reviewby, ";
            insertQuery += "commenttoauthor, ";
            insertQuery += "commenttoeditor, ";
            insertQuery += "version, ";
            insertQuery += "filename, ";
            insertQuery += "createdon ";
            insertQuery += ")";
            insertQuery += " values ";
            insertQuery += "(";
            insertQuery += "'" + reviewby + "', ";
            insertQuery += "'" + IOUtil.Base64Encode(commenttoauthor) + "', ";
            insertQuery += "'" + IOUtil.Base64Encode(commenttoeditor) + "', ";
            insertQuery += "'" + version + "', ";
            insertQuery += "'" + filename + "', ";

            insertQuery += "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "'";
            insertQuery += ")";

            try
            {
                if (checkIsExist(processFile, reviewby, version))
                {
                    objResult = updateComment(processFile, reviewby, commenttoauthor, commenttoeditor, version);
                }
                else
                {
                    objResult = SQLLite.executeWithRowId(insertQuery, IOUtil.getDBConnection(processFile));

                }
            }
            catch (Exception ex)
            {
                Log.wrtie(ex.Message);
            }

            return objResult;
        }

        public static IDictionary<string, Object> updateComment(string processFile, string reviewby, string commenttoauthor, string commenttoeditor, string version)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string updateQuery = "update jobtrans ";
            updateQuery += " set ";
            updateQuery += "commenttoauthor = " + "'" + IOUtil.Base64Encode(commenttoauthor) + "', ";
            updateQuery += "commenttoeditor = " + "'" + IOUtil.Base64Encode(commenttoeditor) + "', ";
            updateQuery += "filename = " + "'" + IOUtil.Base64Encode(commenttoeditor) + "' ";
            updateQuery += " where ";
            updateQuery += "reviewby = " + "'" + reviewby + "' and ";
            updateQuery += "version = " + "'" + version + "' ";

            try
            {
                objResult = SQLLite.executeWithRowId(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> updateAuthorResponse(string processFile, string auId, string rvId, string authorResponse, string version)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string updateQuery = "update jobtrans ";
            updateQuery += " set ";
            updateQuery += "authorresponse = " + "'" + IOUtil.Base64Encode(authorResponse) + "', ";
            updateQuery += "authorid = " + "'" + auId + "', ";
            updateQuery += "updatedon = " + "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "' ";
            updateQuery += " where ";
            updateQuery += "reviewby = " + "'" + rvId + "' and ";
            updateQuery += "version = " + "'" + version + "' ";

            try
            {
                objResult = SQLLite.executeWithRowId(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }

        public static bool updateMsHistory(string processFile, string stage, string role, string uid, string version, string filename)
        {
            bool status = false;

            string insQuery = "insert into mshistory (";
            insQuery += "stage, ";
            insQuery += "submittedon, ";
            insQuery += "role, ";
            insQuery += "uid, ";
            insQuery += "version, ";
            insQuery += "filename ";
            insQuery += ") ";
            insQuery += "values( ";
            insQuery += "'" + stage + "', ";
            insQuery += "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "', ";
            insQuery += "'" + role + "', ";
            insQuery += "'" + uid + "', ";
            insQuery += "'" + version + "', ";
            insQuery += "'" + filename + "' ";

            insQuery += ") ";

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            try
            {
                objResult = SQLLite.executeWithRowId(insQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }
            return status;
        }

        public static bool checkIsExist(string processFile, string reviewby, string version)
        {
            bool result = false;

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from jobtrans where reviewby='" + reviewby + "' and version='" + version + "'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
                DataTable records = (DataTable)objResult["data"];
                if (records.Rows.Count > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }

            return result;
        }

        public static IDictionary<string, Object> getReviewerComments(string processFile, string reviewby, string version)
        {

            // version = getLastVersion(processFile).ToString(); 

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from jobtrans where reviewby='" + reviewby + "' and version='" + version + "'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
                DataTable records = (DataTable)objResult["data"];
                if (records.Rows.Count > 0)
                {
                    records.Rows[0]["commenttoauthor"] = IOUtil.Base64Decode(records.Rows[0]["commenttoauthor"].ToString());
                    records.Rows[0]["commenttoeditor"] = IOUtil.Base64Decode(records.Rows[0]["commenttoeditor"].ToString());
                    records.Rows[0]["authorresponse"] = IOUtil.Base64Decode(records.Rows[0]["authorresponse"].ToString());
                }
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> getPreviousVersion(string processFile, string uid)
        {


            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from mshistory where uid = '" + uid + "'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));

            }
            catch (Exception ex)
            {

            }

            return objResult;
        }

        public static IDictionary<string, Object> getReviewerCommentsByVersion(string processFile, string version)
        {

            //version = getLastVersion(processFile).ToString();

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from jobtrans where version='" + version + "'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
                DataTable records = (DataTable)objResult["data"];

                for (int i = 0; i < records.Rows.Count; i++)
                {
                    records.Rows[i]["commenttoauthor"] = IOUtil.Base64Decode(records.Rows[i]["commenttoauthor"].ToString());
                    records.Rows[i]["commenttoeditor"] = IOUtil.Base64Decode(records.Rows[i]["commenttoeditor"].ToString());
                    records.Rows[i]["authorresponse"] = IOUtil.Base64Decode(records.Rows[i]["authorresponse"].ToString());
                }
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static int getLastVersion(string processFile)
        {
            int lastVersion = 0;
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select ifnull(max(version), 0) as lastversion from mshistory where role = 'au'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
                DataTable records = (DataTable)objResult["data"];

                if (records.Rows.Count > 0)
                {
                    lastVersion = Convert.ToInt32(records.Rows[0]["lastversion"]);

                }
            }
            catch (Exception ex)
            {

            }

            return lastVersion;
        }


        public static IDictionary<string, Object> manageVersionBackup(string processFile, string xmlContent, string role, string uid, string stage)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();
            int resultVersion = 0;
            string backupFileName = String.Empty;

            resultVersion = getLastVersion(processFile);

            if (role == "au")
            {
                resultVersion = resultVersion + 1;

            }

            backupFileName = processFile + "/digihtml/tx2_" + role + "_" + uid + "_" + resultVersion + ".xhtml";

            updateMsHistory(processFile, stage, role, uid, resultVersion.ToString(), backupFileName);

            XMLUtil.saveContent(backupFileName, xmlContent);


            objResult.Add("version", resultVersion);
            objResult.Add("file", backupFileName);

            return objResult;
        }

        public static void checkAndUpdateAuthorResponse(SaveAllContentModel saveAllContent, string version)
        {
            try
            {
                if (saveAllContent.role == "au" && saveAllContent.stage == "revision")
                {
                    //List<AuthorResponse> auResponseList = new List<AuthorResponse>();

                    string aResponse = saveAllContent.authorResponse;
                    aResponse = Regex.Replace(aResponse, @"\\", "");

                    dynamic jsonObj = JsonConvert.DeserializeObject(saveAllContent.authorResponse);


                    JArray auResponseList = JArray.Parse(jsonObj);

                    foreach (var auResponse in auResponseList)
                    {

                        updateAuthorResponse(saveAllContent.processFile, saveAllContent.uid, auResponse["reviewerId"].ToString(), auResponse["response"].ToString(), version.ToString());

                    }

                }
            }
            catch (Exception ex)
            {

            }
        }


        public static IDictionary<string, Object> getAllAnnotPlaceHolder(string processFile, string user_id, string version)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from annotations where parentid ='" + user_id + @"'  and refId='" + version + @"' and ifnull(isdeleted, '0') = '0'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }

        public static IDictionary<string, Object> deleteAnnotPlaceHolder(string processFile, string id)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            //string selectQuery = @"select * from annotations where id=" + id;

            string updateQuery = "update annotations ";
            updateQuery += "set ";
            updateQuery += "isdeleted = 1, ";
            updateQuery += "deletetime='" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "' ";
            updateQuery += "where ";
            updateQuery += "id = " + "'" + id + "'";

            try
            {
                objResult = SQLLite.execute(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> deleteAnnotPlaceHolderBySpanId(string processFile, string spanId)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            //string selectQuery = @"select * from annotations where id=" + id;

            string updateQuery = "update annotations ";
            updateQuery += "set ";
            updateQuery += "isdeleted = 1, ";
            updateQuery += "deletetime='" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "' ";
            updateQuery += "where ";
            updateQuery += "position = " + "'" + spanId + "'";

            try
            {
                objResult = SQLLite.execute(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> insertAnnotPlaceHolder(string processFile, string id, string position, string comment, string name, string refId, string info)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string insertQuery = "insert into annotations ";
            insertQuery += "(";
            insertQuery += "position, ";
            insertQuery += "comment, ";
            insertQuery += "name, ";
            insertQuery += "createtime, ";
            insertQuery += "parentid, ";
            insertQuery += "refid, ";
            insertQuery += "info ";
            insertQuery += ")";
            insertQuery += " values ";
            insertQuery += "(";
            insertQuery += "'" + position + "', ";
            insertQuery += "'" + comment + "', ";
            insertQuery += "'" + name + "', ";
            insertQuery += "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "', ";
            insertQuery += "'" + id + "', ";
            insertQuery += "'" + refId + "', ";
            insertQuery += "'" + info + "'";
            insertQuery += ")";

            try
            {
                objResult = SQLLite.executeWithRowId(insertQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }






    }
}
