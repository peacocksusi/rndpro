﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;

namespace DIGIServe
{
	public class XMLUtil
	{
		public static IDictionary<string, Object> read(string xmlPath)
		{

			IDictionary<string, Object> objResult = new Dictionary<string, Object>();


			try
			{
                /* XmlDocument xmldoc = new XmlDocument();
		               xmldoc.PreserveWhitespace = true;
		               XmlReaderSettings readerSettings = new XmlReaderSettings();
		               readerSettings.IgnoreComments = true;
		               readerSettings.ValidationType = ValidationType.DTD;
		               XmlReader reader = XmlReader.Create(xmlPath, readerSettings);*/
                Config _config = new Config();
                string xmlRoot = _config.getValueFor("RootFolder");
                string xmlHost = _config.getValueFor("XMLHost");

                XmlTextReader reader = new XmlTextReader(xmlRoot + @"\" + xmlPath);

                reader.Read();
                string xmlText = reader.ReadOuterXml();


                string imgHost = xmlHost + Path.GetDirectoryName(xmlPath) + @"/";

				imgHost = Regex.Replace(imgHost, @"\\", "/");
                xmlText = Regex.Replace(xmlText, "(<img[^<>]*src=\")([^\"]+\")", "$1" + imgHost + "$2");



                objResult.Add("Status", "1");
                objResult.Add("xml", xmlText);
                objResult.Add("msg", "Loaded sucessfully");
                reader.Close();
            }
			catch (Exception ex)
			{
				objResult.Add("ErrStatus", "1");
				objResult.Add("xml", "");
				objResult.Add("msg", ex.Message);
			}

			return objResult;
		}

		/*public static IDictionary<string, object> read(string xmlPath)
		{
			IDictionary<string, object> dictionary = (IDictionary<string, object>)new Dictionary<string, object>();
			try
			{
				Config config = new Config();
				string valueFor1 = config.getValueFor("RootFolder");
				string valueFor2 = config.getValueFor("XMLHost");
				XmlTextReader xmlTextReader = new XmlTextReader(valueFor1 + "\\" + xmlPath);
				xmlTextReader.Read();
				string input = xmlTextReader.ReadOuterXml();
				string directoryName = Path.GetDirectoryName(xmlPath);
				string str1 = valueFor2 + directoryName + "/";
				string str2 = Regex.Replace(input, "(<img[^<>]*src=\")([^\"]+\")", "$1" + str1 + "$2");
				dictionary.Add("Status", (object)"1");
				dictionary.Add("xml", (object)str2);
				dictionary.Add("msg", (object)"Loaded sucessfully");
				xmlTextReader.Close();
			}
			catch (Exception ex)
			{
				dictionary.Add("ErrStatus", (object)"1");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)ex.Message);
			}
			return dictionary;
		}*/


		public static IDictionary<string, Object> readNote(string xmlPath)
		{

			IDictionary<string, Object> objResult = new Dictionary<string, Object>();


			try
			{

				Config _config = new Config();
				string xmlRoot = _config.getValueFor("RootFolder");

				string noteFile = xmlRoot + @"\" + xmlPath + @"\note1.txt";

				string notText = File.ReadAllText(noteFile);



				objResult.Add("Status", "1");
				objResult.Add("xml", notText);
				objResult.Add("msg", "Loaded sucessfully");

			}
			catch (Exception ex)
			{
				objResult.Add("ErrStatus", "1");
				objResult.Add("xml", "");
				objResult.Add("msg", ex.Message);
			}

			return objResult;
		}


		public static IDictionary<string, Object> saveNotes(string xmlPath, string noteText)
		{

			IDictionary<string, Object> objResult = new Dictionary<string, Object>();


			try
			{


				Config _config = new Config();
				string xmlRoot = _config.getValueFor("RootFolder");



				File.WriteAllText(xmlRoot + @"\" + xmlPath + @"\note1.txt", noteText);

				objResult.Add("Status", "1");
				objResult.Add("xml", "");
				objResult.Add("msg", "saved sucessfully");
			}
			catch (Exception ex)
			{
				objResult.Add("ErrStatus", "0");
				objResult.Add("xml", "");
				objResult.Add("msg", ex.Message);
			}

			return objResult;
		}

		public static IDictionary<string, Object> saveXML(string xmlPath, string xml)
		{

			IDictionary<string, Object> objResult = new Dictionary<string, Object>();


			try
			{


				Config _config = new Config();
				string xmlRoot = _config.getValueFor("RootFolder");

				xml = cleanXML(xml);

				File.WriteAllText(xmlRoot + @"\" + xmlPath, xml);

				objResult.Add("Status", "1");
				objResult.Add("xml", "");
				objResult.Add("msg", "saved sucessfully");
			}
			catch (Exception ex)
			{
				objResult.Add("ErrStatus", "0");
				objResult.Add("xml", "");
				objResult.Add("msg", ex.Message);
			}

			return objResult;
		}


		public static IDictionary<string, object> saveDecision(string xPath, string json)
		{
			IDictionary<string, object> dictionary = (IDictionary<string, object>)new Dictionary<string, object>();
			try
			{
				File.WriteAllText(new Config().getValueFor("RootFolder") + "\\" + xPath, json);
				dictionary.Add("Status", (object)"1");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)"saved sucessfully");
			}
			catch (Exception ex)
			{
				dictionary.Add("ErrStatus", (object)"0");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)ex.Message);
			}
			return dictionary;
		}

		public static IDictionary<string, object> readFile(string xPath)
		{
			IDictionary<string, object> dictionary = (IDictionary<string, object>)new Dictionary<string, object>();
			try
			{
				string str = File.ReadAllText(new Config().getValueFor("RootFolder") + "\\" + xPath);
				dictionary.Add("Status", (object)"1");
				dictionary.Add("xml", (object)str);
				dictionary.Add("msg", (object)"saved sucessfully");
			}
			catch (Exception ex)
			{
				dictionary.Add("ErrStatus", (object)"0");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)ex.Message);
			}
			return dictionary;
		}

		public static IDictionary<string, object> saveContent(string xPath, string content,bool isBackup=false)
		{
			IDictionary<string, object> dictionary = (IDictionary<string, object>)new Dictionary<string, object>();
			try
			{
                Config _config = new Config();
                string xmlHost = _config.getValueFor("XMLHost");
                string imgHost = xmlHost + Path.GetDirectoryName(xPath) + @"/";
                content = Regex.Replace(content, "src=\"[^\"]+/img", "src=\"img");

                if (isBackup == true && File.Exists(_config.getValueFor("RootFolder") + "\\" +xPath))
                {
					string fileName = Path.GetFileNameWithoutExtension(xPath)+DateTime.Now.ToString("_dd_MM_yyy_hh_mm_ss")+Path.GetExtension(xPath);
					string basePath = Path.GetDirectoryName(xPath);

					string xmlText = File.ReadAllText(_config.getValueFor("RootFolder") + "\\" + xPath);
					File.WriteAllText(_config.getValueFor("RootFolder") + "\\" + Path.Combine(basePath, fileName), xmlText);

					//File.Copy(_config.getValueFor("RootFolder") + "\\" + xPath,Path.Combine(basePath,fileName));
                }
                File.WriteAllText(new Config().getValueFor("RootFolder") + "\\" + xPath, content);
				dictionary.Add("Status", (object)"1");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)"saved sucessfully");
			}
			catch (Exception ex)
			{
				dictionary.Add("ErrStatus", (object)"0");
				dictionary.Add("xml", (object)"");
				dictionary.Add("msg", (object)ex.Message);
			}
			return dictionary;
		}

        public static string cleanAnnotation(string xmlText)
        {
            string outXml = String.Empty;
            try
            {
                outXml = xmlText;
                //Regex mathAjax = new Regex("<div id=\"MathJax_Message\"[^<>]*>[^<>]*</div>[\n\r]*");
                //Regex styleLt = new Regex("<link[^<>]*/>");
                //outXml = mathAjax.Replace(outXml, "");

                outXml = Regex.Replace(outXml, "<span class=\"note annot[^>]+>([^<>]+)</span>", "$1");
            }
            catch (Exception ex)
            {
                outXml = xmlText;
            }

            return outXml;

        }
        public static string cleanXML(string xmlText)
		{
			string outXml = String.Empty;
			try
			{
				outXml = xmlText;
				Regex mathAjax = new Regex("<div id=\"MathJax_Message\"[^<>]*>[^<>]*</div>[\n\r]*");
				Regex styleLt = new Regex("<link[^<>]*/>");
				outXml = mathAjax.Replace(outXml, "");
			}
			catch (Exception ex)
			{
				outXml = xmlText;
			}

			return outXml;

		}
	}
}
