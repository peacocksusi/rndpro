﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
//using DataAccessLayer;


namespace DIGIServe
{
    public class SqlHelper
    {
        
        public string strDBConnection = String.Empty; 

        public string executeScalar(string storedProcName, IDictionary<string, object> args, QueryType qType)
        {
            string strResult;
            using (SqlConnection conn = new SqlConnection(strDBConnection))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = storedProcName;
                if (qType == QueryType.StoredProcedure)
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                else
                    cmd.CommandType = System.Data.CommandType.Text;

                foreach (KeyValuePair<string, object> kvp in args)
                {
                    cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }

                conn.Open();
                strResult = cmd.ExecuteScalar().ToString();
                conn.Close();
            }
            return strResult;
        }
        public string executeQuery(string strQuery, IDictionary<string, object> args, QueryType qType)
        {
            string strResult;
            try
            {
                using (SqlConnection conn = new SqlConnection(strDBConnection))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = strQuery;
                    if (qType == QueryType.StoredProcedure)
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    else
                        cmd.CommandType = System.Data.CommandType.Text;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    strResult = "OK";
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                strResult = "Error:" + ex.Message;
            }
            return strResult;
        }
        public DataTable getDataTable(string strQueryText, IDictionary<string, object> args, QueryType qType)
        {

            string strResult = string.Empty;
            DataTable objDt = new DataTable();

            SqlDataAdapter da = new SqlDataAdapter();
            using (SqlConnection conn = new SqlConnection(strDBConnection))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = strQueryText;
                if (qType == QueryType.StoredProcedure)
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                else
                    cmd.CommandType = System.Data.CommandType.Text;
                foreach (KeyValuePair<string, object> kvp in args)
                {
                    cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }

                SqlParameter parm2 = new SqlParameter("@Result", SqlDbType.VarChar);
                parm2.Size = -1;
                parm2.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(parm2);

                conn.Open();
                da = new SqlDataAdapter(cmd);
                da.Fill(objDt);
                strResult = Convert.ToString(cmd.Parameters["@Result"].Value);
                conn.Close();

                if (strResult.StartsWith("1|") || strResult == "")
                    return objDt;
                else
                {
                    string strException = strResult.Replace("|", ", ");
                    throw new Exception(strException);

                }

            }
        }

        public DataSet getDataSet(string strQueryText, IDictionary<string, object> args, QueryType qType)
        {
            string strResult = string.Empty;
            DataSet objDs = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter();
            using (SqlConnection conn = new SqlConnection(strDBConnection))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = strQueryText;
                if (qType == QueryType.StoredProcedure)
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                else
                    cmd.CommandType = System.Data.CommandType.Text;
                foreach (KeyValuePair<string, object> kvp in args)
                {
                    cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                }

                SqlParameter parm2 = new SqlParameter("@Result", SqlDbType.VarChar);
                parm2.Size = -1;
                parm2.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(parm2);

                conn.Open();
                da = new SqlDataAdapter(cmd);
                da.Fill(objDs);
                strResult = Convert.ToString(cmd.Parameters["@Result"].Value);
                conn.Close();

                if (strResult.StartsWith("1|"))
                    return objDs;
                else
                {
                    string strException = strResult.Replace("|", ", ");
                    throw new Exception(strException);

                }
            }

        }

        public string executeProceWithOutput(string strQueryText, IDictionary<string, object> args, QueryType qType)
        {
            string strResult = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(strDBConnection))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = strQueryText;
                    if (qType == QueryType.StoredProcedure)
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    else
                        cmd.CommandType = System.Data.CommandType.Text;
                    foreach (KeyValuePair<string, object> kvp in args)
                    {
                        cmd.Parameters.AddWithValue(kvp.Key, kvp.Value);
                    }

                    SqlParameter parm2 = new SqlParameter("@Result", SqlDbType.VarChar);
                    parm2.Size = -1;
                    parm2.Direction = ParameterDirection.Output;

                    cmd.Parameters.Add(parm2);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    strResult = Convert.ToString(cmd.Parameters["@Result"].Value);
                    conn.Close();

                    if (strResult.StartsWith("1|"))
                        return strResult;
                    else
                    {
                        string strException = strResult.Replace("|", ", ");
                        throw new Exception(strException);

                    }
                }
            }
            catch (Exception ex)
            {
                strResult = "Error:" + ex.Message;
            }
            return strResult;
        }

    }
    public enum QueryType
    {
        StoredProcedure,
        Text
    };
}
