﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIGIServe
{
   public class Annotation
    {
        public static IDictionary<string, Object> getAll(string processFile)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from annotations where ifnull(isdeleted, '0') = '0'";

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }

        public static IDictionary<string, Object> getById(string processFile, string id)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            string selectQuery = @"select * from annotations where id=" + id;

            try
            {
                objResult = SQLLite.select(selectQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }

        public static IDictionary<string, Object> delete(string processFile, string id)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            //string selectQuery = @"select * from annotations where id=" + id;

            string updateQuery = "update annotations ";
            updateQuery += "set ";
            updateQuery += "isdeleted = 1, ";
            updateQuery += "deletetime='" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "' ";
            updateQuery += "where ";
            updateQuery += "id = " + "'" + id + "'";

            try
            {
                objResult = SQLLite.execute(updateQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }


        public static IDictionary<string, Object> insert(string processFile, string id, string position, string comment,string name, string refId, string info)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();
        
            string insertQuery = "insert into annotations ";
            insertQuery += "(";
            insertQuery += "position, ";
            insertQuery += "comment, ";
            insertQuery += "name, ";
            insertQuery += "createtime, ";
            insertQuery += "parentid, ";
            insertQuery += "refid, ";
            insertQuery += "info ";
            insertQuery += ")";
            insertQuery += " values ";
            insertQuery += "(";
            insertQuery += "'" + position + "', ";
            insertQuery += "'" + comment + "', ";
            insertQuery += "'" + name + "', ";
            insertQuery += "'" + DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt") + "', ";
            insertQuery += "'" + id + "', ";
            insertQuery += "'" + refId + "', ";
            insertQuery += "'" + info + "'";
            insertQuery += ")";

            try
            {
                objResult = SQLLite.executeWithRowId(insertQuery, IOUtil.getDBConnection(processFile));
            }
            catch (Exception ex)
            {

            }

            return objResult;
        }
    }
}
