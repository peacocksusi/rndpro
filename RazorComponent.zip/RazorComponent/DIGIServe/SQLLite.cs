﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Text;

namespace DIGIServe
{
    class SQLLite
    {
        public static IDictionary<string, Object> select(string query, string dbConn)
        {
            DataTable _data = new DataTable();
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            using (SQLiteConnection conn = new SQLiteConnection(dbConn))
            {
                using (SQLiteCommand cmd = new SQLiteCommand())
                {
                    conn.Open();
                    cmd.Connection = conn;

                    SQLiteHelper sh = new SQLiteHelper(cmd);

                    try
                    {
                        _data = sh.Select(query);
                        objResult.Add("status", "1");
                        objResult.Add("msg", "success");

                    }
                    catch (Exception ex)
                    {
                        objResult.Add("status", "0");
                        objResult.Add("msg", ex.Message);
                        Log.wrtie("QUERY:" + query + Environment.NewLine + "ERROR:" + ex.Message);
                    }

                    conn.Close();
                }
            }

            objResult.Add("data", _data);
            return objResult;
        }

        public static IDictionary<string, Object> execute(string query, string dbConn)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            using (SQLiteConnection conn = new SQLiteConnection(dbConn))
            {
                using (SQLiteCommand cmd = new SQLiteCommand())
                {
                    conn.Open();
                    cmd.Connection = conn;

                    SQLiteHelper sh = new SQLiteHelper(cmd);

                    try
                    {
                        sh.Execute(query);
                        objResult.Add("status", "1");
                        objResult.Add("msg", "success");
                    }
                    catch (Exception ex)
                    {
                        objResult.Add("status", "0");
                        objResult.Add("msg", ex.Message);
                    }

                    conn.Close();
                }
            }

            return objResult;
        }

        public static IDictionary<string, Object> executeWithRowId(string query, string dbConn)
        {
            IDictionary<string, Object> objResult = new Dictionary<string, Object>();

            using (SQLiteConnection conn = new SQLiteConnection(dbConn))
            {
                using (SQLiteCommand cmd = new SQLiteCommand())
                {
                    conn.Open();
                    cmd.Connection = conn;

                    SQLiteHelper sh = new SQLiteHelper(cmd);

                    try
                    {
                        sh.Execute(query);
                        objResult.Add("status", "1");
                        objResult.Add("msg", "success");
                        objResult.Add("lastRowId", sh.LastInsertRowId().ToString());
                    }
                    catch (Exception ex)
                    {
                        objResult.Add("status", "0");
                        objResult.Add("msg", ex.Message);
                        objResult.Add("lastRowId", "");
                    }

                    conn.Close();
                }
            }

            return objResult;
        }
    }
}
