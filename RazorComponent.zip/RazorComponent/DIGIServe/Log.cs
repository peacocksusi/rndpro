﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DIGIServe
{
    public class Log
    {
        public static void wrtie(string messsage)
        {
            Config _config = new Config();
            try
            {
                var log = Environment.NewLine;
                log += "======================================================";
                log += "DATE:" + DateTime.Now;
                log += Environment.NewLine;
                log += messsage;
                log += "======================================================";
                log += Environment.NewLine;

                if (File.Exists(_config.getValueFor("LogFile")))
                {
                    File.AppendAllText(_config.getValueFor("LogFile"), log);
                }
                else
                {
                    File.WriteAllText(_config.getValueFor("LogFile"), log);
                    
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
