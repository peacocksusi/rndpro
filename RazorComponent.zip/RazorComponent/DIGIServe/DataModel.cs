﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIGIServe
{
    public class EditorModel
    {
        public string xmlContent { get; set; }
        public string xmlPath { get; set; }
        public string uid { get; set; }
    }

    public class SaveAllContentModel
    {
        public string xmlContent { get; set; }
        public string xmlPath { get; set; }
        public bool isAutoSave { get; set; }
        public bool isAutoSaveBackup { get; set; }
        public string uid { get; set; }
        public string role { get; set; }
        public string stage { get; set; }
        public bool isSubmitted { get; set; }
        public string commentToAuthor { get; set; }
        public string commentToEditor { get; set; }
        public string authorResponse { get; set; }
        public string processFile { get; set; }

    }

    public class AuthorResponse
    {
        public string reviewerId { get; set; }
        public string response { get; set; }
    }
}
