﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace DIGIServe
{
    public class AWSRequest
    {
        public static async Task<string> downloadToLocal(string fileId, string fileKey, string repositoryCode) {
            string result = String.Empty;

            IDictionary<string, Object> objResult = new Dictionary<string, Object>();
            try
            {

                string data = @"{""FileName"":" + fileId + @",""FilePath"":" + fileKey +  @",""repositoryCode"" :"  + repositoryCode + "}";
                string fileName = "";
                string contentType = "application/json";
                //string method = "POST";

                HttpClient httpclinet = new HttpClient();
                byte[] dataBytes = Encoding.UTF8.GetBytes(data);

                var stringContent = new StringContent(data, Encoding.UTF8, contentType);
                Config config = new Config();
                HttpResponseMessage response = await httpclinet.PostAsync(config.getValueFor("AWSApi"), stringContent);

                if (response.IsSuccessStatusCode)
                {
                    var stream = await response.Content.ReadAsStreamAsync();
                    
                    //StreamFormFile formFile = new StreamFormFile(stream, "inputfile", fileName, stream.Length);
                    //return formFile;
                    //return stream.ToString();

                }

                //return null;

                //objResult.Add("status", "1");
                //objResult.Add("msg", "success");

                result = "success";

            }
            catch (Exception ex)
            {

                result = ex.Message;
                //objResult.Add("status", "0");
                //objResult.Add("msg", ex.Message);
            }

            return result;
        }
    }
}
