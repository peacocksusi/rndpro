﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiEditRazorLibrary.Class
{
    public class AppProperties
    {
        public string editorId = "manuscriptView";
        public string prcoessFile { get; set; }

        public string fileId { get; set; }

        public string fileKey { get; set; }

        public string cUserName { get; set; }

        public string cUserID { get; set; }
        public string cRole { get; set; }
        public string stage { get; set; }

        public bool trackChanges = false;
        public static string api { get; set; }

        public IDictionary<string, Object> props = new Dictionary<string, Object>();


    }
}
