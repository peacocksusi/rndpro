﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DigiEditRazorLibrary.Class
{
    public class APIRequest
    {
        public static async Task<string> PostAsync(string uri, string data = "", string contentType = "text/plain", string method = "POST")
        {

            try
            {
                HttpClient httpclinet = new HttpClient();
                byte[] dataBytes = Encoding.UTF8.GetBytes(data);

                var stringContent = new StringContent(data, Encoding.UTF8, contentType);
                
                HttpResponseMessage response = await httpclinet.PostAsync(uri, stringContent);

                if (response.IsSuccessStatusCode)
                {
                    var stream = await response.Content.ReadAsStreamAsync();
                    StreamReader readStream = new StreamReader(stream, Encoding.UTF8);
                    return readStream.ReadToEnd();
                }
                else {
                    return "Failed";
                }
            }
            catch (Exception ex)
            {
                return ex.Message + uri;
            }
        }

        public static async Task<string> GetAsync(string uri)
        {
            try
            {
                HttpClient httpclinet = new HttpClient();
                HttpResponseMessage response = await httpclinet.GetAsync(uri);

                if (response.IsSuccessStatusCode)
                {
                    var stream = await response.Content.ReadAsStreamAsync();
                    StreamReader readStream = new StreamReader(stream, Encoding.UTF8);
                    return readStream.ReadToEnd();
                }
                else
                {
                    return "Failed";
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }





    }
}
