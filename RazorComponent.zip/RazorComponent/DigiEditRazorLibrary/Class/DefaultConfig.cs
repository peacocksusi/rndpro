﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DigiEditRazorLibrary.Class
{
    public class DefaultConfig
    {

        public static string API_URL = "https://localhost:44371";
        public readonly static string API_PATH = "/Editor";
        public readonly static string COLLAB_PATH = "/Collab";
        public readonly static string ANNOT_PATH = "/Annotation";
        public readonly static string FSO_PATH = "/FSO";
        public readonly static string FETCH_XML = API_PATH + "/readXML/?xmlPath=";
        public readonly static string WRITE_XML = API_PATH + "/writeXml/";
        public readonly static string READ_FILE = API_PATH + "/ReadFile?xPath={xPath}";
        public readonly static string WRITE_NOTE = API_PATH + "/writeFullNote/";
        public readonly static string SAVE_DESCISION = API_PATH + "/SaveDecision/";
        public readonly static string SAVE_ALL = API_PATH + "/saveAllContent/";
        public readonly static string GET_FILES = FSO_PATH + "/GetFileNamesByDirectoryPath?processFile={processFile}&baseDirName={baseDirName}";
        public readonly static string GET_REVIEWER_COMMENTS = API_PATH + "/getReviewerComment?processFile={processFile}&reviewby={reviewby}&version={version}";
        public readonly static string GET_ALL_REVIEWER_COMMENTS = API_PATH + "/getAllReviewerComment?processFile={processFile}&version={version}";
        public readonly static string GET_PREVIOUS_VERSION_LIST = API_PATH + "/getPreviousVersionList?processFile={processFile}&uid={uid}";
        public readonly static string GET_LAST_VERSION = API_PATH + "/GetLastVersion?processFile={processFile}";
        public readonly static string UPDATE_AUTHOR_RESPONSE = API_PATH + "/UpdateAuthorResponse?processFile={processFile}&auhtorId={auhtorId}&reviwerId={reviwerId}&authorResponse={authorResponse}&version={version}";
        public readonly static string SAVE_ANNOT_PLACE_HOLDER = ANNOT_PATH + "/insertAnnotPlaceHolder?processFile={processFile}&id={id}&position={position}&comment={comment}&name={name}&refId={refId}&info={info}";
        public readonly static string GET_ANNOT_PLACE_HOLDER = ANNOT_PATH + "/getAnnotPHAll?processFile={processFile}&user_id={user_id}&version={version}";
        public readonly static string DEL_ANNOT_PLACE_HOLDER = ANNOT_PATH + "/deleteAnnotPlaceHolder?processFile={processFile}&spanId={spanId}";
        public readonly static string PROCCESS_FILE_NAME = "/digihtml/tx2.xhtml";

        public readonly static int AUTO_SAVE_TIME_INTERVAL = 5 * (1000 * 60); //5 Minuts;
        public readonly static int AUTO_SAVE_LIMIT = 3;

        public readonly static string REVIEWER_GUIDELINE_URL = "https://www.mpslimited.com/";
        public readonly static string RELATED_LITERATURE_URL = "https://www.w3schools.com/js/js_exercises.asp";

        public readonly static string ROOT_JS = "";

        public static string getRootScript()
        {
            return ROOT_JS;
        }

    }
}
