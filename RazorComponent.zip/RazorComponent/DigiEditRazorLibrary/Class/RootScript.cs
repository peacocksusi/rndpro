﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace DigiEditRazorLibrary.Class
{
    public class RootScript
    {
        static string loadJsScript = @"function loadJs(sourceUrl)
        {
            if (sourceUrl.Length == 0)
            {
                console.error('Invalid source URL');
                return;
            }

            var tag = document.createElement('script');
            tag.src = sourceUrl;
            tag.type = 'text/javascript';

            tag.onload = function() {
                console.log('Script loaded successfully');
            }

            tag.onerror = function() {
                console.error('Failed to load script');
            }
            document.body.appendChild(tag);
        }";


        public static string run()
        {

            return loadJsScript + "loadJs('" + DefaultConfig.getRootScript() + "')";
        }

    }
}
