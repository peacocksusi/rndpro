﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DigiEditRazorLibrary.Class
{
    public class DigiWrapper
    {


        public static async Task<string> getAssociateFiles(AppProperties appProperties)
        {

            try
            {
                string url = appProperties.props["api"].ToString() + DefaultConfig.GET_FILES;
                url = url.Replace("{processFile}", appProperties.props["fileKey"].ToString());
                url = url.Replace("{baseDirName}", "AssosiateFileFolder");
                string result = await APIRequest.GetAsync(url);
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static async Task<string> getXHTML(AppProperties props)
        {

            try
            {
                string url = props.fileKey + AppProperties.api + "test url"+ DefaultConfig.READ_FILE;
                url += props.fileKey;
                string result = await APIRequest.PostAsync(url);
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }


        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

    }
}
