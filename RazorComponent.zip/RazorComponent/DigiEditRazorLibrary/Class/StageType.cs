﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiEditRazorLibrary.Class
{
    public class StageType
    {
        public static string Submission = "submission";
        public static string Revision = "revision";
    }
}
