﻿




export default class CkEditorObj {

    editorInstance = null;

    init(callBack, isTrackChange) {

        if (CKEDITOR.env.ie && CKEDITOR.env.version < 9)
            CKEDITOR.tools.enableHtml5Elements(document);


        CKEDITOR.config.width = 'auto';

        var wysiwygareaAvailable = this.isWysiwygareaAvailable(),
            isBBCodeBuiltIn = !!CKEDITOR.plugins.get('bbcode');
        var editorElement = CKEDITOR.document.getById('manuscriptView');

        // :(((
        if (isBBCodeBuiltIn) {
            editorElement.setHtml(

            );
        }

        if (wysiwygareaAvailable) {
            var removePluginsItem = 'magicline';

            if (isTrackChange == 'false') {
                removePluginsItem += ',lite';
                //CKEDITOR.replace('manuscriptView', {
                //  removePlugins: 'lite,magicline'
                //});
            }

            if (DigiEdit.props.readonly == 'true') {
                removePluginsItem += ',tableselection,tabletools,contextmenu';
            }
            //else {
            // CKEDITOR.replace('manuscriptView', {
            //   removePlugins: 'magicline'
            //});
            //}


            CKEDITOR.replace('manuscriptView', {
                removePlugins: removePluginsItem
            });

            //nanospell.ckeditor('manuscriptView', {
            //    dictionary: "en",   
            //    server: "asp.net"      
            //}); 

            CKEDITOR.on('instanceReady', function (obj) {
                callBack(obj);
            });

            CKEDITOR.on('change', function () {

            });
        }
        else {
            editorElement.setAttribute('contenteditable', 'true');
            CKEDITOR.inline('editor');
        }

    };

    isWysiwygareaAvailable() {
        // If in development mode, then the wysiwygarea must be available.
        // Split REV into two strings so builder does not replace it :D.
        if (CKEDITOR.revision == ('%RE' + 'V%')) {
            return true;
        }

        return !!CKEDITOR.plugins.get('wysiwygarea');
    }

}
