﻿import CkEditorObj from './js/ckeditor.js';
import toast from './DIGIClient/Toast.js';

