﻿



setTimeout(function () {

    $(function () {

        $("body").on("click", ".note", function () {

            var _id = $(this).attr('id');
            var iFrame = window.parent.document;
            var para = iFrame.getElementById('annot_' + _id);
            $(para).focus();
            var offsetTop = para.offsetTop;
            para.className += ' blink_me';

            setTimeout(function () {
                var elem = iFrame.getElementsByClassName('blink_me');
                for (var i = 0; i < elem.length; i++) {
                    var cssName = elem[i].className;
                    cssName = cssName.replace(/[ ]*blink_me/, '');
                    elem[i].className = cssName;
                }
            }, 1500)

            //$(iFrame).contents().scrollTop(offsetTop);
        });



        $("span.extlink, span.weblink, span.doi").click(function () {
            var redirectTo = $(this).attr("href");
            window.open(redirectTo);
        });


        /*window.WEBSPELLCHECKER_CONFIG = {
            autoSearch: true,

        };*/


    });


}, 2000);
