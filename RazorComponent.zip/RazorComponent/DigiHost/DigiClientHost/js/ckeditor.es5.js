﻿'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

if (CKEDITOR.env.ie && CKEDITOR.env.version < 9) CKEDITOR.tools.enableHtml5Elements(document);

// The trick to keep the editor in the sample quite small
// unless user specified own height.
//CKEDITOR.config.height = window.innerHeight;
CKEDITOR.config.width = 'auto';

var CkEditorObj = (function () {
    function CkEditorObj() {
        _classCallCheck(this, CkEditorObj);
    }

    _createClass(CkEditorObj, [{
        key: 'init',
        value: function init(callBack, isTrackChange) {
            var wysiwygareaAvailable = this.isWysiwygareaAvailable(),
                isBBCodeBuiltIn = !!CKEDITOR.plugins.get('bbcode');
            var editorElement = CKEDITOR.document.getById('manuscriptView');

            // :(((
            if (isBBCodeBuiltIn) {
                editorElement.setHtml();
            }

            if (wysiwygareaAvailable) {
                if (isTrackChange == 'false') {
                    CKEDITOR.replace('manuscriptView', {
                        removePlugins: 'lite,magicline'
                    });
                } else {
                    CKEDITOR.replace('manuscriptView', {
                        removePlugins: 'magicline'
                    });
                }

                CKEDITOR.on('instanceReady', function (obj) {
                    callBack();
                });

                CKEDITOR.on('change', function () {});
            } else {
                editorElement.setAttribute('contenteditable', 'true');
                CKEDITOR.inline('editor');
            }
        }
    }, {
        key: 'isWysiwygareaAvailable',
        value: function isWysiwygareaAvailable() {
            // If in development mode, then the wysiwygarea must be available.
            // Split REV into two strings so builder does not replace it :D.
            if (CKEDITOR.revision == '%RE' + 'V%') {
                return true;
            }

            return !!CKEDITOR.plugins.get('wysiwygarea');
        }
    }]);

    return CkEditorObj;
})();

exports['default'] = CkEditorObj;
module.exports = exports['default'];

