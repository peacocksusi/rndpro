﻿
import Split from './js/split.js';
import CkEditorObj from './js/ckeditor.js';
import toast from './DIGIClient/Toast.js';
import editorUtil from './DIGIClient/Util.js';
import apiRequest from './DIGIClient/API.js';
import config from './DIGIClient/Config.js';
import ques from './DIGIClient/Ques.js';
import reviewManager from './DigiClient/ReviewManager.js';
import msgManager from './DIGIClient/MsgManager.js';
import popupTool from './DIGIClient/PopupTool.js';
import defaultConfig from './DIGIClient/Config.js';
import fs from './DIGIClient/FsManger.js';




//var url = windows.location;
//var urlInfo = url.Split('DigiClientHost');
//alert(urlInfo[0]);
//var domainPath = getBasePath('DigiClientHost');

var propDiv = null;
var objCkeditor = new CkEditorObj();
var _assembely = 'DigiEditRazorLibrary';
var controlKey = false;
var dotnetInstance = null;


var editorNoteDocCSS = `
<style>
.editorNote{
    color: #000;
}    
.editorNote::before {
    content: '';
    background-color: transparent;
    border-bottom: none;
    }
</style>
`;

var additionalDocCSS = `
<style id="additionalDocCSS">
.[NOTE] {
	/*color: red;*/
	/*border-bottom: dashed 1px dodgerblue;*/
	cursor: pointer;
    font-style: normal;
    position:relative;
}

.[NOTE]::after {
    content: attr(data-caption);
   /* background: url(../assets/img/anchor.png) no-repeat; */
    background-color: red;
    color: #fff;
    border-radius: 50% / 50%;
    font-size: 6px;
    text-align: center;
    padding: 2px;
    z-index: 11111;
 
    top: -8px;
    min-width: 13px;

    position: absolute;
    display: inline-block;
    vertical-align: middle;
    overflow: none;
    text-decoration: none;
    font-family: "Arial Unicode MS";
    
    text-indent: 0px;
    right: -10px;
    opascity: 0.7;
}

</style>
`;

var popupToolItems = {
    "popupToolMenu1": [
        {
            "id": "annot", "title": "ANNOTATION", "icon": "/images/icons8-comments-50-grey.png", "callback":
                function (e) {
                    window.DigiEdit.addAnnot(e);
                }
        }
    ]
}

var props = {
    "host": '/DigiClientHost',
    "docJS": [
        { 'name': 'CKEDITOR', 'src': '/lib/ckeditor4/ckeditor.js', 'sts': 0, 'isInternal': 1 },
        { 'name': 'CKEDITOR', 'src': '/js/jfun.js', 'sts': 0, 'isInternal': 1 },
        { 'name': 'BOOTSTRAP_JS', 'src': 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js', 'sts': 0, 'isInternal': 0 }
    ],
    "docCSS": [
        { 'name': 'SITE_CSS', 'src': '/css/site.css', 'sts': 0, 'isInternal': 1 },
        //{ 'name': 'SPLIT_CSS', 'src': '/css/split.css', 'sts': 0, 'isInternal': 1 },
        { 'name': 'BOOTSTRAP_CSS', 'src': 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css', 'sts': 0, 'isInternal': 0 }
    ],
    "jsFile": [
        //{ 'src': '../rangy-1.3.1/lib/rangy-core.js', 'sts': 0 },
        //{ 'src': '../rangy-1.3.1/lib/rangy-classapplier.js', 'sts': 0 },
        //{ 'src': '../rangy-1.3.1/lib/rangy-highlighter.js', 'sts': 0 },
        { 'src': '/lib/jquery/dist/jquery.min.js', 'sts': 0 },

        { 'src': '/js/doc.js', 'sts': 0 },
        { 'src': '/DIGIClient/RangeSelection.js', 'sts': 0 }
    ],
    "cssFile": [
        { 'src': '/css/book.css', 'sts': 0 },
        { 'src': '/css/article.css', 'sts': 0 }
    ],
    "quesJSON": "/data/QL.json",
    "leftWidth": 65,
    "rightWidth": 34,
    "view": "",
    "comments": "true",
    "readonly": "false",
    "trackChanges": "",
    "userName": "",
    "role": "",
    "userId": "",
    "stage": "",
    "processFile": "",
    "editorContainerId": "cke_1_contents",
    "editorToolId": "cke_1_top",
    "parentContainer": "digiEdit_Wrapper",
    "editorId": "manuscriptView",
    "baseURI": "",
    "repCode": "",
    "frameTop": 0,
    "saveState": false,
    "authorNotesSelected": true,
    "editorNotesSelected": false,
    "authorNoteCount": 0,
    "editoNoteCount": 0,
    "authorNotes": "",
    "editorNotes": "",
    "autoSaveIndex": 0,
    "cContent": "",
    "isSubmitted": false,
    "isAddStyleLoaded": false,
    "version": 1,
    "reviewers": [0, 0, 0],
    "authorResponse": "",
    "currentSessionId": editorUtil.uuidv4()
}


var setInstance = (function (instance) {
    dotnetInstance = instance;
});


//var getHostPath = (function (baseUrl) {
//    var url = windows.location;
//    var urlInfo = url.Split(baseUrl);

//});


class DigiEdit {

    constructor(props) {
        this.props = props;
        this.mManager = new msgManager();
        this.oPopupTool = null;
        this.hidenseek = (function (key) { hidenseek(key); });
    }

    getProps() {
        return this.props;
    }

    addAnnot = (function (e) {
        this.objReviewManager.addAnnot(e);
    })

    setSync = (function () {
        //this.connection = new signalR.HubConnectionBuilder().withUrl("https://localhost:44366/chathub").build();

        this.connection = new signalR.HubConnectionBuilder().withUrl("http://192.168.26.227/signalr/chatHub").build();



        this.connection.on("ReceiveMessage", function (user, message) {
            //updateMessage(user, message);
            //alert(message);
            addorDeleteAnnotSpan(message);
        });

        this.connection.on("GroupMessage", function (user, message) {
            //updateMessage(user, message);
            // alert(message);

        });

        this.connection.start().then(function () {
            //props.connection.invoke("JoinGroup", props.prcoessFile);
            //props.connection.invoke("AddToRoom", props.prcoessFile, props.cUserID);

        }).catch(function (err) {
            return console.error(err.toString());
        });

    });

    getPropsByKey(key) {

        //var val = DotNet.invokeMethodAsync('DigiEditRazorLibrary', 'getProps',  'test');
        //window.getProps(key);
    }

    showLoading() {
        var _loader = document.querySelector('#prograssBar');
        _loader.className = '';
    }

    hideLoading() {
        var _timeHandler = setTimeout(function () {
            var _loader = document.querySelector('#prograssBar');
            _loader.className = _loader.className + 'hideAnimate';
        }, 250)
    }

    showDocError(msg) {
        var _doc_error = document.querySelector('#doc_error');
        //_loader.className = '';
        _doc_error.style.display = 'block';
        _doc_error.innerHTML = '<div class="digi_err_detail">' + msg + '</div>';
        this.mManager.showMessage("9999", false, null);
    }


    loadDoc() {
        try {

            DotNet.invokeMethodAsync(_assembely, 'getDoc', props.baseURI, props.processFile, props.repCode).then(function (data) {


                var editorElement = document.getElementById(props.editorId);
                try {

                    var docInfo = JSON.parse(data);
                    var status = docInfo.Status;
                    var xml = docInfo.xml;
                    if (Number(status) == 1) {
                        editorElement.innerHTML = xml;
                    }
                    else {
                        window.DigiEdit.showDocError(docInfo.msg);
                    }
                }
                catch (e) {
                    console.log(e);
                    window.DigiEdit.showDocError(e);
                }

                objCkeditor.init(window.DigiEdit.editorLoadCompleted, props.trackChanges);

            });

        }
        catch (e) {
            console.log(e);
            window.DigiEdit.showDocError(e);
        }

    }


    checkAndLoadDoc = (function () {
        var status = false;
        /*while (status == false) {
            var ck = props.docJS.find(ck => ck.name == "CKEDITOR");
            if (ck.sts == 1) {
                loadDoc();
                status = true;
            }
        }*/
        ques.getDecisionList();
        var timeOutHandle = setTimeout(function () {
            window.DigiEdit.loadDoc();
        }, 3000);

    });

    showAssociateFileDialog = (function () {
        try {
            DotNet.invokeMethodAsync(_assembely, 'getAssosiateFiles', 'test').then(function (data) {
                alert(data);
            });
        }
        catch (e) {
            console.log(e);
        }
    });

    editorLoadCompleted = (function (obj) {

        setTimeout(function () {
            fitHeight();
        }, 100);

        window.DigiEdit.addCss();
        window.DigiEdit.addScript();
        window.DigiEdit.setEditorOptions();
        window.DigiEdit.loadPopupTools();
        window.DigiEdit.hideLoading();
        setOptions();
        setStyles(hidenseek(window.DigiEdit.props.userId));
    });

    hideToolbar = (function () {
        var editorTool = document.querySelector('#' + this.props.editorToolId);
        editorTool.style.display = 'none';
        fitHeight();
    });

    showToolbar = (function () {
        var editorTool = document.querySelector('#' + this.props.editorToolId);
        editorTool.style.display = 'block';
        fitHeight();
    });

    setEditorOptions = (function () {
        if (this.props.readonly == 'true') {
            this.hideToolbar();
            this.setReadonlyForEditor();
        }
        else {
            this.showToolbar();
        }

        if (DotNet.invokeMethod(_assembely, 'isReviewer', this.props.role).result) {
            this.objReviewManager = new reviewManager();

        }
    });

    setReadonlyForEditor = (function () {

        setTimeout(function () {
            var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
            var body = iFrame.getElementsByTagName('body')[0];
            body.removeAttribute('contenteditable');

            body.addEventListener("keydown", allowBodyEvent);
            body.addEventListener("keypress", allowBodyEvent);
            body.addEventListener("keyup", allowBodyEvent);


        }, 200);

    })

    addScript() {
        var scriptTimehandler = setTimeout(function () {
            window.DigiEdit.props.jsFile.forEach(jsInfo => {
                if (jsInfo.sts == 0) {
                    var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
                    var head = iFrame.getElementsByTagName('head')[0];
                    var script = document.createElement('script');
                    script.type = 'text/javascript';

                    script.src = window.DigiEdit.props.host + jsInfo.src;
                    //mathScript.onload = callbackMethod;
                    try {
                        head.appendChild(script);
                        jsInfo.sts = 1;
                    }
                    catch (e) {
                        window.DigiEdit.addScript();
                    }
                }
            });

        }, 100);

    }

    addCss() {
        var scriptTimehandler = setTimeout(function () {
            window.DigiEdit.props.cssFile.forEach(jsInfo => {
                if (jsInfo.sts == 0) {
                    var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
                    var head = iFrame.getElementsByTagName('head')[0];
                    var style = document.createElement('link');
                    style.type = 'text/css';
                    style.rel = 'stylesheet';

                    style.href = window.DigiEdit.props.host + jsInfo.src;

                    try {
                        head.appendChild(style);
                        jsInfo.sts = 1;
                    }
                    catch (e) {
                        window.DigiEdit.addCss();
                    }
                }
            });

        }, 100);

    }



    loadPopupTools = (function () {
        var popupToolItemsStr = propDiv.getAttribute('data-popuptools');
        popupToolItemsStr.replace(/ /, '');

        if (popupToolItemsStr == '') { return; }

        var popupToolItemList = popupToolItemsStr.split(',');
        if (popupToolItemList.length > 0) {
            this.oPopupTool = new popupTool();
        }
        for (var i = 0; i < popupToolItemList.length; i++) {
            var pItems = popupToolItems[popupToolItemList[i]];
            for (var j = 0; j < pItems.length; j++) {
                this.oPopupTool.addItem(window.DigiEdit.props.host + pItems[j].icon, pItems[j].title, pItems[j].callback);
            }
        }
    });

}

var hidenseek = (function (key) {
    return DotNet.invokeMethod(_assembely, 'getVal', key).result;
});

var send2Server = (function (user, message) {
    props.connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
});

var setStyles = (function (_id) {
    var additionalCss = additionalDocCSS;
    additionalCss = additionalCss.replace(/\[NOTE\]/g, 'user_note' + _id);
    var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
    var head = iFrame.getElementsByTagName('head')[0];

    var styleContainer = iFrame.getElementById('additionalDocCSS');
    if (styleContainer) {
        styleContainer.remove();
    }
    head.innerHTML += additionalCss + editorNoteDocCSS;
});


var addorDeleteAnnotSpan = (function (annotInfo) {
    var tag = document.createElement('span');
    var range = null;
    var rangeInfo;
    var parentId = "";
    try {
        var jsonObj = JSON.parse(annotInfo);
        parentId = jsonObj.parentId;
        if (jsonObj.sessionId != props.currentSessionId && jsonObj.file == props.prcoessFile) {
            if (jsonObj.annot == 'add') {
                // alert(jsonObj.rangeInfo);
                rangeInfo = jsonObj.rangeInfo;

                tag.id = jsonObj.tagId;
                tag.className = jsonObj.className;
                tag.setAttribute('data-caption', jsonObj.caption);
                tag.setAttribute('data-type', jsonObj.type);
                tag.setAttribute('data-start', rangeInfo.start);
                tag.setAttribute('data-end', rangeInfo.end);

                range = document.getElementsByTagName('iframe')[0].contentWindow.restoreRange(rangeInfo);
                //var range = editorUtil.getSelectionRange();
                //alert(editorUtil.getNodesInRange(range));

                if (checkIsAnnotExist(tag.id) == false) {

                    range.surroundContents(tag);
                    range.collapse(true);
                }
            }
            else {
                deleteAnnotSpan(jsonObj);
            }
            //autoSave();
        }
    }
    catch (e) {
        //alert(e);
        if (checkIsAnnotExist(tag.id) == false) {
            //var node = editorUtil.getSelectedNode(editorUtil.getWindowAndDoc().doc, editorUtil.getWindowAndDoc().win);
            //var range = editorUtil.getSelectionRange();

            //document.getElementsByTagName('iframe')[0].contentWindow.applySpan();
            //var range = editorUtil.getSelectionRange();
            if (rangeInfo.back) {

                //savedSel.end = savedSel.start;
                rangeInfo.end = rangeInfo.start;
            }
            else {
                rangeInfo.start = rangeInfo.end;
            }
            range = document.getElementsByTagName('iframe')[0].contentWindow.restoreRange(rangeInfo);
            range.insertNode(tag);
            range.collapse(true);
            //var _pId = editorUtil.getParentId();
            //if (_pId == parentId) {
            //    range.insertNode(tag);
            //    range.collapse(true);
            //}
            //else {
            //    var elem = document.getElementsByTagName('iframe')[0].contentDocument.getElementById(parentId);
            //    elem.innerHTML = tag.outerHTML + elem.innerHTML;
            //}
            console.log(e);

            //tag.outerHTML = "<br/>" + tag.outerHTML;
        }
    }
})

var checkIsAnnotExist = (function (annotId) {
    var rseult = false;

    var annot = document.getElementsByTagName('iframe')[0].contentDocument.getElementById(annotId);

    if (annot) {
        rseult = true;
    }

    return rseult;
})

var addAnnot = (function (e) {


    var txt = editorUtil.getSelectionText();

    if (txt == '') {
        return false;
    }

    var bmList = document.getElementsByClassName('noteBookMark');
    var elemId = '';

    if (bmList.length <= 0) {
        //alert(mManager.get('1001').length);
        mManager.showMessage('1001', false, null);
        //alert('Select the insertion point');
        return false;
    }

    if (props.authorNotesSelected == false && props.editorNotesSelected == false) {
        alert('Note container not selected');
        return false;
    }

    var refId = '';
    var seq = '';
    var type = '';
    var range = editorUtil.getSelectionRange();
    var tag = document.createElement('span');


    if (props.authorNotesSelected == true) {
        props.authorNoteCount++;
        seq = props.authorNoteCount;
        refId = 'A' + props.authorNoteCount;
        elemId = 'authorNoteBox';
        type = 'authorNote';
    }
    else {
        props.editoNoteCount++;
        seq = props.editoNoteCount;
        refId = 'E' + props.editoNoteCount;
        elemId = 'editorNoteBox';
        type = 'editorNote';
    }

    var caption = refId;
    refId = refId + '_user_note' + hidenseek(window.DigiEdit.props.userId) + "_" + editorUtil.uuidv4();
    tag.id = refId;
    tag.className = 'note annot user_note' + hidenseek(window.DigiEdit.props.userId) + " " + type;
    tag.setAttribute('data-caption', caption);
    tag.setAttribute('data-type', type);


    try {
        var rangeInfo = document.getElementsByTagName('iframe')[0].contentWindow.getRangeInfo();
        var parentId = editorUtil.getParentId();
        var msgObj = { "sessionId": props.currentSessionId, "annot": "add", "file": props.prcoessFile, "rangeInfo": rangeInfo, "tagId": refId, "className": tag.className, "caption": caption, "type": type, "parentId": parentId }
        tag.setAttribute('data-start', rangeInfo.start);
        tag.setAttribute('data-end', rangeInfo.end);
        saveAnnotPlaceHolder(msgObj);

        props.connection.invoke("SendMessage", hidenseek(window.props.userId), JSON.stringify(msgObj)).catch(function (err) {
            return console.error(err.toString());
        });
    }
    catch (e) {
        //alert(e);
    }
    //alert(rangeInfo);

    var txt = editorUtil.getSelectionText();

    if (txt != '') {
        txt = txt.slice(0, 100);
    }

    try {

        var noteBox = document.getElementById(elemId);
        var bmList = noteBox.getElementsByClassName('noteBookMark');
        if (bmList.length > 0) {
            var bm = bmList[bmList.length - 1];
            bm.outerHTML += '<span class="note-group" data-uid="' + props.cUserID + '"><span tabindex="1"  class="note-item prevent-select" id="annot_' + refId + '" data-id="' + refId + '" data-seq="' + seq + '"><sup>' + caption + '</sup>&lt;' + txt + '&gt;' + '</span><span class="note-control prevent-select"><i class="fa fa-copy" onclick="copyAnnot(e);"></i> <i class="fa fa-trash" onclick="deleteAnnot(this)"></i> </span></span><span class="space">&nbsp;&nbsp;</span>';
            //editorUtil.removeByClass('noteBookMark');
            setNextFocus();
        }

        range.surroundContents(tag);


    }
    catch (e) {
        /* if (props.authorNotesSelected == true) {
             props.authorNoteCount = props.authorNoteCount - 1;
         }
         else {
             props.editoNoteCount = props.editoNoteCount - 1;
         }*/

        range.insertNode(tag);

        //alert('Text partially selected ');
    }

    autoSave();
});

var setOptions = (function () {

    addCustomEventListeners();
    try {
        var doc = editorUtil.getWindowAndDoc().doc;
        doc.getElementsByTagName('body')[0].addEventListener("mouseup", (e) => {
            switch (e.which || e.button) {
                case 1:
                    //alert('Left Mouse button pressed.');
                    showSlectOptions(event);
                    break;
                case 2:
                    //alert('Middle Mouse button pressed.');
                    break;
                case 3: {
                    try {
                        oPopupTool.hide();
                    } catch (e) { }
                }
                    //alert('Right Mouse button pressed.');
                    break;
                default:
                //alert('You have a strange Mouse!');
            }
        });
    }
    catch (e) {
        setTimeout(function () {
            setOptions();
        }, 100)
    }
});

var showSlectOptions = (function (event) {
    try {
        var _txt = editorUtil.getSelectionText();
        if (_txt != "" && _txt != "\n") {
            var pos = { "x": event.clientX + 30, "y": event.clientY + props.frameTop };
            window.DigiEdit.oPopupTool.show(pos);
        }
        else {
            window.DigiEdit.oPopupTool.hide();
        }
    } catch (e) { console.log(e) }
});

var addCustomEventListeners = (function () {
    var body = document.getElementsByTagName('body')[0];

    body.addEventListener("mouseup", (event) => {
        try {
            oPopupTool.hide();
        }
        catch (e) {

        }
    });

});



/*Review Related*/

var enableAnnotation = (function () {
    //editorUtil.enableForEdit('noteEntry');
});

var bodyKeyUp = (function (e) {
    const key = e.key;
    if (key === "Control") {
        controlKey = false;
    }
});



var allowBodyEvent = (function (e) {
    const key = e.key;
    if (key === "Control") {
        controlKey = true;
    }

    var allowedKeys = [
        "ArrowLeft",
        "ArrowRight",
        "ArrowUp",
        "ArrowDown"
    ];

    if ((controlKey == true && key.toLowerCase() == 'c') || (allowedKeys.indexOf(key))) {

    }

    else {
        e.preventDefault();
        return false;
    }
});

/*Review Related*/


document.addEventListener('DOMContentLoaded', function () {

    window.onresize = adjustResize;
    getBasePath();
    initDocResources();
    initView();
    setSplitWindow();
    enableAnnotation();
});



var getBasePath = (function () {
    var rootScript = 'DigiClientHost/index.js';
    var rootBundle = 'DigiClientHost/index.bundle.js';
    var scriptTags = document.querySelectorAll('script[src]');
    for (var i = 0; i < scriptTags.length; i++) {
        var src = scriptTags[i].src;
        if (src.toLowerCase().includes(rootScript.toLowerCase()) || src.toLowerCase().includes(rootBundle.toLowerCase())) {
            var urlInfo = src.split('/DigiClientHost');
            props.host = urlInfo[0] + props.host;
        }
    }
});

var initDocResources = (function () {
    addDocJS();
    addDocCSS();
});

var addDocJS = (function () {
    for (var i = 0; i < props.docJS.length; i++) {
        loadJs(props.docJS[i]);
    }
});

var addDocCSS = (function () {
    for (var i = 0; i < props.docCSS.length; i++) {
        loadCss(props.docCSS[i]);
    }
});

var initView = (function () {

    propDiv = document.querySelector('#dataProps');
    props.view = propDiv.getAttribute('data-view');
    props.comments = propDiv.getAttribute('data-annot');
    props.readonly = propDiv.getAttribute('data-readonly');
    props.trackChanges = propDiv.getAttribute('data-trackchanges');


    //props.processFile = document.querySelector('#digiEdit_fileId').value;
    props.processFile = document.querySelector('#digiEdit_field_2').value;
    props.userId = document.querySelector('#digiEdit_field_3').value;
    props.userName = document.querySelector('#digiEdit_field_4').value;
    props.role = document.querySelector('#digiEdit_field_5').value;
    props.stage = document.querySelector('#digiEdit_field_6').value;
    props.baseURI = document.querySelector('#digiEdit_field_7').value;
    props.repCode = document.querySelector('#digiEdit_field_8').value;

    var objDigiEdit = new DigiEdit(props);
    window.DigiEdit = objDigiEdit;
    objDigiEdit.checkAndLoadDoc();

});




var adjustResize = (function () {
    fitHeight();
});


var setSplitWindow = (function () {
    if (props.view == 'split') {
        Split(['#left-pane', '#right-pane'], {
            sizes: [props.leftWidth, props.rightWidth],
            //minSize: 300,
            //maxSize: 650,
            //gutterSize: 8,
            //gutterAlign: 'start',
            //snapOffset: 20,
            //dragInterval: 7,
        })
    }
});




var loadJs = (function (obj) {
    var sourceUrl = obj.src;


    if (sourceUrl.Length == 0) {
        console.error('Invalid source URL');
        return;
    }

    if (obj.isInternal == 1) {
        sourceUrl = props.host + sourceUrl;
    }

    var tag = document.createElement('script');
    tag.src = sourceUrl;
    tag.type = 'text/javascript';
    tag.setAttribute('data-name', obj.name);
    tag.onload = function (e) {
        var _name = e.target.getAttribute('data-name');
        var _obj = props.docJS.find(_obj => _obj.name == _name);
        _obj.sts = 1;
        console.log('Script loaded successfully');
    }

    tag.onerror = function () {
        console.error('Failed to load script');
    }
    document.body.appendChild(tag);
});

var loadCss = (function (obj) {
    var sourceUrl = obj.src;
    if (sourceUrl.Length == 0) {
        console.error('Invalid source URL');
        return;
    }

    if (obj.isInternal == 1) {
        sourceUrl = props.host + sourceUrl;
    }

    var tag = document.createElement('link');
    tag.rel = 'stylesheet';
    tag.href = sourceUrl;
    tag.type = 'text/css';
    tag.setAttribute('data-name', obj.name);
    tag.onload = function (obj) {
        obj.sts = 1;
        console.log('Script loaded successfully');
    }

    tag.onerror = function () {
        console.error('Failed to load script');
    }
    document.body.appendChild(tag);
});



var fitHeight = (function (view) {

    var compensateValue = 10;
    var parentContainer = document.querySelector('#' + props.parentContainer);
    var editorTool = document.querySelector('#' + props.editorToolId);
    var menuBar = document.querySelector('#menuBar');

    var vHeight = window.innerHeight;

    var toolHeight = 0;
    var menuHeight = 0;


    try {
        toolHeight = editorTool.offsetHeight;
        menuHeight = menuBar.offsetHeight;
    }
    catch (e) {
        //alert(e);
        console.log(e);
    }

    vHeight = vHeight - menuHeight - parentContainer.offsetTop;

    props.frameTop = (compensateValue + toolHeight + menuHeight + 20);


    document.querySelector('#' + props.editorContainerId).style.height = (vHeight - toolHeight - compensateValue) + 'px';
    document.querySelector('#main-pane').style.height = (vHeight - compensateValue) + 'px';


    try {
        var tabPanel1 = document.querySelector('#tabPanel1');
        var tabPanel2 = document.querySelector('#tabPanel2');

        tabPanel1.style.height = (vHeight - 80) + 'px';
        tabPanel2.style.height = (vHeight - 80) + 'px';
        //document.querySelector('#tabContent01').style.height = (vHeight - 74) + 'px';
    }
    catch (e) { }

});




