export default class MsgConfig {

    static messages = [
        {
            "msg_id": "1001",
            "type": "Warning",
            "text": "Select the insertion point"
        },
        {
            "msg_id": "1002",
            "type": "Warning",
            "text": "Note container not selected"
        },
        {
            "msg_id": "1003",
            "type": "Warning",
            "text": "Text partially selected"
        }
        ,
        {
            "msg_id": "1004",
            "type": "Decision",
            "text": "Updated Successfully"
        },
        
        {
            "msg_id": "9002",
            "type": "Error",
            "text": "Please complete the questionnaire before submitting your review"
        },
        {
            "msg_id": "9001",
            "type": "Error",
            "text": "Unable to save content"
        }
        ,
        {
            "msg_id": "1005",
            "type": "Warning",
            "text": "Please add comments for author or editor before submitting your review"
        }
        ,
        {
            "msg_id": "1007",
            "type": "Success",
            "text": "You have successfully Submitted!..."
        }
        ,
        {
            "msg_id": "9999",
            "type": "Error",
            "text": "Unable to load Document"
        }
    ]
}

