/*import { Peer } from "peerjs";*/
import apiRequest from './API.js';
import editorUtil from './Util.js';


var _THIS;

export default class collab {
    processFile = "";
    userName = "";
    peer = "";
    id = "";
    connectedPeers = {};
    userList = [];
    activeConnection = [];
    rangy = "";


    constructor(processFile, name) {
        this.processFile = processFile;
        this.userName = name;
        this.peer = new Peer();
        _THIS = this;
        this.saveSession();
    }
    saveSession() {
        var url = editorUtil.getConfig('COLLAB_PATH') + "/collabStart?processFile=" + this.processFile + "&nodeId=" + this.id + "&name=" + this.userName;
        apiRequest.send(url).then(function (data) {
            //alert(data);
        });
    }


    closeSession() {
        var url = editorUtil.getConfig('COLLAB_PATH') + "/collabEnd?processFile=" + this.processFile + "&nodeId=" + this.id + "&name=" + this.userName;
        apiRequest.send(url).then(function (data) {
            //alert(data);
        });
    }

    connectPeer(requestedPeer) {

        if (!this.connectedPeers[requestedPeer]) {
            // Create 2 connections, one labelled chat and another labelled file.
            var c = this.peer.connect(requestedPeer, {
                label: 'chat',
                serialization: 'none',
                metadata: { message: '[CONNECTED]' }
            });
            if (c) {
                c.on('open', function () {
                    _THIS.updateMessage("", c.peer + ": Connected");
                    _THIS.activeConnection.push(c);
                    _THIS.connect(c);
                });
                c.on('error', function (err) {
                    // alert(err);
                });



            }
        }
        //this.connectedPeers[requestedPeer] = 1;
    }


    connect(c) {

        if (c.label === 'chat') {


            c.peer.on('disconnected', () => {
                this.disconnectBackoff = 1;
                this.retrySocketConnection();
            });


            c.on('data', function (data) {
                // _THIS.updateMessage(c.Peer, data);
            });

            c.on('close', function () {


                delete _THIS.connectedPeers[c.peer];
            });

        }

        //this.connectedPeers[c.peer] = 1;
    }


    updateMessage(id, data) {
        // alert(data);
        var _iWindow = document.getElementsByTagName('iframe')[0];


        _iWindow.contentWindow.setH(data);

        //document.querySelector('#collab').innerHTML += data;

        //document.querySelector('#rangeref').value = data;
        //_THIS.rangy.deserializeSelection(data);
        /* if(data.indexOf('invoke')>0){
             var jOj = JSON.parse(data);
             this.setCursor(jOj['c'], jOj['user'], jOj['rid'],  jOj['top'],  jOj['left']);
         }*/
    }


    getPosition(element) {
        var clientRect = element.getBoundingClientRect();
        return {
            left: clientRect.left + document.body.scrollLeft,
            top: clientRect.top + document.body.scrollTop
        };
    }

    setCursor(pos, u, id, t, l) {
        var tag = document.getElementById(id);
        this.removeElementsByClass("collab-cursor");
        var span = document.createElement('span');
        span.innerHTML = "|<small>" + u + "</small>";
        span.setAttribute("tabindex", 0);
        span.className = "collab-cursor";
        var pos = this.getPosition(tag);
        span.style = "top:" + t + 'px;' + "left:" + l + 'px;';

        document.body.append(span);

        span.focus();

        //tag.className = tag.className + "collab-node";

        //tag.innerHTML += span.outerHTML;

        //tag.appendChild(span);

        // Creates range object
        /* var setpos = document.createRange();
           
         // Creates object for selection
         var set = window.getSelection();
           
         // Set start position of range
         setpos.setStart(tag, pos);
           
         // Collapse range within its boundary points
         // Returns boolean
         
 
         
 
         setpos.insertNode(span);
         setpos.collapse(true);
          span.focus(); 
         // Remove all ranges set
         //set.removeAllRanges();
           
         // Add range with respect to range object.
         //set.addRange(setpos);
           
         // Set cursor on focus
         //tag.focus();*/
    }

    setCaretPosition(caretPos) {
        var elem = document.getElementById('editspace');

        if (elem != null) {
            if (elem.createTextRange) {
                var range = elem.createTextRange();
                range.move('character', caretPos);
                range.select();
            }
            else {
                if (elem.selectionStart) {
                    elem.focus();
                    elem.setSelectionRange(caretPos, caretPos);
                }
                else
                    elem.focus();
            }
        }
    }

    removeElementsByClass(className) {
        const elements = document.getElementsByClassName(className);
        while (elements.length > 0) {
            elements[0].parentNode.removeChild(elements[0]);
        }
    }

    getActiveUsers(msg) {
        var url = editorUtil.getConfig('COLLAB_PATH') + "/getCollabSessions?processFile=" + this.processFile;
        apiRequest.send(url).then(function (data) {
            //alert(data);
            //document.getElementById("editspace").innerHTML = data;

            var nodeList = JSON.parse(data);
            if (nodeList.data) {
                nodeList.data.forEach(node => {
                    /*
                        this.connectPeer(node.refid);
                    }*/
                    if (node.refid != _THIS.id) {
                        if (!_THIS.checkExistConnection(node.refid)) {
                            _THIS.connectPeer(node.refid);
                        }
                    }
                });
            }

            _THIS.sendMessage(msg);
        });
    }

    sendMessage(data) {
        for (var i = 0; i < _THIS.activeConnection.length; i++) {
            var conn = _THIS.activeConnection[i];
            if (conn.peer != _THIS.id) {
                conn.send(data);
            }
            //fn(conn, $(this));
        }
    }

    checkExistConnection(user) {
        var found = false;
        _THIS.activeConnection.forEach(con => {
            if (con.peer == user) { found = true; }
        });
        return found;
    }






}