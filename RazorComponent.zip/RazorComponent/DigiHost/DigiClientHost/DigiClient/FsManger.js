﻿import apiRequest from './API.js';
import editorUtil from './Util.js';
import defaultConfig from '../DIGIClient/Config.js';
import toast from '../DIGIClient/Toast.js';


export default class FsManager {
    static saveContent(xmlContent, isAutoSave, isAutoSaveBackup, stage, isSubmitted) {

        var postData = {
            "xmlContent": xmlContent,
            "xmlPath": Function.root().props.prcoessFile +  defaultConfig.PROCCESS_FILE_NAME,
            "isAutoSave": isAutoSave,
            "isAutoSaveBackup": isAutoSaveBackup,
            "uid": Function.root().props.cUserID,
            "role": Function.root().props.cRole,
            "stage": Function.root().props.stage,
            "isSubmitted": isSubmitted,
            "commentToAuthor": Function.root().props.authorNotes,
            "commentToEditor": Function.root().props.editorNotes,
            "authorResponse": Function.root().props.authorResponse,
            "processFile": Function.root().props.prcoessFile
        }

        const requestOptions = {
            method: 'POST',
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(postData)
        };

        let url = defaultConfig.SAVE_ALL;
        let returnVal = apiRequest.sendWithOptions(url, requestOptions);

        toast.showToast("Content Saved");
    }
}