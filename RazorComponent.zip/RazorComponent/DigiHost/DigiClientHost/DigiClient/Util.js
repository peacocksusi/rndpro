import defaultConfig from './Config.js';

export default class editorUtil {

    static getConfig = (key) => {
        return defaultConfig[key];
    }

    static addScript = (scriptPath, scriptId) => {
        if (!document.getElementById(scriptId)) {
            let script = document.createElement("script");
            script.src = scriptPath;
            script.id = scriptId;
            script.async = true;
            document.body.appendChild(script);
        }
    }

    static readXML = (xmlPath) => {
        const responseText = "";
        const apiRequest = async (path) => {
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain' },
            };

            responseText = await fetch(path, requestOptions)
                .then(response => response.text());
            return responseText;
        }
        apiRequest(xmlPath);

    }

    static getParameterByName(name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    }

    static apiRequest = async (path) => {

        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain' },
        };

        const responseText = await fetch(path, requestOptions)
            .then(response => response.text());


    }


    static initEditor = (DecoupledDocumentEditor, objEditer) => {
        DecoupledDocumentEditor
            .create(document.querySelector('.editor'), {

                licenseKey: '',

                htmlSupport: {
                    allow: [
                        {
                            name: /.*/,
                            attributes: true,
                            classes: true,
                            styles: true
                        },
                        {
                            name: 'math',
                            attributes: true,
                            classes: true,
                            styles: true
                        }
                    ]
                },
                math: {
                    engine: 'mathjax',
                    outputType: 'script',
                    forceOutputType: false,
                    enablePreview: true
                }



            })
            .then(editor => {
                window.editor = editor;
                objEditer = editor;
                // Set a custom container for the toolbar.
                document.querySelector('.document-editor__toolbar').appendChild(editor.ui.view.toolbar.element);
                document.querySelector('.ck-toolbar').classList.add('ck-reset_all');

            })
            .catch(error => {
                console.error('Oops, something went wrong!');
                //hideLoading();
                console.error(error);
            });

        return objEditer;

    }


    static getParentId(elem) {
        var _range = this.getSelectionRange();
        var _id = _range.startContainer.parentNode.id;
        /*while (_id==""){
            var parentElem = elem.parentElement;
            var _temp = parentElem.id;
            if(_temp){
                _id = _temp;
            }
        }*/
        return _id;
    }

    static getSelectionRange() {
        var _iWindow = document.getElementsByTagName('iframe')[0].contentWindow;
        var sel;
        if (_iWindow.getSelection) {
            sel = _iWindow.getSelection();
            if (sel.rangeCount) {
                return sel.getRangeAt(0);
            }
        } else if (_iWindow.document.selection) {
            return _iWindow.document.selection.createRange();
        }
        return null;
    }


    static getSelectionRangeByparam(win, doc) {

        var object;

        if (document.selection)
            object = doc.selection.createRange();
        else {
            var selection = win.getSelection();
            if (selection.rangeCount > 0)
                object = selection.getRangeAt(0);
        }

        return object;
    }


    static getInitial(name) {
        var _i = name.toUpperCase().charAt(0);
        return _i
    }



    static getNextNode(node) {
        if (node.firstChild)
            return node.firstChild;
        while (node) {
            if (node.nextSibling)
                return node.nextSibling;
            node = node.parentNode;
        }
    }

    static getNodesInRange(range) {
        var start = range.startContainer;
        var end = range.endContainer;
        var commonAncestor = range.commonAncestorContainer;
        var nodes = [];
        var node;

        // walk parent nodes from start to common ancestor
        for (node = start.parentNode; node; node = node.parentNode) {
            nodes.push(node);
            if (node == commonAncestor)
                break;
        }
        nodes.reverse();

        // walk children and siblings from start until end is found
        for (node = start; node; node = this.getNextNode(node)) {
            nodes.push(node);
            if (node == end)
                break;
        }

        return nodes;
    }




    static getSelectedNode(doc, win) {
        if (document.selection)
            return doc.selection.createRange().parentElement();
        else {
            var selection = win.getSelection();
            if (selection.rangeCount > 0)
                return selection.getRangeAt(0).startContainer.parentNode;
        }
    }

    static getSelectionText() {
        var win = this.getWindowAndDoc().win;
        var doc = this.getWindowAndDoc().doc;

        var text = "";
        if (win.getSelection) {
            text = win.getSelection().toString();
        } else if (doc.selection && doc.selection.type != "Control") {
            text = doc.selection.createRange().text;
        }
        return text;
    }


    static getWindowAndDoc() {
        var _iWindow = document.getElementsByTagName('iframe')[0];
        return { "doc": _iWindow.contentWindow.document, "win": _iWindow.contentWindow }
    }

    static getSelectionPos() {
        var win = this.getWindowAndDoc().win;
        var doc = this.getWindowAndDoc().doc;
        var object;

        if (document.selection)
            object = doc.selection.createRange().parentElement();
        else {
            var selection = win.getSelection();
            if (selection.rangeCount > 0)
                object = selection.getRangeAt(0).startContainer.parentNode;
        }

        var pos = object.getBoundingClientRect();
        return pos;
    }

    static addCss(cssFile) {
        var scriptTimehandler = setTimeout(function () {
            cssFile.forEach(jsInfo => {
                if (jsInfo.sts == 0) {
                    var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
                    var head = iFrame.getElementsByTagName('head')[0];
                    var style = document.createElement('link');
                    style.type = 'text/css';
                    style.rel = 'stylesheet';
                    style.href = jsInfo.src;
                    //mathScript.onload = callbackMethod;
                    try {
                        head.appendChild(style);
                        jsInfo.sts = 1;
                    }
                    catch (e) {
                        addCss(jsInfo);
                    }
                }
            });

        }, 100);

    }

    static addScript(jsInfo) {
        var scriptTimehandler = setTimeout(function () {
            jsFile.forEach(jsInfo => {
                if (jsInfo.sts == 0) {
                    var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
                    var head = iFrame.getElementsByTagName('head')[0];
                    var script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.src = jsInfo.src;
                    //mathScript.onload = callbackMethod;
                    try {
                        head.appendChild(script);
                        jsInfo.sts = 1;
                    }
                    catch (e) {
                        addScript(jsInfo);
                    }
                }
            });

        }, 100);

    }

    static showByClass = (function (className) {
        var box = document.querySelectorAll('.' + className);
        for (var i = 0; i < box.length; i++) {
            box[i].style.display = 'block ! important';
        }
    });

    static hideByClass = (function (className) {

        var box = document.querySelectorAll('.' + className);
        for (var i = 0; i < box.length; i++) {
            box[i].style.display = 'none';
        }
    });

    static hideById = (function (idValue) {

        var box = document.querySelectorAll('#' + idValue);
        box.style.display = 'none !important';
    });

    static uuidv4() {
        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }

    static bindEvent = (eventNames, selector, handler) => {
        eventNames.split(' ').forEach((eventName) => {
            document.addEventListener(eventName, function (event) {
                if (event.target.matches(selector + ', ' + selector + ' *')) {
                    handler.apply(event.target.closest(selector), arguments)
                }
            }, false)
        })
    }

    static enableForEdit = (function (className) {
        var box = document.querySelectorAll('.' + className);
        for (var i = 0; i < box.length; i++) {
            box[i].setAttribute('contenteditable', 'true');
        }
    });

    static removeByClass = (function (className) {
        var bmList = document.getElementsByClassName(className);
        for (var i = 0; i < bmList.length; i++) {
            var element = bmList[i];
            element.remove();
        }
    })

    static cleanXHTML = (function (xmlContent) {


        return xmlContent;
    })

    static exportToPdf = (function (elementId) {
        var doc = new jsPDF();
        var elementHTML = document.querySelector(elementId);

        doc.html(elementHTML, {
            callback: function (doc) {
                // Save the PDF
                doc.save('review.pdf');
            },
            margin: [10, 10, 10, 10],
            autoPaging: 'text',
            x: 0,
            y: 0,
            width: 190, //target width in the PDF document
            windowWidth: 675 //window width in CSS pixels
        });
    })

    static getAllNodes = (function () {
        var sel = null;
        var nodes;
        try {
            if (window.getSelection) {
                sel = window.getSelection;
            }
            else {
                sel = document.selection;
            }
            this.getTextNodesBetween(sel);
        }
        catch (e) {
        }
        return nodes;
    })

    static getTextNodesBetween = (function (selection) {
        var range = selection.getRangeAt(0), rootNode = range.commonAncestorContainer,
            startNode = range.startContainer, endNode = range.endContainer,
            startOffset = range.startOffset, endOffset = range.endOffset,
            pastStartNode = false, reachedEndNode = false, textNodes = [];
        function getTextNodes(node) {
            var val = node.nodeValue;
            if (node == startNode && node == endNode && node !== rootNode) {
                if (val) textNodes.push(val.substring(startOffset, endOffset));
                pastStartNode = reachedEndNode = true;
            } else if (node == startNode) {
                if (val) textNodes.push(val.substring(startOffset));
                pastStartNode = true;
            } else if (node == endNode) {
                if (val) textNodes.push(val.substring(0, endOffset));
                reachedEndNode = true;
            } else if (node.nodeType == 3) {
                if (val && pastStartNode && !reachedEndNode && !/^\s*$/.test(val)) {
                    textNodes.push(val);
                }
            }
            for (var i = 0, len = node.childNodes.length; !reachedEndNode && i < len; ++i) {
                if (node !== sumterDialog) getTextNodes(node.childNodes[i]);
            }
        }
        getTextNodes(rootNode);
        return textNodes;
    })

    // Lazy Range object detection.
    static isRange = (function (obj) {
        return ('type' in obj && obj.type === 'Range');
    });

    // Good-enough Range object comparison.
    static rangeChange = (function (data1, data2) {
        return (data1.type !== data2.type || data1.focusNode !== data2.focusNode || data1.focusOffset !== data2.focusOffset);
    });

}