export default class apiRequest {
    static send = async (path) => {
		
		const requestOptions = {
			method: 'POST',
			headers: { 'Content-Type': 'text/plain' },
		};

		const responseText = await fetch(path, requestOptions)
			.then(response => response.text())
            .then(data =>{
                return data;
            });
			
		return responseText;
	}

	static sendWithOptions = async (path, requestOptions) => {
		
		const responseText = await fetch(path, requestOptions)
			.then(response => response.text())
            .then(data =>{
                return data;
            });
			
		return responseText;
	}

	static sendWithBody = async (path, requestOptions) => {
		
		const responseText = await fetch(path, requestOptions)
			.then(response => response.text())
            .then(data =>{
                return data;
            });
			
		return responseText;
	}

	static sendForJson = async (path) => {

		const requestOptions = {
			method: 'POST',
			headers: { 'Content-Type': 'text/plain' },
		};

		const responseText = await fetch(path)
			.then(response => response.text())
			.then(data => {
				return data;
			});

		return responseText;
	}
}