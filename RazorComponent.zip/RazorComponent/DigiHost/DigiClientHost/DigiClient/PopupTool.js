﻿import editorUtil from '../DIGIClient/Util.js';

export default class PopupTool {
    id = "";
    toolSpace = null;
    popup = null;

    constructor() {
        this.id = editorUtil.uuidv4();
        this.preparePopupTool();
    }
    preparePopupTool() {
        var toolSpaceId = "toolSpace_" + this.id;
        var popUpId = "popup_" + this.id;
        var toolDivHTML = `<div class="popToolMenu" id="` + popUpId + `">
                    <div id="` + toolSpaceId + `"></div>
                    <i class="bottomtrai"></i>
                   </div>`;
        var popUpStyles = `
            <style>
                .popToolMenu {
                    min-width: 35px;
                    text-align: center;
                    transform: translate(-50%, -100%);
                    padding: 0px;
                    color: #444444;
                    background-color: #fff;
                    font-weight: normal;
                    font-size: 13px;
                    border-radius: 8px;
                    position: absolute;
                    z-index: 99999999;
                    box-sizing: border-box;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.5);
                    visibility: hidden;
                    opacity: 0;
                    transition: opacity 0.8s;
                }

                    .popToolMenu .btn {
                        padding: 3px;
                        outline-color: #d2d2d2;
                    }

                    .popToolMenu img {
                        width: 20px;
                    }

                    .popToolMenu .bottomtrai {
                        position: absolute;
                        top: 100%;
                        left: 50%;
                        margin-left: -12px;
                        width: 24px;
                        height: 12px;
                        overflow: hidden;
                    }

                        .popToolMenu .bottomtrai::after {
                            content: '';
                            position: absolute;
                            width: 12px;
                            height: 12px;
                            left: 50%;
                            transform: translate(-50%,-50%) rotate(45deg);
                            background-color: #EEEEEE;
                            box-shadow: 0 1px 8px rgba(0,0,0,0.5);
                        }
            </style>
        `;

        var digiToolsPlaceHolder = document.querySelector('#digiToolsPlaceHolder');
        digiToolsPlaceHolder.innerHTML += toolDivHTML + popUpStyles;


        this.toolSpace = document.querySelector('#' + toolSpaceId);
        this.popup = document.querySelector('#' + popUpId);
    }

    addItem(img, title, callback) {
        var tool = document.createElement("div");
        tool.className = "btn btn-sm";
        tool.setAttribute("title", title);
        tool.setAttribute("data-callback", callback);
        tool.innerHTML = '<img src="' + img + '" />';
        tool.addEventListener("click", callback.bind());
        this.toolSpace.appendChild(tool);
    }

    toolClicked(obj) {
        var callback = obj.currentTarget.getAttribute("data-callback");
        eval(callback);
    }

    show(jObj) {
        var mainCont = document.getElementById('left-pane');
        this.popup.style.visibility = 'visible';
        this.popup.style.opacity = '1';
        this.popup.style.top = (jObj.y) + 'px';
        this.popup.style.left = (jObj.x) + 'px';
    }

    hide() {
        this.popup.style.visibility = 'hidden';
        this.popup.style.opacity = '0';
    }

}