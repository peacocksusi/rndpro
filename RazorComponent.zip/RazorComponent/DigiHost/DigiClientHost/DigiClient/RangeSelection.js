﻿var selectionHasExtend = (typeof window.getSelection().extend !== "undefined");

var getRangeInfo = (function () {
    var containerEl = document.getElementsByTagName('body')[0];
    var maxHit = 3;
    var cHit = 1;

    if (window.getSelection && document.createRange) {
        var range = window.getSelection().getRangeAt(0);
        var preSelectionRange = range.cloneRange();
        preSelectionRange.selectNodeContents(containerEl);
        preSelectionRange.setEnd(range.startContainer, range.startOffset);
        var start = preSelectionRange.toString().length;

        return {
            start: start,
            end: start + range.toString().length,
            back: isSelectionBackward(window.getSelection()),
            len: window.getSelection().toString().length
        };
    }
    else {
        var selectedTextRange = document.selection.createRange();
        var preSelectionTextRange = document.body.createTextRange();
        preSelectionTextRange.moveToElementText(containerEl);
        preSelectionTextRange.setEndPoint("EndToStart", selectedTextRange);
        var start = preSelectionTextRange.text.length;

        return {
            start: start,
            end: start + selectedTextRange.text.length,
            back: isSelectionBackward(document.selection),
            len: selectedTextRange.text
        }
    }

});


function isSelectionBackward(sel) {
    var backward = false;
    if (!sel.isCollapsed) {
        var range = document.createRange();
        range.setStart(sel.anchorNode, sel.anchorOffset);
        range.setEnd(sel.focusNode, sel.focusOffset);
        backward = range.collapsed;
    }
    return backward;
}

var applySpan = (function (classname) {
    //var range1 = rangy.createRange();
    //range1.selectNode(document.body);
    //var textNodes = range1.getNodes([3], function (node) {
    //    return /\bfoo\b/i.test(node.data);
    //});

    //alert(textNodes);
    rangy.init();
    highlighter = rangy.createHighlighter();


    highlighter.addClassApplier(rangy.createClassApplier("note", {
        ignoreWhiteSpace: true,
        elementTagName: "span"
    }));

});


var restoreRange = (function (savedSel, wordSelect = false) {
    //savedSel.start = savedSel.start;
    //if (wordSelect == false) {
    //    if (savedSel.back) {
    //        savedSel.start = savedSel.end;
    //        //savedSel.end = savedSel.start;
    //    }
    //    else {
    //        savedSel.end = savedSel.start;
    //    }
    //}

    if (wordSelect == false) {
        savedSel.start = savedSel.end;
    }
    
    var containerEl = document.getElementsByTagName('body')[0];
    if (savedSel.start != savedSel.end) {
        cHit = 1;
    }
    if (window.getSelection && document.createRange) {
        var charIndex = 0, range = document.createRange();
        range.setStart(containerEl, 0);
        range.collapse(true);
        var nodeStack = [containerEl], node, foundStart = false, stop = false;

        while (!stop && (node = nodeStack.pop())) {
            if (node.nodeType == 3) {
                var nextCharIndex = charIndex + node.length;
                if (!foundStart && savedSel.start >= charIndex && savedSel.start <= nextCharIndex) {
                    range.setStart(node, savedSel.start - charIndex);
                    foundStart = true;
                }
                if (foundStart && savedSel.end >= charIndex && savedSel.end <= nextCharIndex) {
                    range.setEnd(node, savedSel.end - charIndex);
                    stop = true;
                }
                charIndex = nextCharIndex;
            } else {
                var i = node.childNodes.length;
                while (i--) {
                    nodeStack.push(node.childNodes[i]);
                }
            }
        }
        if (savedSel.back) {
            try {
                var sel = window.getSelection();

                var endRange = range.cloneRange();
                endRange.collapse(false);

                sel.removeAllRanges();
                sel.addRange(endRange);
                if (savedSel.start == savedSel.end) {
                    //sel.extend(endRange.startContainer, sel.anchorOffset - savedSel.len);
                }
                else {
                    sel.extend(endRange.startContainer, sel.anchorOffset - savedSel.len);
                }
                range = window.getSelection().getRangeAt(0);
            }
            catch (e) {
                savedSel.start = savedSel.end;
                cHit++;

                if (cHit <= 3) {
                    restoreRange(savedSel);
                }
            }
            //return true;
        } else {
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        }
        return range;
    }
    else {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(containerEl);
        textRange.collapse(true);
        textRange.moveEnd("character", savedSel.end);
        textRange.moveStart("character", savedSel.start);
        textRange.select();
    }
});
