﻿import msgConfig from '../data/MsgConfig.js';

export default class MsgManager {

    constructor() {
        this.prepareMsgDlg();
    }

    prepareMsgDlg() {
        var dlgHTML = `<div class="modal" id="messageBox" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="_msgTitle">Modal title</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div id="_msgText"></div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" id="_dlgOk">Ok</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="_dlgCancel">Cancel</button>
                                </div>
                            </div>
                    </div >
                </div >
                <button id="messageTrigger" style="display: none;" type="button" data-toggle="modal" data-target="#messageBox">
                    Open
                </button>`;

        var body = document.getElementsByTagName('body')[0];
        body.innerHTML += dlgHTML;
    }

    showMessage(msgId, okCancle, callbackForOk) {

        var msg = this.get(msgId);

        document.querySelector("#_msgTitle").innerHTML = msg.type;
        document.querySelector("#_msgText").innerHTML = msg.text;

        if (okCancle == true) {
            document.querySelector("#_dlgOk").style.display = 'block';
        }
        else {
            document.querySelector("#_dlgOk").style.display = 'none';
        }

        document.querySelector("#_dlgOk").addEventListener("click", callbackForOk);

        document.querySelector("#messageTrigger").click();



    }

    get(msgId) {
        try {
            var message = msgConfig.messages.filter(function (el) {
                if (el.msg_id == msgId) {
                    return el;
                }
            });
            return message[0];
        }
        catch (e) {
            return {
                "msg_id": "0000",
                "type": "Error",
                "text": e.message
            };
        }
    }

}