﻿import apiRequest from './API.js';
import editorUtil from './Util.js';

export default class Ques {

    static getDecisionList() {
        var url = window.DigiEdit.props.host + window.DigiEdit.props.quesJSON;
        try {
            apiRequest.sendForJson(url).then(function (data) {
                var quesList = JSON.parse(data);
                var qListHtml = '';
                for (var i = 0; i < quesList.question.length; i++) {
                    var qItem = quesList.question[i];
                    var id = qItem.id;
                    var txt = qItem.text;
                    var type = qItem.type;
                    var required = qItem.required;
                    var qhtml = '';
                    var star = '';

                    if (required) {
                        star = '<span style="color: red;">*</span>'
                    }

                    qhtml = '<div class="qTitle">' + txt + star + '</div>';

                    if (type == 'dropdown') {
                        qhtml += '<select id="ql_' + id + '" class="form-control">';
                        for (var k = 0; k < qItem.options.length; k++) {
                            qhtml += '<option data-required="' + required + '" value="' + qItem.options[k] + '">' + qItem.options[k] + '</option>';
                        }
                        qhtml += '</select>';
                    }
                    if (type == 'radio') {
                        qhtml += '<div id="ql_' + id + '" class="radioOptions">';
                        for (var k = 0; k < qItem.options.length; k++) {
                            qhtml += '<span data-required="' + required + '" class="optSpan"><input type="radio" name="ques_' + id + '" value="' + qItem.options[k] + '" id="q_' + id + '_opt_' + (k + 1) + '" />';
                            qhtml += qItem.options[k] + '</span>';
                        }
                        qhtml += '</div>';
                    }
                    qListHtml += qhtml;
                }
                document.getElementById('decisionQuest').innerHTML = qListHtml;
               
            });
        }
        catch (e) {
            alert(e);
        }
    }

    static saveQuestionAnswers(userId) {
        var url = window.DigiEdit.props.host + window.DigiEdit.props.quesJSON;
       
        try {
            apiRequest.sendForJson(url).then(function (data) {
                var quesList = JSON.parse(data);
                quesList.user = userId;
                var requiredValid = true;
                for (var i = 0; i < quesList.question.length; i++) {
                    var qItem = quesList.question[i];
                    var id = qItem.id;
                    var type = qItem.type;
                    var required = qItem.required;
                    if (type == 'dropdown') {
                        var selectCtrl = document.getElementById('ql_' + id);
                        qItem.captured = selectCtrl.options[selectCtrl.selectedIndex].text;
                        if (required == true) {
                            if (qItem.captured == qItem.options[0]) {
                                requiredValid = false;
                            }
                        }
                    }
                    if (type == 'radio') {
                        var checkedItem = document.querySelector('input[name="ques_' + id + '"]:checked');
                        if (checkedItem) {
                            qItem.captured = checkedItem.value;
                        }
                        else {
                            qItem.captured = "";
                        }

                        if (required) {
                            if (qItem.captured == '') {
                                requiredValid = false;
                            }
                        }




                    }
                }

                if (requiredValid == false) {
                    Function.root().mManager.showMessage('9002', false, null);
                    return false;
                }


                var prcoessFile = editorUtil.getParameterByName('f');
                var jsonFile = prcoessFile + '/decision_' + 'v' + Function.root().props.version + '_' + quesList.user + '.json';

                //alert(jsonFile);

                let formData = new FormData();
                formData.append('xmlPath', jsonFile);
                formData.append('json', JSON.stringify(quesList, null, 2));

                const requestOptions = {
                    method: 'POST',
                    body: formData
                };

                var url = editorUtil.getConfig('SAVE_DESCISION');
                apiRequest.sendWithOptions(url, requestOptions).then(function (data) {
                    //alert('Decision updated...');
                    //Function.root().mManager.showMessage('1004', false, null);
                    Function.root().props.saveState = true;
                });

            });
        }
        catch (e) {
            alert(e);
        }
    }

    static updateSelectedValues() {
        var prcoessFile = editorUtil.getParameterByName('f');
        var jsonFile = prcoessFile + '/decision_' + 'v' + editorUtil.getParameterByName('version') + '_' + Function.root().props.cUserID + '.json';
        var url = editorUtil.getConfig('READ_FILE');
        url = url.replace("{xPath}", jsonFile);

        try {
            apiRequest.send(url).then(function (data) {
                var quesList = JSON.parse(data);
               
                var requiredValid = true;
                for (var i = 0; i < quesList.question.length; i++) {
                    var qItem = quesList.question[i];
                    var id = qItem.id;
                    var type = qItem.type;
                    var required = qItem.required;
                    var captured = qItem.captured;
                    if (type == 'dropdown') {
                        var selectCtrl = document.getElementById('ql_' + id);
                        selectCtrl.value = captured;
                    }
                    if (type == 'radio') {
                        var checkedItem = document.querySelector('input[name="ques_' + id + '"]');
                        checkedItem.value = captured;
                    }

                }
            });
        }
        catch (e) {
        }

    } 

    static updateDecision(jsonObj) {
        let formData = new FormData();
        formData.append('xmlPath', prcoessFile);
        formData.append('json', xml + '<AUBKID:' + window.au_bkID + '>');

        const requestOptions = {
            method: 'POST',
            body: formData
        };

        var url = editorUtil.getConfig('WRITE_NOTE');
        apiRequest.sendWithOptions(url, requestOptions).then(function (data) {
            alert('Decision updated...');
        });
    }

    static formQuestionHTml(qItem) {
        var id = qItem.id;
        var txt = qItem.text;
        var type = qItem.type;
        var qhtml = '';

        qhtml = '<div class="qTitle">' + txt + '</div>';

        if (type == 'dropdown') {
            qhtml += '<select id="ql_' + id + '" class="form-control">';
            for (var k = 0; k < qItem.options.length; k++) {
                qhtml += '<option value="' + qItem.options[0] + '">' + qItem.options[0] + '</option>';
            }
            qhtml += '</select>';
        }

    }

}