﻿import editorUtil from './Util.js';

export default class ReviewManager {
    constructor() {
        this.controlKey = false;
        this.init();

    }

    init() {
        if (editorUtil.getParameterByName('v').toLowerCase().toLowerCase() != 'backup') {
            editorUtil.enableForEdit('noteEntry');
            setTimeout(function () {
                document.getElementById('authorNoteBox').focus();
            }, 3000);
        }
        else {
            setTimeout(function () {
                editorUtil.showByClass('authorResponse');
            }, 1000);
        }

        this.attachEventsToNotes();
    }


    attachEventsToNotes = (function () {
        try {

            if (editorUtil.getParameterByName('v').toLowerCase().toLowerCase() != 'backup') {
                editorUtil.bindEvent("click", ".noteEntry", this.updateNoteFocus);
                editorUtil.bindEvent("foucs", ".noteEntry", this.updateNoteFocus);

                editorUtil.bindEvent("keyup", ".noteEntry", this.updateNoteSelectionCursor);
                editorUtil.bindEvent("mouseup", ".noteEntry", this.updateNoteSelectionCursor);

                editorUtil.bindEvent("keypress", ".noteEntry", this.handleNoteKeyDown);
                editorUtil.bindEvent("keydown", ".noteEntry", this.handleNoteKeyDown);

                //editorUtil.bindEvent("click", "#noteSaveBtn", saveAll);
            }

            else {
                //editorUtil.hideById('noteSaveBtn');
                var element = document.getElementById('noteSaveBtn');
                element.remove();
                //document.getElementById('noteSaveBtn').remove();
            }
        } catch (e) {
            console.log(e);
        }


    });


    updateNoteFocus = (function (e) {
        var opt = e.currentTarget.activeElement.id;

        if (opt == 'authorNoteBox') {
            window.DigiEdit.props.authorNotesSelected = true;
            window.DigiEdit.props.editorNotesSelected = false;
        }
        if (opt == 'editorNoteBox') {
            window.DigiEdit.props.authorNotesSelected = false;
            window.DigiEdit.props.editorNotesSelected = true;
        }
    })

    updateNoteSelectionCursor = (function (e) {
        const key = e.key;
        if (key === "Control") {
            this.controlKey = false;
        }
        var range = editorUtil.getSelectionRangeByparam(window, document);
        window.DigiEdit.objReviewManager.removeNoteBookMark();
        var noteBookMark = document.createElement('span');
        noteBookMark.setAttribute("class", "noteBookMark");
        range.insertNode(noteBookMark);
    })

    removeNoteBookMark = (function () {
        var bmList = document.getElementsByClassName('noteBookMark');
        for (var i = 0; i < bmList.length; i++) {
            var element = bmList[i];
            element.remove();
        }

    })

    handleNoteKeyDown = (function (e) {
        const key = e.key;
        var element = e.currentTarget;

        var node = editorUtil.getSelectedNode(document, window);
        if (key === "Control") {
            this.controlKey = true;
        }

        if (this.controlKey == true && key.toLowerCase() == 'x') {
            return;
        }

        if (node.className.includes('note-item')) {

            if (key === "Delete" || key === "Backspace") {

                e.preventDefault();
                //if (node.className.includes('space') == false) {
                this.deleteAnnot(node);
                //}

            }
            else if (key === "Control" || key === "ArrowLeft" || key === "ArrowRight") {

            }
            else {
                //if (node.className.includes('space') == false) {
                e.preventDefault();

                //}
                moveCaretCursor(node);
                return false;

            }

        }

        if (node.className.includes('space') == true && node.innerText == ' ') {
            if (key === "Delete" || key === "Backspace") {
                var noteGroupTag = node.previousSibling;
                if (noteGroupTag.className.includes('note-group')) {
                    var noteItemTag = noteGroupTag.getElementsByClassName('note-item');
                    if (noteItemTag.length > 0) {
                        this.deleteAnnot(noteItemTag[0]);
                    }
                }

                e.preventDefault();
            }
        }

        if (node.tagName.toLowerCase() == 'sup') {
            if (key === "Control" || key === "ArrowLeft" || key === "ArrowRight") {

            }
            else {
                e.preventDefault();
            }
        }

    });

    moveCaretCursor = (function (element) {
        try {
            var noteGroup = element.parentNode;
            var tag = noteGroup.parentNode;
            var setpos = document.createRange();
            var set = window.getSelection();
            var fullText = tag.innerText;
            var noteText = noteGroup.innerText;

            /*fullText = fullText.replace(noteText, '/SPLIT/' + noteText);
            var splits = fullText.split("/SPLIT/");
    
            var pfxCount = 0;
    
            if (splits.length > 0) {
                pfxCount = splits[0].length;
            }
            */


            setpos.setStart(noteGroup.childNodes[0], noteGroup.innerText + 1);

            setpos.collapse(true);


            set.removeAllRanges();


            set.addRange(setpos);

            tag.focus();
        } catch (e) {
            //alert(e);
        }
    });

    deleteAnnot = (function (noteItem) {
        try {
            var refId = noteItem.getAttribute('data-Id');
            Function.root().delAnnotPlaceHolder(refId);
            var iFrame = document.getElementsByTagName('iframe')[0].contentDocument;
            //var body = iFrame.getElementsByTagName('body')[0];
            var para = iFrame.getElementById(refId);
            para.outerHTML = para.innerHTML;
            noteItem.parentNode.remove();
            var userId = Function.root().props.cUserID;
            var msgObj = { "sessionId": Function.root().props.currentSessionId, "annot": "delete", "file": Function.root().props.prcoessFile, "rangeInfo": "", "tagId": refId, "className": "", "caption": "", "type": "" }
            props.connection.invoke("SendMessage", userId, JSON.stringify(msgObj)).catch(function (err) {
                return console.error(err.toString());
            });
        }
        catch (e) { }
    })


    addAnnot = (function (e) {

        var txt = editorUtil.getSelectionText();

        if (txt == '') {
            return false;
        }

        var bmList = document.getElementsByClassName('noteBookMark');
        var elemId = '';

        if (bmList.length <= 0) {
            //alert(mManager.get('1001').length);
            mManager.showMessage('1001', false, null);
            //alert('Select the insertion point');
            return false;
        }

        if (props.authorNotesSelected == false && props.editorNotesSelected == false) {
            alert('Note container not selected');
            return false;
        }

        var refId = '';
        var seq = '';
        var type = '';
        var range = editorUtil.getSelectionRange();
        var tag = document.createElement('span');


        if (props.authorNotesSelected == true) {
            props.authorNoteCount++;
            seq = props.authorNoteCount;
            refId = 'A' + props.authorNoteCount;
            elemId = 'authorNoteBox';
            type = 'authorNote';
        }
        else {
            props.editoNoteCount++;
            seq = props.editoNoteCount;
            refId = 'E' + props.editoNoteCount;
            elemId = 'editorNoteBox';
            type = 'editorNote';
        }

        var caption = refId;
        refId = refId + '_user_note' + hidenseek(window.DigiEdit.props.userId) + "_" + editorUtil.uuidv4();
        tag.id = refId;
        tag.className = 'note annot user_note' + hidenseek(window.DigiEdit.props.userId) + " " + type;
        tag.setAttribute('data-caption', caption);
        tag.setAttribute('data-type', type);


        try {
            var rangeInfo = document.getElementsByTagName('iframe')[0].contentWindow.getRangeInfo();
            var parentId = editorUtil.getParentId();
            var msgObj = { "sessionId": props.currentSessionId, "annot": "add", "file": props.prcoessFile, "rangeInfo": rangeInfo, "tagId": refId, "className": tag.className, "caption": caption, "type": type, "parentId": parentId }
            tag.setAttribute('data-start', rangeInfo.start);
            tag.setAttribute('data-end', rangeInfo.end);
            saveAnnotPlaceHolder(msgObj);

            props.connection.invoke("SendMessage", hidenseek(window.props.userId), JSON.stringify(msgObj)).catch(function (err) {
                return console.error(err.toString());
            });
        }
        catch (e) {
            //alert(e);
        }
        //alert(rangeInfo);

        var txt = editorUtil.getSelectionText();

        if (txt != '') {
            txt = txt.slice(0, 100);
        }

        try {

            var noteBox = document.getElementById(elemId);
            var bmList = noteBox.getElementsByClassName('noteBookMark');
            if (bmList.length > 0) {
                var bm = bmList[bmList.length - 1];
                bm.outerHTML += '<span class="note-group" data-uid="' + props.cUserID + '"><span tabindex="1"  class="note-item prevent-select" id="annot_' + refId + '" data-id="' + refId + '" data-seq="' + seq + '"><sup>' + caption + '</sup>&lt;' + txt + '&gt;' + '</span><span class="note-control prevent-select"><i class="fa fa-copy" onclick="copyAnnot(e);"></i> <i class="fa fa-trash" onclick="deleteAnnot(this)"></i> </span></span><span class="space">&nbsp;&nbsp;</span>';
                //editorUtil.removeByClass('noteBookMark');
                setNextFocus();
            }

            range.surroundContents(tag);


        }
        catch (e) {
            /* if (props.authorNotesSelected == true) {
                 props.authorNoteCount = props.authorNoteCount - 1;
             }
             else {
                 props.editoNoteCount = props.editoNoteCount - 1;
             }*/

            range.insertNode(tag);

            //alert('Text partially selected ');
        }
    });

}