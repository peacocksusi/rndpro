import apiRequest from './API.js';
import editorUtil from './Util.js';


var _THIS;

export default class annot {
    processFile = "";
    userName = "";
    constructor(processFile, name){
        this.processFile = processFile;
        this.userName = name;
        _THIS = this;
    }


    add(id, comment, position, type, refId){
        var info = {"type" : type};
        var infoTxt = JSON.stringify(info)
        var url = editorUtil.getConfig('ANNOT_PATH')  + "/insertAnnotation?processFile=" + this.processFile + "&id=" + id + "&position=" + position + "&comment=" + comment + "&name=" + this.userName + "&refId=" + refId + "&info=" + infoTxt;
        apiRequest.send(url).then(function(data) {
            //alert(data);
            window.send2Server("", '{"ref":"'+id+'", "type":"annot-bind"}');
        });
    }

    deleteAnnot(elem){
        //alert('Remove');

        var annotId = elem.getAttribute('data-note-id');

        var url = editorUtil.getConfig('ANNOT_PATH')  + "/deleteAnnotation?processFile=" + this.processFile + "&id=" + annotId;
        apiRequest.send(url).then(function(data) {
           window.objAnnot.getAnnotationAll(elem);
        });

    }

   showAnnotPopup(jObj){
        //alert(112);
        var selectionPopup1 = document.getElementById('selectionPopup_1');
        var mainCont = document.getElementById('main');
        //alert(mainCont.style.marginLeft);
        selectionPopup1.style.display = 'block';
        selectionPopup1.style.top = (jObj.y + 30) + 'px';
        selectionPopup1.style.left = (jObj.x + mainCont.offsetLeft) + 'px';
   }
   
   hideAnnotPopup(){
        var selectionPopup1 = document.getElementById('selectionPopup_1');
        selectionPopup1.style.display = 'none';
   }

   getAnnotationAll(elem){

        var url = editorUtil.getConfig('ANNOT_PATH')  + "/getAnnotationAll?processFile=" + this.processFile;
        apiRequest.send(url).then(function(data) {
            var _JSON = JSON.parse(data);
            
            if(_JSON){
                var _annotRecords = _JSON.data;
                if(!_annotRecords){return 0;}
                var editorSpace = document.getElementById('noteList');
                editorSpace.innerHTML = '';
                for(var i=0; i<_annotRecords.length; i++ ){
                    //this.bindAnnot(_annotRecords[i]);
                    var record = _annotRecords[i];
                    var template = document.getElementById('_noteTemplate');
                    var replyWidget = template.getElementsByClassName('replyBox')[0];
                    var removeBut = document.getElementsByClassName('mnuRemoveAnnot')[0];

                    
                    template.getElementsByClassName('aunameintl')[0].innerHTML = editorUtil.getInitial(_annotRecords[i].name);
                    template.getElementsByClassName('auname')[0].innerHTML = _annotRecords[i].name; 
                    template.getElementsByClassName('autime')[0].innerHTML = _annotRecords[i].createtime;
                    removeBut.setAttribute('data-note-id', _annotRecords[i].id);
                    
                    replyWidget.setAttribute('data-note-id', _annotRecords[i].id);


                    var linkBut = template.getElementsByClassName('linkBut')[0];
                    var ico = '';
                    if(_annotRecords[i].parentid != ''){
                        linkBut.children[0].setAttribute('data-id', _annotRecords[i].parentid);
                        ico = '<span style="cursor: pointer;" data-id="' + _annotRecords[i].parentid + '" target="_ckEditorWindow" onclick="navToPos(this);"><img style="width: 15px; height: 15px;" class="side-tool-img" src="assets/img/web-link-icon-png-24.jpg"/> </sapn>';
                        linkBut.style.display = 'none';  
                    }
                    else{
                        linkBut.style.display = 'none';     
                    }

                    template.getElementsByClassName('aumsg')[0].innerHTML = ico + _annotRecords[i].comment;
                    
                    
                    editorSpace.innerHTML+=template.innerHTML;

                    //removeBut.removeAttribute('data-note-id');
                    //replyWidget.removeAttribute('data-note-id');
                    
                }


            }
        });
        
    }


    getFullNote(){

        var url = editorUtil.getConfig('API_PATH')  + "/ReadFullNote?processFile=" + this.processFile;
        apiRequest.send(url).then(function(data) {
            try{
                var result = data.toString().match(/<AUBKID[^<>]*>/);
                var r = result.toString().match(/[0-9]+/);
                window.au_bkID = parseInt(r.toString());
                //alert(window.au_bkID);
            }catch(e){

                console.log(e);
            }
            var notText = data.replace(/<AUBKID[^<>]*>/, '');
            var noteDiv = document.getElementById('_fullNote');
            noteDiv.innerHTML = notText;
        });
        
    }

     htmlToElem(html) {
        let temp = document.createElement('template');
        html = html.trim(); // Never return a space text node as a result
        temp.innerHTML = html;
        return temp.content.firstChild;
      }

    bindAnnot(record){
        var template = document.getElementById('_noteTemplate');
        var editorSpace = document.getElementById('editorSpace');
        
        template.getElementsByClassName('aunameintl')[0].innerHTML = editorUtil.getInitial(record.name);
        template.getElementsByClassName('auname')[0].innerHTML = record.name; 
        template.getElementsByClassName('aumsg')[0].innerHTML = record.comment;

        editorSpace.append(template.innerHTML);
        

    }
}