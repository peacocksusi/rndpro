

export default class defaultConfig {

    static API_URL = 'http://10.45.4.21/digieditapi';
    //static API_URL = 'https://localhost:44371';
    static API_PATH = this.API_URL + '/Editor';
    static COLLAB_PATH = this.API_URL + '/Collab';
    static ANNOT_PATH = this.API_URL + '/Annotation';
    static FSO_PATH = this.API_URL + '/FSO';

   
    static FETCH_XML = this.API_PATH + '/readXML/?xmlPath=';
    static WRITE_XML = this.API_PATH + '/writeXml/';
    static READ_FILE = this.API_PATH + '/ReadFile?xPath={xPath}';
    static WRITE_NOTE = this.API_PATH + '/writeFullNote/';
    static SAVE_DESCISION = this.API_PATH + '/SaveDecision/';
    static SAVE_ALL = this.API_PATH + '/saveAllContent/';
    static GET_FILES = this.FSO_PATH + '/GetFileNamesByDirectoryPath?processFile={processFile}&baseDirName={baseDirName}';
    static GET_REVIEWER_COMMENTS = this.API_PATH + '/getReviewerComment?processFile={processFile}&reviewby={reviewby}&version={version}';
    static GET_ALL_REVIEWER_COMMENTS = this.API_PATH + '/getAllReviewerComment?processFile={processFile}&version={version}';
    static GET_PREVIOUS_VERSION_LIST = this.API_PATH + '/getPreviousVersionList?processFile={processFile}&uid={uid}';
    static GET_LAST_VERSION = this.API_PATH + '/GetLastVersion?processFile={processFile}'; 
    static UPDATE_AUTHOR_RESPONSE = this.API_PATH + '/UpdateAuthorResponse?processFile={processFile}&auhtorId={auhtorId}&reviwerId={reviwerId}&authorResponse={authorResponse}&version={version}';


    //
    static SAVE_ANNOT_PLACE_HOLDER = this.ANNOT_PATH + '/insertAnnotPlaceHolder?processFile={processFile}&id={id}&position={position}&comment={comment}&name={name}&refId={refId}&info={info}'; 
    static GET_ANNOT_PLACE_HOLDER = this.ANNOT_PATH + '/getAnnotPHAll?processFile={processFile}&user_id={user_id}&version={version}';
    static DEL_ANNOT_PLACE_HOLDER = this.ANNOT_PATH + '/deleteAnnotPlaceHolder?processFile={processFile}&spanId={spanId}'; 
    static PROCCESS_FILE_NAME = '/digihtml/tx2.xhtml';
    

    static AUTO_SAVE_TIME_INTERVAL = 5 * (1000 * 60) //5 Minuts;
    static AUTO_SAVE_LIMIT = 3;
    static REVIEWER_GUIDELINE_URL = 'https://www.mpslimited.com/';
    static RELATED_LITERATURE_URL = 'https://www.w3schools.com/js/js_exercises.asp';


    static jsFile = [
        //{ 'src': 'rangy-1.3.1/lib/rangy-core.js', 'sts': 0 },
        //{ 'src': 'rangy-1.3.1/lib/rangy-classapplier.js', 'sts': 0 },
        //{ 'src': 'rangy-1.3.1/lib/rangy-highlighter.js', 'sts': 0 },
        //{ 'src': 'js/highlight.js', 'sts': 0 }
    ];

    static cssFile = [
        { 'src': '../css/book.css', 'sts': 0 },
        { 'src': '../css/article.css', 'sts': 0 }
    ];
}