﻿import apiRequest from './API.js';
import editorUtil from './Util.js';

export default class Toast {
    static showToast(msg) {
        var toast = document.createElement('span');
        toast.setAttribute("class", "toast");
        toast.innerHTML = msg; 
        //alert(toast.innerHTML);
        document.body.appendChild(toast);
        setTimeout(function () {
            toast.remove();
        }, 3000)
    } 
}
