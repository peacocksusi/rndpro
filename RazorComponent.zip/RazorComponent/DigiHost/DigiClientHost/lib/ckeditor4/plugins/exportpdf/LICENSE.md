Software License Agreement
==========================

**CKEditor 4 Export to PDF plugin** (https://ckeditor.com/ckeditor-4/)<br>
Copyright (c) 2003-2022, [CKSource](http://cksource.com) Holding sp. z o.o. All rights reserved.

CKEditor 4 Export to PDF plugin is licensed under a commercial license and is protected by copyright law.
For more details about available licensing options please contact us at sales@cksource.com.

Sources of Intellectual Property Included in CKEditor 4 export to PDF
---------------------------------------------------------------------

Where not otherwise indicated, all CKEditor 4 Export to PDF plugin content is authored by CKSource engineers and consists of CKSource-owned intellectual property.

Trademarks
----------

**CKEditor** is a trademark of [CKSource](http://cksource.com) Holding sp. z o.o. All other brand and product names are trademarks, registered trademarks or service marks of their respective holders.
