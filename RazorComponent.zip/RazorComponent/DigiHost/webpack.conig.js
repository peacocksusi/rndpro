module.exports = {
  entry: './DigiClientHost/index.js',
  mode: 'production',
  output: {
	path: '/dist',
	filename: 'index.bundle.js',
  },
};