using ProjectHerald.View.Pages.Account;
using DigiEditRazorLibrary;
using System.Reflection.Metadata;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages().AddRazorRuntimeCompilation();
builder.Services.AddSession();
builder.Services.AddScoped<DigiEditRazorLibrary.Widgets.DigiEditComponent>();
builder.Services.AddMvc().AddRazorPagesOptions(o => o.Conventions.AddPageRoute("/Review/DigiEdit", ""));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
else
{
    app.UseWebAssemblyDebugging();
}

app.UseBlazorFrameworkFiles();
app.MapFallbackToFile("index.html");

app.UseStaticFiles();

app.UseRouting();
app.UseSession();

app.UseAuthorization();


app.MapRazorPages();

app.Run();
