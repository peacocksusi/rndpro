﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectHerald.View.Pages
{
    public class TempModel : PageModel
    {
        private readonly ILogger<TempModel> _logger;

        public TempModel(ILogger<TempModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
    }
}