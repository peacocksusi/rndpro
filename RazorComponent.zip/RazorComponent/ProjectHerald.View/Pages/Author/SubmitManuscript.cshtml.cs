using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectHerald.View.Pages.Author
{
    public class SubmitManuscriptModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
