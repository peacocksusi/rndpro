using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectHerald.View.Pages.Author
{
    public class AuthorDashboardModel : PageModel
    {
        
        public string Username { get; set; }
        public int PendingRevision { get; set; }
        public int SubmissionRevision { get; set; }
        public int DecisionAwaited { get; set; }
        public int DecisionMade { get; set; }
        public int ActionNeeded { get; set; }
        public int SubmissionHistory { get; set; }
        public void OnGet()
        {
            Username = "Darshan Prabhudev";
        }
    }
}
