using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectHerald.View.Pages.Account
{
    public class ChangePasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
