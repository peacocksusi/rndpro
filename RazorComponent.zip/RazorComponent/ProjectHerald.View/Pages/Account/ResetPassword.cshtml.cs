using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectHerald.View.Pages.Account
{
    public class ResetPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
