﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HTMLSplit.Service;
using Utils;
using System.IO;
using Microsoft.Extensions.Configuration;
using Utils.Logger;
using Utils.Common;
using System.Reflection;
using Utils.Models;

namespace HTMLSplit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HTMLSplitController : ControllerBase
    {

        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
		private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

		private string message;
        private string uniqueNumber;
        private string docxFileName;

        public HTMLSplitController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        [Route("splitHTML")]
        [HttpPost]
        public async Task<CoreResponseModel> splitHTML([FromQuery] string uniqueNumber)
        {
            htmlDocument htDoc = new htmlDocument(configuration,logger,customConstant);
			CoreResponseModel coreResponseModel = new CoreResponseModel();
			coreResponseModel.projectName = this.projectName;
			try
            {
                this.uniqueNumber = uniqueNumber;
                htDoc.Startup(uniqueNumber);
                this.docxFileName = htDoc.docxFileName;

                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file process started.");
                htDoc.GetFrontMatter();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " front.html generated.");
                htDoc.GetBodyMatter();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " body.html generated.");
                htDoc.GetBackMatter();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " back.html generated.");
                message = htDoc.message;
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file process completed.");

				coreResponseModel.status = 200;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogInfo(message);

				return coreResponseModel;
			}

            catch (Exception ex) 
            {
				message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;

				coreResponseModel.status = 400;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogError(message);

				return coreResponseModel;
			}


        }
    }
}