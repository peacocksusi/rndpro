﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Utils.Common;
using Utils.Logger;

namespace HTMLSplit.Service
{
    public class htmlDocument
    {

        private Hashtable backMatterTitle = new Hashtable();
        private string homePath = null;
        private XmlDocument htmlContentNode = new XmlDocument();
        private string fullTextContent = "";
        private string outPath = "";
        public string docxFileName = "";
        public string txtOutputPath = "";
        public string uniqueNumber = "";


        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;


        public string message = "";


        public htmlDocument(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
            backMatterTitle.Add("Declaration of interests", "");
            backMatterTitle.Add("Acknowledgements", "");
            backMatterTitle.Add("References", "");
        }



        public void Startup(string uniqueNumber)
        {
            string htmlContent = "";
            try
            {
                this.uniqueNumber = uniqueNumber;
                this.htmlContentNode.PreserveWhitespace = true;
                XmlDocument xmlDoc = new XmlDocument();
                homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);
                outPath = Cnfunctions.GetModifiedPath(customConstant.HTML_OUTPATH, uniqueNumber, customConstant);
                string htmlContentPath = Path.Combine(outPath, customConstant.PLAINHTML_NAME);
                htmlContent = Cnfunctions.ReadString(htmlContentPath);

                htmlContent = Regex.Match(htmlContent, "<body>(.*?)</body>", RegexOptions.Singleline).Value;
                if (htmlContent == "")
                {
                    this.message = "[Startup] => Check " + customConstant.PLAINHTML_NAME + " file path";
                    // return;
                }
                xmlDoc.LoadXml(htmlContent); xmlDoc.PreserveWhitespace = true;
                htmlContent = xmlDoc.SelectSingleNode("//body").OuterXml.Replace("<body>", "<article>").Replace("</body>", "</article>");
                this.htmlContentNode.LoadXml(htmlContent);

                this.docxFileName = Cnfunctions.setDocxFileName(homePath);
                this.FullTextGetReplace();
                string plainHtmlText = Regex.Replace(htmlContent, "<(div|list|li)[^<>]*>", Environment.NewLine);
                plainHtmlText = Regex.Replace(plainHtmlText, "</?[^<>]+>", "");
                plainHtmlText = Regex.Replace(Regex.Replace(plainHtmlText, "([\r\n])+", "$1"), "\\A([\r\n])+", "");
                txtOutputPath = Cnfunctions.GetModifiedPath(customConstant.TXT_OUTPATH, uniqueNumber, customConstant);
                Cnfunctions.CreateFile(txtOutputPath, plainHtmlText, customConstant.PLAINTXT_NAME);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }





        // Split the Header part
        public void GetFrontMatter()
        {

            XmlDocument sHead = new XmlDocument();
            XmlDocument fullTextXMLDoc = new XmlDocument();
            string FMEnd = "";
            bool isPattern2 = false;
            bool isBreak = false;
            try
            {
                fullTextXMLDoc.LoadXml(this.fullTextContent); fullTextXMLDoc.PreserveWhitespace = true;

                // split based on head level
                if (fullTextXMLDoc.SelectSingleNode("//body/div/*") != null)
                {
                    if (fullTextXMLDoc.SelectSingleNode("//body/div/head[text()]") != null)
                        FMEnd = fullTextXMLDoc.SelectSingleNode("//body/div/head[text()]").InnerText;
                    else
                        FMEnd = fullTextXMLDoc.SelectSingleNode("//body/div/*[text()]").InnerText;
                }

                sHead.LoadXml("<root></root>");
                XmlNode htmlArticleNode = this.htmlContentNode.SelectSingleNode("//article");
                //FMEnd = Regex.Replace(FMEnd, "[^a-zA-z0-9\\s.]", "");
                FMEnd = Regex.Replace(FMEnd, "[^a-zA-z]", "");
                if (!Regex.IsMatch( Regex.Replace(htmlArticleNode.InnerText, "[^a-zA-z0-9\\s.]", ""), FMEnd))
                {
                    var fullTextTeiHeaderNode = fullTextXMLDoc.SelectSingleNode("//teiHeader");
                    if (fullTextTeiHeaderNode != null)
                    {
                        string sEndpos = Regex.Match(fullTextTeiHeaderNode.InnerText.Trim(), @"(\S+(?:\s+\S+){0,5}$)").Value.ToLower();

                        FMEnd = sEndpos;
                        isPattern2 = true;
                    }
                }

                for (var i = 0; i <= htmlArticleNode.ChildNodes.Count - 1;)
                {
                    if (isPattern2)
                    {
                        if (isBreak)
                        {
                            break;
                        }
                        if (htmlArticleNode.ChildNodes[i].InnerText.ToLower().EndsWith(FMEnd))
                        {
                            isBreak = true;

                        }
                    }
                    if (Regex.IsMatch(htmlArticleNode.ChildNodes[i].InnerText, FMEnd + "$" + @"|introduction\b$", RegexOptions.IgnoreCase))
                    {

                        break;
                    }
                    if (this.XmlDocumentFragment(htmlArticleNode.ChildNodes[i], sHead) != null)
                    {

                        sHead.DocumentElement.AppendChild(this.XmlDocumentFragment(htmlArticleNode.ChildNodes[i], sHead));
                        this.htmlContentNode.SelectSingleNode("//article").RemoveChild(htmlArticleNode.ChildNodes[i]);
                    }
                    else
                    {
                        this.message = "[GetFrontMatter] => XMLDocumentFragment is null";
                        break;
                    }
                }

                string frontInnerxml = "";

                if (sHead.SelectSingleNode("//root").InnerXml.Contains("<div class=\"front\">"))
                {
                    frontInnerxml = "<div class=\"articlemeta\">" + sHead.SelectSingleNode("//root").InnerXml+"</div>";
                }
                else
                {
                    frontInnerxml = "<div class=\"front\"><div class=\"articlemeta\">" + sHead.SelectSingleNode("//root").InnerXml + "</div></div>";
                }
                Cnfunctions.CreateHTML(outPath, "<article>" + frontInnerxml + "</article>", customConstant.FRONTHTML_NAME);
                string frontHtmlText = Regex.Replace(sHead.OuterXml, "<(div|list|li)[^<>]*>", Environment.NewLine);
                frontHtmlText = Regex.Replace(frontHtmlText, "</?[^<>]+>", "");
                frontHtmlText = Regex.Replace(Regex.Replace(frontHtmlText, "([\r\n])+", "$1"), "\\A([\r\n])+", "");
                Cnfunctions.CreateFile(txtOutputPath, frontHtmlText, customConstant.FRONTTXT_NAME);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }




        // Split the Body part
        public void GetBodyMatter()
        {
            XmlDocument sBody = new XmlDocument();
            XmlDocument fullTextXMLDoc = new XmlDocument();
            bool isPattern1 = false;
            try
            {

                sBody.LoadXml("<root></root>");
                fullTextXMLDoc.LoadXml(this.fullTextContent); fullTextXMLDoc.PreserveWhitespace = true;
                XmlNode htmlArticleNode = this.htmlContentNode.SelectSingleNode("//article");
                string BMEnd = "";
                if (fullTextXMLDoc.SelectSingleNode("//back/div/div/*") != null)
                {
                    if (fullTextXMLDoc.SelectSingleNode("//back/div/head[text()]") != null)
                        BMEnd = fullTextXMLDoc.SelectSingleNode("//back/div/head[text()]").InnerText;
                    else if (fullTextXMLDoc.SelectSingleNode("//back/div/div/head[text()]") != null)
                        BMEnd = fullTextXMLDoc.SelectSingleNode("//back/div/div/head[text()]").InnerText;
                    else BMEnd = fullTextXMLDoc.SelectSingleNode("//back/div/div/*[text()]").InnerText;
                }

                if (BMEnd != "" && this.htmlContentNode.OuterXml.Contains(BMEnd))
                {
                    isPattern1 = true;
                }
                if (htmlArticleNode != null)
                {
                    for (var i = 0; i <= htmlArticleNode.ChildNodes.Count - 1;)
                    {
                        if (isPattern1)
                        {
                            if (Regex.IsMatch(htmlArticleNode.ChildNodes[i].InnerText, BMEnd + @"\b"))
                            {

                                break;
                            }
                        }
                        else
                        {

                            if (backMatterTitle.ContainsKey(htmlArticleNode.ChildNodes[i].InnerText))
                                break;

                        }

                        sBody.DocumentElement.AppendChild(this.XmlDocumentFragment(htmlArticleNode.ChildNodes[i], sBody));
                        this.htmlContentNode.SelectSingleNode("//article").RemoveChild(htmlArticleNode.ChildNodes[i]);

                    }
                    Cnfunctions.CreateHTML(outPath, "<article><div class=\"body\">" + sBody.SelectSingleNode("//root").InnerXml + "</div></article>", customConstant.BODYHTML_NAME);
                    string bodyHtmlText = Regex.Replace(sBody.OuterXml, "<(div|list|li)[^<>]*>", Environment.NewLine);
                    bodyHtmlText = Regex.Replace(bodyHtmlText, "</?[^<>]+>", "");
                    bodyHtmlText = Regex.Replace(Regex.Replace(bodyHtmlText, "([\r\n])+", "$1"), "\\A([\r\n])+", "");
                    Cnfunctions.CreateFile(txtOutputPath, bodyHtmlText, customConstant.BODYTXT_NAME);
                }

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        // Split the Back part
        public void GetBackMatter()
        {
            try
            {

                Cnfunctions.CreateHTML(outPath, "<article><div class=\"back\">" + this.htmlContentNode.SelectSingleNode("//article").InnerXml + "</div></article>", customConstant.BACKHTML_NAME);
                string backHtmlText = Regex.Replace(htmlContentNode.OuterXml, "<(div|list|li)[^<>]*>", Environment.NewLine);
                backHtmlText = Regex.Replace(backHtmlText, "</?[^<>]+>", "");
                backHtmlText = Regex.Replace(Regex.Replace(backHtmlText, "([\r\n])+", "$1"), "\\A([\r\n])+", "");

                Cnfunctions.CreateFile(txtOutputPath, backHtmlText, customConstant.BACKTXT_NAME);
                this.message = "Split Completed";
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



        //fullText read and set
        public void FullTextGetReplace()
        {
            try
            {

                string fullTextPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant), docxFileName + "-processFulltextDocument.xml");
                string fullText = Cnfunctions.ReadString(fullTextPath);
                fullText = Regex.Replace(fullText, @"<div\s?[^>]+/>", "");
                fullText = Regex.Replace(fullText, "<tei .*?>", "<tei>", RegexOptions.IgnoreCase);
                fullText = Regex.Replace(fullText, "<div .*?>", "<div>", RegexOptions.IgnoreCase);
                fullText = Regex.Replace(fullText, " xmlns=\"http://www.tei-c.org/ns/1.0\"", "");
                this.fullTextContent = fullText;
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        // create fragment for append child node
        public XmlDocumentFragment XmlDocumentFragment(XmlNode node, XmlDocument doc)
        {
            try
            {

                XmlDocumentFragment fragmentNode = doc.CreateDocumentFragment();
                fragmentNode.InnerXml = node.OuterXml;

                return fragmentNode;
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                return null;
            }

        }


    }


}
