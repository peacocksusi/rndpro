﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utils.Models;

namespace PdfToGxml.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {

        [HttpGet]

        public ProjectInfo Get()
        {
            ProjectInfo projectInfo = new ProjectInfo();
            projectInfo.Name = "PdfToGxml";
            projectInfo.Version = "0.0.0";
            projectInfo.Description = "This api is helps to convert pdf to Grobid process xml";
            return projectInfo;
        }
    }
}
