﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using PdfToGxml.Services;
using System;
using System.Reflection;
using Utils.Common;
using Utils.Logger;
using Utils.Models;

namespace PdfToGxml.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfToGxmlConvertController : ControllerBase
    {

        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

        private string message;
        private string uniqueNumber;
        private string docxFileName;
        public PdfToGxmlConvertController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }


        [HttpPost]
        [Route("convert1")]
        public async Task<CoreResponseModel> convert1(string uniqueNumber, string config = "")
        {

            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.projectName = this.projectName;

            try
            {
                string processStatus = "";
                this.uniqueNumber = uniqueNumber;
                string pdfPath = Cnfunctions.GetModifiedPath(this.customConstant.PDF_OUTPATH, uniqueNumber, this.customConstant);
                string homePath = Cnfunctions.GetModifiedPath(this.customConstant.HOME_PATH, uniqueNumber, this.customConstant);
                docxFileName = Cnfunctions.setDocxFileName(homePath);
                pdfPath += "\\" + docxFileName + ".pdf";

                XMLConverter objXMLConverter = new XMLConverter(configuration, logger, customConstant);
                processStatus = await objXMLConverter.pdf2xml(pdfPath, "processFulltextDocument", uniqueNumber, config);
                if (processStatus == "success")
                {
                    processStatus = await objXMLConverter.pdf2xml(pdfPath, "processHeaderDocument", uniqueNumber, config);

                }
                if (processStatus == "success")
                {
                    //processStatus= await objXMLConverter.pdf2xml(pdfPath, "processReferences", uniqueNumber);
                }

                if (processStatus == "success")
                {
                    this.message = uniqueNumber + " " + this.docxFileName + " " + "Grobid xml file created";
                    coreResponseModel.status = 200;
                    coreResponseModel.uniqueNumber = this.uniqueNumber;
                    coreResponseModel.message = this.message;
                    this.logger.LogInfo(message);

                }
                else
                {
                    this.message = uniqueNumber + " " + this.docxFileName + " " + "Grobid xml file does not created";
                    coreResponseModel.status = 400;
                    coreResponseModel.uniqueNumber = this.uniqueNumber;
                    coreResponseModel.message = this.message;
                    this.logger.LogError(message);
                }

                return coreResponseModel;
            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;
                coreResponseModel.status = 400;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogError(message);

                return coreResponseModel;
            }
        }

        [HttpPost]


        public async Task<CoreResponseModel> convert(string uniqueNumber, string config = "")
        {
            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.projectName = this.projectName;
            coreResponseModel.uniqueNumber = uniqueNumber;
            try
            {

                string result = "success";

                string[] apiNameArr = new string[] { "processFulltextDocument", "processHeaderDocument" };
                XMLConverter converter = new XMLConverter(configuration, logger, customConstant);
                foreach (var apiName in apiNameArr)
                {
                    if (result != "success") break;
                    string homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);
                    string docxFileName = Cnfunctions.setDocxFileName(homePath);
                    string pdfFilePath = Cnfunctions.GetModifiedPath(customConstant.PDF_OUTPATH, uniqueNumber, customConstant);
                    pdfFilePath += "\\" + docxFileName + ".pdf";
                    string xmlFilePath = Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant);
                    xmlFilePath = xmlFilePath + "\\" + docxFileName + "-" + apiName + ".xml";
                    string xmlurl = customConstant.PDF_TO_GXML_URL;
                    this.logger.LogInfo(uniqueNumber + " " + docxFileName +" "+ xmlurl);


                    this.logger.LogInfo(uniqueNumber + " " + docxFileName + " Request called for " + apiName + " conversion");

                    if (config.ToLower() == "test")
                    {
                        xmlurl = customConstant.PDF_TO_GXML_TEST_URL;
                    }

                    result = await converter.PdfToGXMLConverter(pdfFilePath, xmlurl + apiName, xmlFilePath);
                    if (result != "success")
                    {

                        result = await converter.PdfToGXMLConverter(pdfFilePath, xmlurl + apiName, xmlFilePath);
                        this.logger.LogWarn(uniqueNumber+" "+docxFileName+ " This grobid api call second Time." );
                    }
                    this.logger.LogInfo("File Created for "+apiName + " conversion");
                }


                if (result == "success")
                {
                    this.message = uniqueNumber + " " + this.docxFileName + " " + "Grobid process successfully completed";
                    coreResponseModel.status = 200;
                    coreResponseModel.uniqueNumber = this.uniqueNumber;
                    coreResponseModel.message = this.message;
                    this.logger.LogInfo(message);

                }
                else
                {
                    this.message = uniqueNumber + " " + this.docxFileName + " " + result;
                    coreResponseModel.status = 400;
                    coreResponseModel.uniqueNumber = this.uniqueNumber;
                    coreResponseModel.message = this.message;
                    this.logger.LogError(message);
                }
                return coreResponseModel;

            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;
                coreResponseModel.status = 400;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogError(message);

                return coreResponseModel;
            }

        }

    }
}
