﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NLog;
using System.Net;
using System.Text;
using System.Threading;
using Utils.Logger;
using Utils.Common;

namespace PdfToGxml.Services
{
    class XMLConverter
    {

        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        private string uniqueNumber = "";
        private string docxFileName = "";

        public XMLConverter(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;

        }

        public async Task<string> pdf2xml(string filePath, string apiname, string uniqueNumber, string config = "")
        {
            string result;
            this.uniqueNumber = uniqueNumber;
            this.docxFileName = Cnfunctions.setDocxFileName(Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant));
            try
            {
                Console.WriteLine("Request called for " + apiname + " conversion");
                this.logger.LogInfo("Request called for " + apiname + " conversion");
                string outpath = Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant);
                string xmlurl = customConstant.PDF_TO_GXML_URL;
                if (config.ToLower() == "test")
                {
                    xmlurl = customConstant.PDF_TO_GXML_TEST_URL;
                }
                this.logger.LogInfo("Grobid URL: " + xmlurl + " config: " + config);
                string filename_noext = Path.GetFileNameWithoutExtension(filePath);
                // var url = "http://192.168.60.45:8070/api/" + apiname;
                // var url = "http://192.168.60.151:8070/api/" + apiname;
                var url = xmlurl + apiname;
                HttpClient oHttpClient = new HttpClient();
                oHttpClient.Timeout = TimeSpan.FromMinutes(10);
                var FileName = Path.GetFileName(filePath);
                oHttpClient.DefaultRequestHeaders.Add("Accept", "application/xml");

                using (var multipartFormContent = new MultipartFormDataContent())
                {
                    //Add other fields
                    var fileStreamContent = new StreamContent(File.OpenRead(filePath));
                    //Thread.Sleep(5000);
                    // Console.WriteLine("testing - before add stream");
                    fileStreamContent.Headers.ContentType = new MediaTypeHeaderValue("multipart/form-data");
                    multipartFormContent.Add(fileStreamContent, name: "input", fileName: FileName);
                    //Thread.Sleep(5000);
                    // Console.WriteLine("testing - after add stream");

                    var response = await oHttpClient.PostAsync(url, multipartFormContent);
                    response.EnsureSuccessStatusCode();
                    var bytes = await response.Content.ReadAsByteArrayAsync();
                    result = System.Text.Encoding.UTF8.GetString(bytes);
                    // result = response.Content.ReadAsStreamAsync().GetAwaiter().ToString();
                    if (!Directory.Exists(outpath))
                    {
                        Directory.CreateDirectory(outpath);
                    }
                    string outPathWithFileName = outpath + "\\" + filename_noext + "-" + apiname + ".xml";
                    File.WriteAllText(outPathWithFileName, result);
                    if (!File.Exists(outPathWithFileName))
                    {
                        return "fail";
                    }
                    Console.WriteLine("success");
                    return "success";
                }
            }
            catch (Exception ex)
            {


                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);

                Console.WriteLine(ex.Message);
                throw;

            }
        }


        public async Task<string> PdfToGXMLConverter(string pdfFilePath, string url, string xmlFilePath)
        {

            string reponseMessage = "";
            try
            {
                if (!File.Exists(pdfFilePath))
                {
                    reponseMessage = this.uniqueNumber + $" The path is {pdfFilePath} doesn't exist.";
                    this.logger.LogError(reponseMessage);
                    throw new Exception(reponseMessage);
                }
                using (var httpClient = new HttpClient())
                {
                    byte[] pdfBytes = File.ReadAllBytes(pdfFilePath);

                    using (var formData = new MultipartFormDataContent())
                    {
                        var pdfContent = new ByteArrayContent(pdfBytes);
                        pdfContent.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
                        formData.Add(pdfContent,"input",Path.GetFileName(pdfFilePath));

                        using (var response = await httpClient.PostAsync(url,formData))
                        {
                            if (!Directory.Exists(Path.GetDirectoryName(xmlFilePath)))
                            {
                                Directory.CreateDirectory(Path.GetDirectoryName(xmlFilePath));
                            }
                            if (response.IsSuccessStatusCode)
                            {
                                string xmlReponse = await response.Content.ReadAsStringAsync();
                                File.WriteAllText(xmlFilePath,xmlReponse);
                                reponseMessage = "success";
                            }
                            else
                            {
                                reponseMessage = this.uniqueNumber + $" Grobid API request failed with status code: {response.StatusCode}";
                                this.logger.LogError(reponseMessage);
                                throw new Exception(reponseMessage);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                reponseMessage = ex.Message;
                this.logger.LogError(this.uniqueNumber + " " + ex.Message);
                //throw ex;
            }

            return reponseMessage;
        }



    }
}
