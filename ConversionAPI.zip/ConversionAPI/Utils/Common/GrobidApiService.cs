﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Utils.Common
{
    public class GrobidApiService
    {

        public static async Task<string> GetHeaderNames(string authorText, ICustomConstant CustomConstant)
        {

            try
            {


                string url = CustomConstant.PDF_TO_GXML_URL + "processHeaderNames";
                string result = "";
                var paramss = new Dictionary<string, string>();
                paramss.Add("names", authorText);

                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));

                    HttpResponseMessage response = client.PostAsync(url, new FormUrlEncodedContent(paramss)).Result;
                    if (response.IsSuccessStatusCode)
                    {
                    result = response.Content.ReadAsStringAsync().Result;

                    }

                    XDocument doc = XDocument.Parse("<root>" + result + "</root>");
                    foreach (var node in doc.Descendants())
                    {
                        node.Attributes("xmlns").Remove();
                        node.Name = node.Name.LocalName;
                    }
                    result = doc.ToString();
                }
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }

        }
        
        public static async Task<string> GetAffiliation(string affText, ICustomConstant CustomConstant)
        {

            try
            {


                string url = CustomConstant.PDF_TO_GXML_URL + "processAffiliations";
                string result = "";
                var paramss = new Dictionary<string, string>();
                paramss.Add("affiliations", affText);

                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));

                    HttpResponseMessage response = client.PostAsync(url, new FormUrlEncodedContent(paramss)).Result;
                    result = response.Content.ReadAsStringAsync().Result;

                    XDocument doc = XDocument.Parse("<root>" + result + "</root>");
                    foreach (var node in doc.Descendants())
                    {

                        node.Attributes("xmlns").Remove();
                        node.Name = node.Name.LocalName;
                    }
                    result = doc.ToString();
                }
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }

        }
    }
}
