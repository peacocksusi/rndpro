﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Utils.Common.CustomConstant;

namespace Utils.Common
{
    public interface ICustomConstant
    {
        List<ReplaceTextArrayModel> COMMON_REPLACE_TEXT_LIST { get; set; }
        string[] API_GATEWAY_LIST { get; set; }
        dynamic jsonData { get; set; }
        string MAIN_FILE_PATH { get; set; }
        string LIST_FILE_PATH { get; set; }
        string STYLES_FILE_PATH { get; set; }
        string FOOTNOTE_FILE_PATH { get; set; }
        string ENDNOTE_FILE_PATH { get; set; }
        string WORD_FOLDER_PATH { get; set; }
        string ZIP_EXTNS { get; set; }
        string FOLDER_PATH { get; set; }
        string DATE_FORMAT { get; set; }
        string CURRENT_DATE_PATTERN { get; set; }
        string UNIQUE_PATTERN { get; set; }
        string HOME_PATH { get; set; }
        string DIGI_LINK { get; set; }
        string SYNC_OUT_PATH { get; set; }
        string SYNC_IN_PATH { get; set; }
        string S3_BUCKET_URL { get; set; }
        string DOC_TO_PDF_URL { get; set; }
        string DOC_TO_HTML_URL { get; set; }
        string PDF_TO_GXML_URL { get; set; }
        string PDF_TO_GXML_TEST_URL { get; set; }
        string GXML_URL { get; set; }
        string HTMLSPLIT_URL { get; set; }
        string HTMLHEAD_URL { get; set; }
        string HTMLBODY_URL { get; set; }
        string HTMLTAIL_URL { get; set; }
        string JSONHEAD_URL { get; set; }
        string JSONUPDATEHEAD_URL { get; set; }
        string GXML_OUTPATH { get; set; }
        string DOCX_OUTPATH { get; set; }
        string PDF_OUTPATH { get; set; }
        string WORDML_OUTPATH { get; set; }
        string HTML_OUTPATH { get; set; }
        string JSON_OUTPATH { get; set; }
        string TEI_OUTPATH { get; set; }
        string TXT_OUTPATH { get; set; }
        string STRUCTEDHTML_OUTPATH { get; set; }
        string DIGIHTML_OUTPATH { get; set; }

        string PLAINHTML_NAME { get; set; }
        string FRONTHTML_NAME { get; set; }
        string BODYHTML_NAME { get; set; }
        string BACKHTML_NAME { get; set; }
        string DIGIHTML_NAME { get; set; }
        string PLAINTXT_NAME { get; set; }
        string FRONTTXT_NAME { get; set; }
        string BODYTXT_NAME { get; set; }
        string BACKTXT_NAME { get; set; }
        string HEADERJSON_NAME { get; set; }
        string RESPONSETXT_NAME { get; set; }


        void getJsonFile();



    }
}
