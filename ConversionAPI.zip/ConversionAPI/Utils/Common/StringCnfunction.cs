﻿using Microsoft.Extensions.FileSystemGlobbing.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using static System.Net.Mime.MediaTypeNames;

namespace Utils.Common
{
    public static class StringCnfunction
    {

        public static string[] GetArray(XmlNodeList nodeList)
        {
            string[] arrayOfValues = null;
            if (nodeList.Count > 0)
            {
                arrayOfValues = new string[nodeList.Count];
                int index = 0;
                foreach (System.Xml.XmlNode node in nodeList)
                {
                    arrayOfValues[index] = node.InnerText;
                    index += 1;
                }
            }
            return arrayOfValues;
        }

        public static int GetWordCount(string str)
        {
            int result = 0;
            Regex rx = new Regex(@"\b\w+\b",
         RegexOptions.Compiled | RegexOptions.IgnoreCase);
            MatchCollection matches = rx.Matches(str);
            //MatchCollection wordCollection = Regex.Matches(str, "");

            result = matches.Count;
            return result;
        }

        public static bool ContainsAny(this string haystack, params string[] needles)
        {
            foreach (string needle in needles)
            {
                if (haystack.Contains(needle))
                    return true;
            }

            return false;
        }
        
        public static bool StartWithAny(this string haystack, params string[] needles)
        {
            foreach (string needle in needles)
            {
                if (haystack.StartsWith(needle))
                    return true;
            }

            return false;
        }

        //compute Distance
        public static int GetSimilarityByComputeDistance(string string1, string string2)
        {
            try
            {
                if (string1.Length > 0 && string1 == string2)
                {
                    return 100;
                }
                float dis = ComputeDistance(string1, string2);
                float maxLen = string1.Length;
                float similarityFloat = 0;
                int similarityPercentage = 0;
                if (maxLen < string2.Length)
                    maxLen = string2.Length;
                if (maxLen == 0.0F)
                    return 100;
                else
                    similarityFloat = 1.0F - dis / maxLen;
                similarityPercentage = (int)(similarityFloat * 100);
                return similarityPercentage;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return 0;
            }
        }


        private static int ComputeDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] distance = new int[n + 1, m + 1];
            // matrix
            int cost = 0;
            if (n == 0)
                return m;
            if (m == 0)
                return n;
            // init1

            int i = 0;
            while (i <= n)
                distance[i, 0] = Math.Max(Interlocked.Increment(ref i), i - 1);
            int j = 0;
            while (j <= m)
                distance[0, j] = Math.Max(Interlocked.Increment(ref j), j - 1);
            // find min distance

            for (i = 1; i <= n; i++)
            {
                for (j = 1; j <= m; j++)
                {
                    cost = t.Substring(j - 1, 1) == s.Substring(i - 1, 1) ? 0 : 1;
                    distance[i, j] = Math.Min(distance[i - 1, j] + 1, Math.Min(distance[i, j - 1] + 1, distance[i - 1, j - 1] + cost));
                }
            }
            return distance[n, m];
        }

        //longest common subsequence

        public static int GetLCS(string string1, string string2)
        {
            //string1 = "SingaporeCentreforDPrintingSchoolofMechanicalandAerospaceEngineering";
            //string2 = "SingaporeCentreforDPrintinxgSchoolofMechanicalandAerospaceEngineering";

            string source;
            string target;

            if (string1.Length < string2.Length)
            {
                source = string1;
                target = string2;
            }
            else
            {
                source = string2;
                target = string1;
            }

            if (source.Length>0&& string1 == string2)
            {
                return source.Length;
            }


            if (string.IsNullOrEmpty(source) || string.IsNullOrEmpty(target)) return 0;
            var ival = source.Length + 1;
            var jval = target.Length + 1;
            var L = new int[ival, jval];
            var maximumLength = 0;
            var lastSubsBegin = 0;
            var stringBuilder = new StringBuilder();
            var totalMatch = new StringBuilder();

            var minVal = Math.Min(source.Length, target.Length);
            var maxVal = Math.Max(source.Length, target.Length);


            for (var i = 0; i < minVal; i++)
            {
                for (var j = 0; j < maxVal; j++)
                {
                    if (source[i] != target[j])
                    {
                        L[i, j] = 0;
                    }
                    else
                    {
                        if (i == 0 || j == 0)
                            L[i, j] = 0;
                        else
                            L[i, j] = 1 + L[i - 1, j - 1];


                        if (L[i, j] > maximumLength)
                        // if (L[i, j] > 10)
                        {
                            maximumLength = L[i, j];
                            var thisSubsBegin = i - L[i, j] + 1;
                            if (lastSubsBegin == thisSubsBegin)
                            {
                                //if the current LCS is the same as the last time this block ran
                                stringBuilder.Append(source[i]);
                                // matching next characters
                                totalMatch.Append(source[i]);
                            }
                            else //this block resets the string builder if a different LCS is found
                            {
                                lastSubsBegin = thisSubsBegin;
                                stringBuilder.Length = 0; //clear it
                                stringBuilder.Append(source.Substring(lastSubsBegin, i + 1 - lastSubsBegin));
                                // matching first character
                                // totalMatch.Append(source.Substring(lastSubsBegin, i + 1 - lastSubsBegin));
                                totalMatch.Append(source[i]);
                            }
                        }
                    } // else
                } // for
            }// for

            for (var j = 0; j < maxVal; j++)
            {
                L[minVal, j] = 0;
            }
            for (var i = 0; i < minVal; i++)
            {
                L[0, maxVal] = 0;
            }


            var result = 0;
            for (var i = 0; i < minVal; i++)
            {
                for (var j = 0; j < maxVal; j++)
                {
                    if (L[i, j] > 0 && L[i - 1, j - 1] + 1 == L[i, j] && L[i + 1, j + 1] == L[i, j] + 1)
                    {
                        result = result + 1;
                        break;
                    }
                }
            }



            //Console.WriteLine("Longest matched string --> " + stringBuilder.ToString());
            //Console.WriteLine("Longest match percentage --> " + (stringBuilder.ToString().Length * 100) / source.Length + "%");
            //Console.WriteLine("Total matched string --> " + totalMatch.ToString());
            //double resultVal = (double)(result * 100) / maxVal;
            //Console.WriteLine("Match percentage --> " + resultVal + "%");
            //Console.WriteLine("Total matched string count --> " + result);
            int returnNum = stringBuilder.ToString().Count();
            return returnNum;

        }


        public static string RemoveNonAlphapeticWord(string givenString)
        {

            string returnString = Regex.Replace(givenString, "[^a-zA-z]", "");
            return returnString;
        }


        public static string RemoveTagsWithAttributes(string givenString)
        {

            string returnString = Regex.Replace(givenString, "<[^<>]*>", "");
            return returnString;
        }



        //Compare string with unique input values
        public static int UniqueWordSimilarity(string str1, string str2)
        {
            int returnPercentage = 0;

            Dictionary<string, int> str1KeyValuePairs = GenerateDictionary(str1);
            Dictionary<string, int> str2KeyValuePairs = GenerateDictionary(str2);
            Dictionary<string, int> resultKeyValuePairs = new Dictionary<string, int>();



            resultKeyValuePairs["totalCount"] = str1KeyValuePairs.Count;
            resultKeyValuePairs["pass"] = 0;
            resultKeyValuePairs["fail"] = 0;

            foreach (var item in str1KeyValuePairs)
            {
                if (str2KeyValuePairs.ContainsKey(item.Key))
                {
                    if (item.Value == str2KeyValuePairs[item.Key])
                    {
                        resultKeyValuePairs["pass"] = resultKeyValuePairs["pass"] + 1;
                        continue;
                    }
                }




                resultKeyValuePairs["fail"] = resultKeyValuePairs["fail"] + 1;
            }

            //Console.WriteLine("Pass: " + resultKeyValuePairs["pass"]);
            //Console.WriteLine("Fail: " + resultKeyValuePairs["fail"]);
            //Console.WriteLine("Total Count: " + resultKeyValuePairs["totalCount"]);


            returnPercentage = (int)(((float)resultKeyValuePairs["pass"] / (float)resultKeyValuePairs["totalCount"]) * 100);
            return returnPercentage;
        }



        //Compare string with unique input values 

        // elements are  position changed from gxml file while this function is help to structure
        //like department position changed is  after institution

        public static int UniqueWordSimilarity1(string str1, string str2)
        {

            string[] str1Arr = Regex.Matches(str1,@"\b\w+\b").Cast<Match>().Select(m => m.Value).ToArray();
            string[] str2Arr = Regex.Matches(str2, @"\b\w+\b").Cast<Match>().Select(m => m.Value).ToArray();

            IEnumerable<string> uniqueItems1 = str1Arr.Distinct<string>();
            IEnumerable<string> uniqueItems2 = str2Arr.Distinct<string>();


           int minArrayCount = Math.Min(uniqueItems1.Count(),uniqueItems2.Count());


            string[] uniqueArr = uniqueItems1.Union(uniqueItems2).ToArray();


            
            


            int returnPercentage = 0;


            returnPercentage = (int)(((float)minArrayCount / (float)uniqueArr.Length) * 100);
            return returnPercentage;
        }

        public static Dictionary<string, int> GenerateDictionary(string str)
        {

            Regex rx = new Regex(@"\b\w+\b",
          RegexOptions.Compiled | RegexOptions.IgnoreCase);
            MatchCollection matches = rx.Matches(str);
            Dictionary<string, int> keyValuePairs = new Dictionary<string, int>();

            foreach (Match match in matches)
            {
                GroupCollection groups = match.Groups;
                string element = groups[0].Value;
                //element = Regex.Replace(element, ignoreCharPattern, "", RegexOptions.IgnoreCase);

                if (element != "")
                {

                    if (keyValuePairs.ContainsKey(element))
                    {
                        keyValuePairs[element] = keyValuePairs[element] + 1;
                    }
                    else
                    {
                        keyValuePairs[element] = 1;
                    }
                }

            }

            //string ignoreCharPattern = "[.|;] ?";
            //    string[] strArr = str.Trim().Replace(",", "").Split(" ");
            ////Dictionary<string, int> keyValuePairs = new Dictionary<string, int>();

            //for (int i = 0; i < strArr.Length; i++)
            //{
            //    string element = strArr[i];
            //    //element = Regex.Replace(element, ignoreCharPattern, "", RegexOptions.IgnoreCase);

            //    if (element != "" && !element.Contains(" "))
            //    {

            //        if (keyValuePairs.ContainsKey(element))
            //        {
            //            keyValuePairs[element] = keyValuePairs[element] + 1;
            //        }
            //        else
            //        {
            //            keyValuePairs[element] = 1;
            //        }
            //    }
            //}

            return keyValuePairs;
        }

        public static DataMatchFoundModel DataMatchFound(string str1, string str2)
        {
            DataMatchFoundModel dataMatchFoundModel = new DataMatchFoundModel();
            dataMatchFoundModel.isMatch = false;
            dataMatchFoundModel.dataMatchedType = "";
            str1 = str1.Trim().ToLower();
            str2 = str2.Trim().ToLower();
            int str1WordCount = RemoveNonAlphapeticWord(str1).Length;
            int str2WordCount = RemoveNonAlphapeticWord(str2).Length;
            int maxWordCount = str1WordCount < str2WordCount ? str2WordCount : str1WordCount;
            try
            {

                int similarityPercentage = StringCnfunction.GetSimilarityByComputeDistance(RemoveNonAlphapeticWord(str1), RemoveNonAlphapeticWord(str2));
                if (str1 != "" && str2 != "")
                {
                    if (similarityPercentage >= 80)
                    {
                        dataMatchFoundModel.isMatch = true;
                        dataMatchFoundModel.dataMatchedType = "computeDistance";
                    }
                    else
                    {
                        int lcsCount = StringCnfunction.GetLCS(RemoveNonAlphapeticWord(str1), RemoveNonAlphapeticWord(str2));
                        if (lcsCount >= maxWordCount * 0.8)
                        {
                            dataMatchFoundModel.isMatch = true;
                            dataMatchFoundModel.dataMatchedType = "lcs";
                        }
                        else
                        {

                            int wordSimilarityPercentage = StringCnfunction.UniqueWordSimilarity1(str1, str2);
                            if (wordSimilarityPercentage >= 75)
                            {
                                dataMatchFoundModel.isMatch = true;
                                dataMatchFoundModel.dataMatchedType = "uniqueWordSimilarity";
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                throw;
            }






            return dataMatchFoundModel;
        }


        public class DataMatchFoundModel
        {
            public bool isMatch { get; set; }

            public string dataMatchedType { get; set; }
        }

    }

}
