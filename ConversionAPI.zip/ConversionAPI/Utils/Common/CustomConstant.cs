﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Utils.Common
{
    public class CustomConstant : ICustomConstant
    {

        public CustomConstant()
        {

            this.StartUp();
        }
        #region PUBLIC VARIABLES

        public List<ReplaceTextArrayModel> COMMON_REPLACE_TEXT_LIST { get; set; }
        public string[] API_GATEWAY_LIST { get; set; }
        public dynamic jsonData { get; set; }
        public string MAIN_FILE_PATH { get; set; }
        public string LIST_FILE_PATH { get; set; }
        public string STYLES_FILE_PATH { get; set; }
        public string FOOTNOTE_FILE_PATH { get; set; }
        public string ENDNOTE_FILE_PATH { get; set; }
        public string WORD_FOLDER_PATH { get; set; }
        public string ZIP_EXTNS { get; set; }
        public string FOLDER_PATH { get; set; }
        public string DATE_FORMAT { get; set; }
        public string CURRENT_DATE_PATTERN { get; set; }
        public string UNIQUE_PATTERN { get; set; }
        public string HOME_PATH { get; set; }
        public string DIGI_LINK { get; set; }
        public string SYNC_OUT_PATH { get; set; }
        public string SYNC_IN_PATH { get; set; }
        public string S3_BUCKET_URL { get; set; }
        public string DOC_TO_PDF_URL { get; set; }
        public string DOC_TO_HTML_URL { get; set; }
        public string PDF_TO_GXML_URL { get; set; }
        public string PDF_TO_GXML_TEST_URL { get; set; }
        public string GXML_URL { get; set; }
        public string HTMLSPLIT_URL { get; set; }
        public string HTMLHEAD_URL { get; set; }
        public string HTMLBODY_URL { get; set; }
        public string HTMLTAIL_URL { get; set; }
        public string JSONHEAD_URL { get; set; }
        public string JSONUPDATEHEAD_URL { get; set; }
        public string GXML_OUTPATH { get; set; }
        public string DOCX_OUTPATH { get; set; }
        public string PDF_OUTPATH { get; set; }
        public string WORDML_OUTPATH { get; set; }
        public string HTML_OUTPATH { get; set; }
        public string JSON_OUTPATH { get; set; }
        public string TEI_OUTPATH { get; set; }
        public string TXT_OUTPATH { get; set; }
        public string STRUCTEDHTML_OUTPATH { get; set; }
        public string DIGIHTML_OUTPATH { get; set; }

        public string PLAINHTML_NAME { get; set; }
        public string FRONTHTML_NAME { get; set; }
        public string BODYHTML_NAME { get; set; }
        public string BACKHTML_NAME { get; set; }
        public string PLAINTXT_NAME { get; set; }
        public string FRONTTXT_NAME { get; set; }
        public string BODYTXT_NAME { get; set; }
        public string BACKTXT_NAME { get; set; }
        public string DIGIHTML_NAME { get; set; }
        public string HEADERJSON_NAME { get; set; }
        public string RESPONSETXT_NAME { get; set; }



        #endregion

        void StartUp()
        {
            this.getJsonFile();
            MAIN_FILE_PATH = "word\\document.xml";
            LIST_FILE_PATH = "word\\numbering.xml";
            STYLES_FILE_PATH = "word\\styles.xml";
            FOOTNOTE_FILE_PATH = "word\\footnotes.xml";
            ENDNOTE_FILE_PATH = "word\\endnotes.xml";
            WORD_FOLDER_PATH = "{fileName}_Extraction";
            ZIP_EXTNS = ".zip";
            FOLDER_PATH = "folderPath";
            DATE_FORMAT = "dd-MM-yyyy";
            CURRENT_DATE_PATTERN = "{currentDate}";
            UNIQUE_PATTERN = "{uniqueNumber}";
            HOME_PATH = jsonData.homePathPattern;
            DIGI_LINK = jsonData.digiLink;
            SYNC_OUT_PATH = jsonData.syncDBOutpath;
            SYNC_IN_PATH = AppDomain.CurrentDomain.BaseDirectory + jsonData.syncDBInpath;
            S3_BUCKET_URL = jsonData.apiUrl.s3bucket;
            DOC_TO_PDF_URL = jsonData.apiUrl.docToPdf;
            DOC_TO_HTML_URL = jsonData.apiUrl.docToHtml;
            PDF_TO_GXML_URL = jsonData.apiUrl.pdfToGxml;
            PDF_TO_GXML_TEST_URL = jsonData.apiUrl.pdfToGxmlTest;
            GXML_URL = jsonData.apiUrl.gxml;
            HTMLSPLIT_URL = jsonData.apiUrl.htmlSplit;
            HTMLHEAD_URL = jsonData.apiUrl.htmlHead;
            HTMLBODY_URL = jsonData.apiUrl.htmlBody;
            HTMLTAIL_URL = jsonData.apiUrl.htmlTail;
            JSONHEAD_URL = jsonData.apiUrl.jsonHead;
            JSONUPDATEHEAD_URL = jsonData.apiUrl.jsonUpdateHead;
            DOCX_OUTPATH = this.HOME_PATH + jsonData.folderName.docx;
            PDF_OUTPATH = this.HOME_PATH + jsonData.folderName.pdf;
            WORDML_OUTPATH = this.HOME_PATH + jsonData.folderName.wordml;
            GXML_OUTPATH = this.HOME_PATH + jsonData.folderName.gxml;
            HTML_OUTPATH = this.HOME_PATH + jsonData.folderName.html;
            JSON_OUTPATH = this.HOME_PATH + jsonData.folderName.json;
            TEI_OUTPATH = this.HOME_PATH + jsonData.folderName.tei;
            TXT_OUTPATH = this.HOME_PATH + jsonData.folderName.txt;
            STRUCTEDHTML_OUTPATH = this.HOME_PATH + jsonData.folderName.structuredHtml;
            DIGIHTML_OUTPATH = this.HOME_PATH + jsonData.folderName.digiHtml;
            PLAINHTML_NAME = jsonData.fileName.plainHtml;
            FRONTHTML_NAME = jsonData.fileName.frontHtml;
            BODYHTML_NAME = jsonData.fileName.bodyHtml;
            BACKHTML_NAME = jsonData.fileName.backHtml;
            DIGIHTML_NAME = jsonData.fileName.digiHtml;
            PLAINTXT_NAME = jsonData.fileName.plainTxt;
            FRONTTXT_NAME = jsonData.fileName.frontTxt;
            BODYTXT_NAME = jsonData.fileName.bodyTxt;
            BACKTXT_NAME = jsonData.fileName.backTxt;
            HEADERJSON_NAME = jsonData.fileName.headerJson;
            RESPONSETXT_NAME = jsonData.fileName.responseTxt;
            API_GATEWAY_LIST = SetApiGateWayList();

            this.CommonReplaceTextList();
        }
        public void getJsonFile()
        {
            try
            {


                string configuration = "";
                #if DEBUG
                configuration = ".dev";
                #endif
                bool isDevelopment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";

                string jsonFilePath = AppDomain.CurrentDomain.BaseDirectory + "//Resources//Common" + configuration + ".json";
                //string jsonFilePath = AppDomain.CurrentDomain.BaseDirectory + "//Resources//Common.dev.json";
                //if (!isDevelopment)
                //{
                //    jsonFilePath = AppDomain.CurrentDomain.BaseDirectory + "//Resources//Common.json";
                //}

                //string jsonFilePath = AppDomain.CurrentDomain.BaseDirectory + "//Resources//Common.json";
                string cleanUpJsonData = Cnfunctions.ReadString(jsonFilePath);

                jsonData = JsonConvert.DeserializeObject<dynamic>(cleanUpJsonData);
            }
            catch (Exception ex)
            {


            }
        }

        public string[] SetApiGateWayList()
        {
            string[] arr = new string[6];
            arr[0] = DOC_TO_PDF_URL;
            arr[1] = DOC_TO_HTML_URL;
            arr[2] = GXML_URL;
            arr[3] = HTMLSPLIT_URL;
            arr[4] = HTMLHEAD_URL;
            arr[5] = JSONHEAD_URL;

            return arr;
        }

        public class ReplaceTextArrayModel
        {
            public int id { get; set; }
            public string findValue { get; set; }
            public string replaceValue { get; set; }

        }

        public class MathReplaceElemModel
        {
            public string findElem { get; set; }
            public string replaceElem { get; set; }
        }



        public void CommonReplaceTextList()
        {
            COMMON_REPLACE_TEXT_LIST = new List<ReplaceTextArrayModel>();
            foreach (var item in jsonData.cleanup)
            {
                COMMON_REPLACE_TEXT_LIST.Add(new ReplaceTextArrayModel { findValue = item.findValue, replaceValue = item.replaceValue });
            }
        }
    }
}
