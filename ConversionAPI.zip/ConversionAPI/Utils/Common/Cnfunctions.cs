﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;

namespace Utils.Common
{
    public class Cnfunctions
    {

        public static string GetInnerText(XmlDocument xDoc, string xPath = ".")
        {
            string result = "";

            if (xDoc == null && xPath == "") return result;

            XmlNode xNode = xDoc.SelectSingleNode(xPath);

            if (xNode == null) return result;

            result = xNode.InnerText.Trim();


            return result;
        }

        public static string GetInnerText(XmlNode xNode, string xPath = ".")
        {
            string result = "";

            if (xNode == null && xPath == "") return result;

            XmlNode xSubNode = xNode.SelectSingleNode(xPath);

            if (xSubNode == null) return result;

            result = xSubNode.InnerText.Trim();


            return result;
        }

        public static string RemoveAttributes(string result, string attr)
        {
            XDocument doc = XDocument.Parse("<root>" + result + "</root>");
            foreach (var node in doc.Descendants())
            {
                node.Attributes(attr).Remove();
                node.Name = node.Name.LocalName;
            }

            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(doc.ToString());
            return xDoc.SelectSingleNode("//root").InnerXml;
        }
        public static string GetModifiedPath(string path, string uniqueNumber, ICustomConstant customConstant)
        {
            if (path != null)
            {
                path = path.Replace(customConstant.CURRENT_DATE_PATTERN, Cnfunctions.GetISTDate(customConstant.DATE_FORMAT));
                path = path.Replace(customConstant.UNIQUE_PATTERN, uniqueNumber);

            }
            return path;
        }
        public static string GetISTDate(string dateFormat = "")
        {
            DateTime today = DateTime.UtcNow;
            TimeZoneInfo timeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            today = TimeZoneInfo.ConvertTime(today, timeZone);

            return today.ToString(dateFormat);

        }
        public static string GetLoggerEndLineString()
        {
            return "-------------------------------------------------------------------------------------------------------------------";
        }

        public static string GetExceptionMethodName(Exception ex = null)
        {
            StackTrace stackTrace = new StackTrace();
            StackFrame stackFrame = stackTrace.GetFrame(1);

            return stackFrame.GetMethod().Name;
        }


        public static async Task<string> UploadHTMFile(string path, IFormFile file)
        {
            string fileName = file.FileName;
            if (file.Length > 0)
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                using (var fileStream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
            }
            return Path.Combine(path, fileName);
        }

        public static void CreateHTML(string path, string docText, string fileName = "", string DocxFileName = "")
        {
            try
            {
                MatchCollection arr = Regex.Matches(docText, @"[\u0100-\uFFFF]");
                for (int intCnt = 0; intCnt <= arr.Count - 1; intCnt++)
                {
                    try
                    {
                        docText = docText.Replace(arr[intCnt].Value, Hex(Convert.ToString(char.ConvertToUtf32(arr[intCnt].Value, 0), 16)));

                    }
                    catch (Exception ex)
                    {

                        docText = docText.Replace(arr[intCnt].Value, "??");
                    }

                }
                docText = Regex.Replace(docText, "\u00A0", " ");
                docText = docText.Replace("#amp;", "&");
                docText = docText.Replace("#macamp;", "&");

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                var oMat = path.Split("\\")[4];
                //<link rel=\"stylesheet\" type=\"text/css\" href=\"http://mpsml.mpslimited.com/CSS/article.css\"></link>
                DocxFileName = DocxFileName != "" ? DocxFileName : oMat;
                string sHeadertmp = "<!DOCTYPE html><html lang=\"en\"><head><META http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><title>" + DocxFileName + "</title><script type=\"text/javascript\" async src=\"https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML\"></script></head>";
                docText = sHeadertmp + Regex.Replace(docText, @"<(\/?)article>", "<$1body>") + "</html>";
                path = fileName != "" ? Path.Combine(path, fileName) : path;
                File.WriteAllText(path, docText);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static void createXHtml(string path, string content, string fileName = "")
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = fileName != "" ? Path.Combine(path, fileName) : path;
            File.WriteAllText(path, "<article>" + content + "</article>");
            //File.WriteAllText(path, "<html><head></head><body>" + content + "</body></html>");
        }


        public static void CreateResponseTxtFile(object obj, string filePath, string apiName, bool isAppend = false)
        {

            try
            {
                string jsonString = JsonConvert.SerializeObject(obj);
                jsonString = apiName + ": " + jsonString + "\n" + Cnfunctions.GetLoggerEndLineString()+"\n";
                CreateFile(filePath, jsonString, isAppend: true);
            }
            catch (Exception ex)
            {

            }

        }

        public static void CreateFile(string path, string docText, string fileName = "", bool isAppend = false)
        {
            path = fileName != "" ? Path.Combine(path, fileName) : path;
            if (!Directory.Exists(Path.GetDirectoryName(path)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));

            }


            if (isAppend)
            {

                if (!File.Exists(path)) File.WriteAllText(path, docText); else File.AppendAllText(path, docText);
            }
            else { File.WriteAllText(path, docText); }

        }


        public static void zipFiles(string[] files)
        {
            // zip.AddDirectory(Server.MapPath("~/Directories/hello"));
            // MemoryStream output = new MemoryStream();
            // zip.Save(output);
            // return File(output, "application/zip", "sample.zip")
        }

        public static byte[] DownloadFile(string outfile)
        {
            byte[] bytes = File.ReadAllBytes(outfile);
            return bytes;
        }
        public static string GetPath()
        {
            return Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, "UploadedFiles"));
        }
        public static string regexreplace(string string1, string string2)
        {
            return "";
        }

        public static bool executeCmd(string exename, string arg)
        {
            return true;
        }

        public static string GetRomanNum(int intNumber)
        {
            string strText = intNumber.ToString();
            // 'Check whether the number varies between 0 to 3000
            if (intNumber > 0 & intNumber < 3000)
                return ConvertToRoman(intNumber);
            return strText;
        }

        public static string encodeSpecialChars(string intNumber)
        {
            return "";
        }

        public static string GetContentFromFile(string path)
        {
            if (File.Exists(path))
            {
                StreamReader sr = new StreamReader(path);
                string content = sr.ReadToEnd();
                sr.Close();
                return content;
            }
            else
            {
                return "";
            }

        }

        public static string ReadString(string path)
        {
            string returnString = "";
            try
            {
                returnString = File.ReadAllText(path).ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
            return returnString;
        }


        public static int GetRandomNumber(int number = 6)
        {
            //Random r = new Random();
            //int minValue = 111111;
            //int maxValue = 999999;

            //int returnNumber = r.Next(minValue, maxValue);
            int unixTimeStamp;
            DateTime currentTime = DateTime.Now;
            DateTime zuluTime = currentTime.ToUniversalTime();
            DateTime unixEpoch = new DateTime(1970, 1, 1);
            unixTimeStamp = (Int32)(zuluTime.Subtract(unixEpoch)).TotalSeconds;
            return unixTimeStamp;

        }

        public static string GetLetter(int intNumber)
        {
            int intTimes = 0;
            string strChar = "";
            string tmp = "";
            if (intNumber > 26)
            {
                intTimes = Convert.ToInt32(Math.Truncate(intNumber / (double)26));
                intNumber = intNumber % 26;
                if (intTimes > 1)
                    intNumber = intNumber + 1;
            }
            intNumber += 64;
            tmp = Convert.ToChar(intNumber).ToString();
            for (int i = 0; i <= intTimes; i++)
                strChar = strChar + tmp;
            return strChar;
        }

        public static string ConvertToRoman(int intNumber)
        {
            string strText = "";
            int a, b, c, d;
            if (intNumber == 0 || intNumber > 3000)
                return intNumber.ToString();
            a = (int)(intNumber / (double)1000);
            // If a > 5 Then intNumber = intNumber - 5
            b = (int)(intNumber / (double)100 % 10);
            // If b > 5 Then intNumber = intNumber - 5
            c = (int)(intNumber / (double)10 % 10);
            // If c > 5 Then intNumber = intNumber - 5
            d = intNumber % 10;
            a = a * 1000;
            b = b * 100;
            c = c * 10;
            if (a == 1000)
                strText = strText + "M";
            else if (a == 2000)
                strText = strText + "MM";
            else if (a == 3000)
                strText = strText + "MMM";
            if (b == 100)
                strText = strText + "C";
            else if (b == 200)
                strText = strText + "CC";
            else if (b == 300)
                strText = strText + "CCC";
            else if (b == 400)
                strText = strText + "CD";
            else if (b == 500)
                strText = strText + "D";
            else if (b == 600)
                strText = strText + "DC";
            else if (b == 700)
                strText = strText + "DCC";
            else if (b == 800)
                strText = strText + "DCCC";
            else if (b == 900)
                strText = strText + "CM";
            if (c == 10)
                strText = strText + "X";
            else if (c == 20)
                strText = strText + "XX";
            else if (c == 30)
                strText = strText + "XXX";
            else if (c == 40)
                strText = strText + "XL";
            else if (c == 50)
                strText = strText + "L";
            else if (c == 60)
                strText = strText + "LX";
            else if (c == 70)
                strText = strText + "LXX";
            else if (c == 80)
                strText = strText + "LXXX";
            else if (c == 90)
                strText = strText + "XC";
            if (d == 1)
                strText = strText + "I";
            else if (d == 2)
                strText = strText + "II";
            else if (d == 3)
                strText = strText + "III";
            else if (d == 4)
                strText = strText + "IV";
            else if (d == 5)
                strText = strText + "V";
            else if (d == 6)
                strText = strText + "VI";
            else if (d == 7)
                strText = strText + "VII";
            else if (d == 8)
                strText = strText + "VIII";
            else if (d == 9)
                strText = strText + "IX";
            return strText;
        }





        public static XmlElement CreateAttribute(ref XmlDocument xDoc, ref XmlElement xEle, string attrName, string attrValue = "")
        {
            try
            {
                xEle.Attributes.Append(xDoc.CreateAttribute(attrName));
                xEle.Attributes.GetNamedItem(attrName).Value = attrValue;
            }
            catch (Exception ex)
            {
                return null;
            }

            return xEle;
        }
        public static XmlNode CreateAttribute(ref XmlDocument xDoc, ref XmlNode xNode, string attrName, string attrValue = "")
        {
            try
            {
                xNode.Attributes.Append(xDoc.CreateAttribute(attrName));
                xNode.Attributes.GetNamedItem(attrName).Value = attrValue;
            }
            catch (Exception ex)
            {
                return null;
            }

            return xNode;
        }


        public static TextReader GetTextReader(string _string)
        {
            TextWriter _stringWriter;
            _stringWriter = new StringWriter();
            _stringWriter.Write(_string);

            TextReader _stringReader;
            _stringReader = new StringReader(_stringWriter.ToString());
            return _stringReader;
        }

        public static bool IsNumeric(string value)
        {
            return value.All(char.IsNumber);
        }

        public static void RenameNode(ref XmlNode parentnode, string oldChildName, string newChildName)
        {
            var newnode = parentnode.OwnerDocument.CreateNode(XmlNodeType.Element, newChildName, "");
            var oldNode = parentnode.SelectSingleNode(oldChildName);

            foreach (XmlAttribute att in oldNode.Attributes)
                newnode.Attributes.Append(att);
            foreach (XmlNode child in oldNode.ChildNodes)
                newnode.AppendChild(child);

            parentnode.ReplaceChild(newnode, oldNode);
        }

        public static XmlElement CreateNode(ref XmlDocument xDoc, string name)
        {
            XmlElement xEle;
            try
            {
                xEle = xDoc.CreateElement(name);
            }
            catch (Exception ex)
            {
                return null;
            }

            return xEle;
        }

        public static XmlElement CreateNode(ref XmlDocument xDoc, string name, string innerString)
        {


            var reader = XElement.Parse("<root>" + innerString + "</root>").CreateNavigator().InnerXml;
            XmlElement xEle;

            try
            {

                xEle = xDoc.CreateElement(name);
                xEle.InnerXml = innerString;
            }

            catch (Exception ex)
            {
                return null;
            }

            return xEle;
        }


        public static string InsertSpanTags(string htmlContent, string teiContent, string elementName = "*", string className = "")
        {
            XmlDocument teiContentNode = new XmlDocument();
            XmlNodeList teiContentNodeElements;
            string teiContentElementText = "";
            string attrName = "";
            MatchCollection elementMatch;
            if (teiContent != null)
            {
                teiContentNode.LoadXml(teiContent);
                teiContentNodeElements = teiContentNode.SelectNodes("//" + elementName);
                foreach (XmlNode teiContentNodeElement in teiContentNodeElements)
                {
                    teiContentElementText = StringCnfunction.RemoveTagsWithAttributes(teiContentNodeElement.InnerXml);
                    //teiContentElementText = Regex.Replace(teiContentNodeElement.InnerText,@"[^a-zA-z0-9 -]", @"&#?[a-z0-9]+;");
                    if (teiContentNodeElement.Attributes.Count > 0 && teiContentNodeElement.Attributes["type"] != null)
                    {
                        attrName = "class=\"" + teiContentNodeElement.Attributes.GetNamedItem("type").Value + "\"";
                    }
                    else if (className != "")
                    {
                        attrName = "class=\"" + className + "\"";
                    }
                    else
                    {
                        attrName = "class=\"" + teiContentNodeElement.Name + "\"";
                    }
                    
                    if (Regex.IsMatch(elementName, "^ref"))
                    {
                        elementMatch = Regex.Matches(htmlContent, "(?<!(<span[^<>]+>))" + Regex.Escape(teiContentElementText) + "(?!(</span>))", RegexOptions.RightToLeft);

                        if (teiContentElementText.Length > 1 && elementMatch.Count > 0)
                        {
                            for (int i = 0; i < elementMatch.Count; i++)
                            {
                                htmlContent = htmlContent.Insert(elementMatch[i].Index + elementMatch[0].Length, "</span>");
                                htmlContent = htmlContent.Insert(elementMatch[i].Index, "<span " + attrName + ">");
                            }
                        }

                    }
                    else
                    {
                        elementMatch = Regex.Matches(htmlContent, "(?<!(<span[^<>]+>))\\b" + Regex.Escape(teiContentElementText) + "\\b(?!(</span>))", RegexOptions.RightToLeft);

                        if (teiContentElementText.Length > 1 && elementMatch.Count > 0)
                        {
                            htmlContent = htmlContent.Insert(elementMatch[0].Index + elementMatch[0].Length, "</span>");
                            htmlContent = htmlContent.Insert(elementMatch[0].Index, "<span " + attrName + ">");

                        }
                    }
                    elementMatch = Regex.Matches(htmlContent, "\b" + Regex.Escape(teiContentElementText) + "\b", RegexOptions.RightToLeft);
                    if (teiContentElementText.Length == 1 && elementMatch.Count > 0)
                    {
                        htmlContent = htmlContent.Insert(elementMatch[0].Index + elementMatch[0].Length, "</span>");
                        htmlContent = htmlContent.Insert(elementMatch[0].Index, "<span " + attrName + ">");
                    }
                }
            }
            return htmlContent;
        }


        public static string RemoveAllTextFormatting(string htmlContent, string tagName)
        {
            XmlDocument xmlDocument = new XmlDocument();
            XmlNodeList nodeList;
            string nodeValue = "";
            xmlDocument.LoadXml(htmlContent); xmlDocument.PreserveWhitespace = true;
            nodeList = xmlDocument.SelectNodes("//div[count(" + tagName + ")=count(node()) and count(" + tagName + ")>0]");
            foreach (XmlNode node in nodeList)
            {
                try
                {
                    nodeValue = Regex.Replace(node.InnerXml, "</?" + tagName + ">", "");
                    node.InnerXml = nodeValue;
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex);
                }
            }
            htmlContent = xmlDocument.OuterXml;

            return htmlContent;
        }


        public static string setDocxFileName(string homePath)
        {
            string docxFileName = "";
            try
            {
                string[] files = Directory.GetFiles(homePath + "\\docx");
                foreach (var file in files)
                {
                    if (Path.GetFileName(file).EndsWith(".docx"))
                    {

                        docxFileName = Path.GetFileNameWithoutExtension(file);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return docxFileName;
        }


        public static string GetEntity(Dictionary<string, string> hsEntity, string FontName, string Val)
        {
            if (FontName == "")
                return "#amp;#x" + Val + ";";
            FontName = FontName + "|" + GetNumeric(Val);
            if (hsEntity.ContainsKey(FontName) == true)
                return hsEntity[FontName].ToString();
            else
                return "";
            //return "#amp;undeclared;";

        }


        public static string GetNumeric(string hexNumber)
        {
            hexNumber = hexNumber.Substring(1);

            int a;
            a = GetDecimalNum(hexNumber.Substring(0, 1)) * 16 * 16 + GetDecimalNum(hexNumber.Substring(1, 1)) * 16 + GetDecimalNum(hexNumber.Substring(2, 1));
            return a.ToString();
        }

        public static int GetDecimalNum(string hexNumberDigit)
        {
            int n;
            switch (hexNumberDigit.Trim())
            {
                case "A":
                    {
                        n = 10;
                        break;
                    }

                case "B":
                    {
                        n = 11;
                        break;
                    }

                case "C":
                    {
                        n = 12;
                        break;
                    }

                case "D":
                    {
                        n = 13;
                        break;
                    }

                case "E":
                    {
                        n = 14;
                        break;
                    }

                case "F":
                    {
                        n = 15;
                        break;
                    }

                default:
                    {
                        n = Convert.ToInt32(hexNumberDigit, 10);
                        break;
                    }
            }
            return n;
        }


        public static string GetEntityFont(Dictionary<string, string> hsEntity, string FontName, string Val)
        {

            // this is updated to make the hexadeciamal number to minimun 3 digits
            while (Val.Length < 4)
                Val = "0" + Val;
            FontName = FontName + "|" + GetNumeric(Val);

            // return the entity if the fontname was found otherwise undeclared
            if (hsEntity.ContainsKey(FontName) == true)
                return hsEntity[FontName].ToString().Replace("&", "#macamp;");
            else
                return "#macamp;undeclared;";
        }

        public static string Hex(string value)
        {
            value = value.ToUpper();
            while (value.Length < 5)
                value = "0" + value;
            return "#amp;#x" + value + ";";
        }





    }
}