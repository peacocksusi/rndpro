﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Models
{
    public class Header
    {
        public string articletype {  get; set; }
        public TitleGroup titlegroup { get; set; }
        public Author[] authors { get; set; }
        public Affiliation[] affiliations { get; set; }
        public string abshead { get; set; }
        public Abspara[] absparas { get; set; }
        public string kwdtitle { get; set; }
        public KwdTerm[] keywords { get; set; }
        public int wordCount { get; set; }
    }

    //titlegroup model

    public class TitleGroup
    {
        public string articletitle { get; set; }
        public string runningtitle { get; set; }
    }

    public class Author
    {
        public string authorid { get; set; }
        public string fname { get; set; }
        public string mname { get; set; }
        public string sname { get; set; }

        public string orcid { get; set; }
        public string suffix { get; set; }
        public string degree { get; set; }
        public bool isCorres { get; set; }
        public string[] affref { get; set; }
    }

    public class Affiliation
    {
        public string afflabel { get; set; }
        public string department { get; set; }
        public string institution { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string  postalcode { get; set; }
    }

    public class Abspara
    {
        public string para { get; set; }
    }

    public class KwdTerm
    {
        public string term { get; set; }
    }


    public class UpdateHeaderModel:CoreRequestModel
    {
        public Header metadata { get; set; }  
    }
}

