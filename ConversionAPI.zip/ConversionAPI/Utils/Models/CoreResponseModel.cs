﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Models
{
	public class CoreResponseModel
	{
        public string uniqueNumber { get; set; }
        public int status { get; set; } 
        public string message { get; set; }
        public string projectName { get; set; }
    }


    public class CoreRequestModel
    {
        public string uniqueNumber { get; set;}
    }
}
