﻿//using System;
//using System.Collections.Generic;
//using System.Data.Common;
//using System.Data;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Transactions;
//using Microsoft.Data.SqlClient;

//namespace Utils
//{
//    internal class SqlHelper
//    {
//        private static string AppDatabaseName;

//        static SqlHelper()
//        {
//            SqlHelper.AppDatabaseName = ConfigurationManager.AppSettings["AppDatabaseName"];
//        }

//        public SqlHelper()
//        {
//        }

//        public static bool ExecuteDynamicSql(string strsql)
//        {
//            bool flag;
//            TransactionScope transactionScope = new TransactionScope();
//            try
//            {
//                try
//                {
//                    try
//                    {
//                        Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                        database.ExecuteNonQuery(database.GetSqlStringCommand(strsql));
//                        transactionScope.Complete();
//                        flag = true;
//                    }
//                    catch (Exception exception1)
//                    {
//                        Exception exception = exception1;
//                        if (DataAccessExceptionHandler.HandleException(ref exception))
//                        {
//                            throw exception;
//                        }
//                        flag = false;
//                    }
//                }
//                finally
//                {
//                    transactionScope.Dispose();
//                }
//            }
//            finally
//            {
//                if (transactionScope != null)
//                {
//                    ((IDisposable)transactionScope).Dispose();
//                }
//            }
//            return flag;
//        }

//        public static bool ExecuteNonQuery(string spName)
//        {
//            bool flag;
//            TransactionScope transactionScope = new TransactionScope();
//            try
//            {
//                try
//                {
//                    try
//                    {
//                        Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                        database.ExecuteNonQuery(database.GetStoredProcCommand(spName));
//                        transactionScope.Complete();
//                        flag = true;
//                    }
//                    catch (Exception exception1)
//                    {
//                        Exception exception = exception1;
//                        if (DataAccessExceptionHandler.HandleException(ref exception))
//                        {
//                            throw exception;
//                        }
//                        flag = false;
//                    }
//                }
//                finally
//                {
//                    transactionScope.Dispose();
//                }
//            }
//            finally
//            {
//                if (transactionScope != null)
//                {
//                    ((IDisposable)transactionScope).Dispose();
//                }
//            }
//            return flag;
//        }

//        public static bool ExecuteNonQuery(string spName, DbParameter[] parameters)
//        {
//            bool flag;
//            TransactionScope transactionScope = new TransactionScope();
//            try
//            {
//                try
//                {
//                    try
//                    {
//                        Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                        DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                        storedProcCommand.Parameters.AddRange(parameters);
//                        database.ExecuteNonQuery(storedProcCommand);
//                        transactionScope.Complete();
//                        flag = true;
//                    }
//                    catch (Exception exception1)
//                    {
//                        Exception exception = exception1;
//                        if (DataAccessExceptionHandler.HandleException(ref exception))
//                        {
//                            throw exception;
//                        }
//                        flag = false;
//                    }
//                }
//                finally
//                {
//                    transactionScope.Dispose();
//                }
//            }
//            finally
//            {
//                if (transactionScope != null)
//                {
//                    ((IDisposable)transactionScope).Dispose();
//                }
//            }
//            return flag;
//        }

//        public static DbParameter[] ExecuteNonQueryWithOutputParameters(string spName, DbParameter[] parameters)
//        {
//            DbParameter[] dbParameterArray;
//            TransactionScope transactionScope = new TransactionScope();
//            try
//            {
//                try
//                {
//                    try
//                    {
//                        Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                        DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                        storedProcCommand.Parameters.AddRange(parameters);
//                        database.ExecuteNonQuery(storedProcCommand);
//                        transactionScope.Complete();
//                        dbParameterArray = parameters;
//                    }
//                    catch (Exception exception1)
//                    {
//                        Exception exception = exception1;
//                        if (DataAccessExceptionHandler.HandleException(ref exception))
//                        {
//                            throw exception;
//                        }
//                        dbParameterArray = null;
//                    }
//                }
//                finally
//                {
//                    transactionScope.Dispose();
//                }
//            }
//            finally
//            {
//                if (transactionScope != null)
//                {
//                    ((IDisposable)transactionScope).Dispose();
//                }
//            }
//            return dbParameterArray;
//        }

//        public static int ExecuteNonQueryWithReturnValue(string spName, DbParameter[] parameters)
//        {
//            int num;
//            TransactionScope transactionScope = new TransactionScope();
//            try
//            {
//                try
//                {
//                    try
//                    {
//                        Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                        DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                        DbParameter[] dbParameterArray = parameters;
//                        for (int i = 0; i < (int)dbParameterArray.Length; i++)
//                        {
//                            DbParameter dbParameter = dbParameterArray[i];
//                            if (dbParameter.Direction == ParameterDirection.Input)
//                            {
//                                storedProcCommand.Parameters.Add(dbParameter);
//                            }
//                        }
//                        DbParameter sqlParameter = new SqlParameter("@rvalue", SqlDbType.Int)
//                        {
//                            Direction = ParameterDirection.ReturnValue
//                        };
//                        storedProcCommand.Parameters.Add(sqlParameter);
//                        database.ExecuteNonQuery(storedProcCommand);
//                        int num1 = 0;
//                        int.TryParse(storedProcCommand.Parameters["@rvalue"].Value.ToString(), out num1);
//                        transactionScope.Complete();
//                        num = num1;
//                    }
//                    catch (Exception exception1)
//                    {
//                        Exception exception = exception1;
//                        if (DataAccessExceptionHandler.HandleException(ref exception))
//                        {
//                            throw exception;
//                        }
//                        num = -1;
//                    }
//                }
//                finally
//                {
//                    transactionScope.Dispose();
//                }
//            }
//            finally
//            {
//                if (transactionScope != null)
//                {
//                    ((IDisposable)transactionScope).Dispose();
//                }
//            }
//            return num;
//        }

//        public static object ExecuteScalar(string spName, DbParameter[] parameters)
//        {
//            object obj;
//            try
//            {
//                try
//                {
//                    Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                    DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                    storedProcCommand.Parameters.AddRange(parameters);
//                    obj = database.ExecuteScalar(storedProcCommand);
//                }
//                catch (Exception exception1)
//                {
//                    Exception exception = exception1;
//                    if (DataAccessExceptionHandler.HandleException(ref exception))
//                    {
//                        throw exception;
//                    }
//                    obj = null;
//                }
//            }
//            finally
//            {
//            }
//            return obj;
//        }

//        public static string ExecuteSPWithOutputParameter(string procedureName, string[] parametervalues, string constr)
//        {
//            SqlConnection sqlConnection = new SqlConnection(constr);
//            if (sqlConnection.State == ConnectionState.Closed)
//            {
//                sqlConnection.Open();
//            }
//            SqlTransaction sqlTransaction = sqlConnection.BeginTransaction();
//            string empty = string.Empty;
//            try
//            {
//                try
//                {
//                    SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConnection);
//                    SqlCommand sqlCommand1 = new SqlCommand(procedureName, sqlConnection);
//                    sqlCommand.CommandType = CommandType.StoredProcedure;
//                    sqlCommand.Transaction = sqlTransaction;
//                    sqlCommand1.CommandType = CommandType.StoredProcedure;
//                    sqlCommand1.Transaction = sqlTransaction;
//                    SqlParameter sqlParameter = new SqlParameter();
//                    if (sqlConnection.State == ConnectionState.Closed)
//                    {
//                        sqlConnection.Open();
//                    }
//                    SqlCommandBuilder.DeriveParameters(sqlCommand1);
//                    int num = 0;
//                    foreach (SqlParameter parameter in sqlCommand1.Parameters)
//                    {
//                        if (parameter.Direction == ParameterDirection.Input)
//                        {
//                            if (!(parametervalues[num].Trim() == string.Empty))
//                            {
//                                sqlCommand.Parameters.AddWithValue(parameter.ParameterName, parametervalues[num]);
//                            }
//                            else
//                            {
//                                sqlCommand.Parameters.AddWithValue(parameter.ParameterName, DBNull.Value);
//                            }
//                            num++;
//                        }
//                        else if (parameter.Direction == ParameterDirection.InputOutput)
//                        {
//                            sqlParameter.ParameterName = parameter.ParameterName;
//                            sqlParameter.SqlDbType = SqlDbType.VarChar;
//                            sqlParameter.Size = 1000;
//                            sqlParameter.Direction = ParameterDirection.Output;
//                            sqlCommand.Parameters.Add(sqlParameter);
//                        }
//                    }
//                    sqlCommand.ExecuteNonQuery();
//                    empty = sqlParameter.Value.ToString();
//                    sqlTransaction.Commit();
//                    sqlCommand.Dispose();
//                    sqlConnection.Close();
//                }
//                catch (Exception exception1)
//                {
//                    Exception exception = exception1;
//                    sqlTransaction.Rollback();
//                    throw exception;
//                }
//            }
//            finally
//            {
//                if (sqlConnection.State == ConnectionState.Open)
//                {
//                    sqlConnection.Close();
//                }
//                sqlConnection = null;
//            }
//            return empty;
//        }

//        private static Database GetDatabase(string dbName)
//        {
//            Database database;
//            try
//            {
//                Database database1 = null;
//                if (dbName != null)
//                {
//                    Database database2 = DatabaseFactory.CreateDatabase(dbName);
//                    database1 = database2;
//                    database = database2;
//                }
//                else
//                {
//                    Database database3 = DatabaseFactory.CreateDatabase();
//                    database1 = database3;
//                    database = database3;
//                }
//            }
//            catch (Exception exception)
//            {
//                throw exception;
//            }
//            return database;
//        }

//        public static IDataReader GetDataReader(string spName)
//        {
//            IDataReader dataReader;
//            try
//            {
//                Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                dataReader = database.ExecuteReader(spName, new object[0]);
//            }
//            catch (Exception exception1)
//            {
//                Exception exception = exception1;
//                if (DataAccessExceptionHandler.HandleException(ref exception))
//                {
//                    throw exception;
//                }
//                dataReader = null;
//            }
//            return dataReader;
//        }

//        public static IDataReader GetDataReader(string spName, object[] parameters)
//        {
//            IDataReader dataReader;
//            try
//            {
//                Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                dataReader = database.ExecuteReader(spName, parameters);
//            }
//            catch (Exception exception1)
//            {
//                Exception exception = exception1;
//                if (DataAccessExceptionHandler.HandleException(ref exception))
//                {
//                    throw exception;
//                }
//                dataReader = null;
//            }
//            return dataReader;
//        }

//        public static DataSet GetDataSet(string spName)
//        {
//            DataSet dataSet;
//            try
//            {
//                Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                dataSet = database.ExecuteDataSet(database.GetStoredProcCommand(spName));
//            }
//            catch (Exception exception1)
//            {
//                Exception exception = exception1;
//                if (DataAccessExceptionHandler.HandleException(ref exception))
//                {
//                    throw exception;
//                }
//                dataSet = null;
//            }
//            return dataSet;
//        }

//        public static DataSet GetDataSet(string spName, DbParameter[] parameters)
//        {
//            DataSet dataSet;
//            try
//            {
//                try
//                {
//                    Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                    DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                    storedProcCommand.Parameters.AddRange(parameters);
//                    dataSet = database.ExecuteDataSet(storedProcCommand);
//                }
//                catch (Exception exception1)
//                {
//                    Exception exception = exception1;
//                    if (DataAccessExceptionHandler.HandleException(ref exception))
//                    {
//                        throw exception;
//                    }
//                    dataSet = null;
//                }
//            }
//            finally
//            {
//            }
//            return dataSet;
//        }

//        public static DataTable GetDataTable(string spName)
//        {
//            DataTable dataTable;
//            try
//            {
//                Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                DataSet dataSet = database.ExecuteDataSet(database.GetStoredProcCommand(spName));
//                DataTable item = new DataTable();
//                if (dataSet.Tables.Count > 0)
//                {
//                    item = dataSet.Tables[0];
//                }
//                dataTable = item;
//            }
//            catch (Exception exception1)
//            {
//                Exception exception = exception1;
//                if (DataAccessExceptionHandler.HandleException(ref exception))
//                {
//                    throw exception;
//                }
//                dataTable = null;
//            }
//            return dataTable;
//        }

//        public static DataTable GetDataTable(string spName, DbParameter[] parameters)
//        {
//            DataTable dataTable;
//            try
//            {
//                try
//                {
//                    Database database = SqlHelper.GetDatabase(SqlHelper.AppDatabaseName);
//                    DbCommand storedProcCommand = database.GetStoredProcCommand(spName);
//                    storedProcCommand.Parameters.AddRange(parameters);
//                    DataSet dataSet = database.ExecuteDataSet(storedProcCommand);
//                    DataTable item = new DataTable();
//                    if (dataSet.Tables.Count > 0)
//                    {
//                        item = dataSet.Tables[0];
//                    }
//                    dataTable = item;
//                }
//                catch (Exception exception1)
//                {
//                    Exception exception = exception1;
//                    if (DataAccessExceptionHandler.HandleException(ref exception))
//                    {
//                        throw exception;
//                    }
//                    dataTable = null;
//                }
//            }
//            finally
//            {
//            }
//            return dataTable;
//        }

//        public static DataTable GetDataTableFromSP(string procedureName, string constr)
//        {
//            SqlConnection sqlConnection = new SqlConnection(constr);
//            DataTable dataTable = new DataTable();
//            try
//            {
//                try
//                {
//                    SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConnection)
//                    {
//                        CommandType = CommandType.StoredProcedure
//                    };
//                    (new SqlDataAdapter(sqlCommand)).Fill(dataTable);
//                }
//                catch (Exception exception)
//                {
//                    throw exception;
//                }
//            }
//            finally
//            {
//                if (sqlConnection.State == ConnectionState.Open)
//                {
//                    sqlConnection.Close();
//                }
//                sqlConnection = null;
//            }
//            return dataTable;
//        }

//        public static DataTable GetDataTableFromSP(string procedureName, string[] parametervalues, string constr)
//        {
//            SqlConnection sqlConnection = new SqlConnection(constr);
//            DataTable dataTable = new DataTable();
//            try
//            {
//                try
//                {
//                    SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConnection);
//                    SqlCommand sqlCommand1 = new SqlCommand(procedureName, sqlConnection);
//                    sqlCommand.CommandType = CommandType.StoredProcedure;
//                    sqlCommand1.CommandType = CommandType.StoredProcedure;
//                    if (sqlConnection.State == ConnectionState.Closed)
//                    {
//                        sqlConnection.Open();
//                    }
//                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
//                    SqlCommandBuilder.DeriveParameters(sqlCommand1);
//                    int num = 0;
//                    foreach (SqlParameter parameter in sqlCommand1.Parameters)
//                    {
//                        if (parameter.Direction == ParameterDirection.Input)
//                        {
//                            if (!(parametervalues[num].Trim() == string.Empty))
//                            {
//                                sqlCommand.Parameters.AddWithValue(parameter.ParameterName, parametervalues[num]);
//                            }
//                            else
//                            {
//                                sqlCommand.Parameters.AddWithValue(parameter.ParameterName, DBNull.Value);
//                            }
//                            num++;
//                        }
//                    }
//                    sqlDataAdapter.Fill(dataTable);
//                }
//                catch (Exception exception)
//                {
//                    throw exception;
//                }
//            }
//            finally
//            {
//                if (sqlConnection.State == ConnectionState.Open)
//                {
//                    sqlConnection.Close();
//                }
//                sqlConnection = null;
//            }
//            return dataTable;
//        }
//    }
//}