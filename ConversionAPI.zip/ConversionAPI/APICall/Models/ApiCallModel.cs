﻿using Utils.Models;

namespace APICall.Models
{
    public class ApiCallModel
    {
    }

    public class GetHeaderRequestModel
    {
        public string fileName { get; set; }
        public string filePath { get; set; }
        public string repositoryCode { get; set; }
    }


    public class GetHeaderResponseModel : CoreResponseModel
    {
        public Header metadata { get; set; }
        //public int wordCount { get; set; }
    }

    public class DownloadPostModel
    {
        public string uniqueNumber { get; set; }
        public string fileName { get; set; }
    }

    public class GetHtmlModel : CoreResponseModel { public string digiLink { get; set; } }
}
