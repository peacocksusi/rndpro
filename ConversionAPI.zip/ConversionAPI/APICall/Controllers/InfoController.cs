﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utils.Models;

namespace APICall.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {

        [HttpGet]

        public ProjectInfo Get()
        {
            ProjectInfo projectInfo = new ProjectInfo();
            projectInfo.Name = "ApiCall";
            projectInfo.Version = "0.0.0";
            projectInfo.Description = "This api is gateway of all conversion API's";
            return projectInfo;
        }
    }
}
