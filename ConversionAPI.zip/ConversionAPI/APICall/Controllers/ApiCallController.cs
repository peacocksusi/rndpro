﻿using APICall.Models;
using APICall.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using System.Threading.Tasks;
using Utils.Common;
using Utils.Logger;
using Utils.Models;
using System.IO;
using Microsoft.AspNetCore.Components.Forms;
using System.IO.Pipes;
using System.Text;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Text.RegularExpressions;
using System;

namespace APICall.Controllers
{
    [Route("api")]
    [ApiController]
    public class ApiCallController : ControllerBase
    {
        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];


        private string message;
        private string uniqueNumber;
        private string docxFileName;
        public ApiCallController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            try
            {

                this.message = "";
                this.configuration = configuration;
                this.logger = logger;
                this.customConstant = customConstant;
            }
            catch (Exception ex)
            {

                this.message = ex.Message;
            }
        }

        [HttpPost]
        [Route("GetHeader")]


        public async Task<GetHeaderResponseModel> GetHeader(GetHeaderRequestModel getHeaderRequestModel)
        {
            ApiCallServices apiCallServices = new ApiCallServices(this.logger);
            GetHeaderResponseModel getHeaderModel = new GetHeaderResponseModel();
            try
            {
                this.uniqueNumber = getHeaderRequestModel.filePath;
                string resquestTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), "request.txt");
                Cnfunctions.CreateResponseTxtFile(getHeaderRequestModel, resquestTxtOutpath, "GetHeader", true);

                string fileName = getHeaderRequestModel.fileName;
                string url = customConstant.S3_BUCKET_URL + "download";
                this.logger.LogInfo(this.uniqueNumber + " GetHeader Started s3bucket url: " + url);
                IFormFile file = await apiCallServices.PostAsyncResStream(url, JsonConvert.SerializeObject(getHeaderRequestModel), getHeaderRequestModel.fileName);

                this.logger.LogInfo(this.uniqueNumber + " FileDownload from s3bucket" + url);
                this.docxFileName = Path.GetFileNameWithoutExtension(fileName);

                if (file != null)
                {
                    getHeaderModel = await HeaderConversion(file, getHeaderRequestModel.filePath);
                }
                else
                {
                    getHeaderModel.status = 400;
                    getHeaderModel.message = this.uniqueNumber + " " + getHeaderRequestModel.fileName + " doesn't exist";
                    this.logger.LogError(getHeaderModel.message);
                }



                return getHeaderModel;
            }
            catch (Exception ex)
            {

                getHeaderModel.status = 400;
                getHeaderModel.message = uniqueNumber + " " + this.docxFileName + " " + ex.Message;
                this.logger.LogError(getHeaderModel.message);
                return getHeaderModel;
            }
        }



        [HttpPost]
        [Route("HeaderConversion")]

        public async Task<GetHeaderResponseModel> HeaderConversion(IFormFile inputfile, string fileKey = "", string config = "")
        {
          
            ApiCallServices apiCallServices = new ApiCallServices(this.logger);
            GetHeaderResponseModel getHeaderModel = new GetHeaderResponseModel();



            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.projectName = this.projectName;

            try
            {
                this.docxFileName = Path.GetFileNameWithoutExtension(inputfile.FileName);

                //set configuration using startup class
                Startup startup = new Startup(this.configuration, this.logger, this.customConstant, fileKey);
                this.uniqueNumber = startup.uniqueNumber;
                string resquestTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), "request.txt");
                Cnfunctions.CreateResponseTxtFile(fileKey, resquestTxtOutpath, "HeaderConversion", true);


                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file process started.");
                startup.docxFileName = this.docxFileName;

                //upload docfile


                startup.UploadFile(inputfile);

                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file uploaded.");

                //extract docfile
                startup.ExtractContent();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file extracted.");
                coreResponseModel.status = 200;

                foreach (var item in customConstant.API_GATEWAY_LIST)
                {
                    string projectNameFromUrl = Regex.Replace(item, @"https?://(?:.*?)/(.*?)/.*", "$1");
                    coreResponseModel.projectName = projectNameFromUrl;

                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " " + projectNameFromUrl + " process started.");
                    coreResponseModel = await apiCallServices.APIWrapper(item, this.uniqueNumber, config);
                    coreResponseModel.projectName = projectNameFromUrl;
                    if (coreResponseModel.status != 200)
                    { break; }
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " " + projectNameFromUrl + " process completed.");

                }



                if (coreResponseModel.status == 200)
                {
                    string plainHtmlFilePath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.TXT_OUTPATH, this.uniqueNumber, customConstant), customConstant.BODYTXT_NAME);
                  

                    message = this.uniqueNumber + " " + this.docxFileName + " file process completed.";
                    getHeaderModel.status = 200;
                    getHeaderModel.uniqueNumber = this.uniqueNumber;
                    getHeaderModel.message = this.message;
                    string headerJsonPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.JSON_OUTPATH, getHeaderModel.uniqueNumber, customConstant), customConstant.HEADERJSON_NAME);
                    string headerJsonString = Cnfunctions.ReadString(headerJsonPath);
                    getHeaderModel.metadata = JsonConvert.DeserializeObject<Header>(headerJsonString);

                    if (System.IO.File.Exists(plainHtmlFilePath))
                    {
                        string plainHtmlTxtContent = Cnfunctions.ReadString(plainHtmlFilePath);
                        MatchCollection matCol = Regex.Matches(plainHtmlTxtContent, @"\w+");
                        getHeaderModel.metadata.wordCount = matCol.Count;

                    }
                    this.logger.LogInfo(message);
                }
                else
                {
                    getHeaderModel.projectName = coreResponseModel.projectName;
                    throw new Exception("check logs in " + coreResponseModel.projectName);
                }
                 string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant),customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(getHeaderModel, responseTxtOutpath, "HeaderConversion", true);

                return getHeaderModel;

            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;
                getHeaderModel.status = 400;
                getHeaderModel.uniqueNumber = this.uniqueNumber;
                getHeaderModel.message = this.message;

                this.logger.LogError(getHeaderModel.message);
                string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(getHeaderModel, responseTxtOutpath, "HeaderConversion", true);
                return getHeaderModel;
            }

        }


        [HttpPost]
        [Route("GetHtml")]

        public async Task<GetHtmlModel> GetHtml([FromQuery] string uniqueNumber)
        {

            string resquestTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), "request.txt");
            Cnfunctions.CreateResponseTxtFile(uniqueNumber, resquestTxtOutpath, "GetHtml", true);
            GetHtmlModel getHtmlModel = new GetHtmlModel();
            CoreResponseModel coreResponseModel = new CoreResponseModel();

            ApiCallServices apiCallServices = new ApiCallServices(this.logger);

            try
            {
                this.uniqueNumber = uniqueNumber;
                getHtmlModel.uniqueNumber = coreResponseModel.uniqueNumber;

                string homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);
                string outPath = Cnfunctions.GetModifiedPath(customConstant.DIGIHTML_OUTPATH, uniqueNumber, customConstant);
                this.docxFileName = Cnfunctions.setDocxFileName(homePath);

                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " structure body html process started.");
                coreResponseModel = JsonConvert.DeserializeObject<CoreResponseModel>(await apiCallServices.PostAsync(customConstant.HTMLBODY_URL.Replace("{uniqueNumber}", this.uniqueNumber), ""));
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " structure body html process completed.");

                if (coreResponseModel.status == 200)
                {
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " structure back html process started.");
                    coreResponseModel = JsonConvert.DeserializeObject<CoreResponseModel>(await apiCallServices.PostAsync(customConstant.HTMLTAIL_URL.Replace("{uniqueNumber}", this.uniqueNumber), ""));
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " structure back html process completed.");
                }

                string frontHtmlPath = Cnfunctions.GetModifiedPath(Path.Combine(customConstant.STRUCTEDHTML_OUTPATH, customConstant.FRONTHTML_NAME), uniqueNumber, customConstant);
                string bodyHtmlPath = Cnfunctions.GetModifiedPath(Path.Combine(customConstant.STRUCTEDHTML_OUTPATH, customConstant.BODYHTML_NAME), uniqueNumber, customConstant);
                string backHtmlPath = Cnfunctions.GetModifiedPath(Path.Combine(customConstant.STRUCTEDHTML_OUTPATH, customConstant.BACKHTML_NAME), uniqueNumber, customConstant);

                string[] structureHtmlPathArr = { frontHtmlPath, bodyHtmlPath, backHtmlPath };
                string str = "";

                foreach (var item in structureHtmlPathArr)
                {
                    if (!System.IO.File.Exists(frontHtmlPath))
                    {
                        str += ", " + Path.GetFileName(item);
                    }
                }


                if (coreResponseModel.status == 200)
                {
                    string digiHtml = ApiCallServices.MergeFiles(structureHtmlPathArr);
                    Cnfunctions.createXHtml(outPath, digiHtml, customConstant.DIGIHTML_NAME);
                    getHtmlModel.digiLink = customConstant.DIGI_LINK.Replace("{uniqueNumber}", uniqueNumber);
                    getHtmlModel.status = 200;
                    getHtmlModel.projectName = this.projectName;
                    getHtmlModel.message = "Digihtml generated";
                    ApiCallServices.AppyDBFile(customConstant.SYNC_IN_PATH, Cnfunctions.GetModifiedPath(customConstant.SYNC_OUT_PATH, uniqueNumber, customConstant));
                    this.logger.LogInfo(message);
                }
                //else if (coreResponseModel.status == 200 && str != "")
                //{
                //    getHtmlModel.projectName = coreResponseModel.projectName;
                //    getHtmlModel.status = 400;
                //    getHtmlModel.message = str.Trim(',') + " html files doesn't exist";
                //    this.logger.LogError(message);
                //}
                else
                {
                    getHtmlModel.projectName = coreResponseModel.projectName;
                    getHtmlModel.status = 400;
                    getHtmlModel.message = coreResponseModel.message;
                    this.logger.LogError(message);
                }

                string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(getHtmlModel, responseTxtOutpath, "GetHtml", true);
                return getHtmlModel;

            }
            catch (Exception ex)
            {
                getHtmlModel.status = 400;
                getHtmlModel.message = uniqueNumber + " " + this.docxFileName + " " + ex.Message;
                this.logger.LogError(getHtmlModel.message);
                string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(getHtmlModel, responseTxtOutpath, "GetHtml", true);
                return getHtmlModel;
            }
        }


        [HttpPost]
        [Route("UpdateHeader")]
        public async Task<CoreResponseModel> UpdateHeader([FromBody] UpdateHeaderModel updateHeaderModel)
        {
            string resquestTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), "request.txt");
            Cnfunctions.CreateResponseTxtFile(updateHeaderModel, resquestTxtOutpath, "UpdateHeader", true);

            CoreResponseModel coreResponseModel = new CoreResponseModel();

            try
            {
                uniqueNumber = updateHeaderModel.uniqueNumber;


                ApiCallServices apiCallServices = new ApiCallServices(this.logger);
                coreResponseModel.projectName = this.projectName;

                coreResponseModel = await apiCallServices.APIWrapper(customConstant.JSONUPDATEHEAD_URL, uniqueNumber, data: JsonConvert.SerializeObject(updateHeaderModel));
                string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(coreResponseModel, responseTxtOutpath,"UpdateHeader", true);

                return coreResponseModel;

            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;
                coreResponseModel.status = 400;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;

                this.logger.LogError(coreResponseModel.message);
                string responseTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), customConstant.RESPONSETXT_NAME);
                Cnfunctions.CreateResponseTxtFile(coreResponseModel, responseTxtOutpath, "UpdateHeader", true);

                return coreResponseModel;
            }
        }




        [HttpPost]
        [Route("download")]
        public IActionResult Download([FromBody] DownloadPostModel downloadPostModel)
        {

            string resquestTxtOutpath = Path.Combine(Cnfunctions.GetModifiedPath(this.customConstant.TXT_OUTPATH, uniqueNumber, this.customConstant), "request.txt");
            Cnfunctions.CreateResponseTxtFile(downloadPostModel, resquestTxtOutpath, "download", true);
            try
            {


                string fileName = downloadPostModel.fileName;
                string uniqueNumber = downloadPostModel.uniqueNumber;
                string path = "";
                if (fileName.EndsWith(".pdf"))
                {

                    path = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.PDF_OUTPATH, uniqueNumber, customConstant), fileName);
                }
                else if (fileName.EndsWith(".html"))
                {
                    path = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.STRUCTEDHTML_OUTPATH, uniqueNumber, customConstant), fileName);

                }
                else if (fileName.EndsWith(".json"))
                {
                    path = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.JSON_OUTPATH, uniqueNumber, customConstant), fileName);

                }

                byte[] bytes = System.IO.File.ReadAllBytes(path);
                return File(bytes, "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {

                return null;
            }
        }





    }
}
