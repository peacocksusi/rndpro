﻿using Microsoft.VisualBasic;
using System.Text.RegularExpressions;
using Utils.Common;
using Utils.Logger;
using static Utils.Common.CustomConstant;

namespace APICall.Services
{
    public class Startup
    {

        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        public string docxFileName = "";
        public string homePath = "";
        private string outPath = "";
        public string message = "";
        public string uniqueNumber = "";
        public Startup(IConfiguration configuration, ILoggerService logger,ICustomConstant customConstant,string uniqueNumber="")
        {
            try
            {
                this.configuration = configuration;
                this.logger = logger;

                this.customConstant = customConstant;
                this.uniqueNumber = uniqueNumber!=""?uniqueNumber:Cnfunctions.GetRandomNumber().ToString();
                string path = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, this.uniqueNumber, this.customConstant);
                this.homePath = path;
                //this.outPath = Path.Combine(homePath, "html");
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }
        }




        public void UploadFile(IFormFile file, string fileName = "")
        {
            try
            {
               

                fileName = fileName != "" ? fileName : file.FileName;

                //change docx to docx for case sensitive issue
                fileName = Regex.Replace(fileName, @"\.docx$", ".docx",RegexOptions.IgnoreCase);
                string path = Path.Combine(this.homePath, "docx");
                if (file.Length > 0)
                {
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    using (var fileStream = new FileStream(Path.Combine(path, fileName), FileMode.Create, FileAccess.ReadWrite))
                    {
                        file.CopyTo(fileStream);
                    }
                }

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }
        }

        public void ExtractContent()
        {
            try
            {
                string fileName = "wordml";
                string path = Path.Combine(this.homePath, fileName);
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                }
                    Directory.CreateDirectory(path);
                FileInfo docxFile = new FileInfo(Path.Combine(this.homePath, "docx", this.docxFileName + ".docx"));
                using (var fileStream = new MemoryStream())
                {
                    docxFile.CopyTo(Path.Combine(path, fileName + customConstant.ZIP_EXTNS));
                }
                //File.Copy(Path.Combine(this.homePath,"docx", this.docxFileName+".docx"), Path.Combine(path, fileName + ZIP_EXTNS), true);
                System.IO.Compression.ZipFile.ExtractToDirectory(Path.Combine(path, fileName + customConstant.ZIP_EXTNS), path);


            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }

        }
    }
}
