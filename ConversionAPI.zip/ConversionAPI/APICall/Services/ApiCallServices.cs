﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Utils.Common;
using Utils.Logger;
using Utils.Models;
using static Utils.Common.CustomConstant;

namespace APICall.Services
{
    public class ApiCallServices
    {
        ILoggerService logger;


        public ApiCallServices(ILoggerService logger)
        {
            this.logger = logger;
        }
        public async Task<string> GetAsync(string uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (HttpWebResponse response = (HttpWebResponse)await request.GetResponseAsync())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                return await reader.ReadToEndAsync();
            }
        }


        public async Task<string> PostAsync(string uri, string data, string contentType = "application/json", string method = "POST")
        {

            try
            {


                byte[] dataBytes = Encoding.UTF8.GetBytes(data);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                request.ContentLength = dataBytes.Length;
                request.ContentType = contentType;
                request.Method = method;

                using (Stream requestBody = request.GetRequestStream())
                {
                    await requestBody.WriteAsync(dataBytes, 0, dataBytes.Length);
                }

                using (HttpWebResponse response = (HttpWebResponse)await request.GetResponseAsync())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    return await reader.ReadToEndAsync();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<IFormFile> CopyStream(Stream stream, string destPath)
        {
            //using (var fileStream = new FileStream(destPath, FileMode.Create, FileAccess.Write))
            //{
            //    stream.CopyTo(fileStream);
            //}
            IFormFile filer = null;
            var fileStream = new MemoryStream();

            stream.CopyTo(fileStream);

            FormFile file = new FormFile(fileStream, 0, stream.Length, null, "test.docx")
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            };

            //file =  new FormFile(fileStream, 0, stream.Length, "name","test.txt");

            return file;

        }



        public async Task<IFormFile> PostAsyncResStream(string uri, string data,string fileName, string contentType = "application/json", string method = "POST")
        {


            try
            {

                HttpClient httpclinet = new HttpClient();
                byte[] dataBytes = Encoding.UTF8.GetBytes(data);

                var stringContent = new StringContent(data, Encoding.UTF8,contentType);

                HttpResponseMessage response = await httpclinet.PostAsync(uri, stringContent);

                if (response.IsSuccessStatusCode)
                {
                    var stream = await response.Content.ReadAsStreamAsync();
                    StreamFormFile formFile = new StreamFormFile(stream, "inputfile", fileName, stream.Length);
                    return formFile;
                }

                return null;

            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public async Task<System.IO.Stream> Upload(string actionUrl, Byte[] fileBytes, string fileKey)
        {
            HttpContent stringContent = new StringContent(fileKey);
            //HttpContent fileStreamContent = new StreamContent(paramFileStream);
            HttpContent bytesContent = new ByteArrayContent(fileBytes);
            using (var client = new HttpClient())
            using (var formData = new MultipartFormDataContent())
            {
                formData.Add(stringContent, "fileKey", "fileKey");
                //formData.Add(fileStreamContent, "file1", "file1");
                formData.Add(bytesContent, "inputfile", "file2");
                var response = await client.PostAsync(actionUrl, formData);
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                return await response.Content.ReadAsStreamAsync();
            }
        }



        public static string MergeFiles(string[] pathArr)
        {
            string result = "";

            foreach (var path in pathArr)
            {
                string htmlContent = Cnfunctions.ReadString(path);
                result += Regex.Replace(Regex.Match(htmlContent, "<body>(.*?)</body>", RegexOptions.Singleline).Value, "</?body>", "");

            }
            return result;

        }


        public static void AppyDBFile(string inPath, string outPath)
        {
            try
            {

                File.Copy(inPath, outPath, true);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task<CoreResponseModel>  APIWrapper(string url,string uniqueNumber,string configuration ="",string data="")
        {
            CoreResponseModel coreResponseModel = new CoreResponseModel();
            url = url.Replace("{uniqueNumber}", uniqueNumber);
            url = url.Replace("{config}", configuration);
            var response = await PostAsync(url, data);

            if (response!=null)
            {
            coreResponseModel = JsonConvert.DeserializeObject<CoreResponseModel>(response) ;

            }
            else
            {
                coreResponseModel.status = 400;
                coreResponseModel.message = "The operation has time out or api returns null";
                coreResponseModel.uniqueNumber = uniqueNumber;
            }
            return coreResponseModel;
        }






    }
}
