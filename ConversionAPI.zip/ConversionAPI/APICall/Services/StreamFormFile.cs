﻿using Microsoft.AspNetCore.Http;
using System.IO;

namespace APICall.Services
{
    public class StreamFormFile : IFormFile
    {
        private readonly Stream _stream;

        public StreamFormFile(Stream stream, string name, string fileName, long length)
        {
            _stream = stream;
            Name = name;
            FileName = fileName;
            Length = length;
        }

        public string ContentType => throw new NotImplementedException();

        public string ContentDisposition => throw new NotImplementedException();

        public IHeaderDictionary Headers => throw new NotImplementedException();

        public long Length { get; }

        public string Name { get; }

        public string FileName { get; }

        public void CopyTo(Stream target)
        {
            _stream.CopyTo(target);
        }

        public Task CopyToAsync(Stream target, CancellationToken cancellationToken = default)
        {
            return _stream.CopyToAsync(target, 81920, cancellationToken); // Use an appropriate buffer size
        }

        public Stream OpenReadStream()
        {
            return _stream;
        }
    }

}
