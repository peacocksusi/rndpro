﻿using HTMLTail.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Utils.Common;
using Utils.Logger;
using Utils.Models;

namespace HTMLTail.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HTMLTailController : Controller
    {

        private readonly IConfiguration configuration;
        private readonly ILoggerService logger;
        private readonly ICustomConstant customConstant;
        private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

        private string message;
        private string uniqueNumber;
        private string docxFileName;

        public HTMLTailController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        [HttpPost]
        public CoreResponseModel structureBackHTML(string uniqueNumber)
        {

            backHtmlDocument backHtmlDoc = new backHtmlDocument(configuration, logger, customConstant);
            CoreResponseModel coreResponseModel = new CoreResponseModel();
            try
            {

                coreResponseModel.projectName = this.projectName;
                this.uniqueNumber = uniqueNumber;
                coreResponseModel.uniqueNumber = this.uniqueNumber;

                backHtmlDoc.StartUp(uniqueNumber);
                if (Regex.IsMatch(backHtmlDoc.backHtmlContent, @"<article><div class=""back"">(.+)</div></article>"))
                {

                    backHtmlDoc.processAcknowledgement();
                    backHtmlDoc.processFunding();
                    backHtmlDoc.processReference();
                    backHtmlDoc.processDeclaration();
                    backHtmlDoc.generateFrontHtml(backHtmlDoc.docxFileName);
                    coreResponseModel.status = 200;
                    coreResponseModel.message = backHtmlDoc.message;
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " " + coreResponseModel.message);
                }
                else
                {
                    backHtmlDoc.generateFrontHtml(backHtmlDoc.docxFileName);
                    coreResponseModel.status = 200;
                    coreResponseModel.message = "Back html is empty";
                    this.logger.LogWarn(this.uniqueNumber + " " + this.docxFileName + " " + coreResponseModel.message);
                }

            }
            catch (Exception ex)
            {
                coreResponseModel.status = 400;
                coreResponseModel.message = backHtmlDoc.message + ex.Message;
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + coreResponseModel.message);
                throw;
            }

            //string path = Cnfunctions.GetPath();
            //string filename = await Cnfunctions.UploadHTMFile(path, backHtmlfile);
            //string refTextPath = backHtmlDoc.getRefText();
            //backHtmlDoc.processReference(refTextPath);
            //byte[] bytes = Cnfunctions.DownloadFile(Path.Combine(path, "back.html"));
            //return File(bytes, "application/octet-stream", "back.html");
            return coreResponseModel;
        }
    }
}
