﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utils.Models;

namespace HTMLTail.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {

        [HttpGet]

        public ProjectInfo Get()
        {
            ProjectInfo projectInfo = new ProjectInfo();
            projectInfo.Name = "HtmlTail";
            projectInfo.Version = "0.0.0";
            projectInfo.Description = "This api is helps to structure back.html";
            return projectInfo;
        }
    }
}
