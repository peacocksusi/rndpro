﻿using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using Utils.Common;
using Utils.Logger;

namespace HTMLTail.Service
{
    public class backHtmlDocument
    {

        private XmlDocument backHtmlNode = new XmlDocument();
        public string backHtmlContent = "";
        private XmlDocument processFullTextXmlNode = new XmlDocument();


        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        public string docxFileName = "";
        private string homePath = "";
        private string outPath = "";
        public string message = "";
        public string pattern = "";
        public string replacement = "";
        public string uniqueNumber = "";
        public backHtmlDocument(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        public void StartUp(string uniqueNumber)
        {
            try
            {
                this.uniqueNumber = uniqueNumber;

                homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);

                outPath = Cnfunctions.GetModifiedPath(customConstant.STRUCTEDHTML_OUTPATH, uniqueNumber, customConstant);
                this.docxFileName = Cnfunctions.setDocxFileName(homePath);
                this.SetBackHtmlContent();
                this.SetProcessFullTextXmlNode();
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void applyStyles()
        {

        }

        public void processAcknowledgement()
        {
            XmlElement refListElem;
            XmlNode backReferenceNode = backHtmlNode.SelectSingleNode("//div[@class='back']/div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'acknowledgement')]");

            if (backReferenceNode != null)
            {
                string backReferenceContent = backReferenceNode.InnerXml;
                refListElem = Cnfunctions.CreateNode(ref backHtmlNode, "div");
                Cnfunctions.CreateAttribute(ref backHtmlNode, ref refListElem, "class", "ack");
                backReferenceContent = Regex.Replace(backReferenceContent, "(Ackn[^\\s\\:<>]+)[\\:\\s]*", "<div class=\"title\">$1</div>", RegexOptions.IgnoreCase);
                backReferenceContent = Regex.Replace(Regex.Replace(backReferenceContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                backReferenceNode.InnerXml = backReferenceContent;
                refListElem.InnerXml = backReferenceContent;

                while (backReferenceNode.NextSibling != null && backReferenceNode.NextSibling.Name == "div" && !(backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("reference") || backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("funding") || backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("declaration")))
                {
                    if (backReferenceNode.NextSibling.Attributes.GetNamedItem("class") == null)
                    {
                        backReferenceNode.NextSibling.Attributes.Append(backHtmlNode.CreateAttribute("class"));
                    }
                    backReferenceNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                    refListElem.AppendChild(backReferenceNode.NextSibling);
                }

                backReferenceNode.ReplaceChild(refListElem, backReferenceNode.FirstChild);




                this.backHtmlContent = this.backHtmlNode.OuterXml;
            }
        }


        public void processFunding()
        {
            XmlElement refListElem;
            XmlNode backReferenceNode = backHtmlNode.SelectSingleNode("//div[@class='back']/div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'funding')]");

            if (backReferenceNode != null)
            {
                string backReferenceContent = backReferenceNode.InnerXml;
                refListElem = Cnfunctions.CreateNode(ref backHtmlNode, "div");
                Cnfunctions.CreateAttribute(ref backHtmlNode, ref refListElem, "class", "funding");
                backReferenceContent = Regex.Replace(backReferenceContent, @"(Fund[^\\:<>]+)[\\:\s]*", "<div class=\"title\">$1</div>", RegexOptions.IgnoreCase);
                //backReferenceContent = Regex.Replace(Regex.Replace(backReferenceContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                backReferenceNode.InnerXml = backReferenceContent;
                refListElem.InnerXml = backReferenceContent;

                while (backReferenceNode.NextSibling != null && backReferenceNode.NextSibling.Name == "div" && !(backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("reference") || backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("acknowledgement") || backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("declaration")))
                {
                    if (backReferenceNode.NextSibling.Attributes.GetNamedItem("class") == null)
                    {
                        backReferenceNode.NextSibling.Attributes.Append(backHtmlNode.CreateAttribute("class"));
                    }
                    backReferenceNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                    refListElem.AppendChild(backReferenceNode.NextSibling);
                }

                backReferenceNode.ReplaceChild(refListElem, backReferenceNode.FirstChild);




                this.backHtmlContent = this.backHtmlNode.OuterXml;
            }
        }

        public void processDeclaration()
        {
            XmlElement refListElem;
            XmlNode backReferenceNode = backHtmlNode.SelectSingleNode("//div[@class='back']/div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'declaration')]");

            if (backReferenceNode != null)
            {
                string backReferenceContent = backReferenceNode.InnerXml;
                refListElem = Cnfunctions.CreateNode(ref backHtmlNode, "div");
                Cnfunctions.CreateAttribute(ref backHtmlNode, ref refListElem, "class", "declaration");
                backReferenceContent = Regex.Replace(backReferenceContent, @"(Decla[^\\:<>]+)[\\:\s]*", "<div class=\"title\">$1</div>", RegexOptions.IgnoreCase);
                //backReferenceContent = Regex.Replace(Regex.Replace(backReferenceContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                backReferenceNode.InnerXml = backReferenceContent;
                refListElem.InnerXml = backReferenceContent;

                while (backReferenceNode.NextSibling != null && backReferenceNode.NextSibling.Name == "div" && !(backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("reference") ||backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("acknowledgement") || backReferenceNode.NextSibling.InnerText.ToLower().StartsWith("funding")))
                {
                    if (backReferenceNode.NextSibling.Attributes.GetNamedItem("class") == null)
                    {
                        backReferenceNode.NextSibling.Attributes.Append(backHtmlNode.CreateAttribute("class"));
                    }
                    backReferenceNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                    refListElem.AppendChild(backReferenceNode.NextSibling);
                }

                backReferenceNode.ReplaceChild(refListElem, backReferenceNode.FirstChild);




                this.backHtmlContent = this.backHtmlNode.OuterXml;
            }
        }

        public void processReference()
        {

            try
            {


                XmlElement refListElem;
                XmlNode backReferenceNode = backHtmlNode.SelectSingleNode("//div[@class='back']/div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'reference')]");

                string fullTextLastReferenceContent = this.processFullTextXmlNode.SelectSingleNode("//back//*[last()][name()=\"biblStruct\"]").InnerText;

                if (backReferenceNode != null)
                {
                    string backReferenceContent = backReferenceNode.InnerXml;
                    refListElem = Cnfunctions.CreateNode(ref backHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref backHtmlNode, ref refListElem, "class", "refList");
                    backReferenceContent = Regex.Replace(backReferenceContent, "(Ref[^\\s\\:<>]+)[\\:\\s]*", "<div class=\"title\">$1</div>", RegexOptions.IgnoreCase);
                    backReferenceContent = Regex.Replace(Regex.Replace(backReferenceContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                    backReferenceNode.InnerXml = backReferenceContent;
                    refListElem.InnerXml = backReferenceContent;
                    while (backReferenceNode.NextSibling != null && backReferenceNode.NextSibling.Name == "div" && !Regex.IsMatch(StringCnfunction.RemoveNonAlphapeticWord(backReferenceNode.NextSibling.InnerText), StringCnfunction.RemoveNonAlphapeticWord(fullTextLastReferenceContent)))
                    {
                        if (backReferenceNode.NextSibling.Attributes.GetNamedItem("class") == null)
                        {
                            backReferenceNode.NextSibling.Attributes.Append(backHtmlNode.CreateAttribute("class"));
                        }
                        backReferenceNode.NextSibling.Attributes.GetNamedItem("class").Value = "bib-reference";
                        refListElem.AppendChild(backReferenceNode.NextSibling);
                    }

                    backReferenceNode.ReplaceChild(refListElem, backReferenceNode.FirstChild);




                    this.backHtmlContent = this.backHtmlNode.OuterXml;
                }
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }



        }



        //final method in HTMLBack API
        public void generateFrontHtml(string DocxFileName = "")
        {
            try
            {
                this.backHtmlContent = Regex.Replace(this.backHtmlContent, @"<div>((<div class=""[^<>]+"">((?:(?!<\/div>).)*)<\/div>)*<\/div>)<\/div>", @"$1");
                Cnfunctions.CreateHTML(outPath, this.backHtmlContent, "Back.html", DocxFileName);
                this.message = "BackHtml file generated";
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



        public void SetBackHtmlContent()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string backHtmlContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.HTML_OUTPATH, uniqueNumber, customConstant), customConstant.BACKHTML_NAME);
                string backHtmlContent = Regex.Match(Cnfunctions.ReadString(backHtmlContentPath), "<body>(.*?)</body>", RegexOptions.Singleline).Value;
                if (backHtmlContent == "")
                {
                    this.message = "[SetbackHtmlNode] => Check " + customConstant.BACKHTML_NAME + "file path";
                    return;
                }
                backHtmlContent = Regex.Replace(backHtmlContent, @"(<list>(.+?)</list>)", "<div>$1</div>");
                backHtmlContent = Regex.Replace(backHtmlContent, @"<(/?)(H|h)eading[0-9]>", "<$1div>");
                //backHtmlContent = Regex.Replace(backHtmlContent, @"</?b>", "");
                backHtmlContent = Regex.Replace(backHtmlContent, @"\r|\n|\t", "");
                backHtmlContent = Regex.Replace(backHtmlContent, @"</(subtleemphasis|b|i|u|emphasis)><\1>", "");
                backHtmlContent = Regex.Replace(backHtmlContent, @"(?<=<div[^>]*>)<\2>([^<>]+)<\/(b|i|u)>(?=</div>)", "$1", RegexOptions.RightToLeft);
                backHtmlContent = Regex.Replace(backHtmlContent, "</?footnotereference>", "", RegexOptions.IgnoreCase);
                backHtmlContent = backHtmlContent.Replace("<xref refid=\"fn*\">", "");
                backHtmlContent = backHtmlContent.Replace("</xref>", "");

                xmlDoc.LoadXml(backHtmlContent); xmlDoc.PreserveWhitespace = true;
                backHtmlContent = xmlDoc.SelectSingleNode("//body").OuterXml.Replace("<body>", "<article>").Replace("</body>", "</article>");
                this.backHtmlNode.LoadXml(backHtmlContent); this.backHtmlNode.PreserveWhitespace = true;
                backHtmlContent = backHtmlNode.InnerXml.Replace("’", "'");
                backHtmlContent = backHtmlNode.InnerXml.Replace("’’", "'");

                this.backHtmlNode.LoadXml(backHtmlContent); this.backHtmlNode.PreserveWhitespace = true;
                this.backHtmlContent = backHtmlContent;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void SetProcessFullTextXmlNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string processFulltextContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant), docxFileName + "-processFulltextDocument.xml");

                string processFullTextContent = Cnfunctions.ReadString(processFulltextContentPath);
                if (processFullTextContent == "")
                {
                    this.message = "[SetprocessFullTextXmlNode] => Check processFulltextDocument.xml file path";
                    return;
                }
                processFullTextContent = Regex.Replace(processFullTextContent, "<lb/>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?fileDesc>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?profileDesc>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?textClass>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                processFullTextContent = Regex.Replace(processFullTextContent, ">[\r\n\t]+", ">");
                processFullTextContent = Regex.Replace(processFullTextContent, "[\r\n\t]+<", "<");
                processFullTextContent = Regex.Replace(processFullTextContent, "><", "> <");
                this.processFullTextXmlNode.PreserveWhitespace = true;
                this.processFullTextXmlNode.LoadXml(processFullTextContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



    }
}
