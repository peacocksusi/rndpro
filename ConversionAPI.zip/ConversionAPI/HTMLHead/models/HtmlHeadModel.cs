﻿namespace HTMLHead.models
{
    public class HtmlHeadModel
    {

    }

    public class MatchedDataModel
    {
        public bool aritcleTitle { get; set; }
        public bool authorGrp { get; set; }
        public int affiliationCount { get; set; }
        public bool abstractStyle { get; set; }
        public bool keyword { get; set; }
    }
}
