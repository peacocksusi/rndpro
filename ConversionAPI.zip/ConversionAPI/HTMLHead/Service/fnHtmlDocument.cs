﻿using HTMLHead.models;
using Microsoft.Extensions.FileSystemGlobbing.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Utils.Common;
using Utils.Logger;
using static System.Net.Mime.MediaTypeNames;
using static Utils.Common.StringCnfunction;

namespace HTMLHead.Service
{
    public class FnHtmlDocument
    {
        #region Global Variables
        //private XDocument frontHtmlXNode = new XDocument();
        private XmlDocument frontHtmlNode = new XmlDocument();
        private string frontHtmlContent = "";
        private XmlDocument processHeaderXmlNode = new XmlDocument();
        private XmlDocument processFullTextXmlNode = new XmlDocument();


        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        public string docxFileName = "";
        private string homePath = "";
        private string outPath = "";
        public string message = "";
        public string pattern = "";
        public string replacement = "";
        public string uniqueNumber = "";
        public Dictionary<string, string> FMElements = new Dictionary<string, string>();

        Dictionary<string, XmlNode> combinedAuthorNode = new Dictionary<string, XmlNode>();
        Dictionary<string, List<string>> combinedAffNode = new Dictionary<string, List<string>>();
        List<string> depList = new List<string>();
        List<string> institutionList = new List<string>();
        List<string> settlementList = new List<string>();
        List<string> regionList = new List<string>();
        List<string> pCodeList = new List<string>();
        List<string> addrLineList = new List<string>();
        List<string> countryList = new List<string>();
        //Dictionary<string, XmlNode> combinedAffNode = new Dictionary<string, XmlNode>();

        MatchedDataModel matchedDataModel = new MatchedDataModel();
        #endregion

        public FnHtmlDocument(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
            this.GetFrontMatterMappedNames();
        }


        //configurations 
        public void StartUp(string uniqueNumber)
        {
            try
            {
                this.uniqueNumber = uniqueNumber;

                homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);

                outPath = Cnfunctions.GetModifiedPath(customConstant.STRUCTEDHTML_OUTPATH, uniqueNumber, customConstant);
                this.docxFileName = Cnfunctions.setDocxFileName(homePath);
                this.SetFrontHtmlContent();
                this.SetProcessHeaderXmlNode();
                this.SetProcessFullTextXmlNode();
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        //process
        public void applyStyles()
        {
            try
            {


                applyArticleTitleStyle();
                applyAuthorGroupStyle();
                applyAffStyle();
                applyAbstractStyle();
                applyKeywordStyle();



            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }
        #region Apply Styles Sub Functions


        public void applyArticleTitleStyle()
        {
            try
            {
                bool isMatched = false;
                XmlNode xmlTitleNode = this.processHeaderXmlNode.SelectSingleNode("//title");
                XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");
                string xmlTitleNodeContent = xmlTitleNode.OuterXml;
                isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "articletitle");
                if (!isMatched)
                {
                    xmlTitleNode = this.processFullTextXmlNode.SelectSingleNode("//title");
                    xmlTitleNodeContent = xmlTitleNode.OuterXml;
                    isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "articletitle");
                }
                matchedDataModel.aritcleTitle = isMatched;
                this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void applyAuthorGroupStyle()
        {
            try
            {

                bool isMatched = false;
                XmlNodeList xmlAuthGrpNode = this.processHeaderXmlNode.SelectNodes("//persName/forename|//persName/surname");
                //XmlNodeList xmlAuthGrpNode = this.processHeaderXmlNode.SelectNodes("//persName");
                XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");
                //string xmlAuthGrpNodeContent = "";
                string[] xmlAuthGrpNodeContent = StringCnfunction.GetArray(xmlAuthGrpNode);

                if (xmlAuthGrpNodeContent != null && xmlAuthGrpNodeContent.Length > 0)
                {

                    foreach (XmlNode frontHtmlNode in frontHtmlNodeList)
                    {
                        if (IsAuthorGrpStructure(frontHtmlNode.InnerText, xmlAuthGrpNodeContent))
                        {
                            XmlNode refNode = frontHtmlNode;
                            Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref refNode, "class", "authors");
                            Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref refNode, "data-matched", "authorGroupPattern");
                            isMatched = true;
                            break;
                        }
                    }
                }



                matchedDataModel.authorGrp = isMatched;
                this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);


            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }

        public bool IsAuthorGrpStructure(string authorDivString, string[] arr)
        {
            bool result = false;
            int count = 0;
            if (arr == null) return result;
            for (int i = 0; i < arr.Length; i++)
            {
                if (Regex.IsMatch(authorDivString, "\\b" + arr[i] + "\\b", RegexOptions.IgnoreCase))
                {
                    count++;
                }

            }
            float countAverage = (float)count / arr.Length;

            if ((countAverage * 100) > 70)
            {
                result = true;
            }


            return result;

        }

        public void applyAffStyle()
        {
            bool isMatched = false;
            try
            {
                XmlNodeList xmlAuthGrpNode = this.processHeaderXmlNode.SelectNodes("//affiliation[not(@key= preceding::affiliation/@key)]");
                XmlNodeList xmlAuthGrpFullTextNode = this.processFullTextXmlNode.SelectNodes("//affiliation[not(@key= preceding::affiliation/@key)]");

                foreach (XmlNode item in xmlAuthGrpNode)
                {
                    XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");

                    isMatched = matchFindAndReplace(item.OuterXml, ref frontHtmlNodeList, "aff");

                    if (isMatched)
                    {
                        matchedDataModel.affiliationCount++;
                    }
                }

                foreach (XmlNode item in xmlAuthGrpFullTextNode)
                {
                    XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");

                    isMatched = matchFindAndReplace(item.OuterXml, ref frontHtmlNodeList, "aff");

                    if (isMatched)
                    {
                        matchedDataModel.affiliationCount++;
                    }
                }
                this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }

        public void applyAbstractStyle()
        {
            try
            {
                bool isMatched = false;
                isMatched = applyAbstractStyleByPattern();
              

                if (!isMatched)
                {
                    XmlNode xmlTitleNode = this.processHeaderXmlNode.SelectSingleNode("//abstract");
                    XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");
                    string xmlTitleNodeContent = xmlTitleNode.OuterXml;
                    isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "abstract", isBreak: false);
                    if (!isMatched)
                    {
                        xmlTitleNode = this.processFullTextXmlNode.SelectSingleNode("//abstract");
                        xmlTitleNodeContent = xmlTitleNode.OuterXml;
                        isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "abstract", isBreak: false);
                    }
                }

                //for (int i = 0; i < frontHtmlNodeList.Count; i++)
                //{
                //    XmlNode item = frontHtmlNodeList[i];
                //    if (item.InnerText.ToLower() != "abstract")
                //    {
                //        continue;
                //    }
                //    if (item.NextSibling.Name == "div" && !item.NextSibling.InnerText.ToLower().StartsWith("keyword"))
                //    {
                //        XmlNode nextSibling = item.NextSibling;
                //        Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref nextSibling, "class", "abstract");
                //        //item.NextSibling.Attributes.Append(this.frontHtmlNode.CreateAttribute("class"));
                //    }
                //}
                matchedDataModel.abstractStyle = isMatched;
                this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void applyKeywordStyle()
        {
            try
            {
                bool isMatched = false;
                XmlNode xmlTitleNode = this.processHeaderXmlNode.SelectSingleNode("//keywords");
                XmlNodeList frontHtmlNodeList = this.frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[not(@data-matched)]");
                string xmlTitleNodeContent = "";
                if (xmlTitleNode != null)
                {
                    xmlTitleNodeContent = xmlTitleNode.OuterXml;
                    isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "keywordgroup");


                }
                if (!isMatched)
                {
                    xmlTitleNode = this.processFullTextXmlNode.SelectSingleNode("//keywords");
                    if (xmlTitleNode != null)
                    {
                        xmlTitleNodeContent = xmlTitleNode.OuterXml;
                        isMatched = matchFindAndReplace(xmlTitleNodeContent, ref frontHtmlNodeList, "keywordgroup");
                    }
                }
                if (!isMatched)
                {

                    isMatched = this.applyKeyWordStyleByPattern();
                }


                matchedDataModel.keyword = isMatched;
                this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }
        #endregion


        public void processAritcleTitle()
        {
            XmlNode articleTitleHtmlNode = this.frontHtmlNode.SelectSingleNode("//div[@class='articletitle']");

            if (articleTitleHtmlNode != null)
            {

                articleTitleHtmlNode.Attributes.GetNamedItem("class").Value = "title";
                XmlNode titleGroupNode = Cnfunctions.CreateNode(ref this.frontHtmlNode, "div");
                Cnfunctions.CreateAttribute(ref this.frontHtmlNode,ref titleGroupNode,"class", "titlegroup");
                titleGroupNode.InnerXml = articleTitleHtmlNode.OuterXml;

                articleTitleHtmlNode.ParentNode.ReplaceChild(titleGroupNode, articleTitleHtmlNode);

                
            }


        }


        public void processAuthor()
        {
            try
            {
                XmlNode authorGrpHtmlNode = this.frontHtmlNode.SelectSingleNode("//div[@class='authors']");



                //insert author class div
                if (authorGrpHtmlNode != null)
                {
                    XmlDocument authorApiElems = new XmlDocument();
                    string GApiHeader = GrobidApiService.GetHeaderNames(authorGrpHtmlNode.InnerText, customConstant).Result;
                    XmlNodeList authorXmlElements = null;
                    if (GApiHeader != null && GApiHeader != "")
                    {
                        authorApiElems.LoadXml(GApiHeader);

                        //process author by Grobid API 
                        authorXmlElements = authorApiElems.SelectNodes("//persName[forename][surname]");
                        this.GetAuthorList(authorXmlElements);

                    }



                    ////process author by header xml file 
                    authorXmlElements = this.processHeaderXmlNode.SelectNodes("//teiHeader//persName[forename][surname]");
                    this.GetAuthorList(authorXmlElements);


                    //process author by fulltext xml file 
                    authorXmlElements = this.processFullTextXmlNode.SelectNodes("//teiHeader//persName[forename][surname]");
                    this.GetAuthorList(authorXmlElements);

                    foreach (XmlNode authorXmlElement in combinedAuthorNode.Values)
                    {
                        var foreName = authorXmlElement.SelectSingleNode("forename").InnerText;
                        var surName = authorXmlElement.SelectSingleNode("surname").InnerText;


                        pattern = foreName + "(?:(?![<>]).)*?" + surName;
                        replacement = "<div class=\"author\">$&</div>";

                        var regex = new Regex(pattern, RegexOptions.IgnoreCase);
                        authorGrpHtmlNode.InnerXml = regex.Replace(authorGrpHtmlNode.InnerXml, replacement, 1);
                        //authorGrpHtmlNode.InnerXml = Regex.Replace(authorGrpHtmlNode.InnerXml, pattern, replacement ,RegexOptions.None);
                    }
                }


                this.frontHtmlContent = this.frontHtmlNode.OuterXml;

                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }




        }

        #region Process Author Sub Functions

        public void GetAuthorList(XmlNodeList authorXmlElements)
        {

            foreach (XmlNode authorXmlElement in authorXmlElements)
            {
                if (authorXmlElement.SelectSingleNode("forename[@type=\"first\"]") != null && authorXmlElement.SelectSingleNode("surname") != null)
                {

                    var foreName = authorXmlElement.SelectSingleNode("forename[@type=\"first\"]").InnerText;
                    var surName = authorXmlElement.SelectSingleNode("surname").InnerText;
                    if (!combinedAuthorNode.ContainsKey(foreName + "-" + surName))
                    {
                        combinedAuthorNode.Add(foreName + "-" + surName, authorXmlElement);

                    }
                }
            }
        }
        #endregion

        public void processAuthorNames()
        {

            try
            {

                XmlNodeList htmlContentNodeList = this.frontHtmlNode.SelectNodes("//div[@class='author']");



                foreach (XmlNode xmlAuthElem in combinedAuthorNode.Values)
                {
                    string xmlPersNameContent = xmlAuthElem.InnerText;
                    foreach (XmlNode htmlAuthorNodeElem in htmlContentNodeList)
                    {
                        string htmlAuthorContent = htmlAuthorNodeElem.InnerText;

                        DataMatchFoundModel dataMatchFoundModel = new DataMatchFoundModel();

                        dataMatchFoundModel = StringCnfunction.DataMatchFound(htmlAuthorContent, xmlPersNameContent);



                        if (dataMatchFoundModel.isMatch)
                        {
                            htmlAuthorNodeElem.InnerXml = AuthorInsertSpanTags(htmlAuthorNodeElem.InnerXml, xmlAuthElem.OuterXml);

                            break;
                        }
                    }

                }

                this.frontHtmlContent = this.frontHtmlNode.OuterXml;

                this.frontHtmlNode.LoadXml(this.frontHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public string AuthorInsertSpanTags(string htmlAuthXml, string xmlAuthXml)
        {

            try
            {


                XmlDocument xmlContentNode = new XmlDocument();
                XmlNodeList xmlContentNodeElements;
                string xmlContentElementText = "";
                string attrName = "";

                MatchCollection elementMatch;
                if (xmlAuthXml != null)
                {
                    xmlContentNode.LoadXml(xmlAuthXml);
                    xmlContentNodeElements = xmlContentNode.SelectNodes("//*");

                    foreach (XmlNode xmlContentNodeElement in xmlContentNodeElements)
                    {
                        xmlContentElementText = xmlContentNodeElement.InnerText;
                        if (xmlContentNodeElement.Attributes.GetNamedItem("type") != null && xmlContentNodeElement.Attributes.GetNamedItem("type").Value == "middle")
                        {
                            attrName = "class=\"middlename\"";

                        }
                        else if (xmlContentNodeElement.Name == "forename")
                        {
                            attrName = "class=\"given-name\"";
                        }
                        else
                        {
                            attrName = "class=\"" + xmlContentNodeElement.Name + "\"";

                        }

                        //elementMatch = Regex.Matches(htmlAuthXml, "(?<!(<span[^<>]+>))(?<!<[^>]*)" + Regex.Escape(xmlContentElementText) + "(?!(</span>))", RegexOptions.RightToLeft | RegexOptions.IgnoreCase);
                        elementMatch = Regex.Matches(htmlAuthXml, "(?<!<[^>]*)(?<!<span[^>][^<]+)" + Regex.Escape(xmlContentElementText), RegexOptions.RightToLeft | RegexOptions.IgnoreCase);
                        if (xmlContentElementText.Length > 0 && elementMatch.Count > 0 && xmlContentNodeElement.Name != "marker")
                        {

                            htmlAuthXml = htmlAuthXml.Insert(elementMatch[elementMatch.Count - 1].Index + elementMatch[elementMatch.Count - 1].Length, "</span>");
                            htmlAuthXml = htmlAuthXml.Insert(elementMatch[elementMatch.Count - 1].Index, "<span " + attrName + ">");

                        }

                    }
                }

                return htmlAuthXml;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void processAutAffRef()
        {
            try
            {



                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
                XmlNodeList frontHtmlAuthNode = frontHtmlNode.SelectNodes("//div[@class='authors']/*[not(@class='author')]");

                foreach (XmlNode frontHtmlAutgrpElement in frontHtmlAuthNode)
                {
                    pattern = @"(\d|\*|\#|(?<![a-z/<])[a-z](?![a-z/>]))";
                    replacement = "<span name=\"aff\" class=\"cite\" href=\"aff$1\">$1</span>";
                    var autGrpElemAffRef = Regex.Replace(frontHtmlAutgrpElement.InnerXml, pattern, replacement);
                    frontHtmlAutgrpElement.InnerXml = autGrpElemAffRef;
                }
                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
                this.authCleanUp();
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }




        public void processAffn()
        {
            try
            {

                this.affnPreCleanup();
                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;

                // for non list affiliation
                XmlNodeList frontAffNodeList = frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='articlemeta']/div[@class='aff']");
                XmlNode frontAuthorsNode = frontHtmlNode.SelectSingleNode("//div[@class='aff']");
                XmlElement affGrpElem = Cnfunctions.CreateNode(ref frontHtmlNode, "div");
                Cnfunctions.CreateAttribute(ref frontHtmlNode, ref affGrpElem, "class", "affiliations");
                if (frontAuthorsNode != null)
                {
                    frontAuthorsNode.ParentNode.InsertBefore(affGrpElem, frontAuthorsNode);

                }
                int index = 1;
                foreach (XmlNode frontAffNode in frontAffNodeList)
                {
                    if (!(frontAffNode.ParentNode != null && Regex.IsMatch(frontAffNode.ParentNode.OuterXml, "<div class=\"\"affiliations\"\">")))
                    {
                       
                        //frontAffNode.ParentNode.InsertBefore(affGrpElem, frontAffNode);
                        frontAffNode.Attributes.Append(frontHtmlNode.CreateAttribute("id"));
                        frontAffNode.Attributes.GetNamedItem("id").Value = "aff" + index;
                        affGrpElem.AppendChild(frontAffNode);
                    }
                    index++;
                }

                frontAffNodeList = frontHtmlNode.SelectNodes("//div[@class='aff']");
                XmlNode affsHtmlNode = frontHtmlNode.SelectSingleNode("//div[@class='affiliations']");
                if (affsHtmlNode != null)
                {

                    XmlDocument affApiElems = new XmlDocument();
                    string GApiHeader = GrobidApiService.GetAffiliation(affsHtmlNode.InnerText, customConstant).Result;
                    if (GApiHeader != "" && GApiHeader != null)
                    {

                        affApiElems.LoadXml(GApiHeader);
                        AffListWrapper(affApiElems);
                    }

                    AffListWrapper(this.processHeaderXmlNode);
                    AffListWrapper(this.processFullTextXmlNode);
                    this.combinedAffNode.Add("department", depList);
                    this.combinedAffNode.Add("institution", institutionList);
                    this.combinedAffNode.Add("settlement", settlementList);
                    this.combinedAffNode.Add("country", countryList);
                    this.combinedAffNode.Add("region", regionList);
                    this.combinedAffNode.Add("postCode", pCodeList);
                    this.combinedAffNode.Add("addrLine", addrLineList);
                    foreach (XmlNode frontAffNode in frontAffNodeList)
                    {
                        foreach (var item in combinedAffNode.Keys)
                        {
                            frontAffNode.InnerXml = AffInsertSpanTags(frontAffNode.InnerXml, item);
                        }
                    }
                }
                affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, "<sup>(.*?)</sup>", "<span class=\"label\">$1</span>");
                //changes capture only digits without dots
                affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, @"(?<!<[^>]*)(?<!<span[^>][^<]+)(\b[\d\*\#])\.?[\s:]+", "<span class=\"label\">$1</span>");

                //affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, @"(?<!<[^>]*)(?<!<span[^>][^<]+)(\b[\d\*\#][.]?[\s|:]+)", "<span class=\"label\">$1</span>");
                affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, @"(<div[^<>]+aff[^<>]+>)\s?([a-zA-Z0-9])\s?(<span)", "$1<span class=\"label\">$2</span>$3");
                affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, "</?i>", "");

                frontAffNodeList = frontHtmlNode.SelectNodes("//div[@class='aff']");

                foreach (XmlNode frontAffNode in frontAffNodeList)
                {
                        string affLabel = "";
                        if (frontAffNode.SelectSingleNode("./span[@class='label']")!=null)
                        {

                         affLabel = frontAffNode.SelectSingleNode("./span[@class='label']").InnerText.Trim();
                        }

                        frontAffNode.Attributes.GetNamedItem("id").Value = "aff" + affLabel;
                    
                }

                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }
        public void AffListWrapper(XmlDocument xmlDoc)
        {

            depList = this.GetAffList(xmlDoc, "/*[@type='department' or @type='laboratory']");
            institutionList = this.GetAffList(xmlDoc, "/*[@type='institution']");
            settlementList = this.GetAffList(xmlDoc, "//settlement");
            countryList = this.GetAffList(xmlDoc, "//country");
            regionList = this.GetAffList(xmlDoc, "//region");
            pCodeList = this.GetAffList(xmlDoc, "//postCode");
            addrLineList = this.GetAffList(xmlDoc, "//addrLine");



        }


        public List<string> GetAffList(XmlDocument affXmlDoc, string tagPath)
        {
            List<string> affChildElemList = new List<string>();
            XmlNodeList xmlChildElems = affXmlDoc.SelectNodes("//affiliation[not(@key= preceding::affiliation/@key)]" + tagPath);
            foreach (XmlNode xmlChildElem in xmlChildElems)
            {
                if (!affChildElemList.Contains(xmlChildElem.InnerXml.Trim()))
                {
                    affChildElemList.Add(xmlChildElem.InnerXml.Trim());

                }



            }
            return affChildElemList;
        }


        public string AffInsertSpanTags(string frontAffContent, string keyName)
        {
            List<string> xmlAffList = this.combinedAffNode[keyName];
            string attr = "class=\"" + keyName + "\"";
            foreach (var xmlAffChildText in xmlAffList)
            {
                MatchCollection elementMatch = Regex.Matches(frontAffContent, "(?<!<[^>]*)(?<!<span[^>][^<]+)" + Regex.Escape(xmlAffChildText), RegexOptions.IgnoreCase);

                if (keyName == "settlement" || keyName == "country" || keyName == "region" || keyName == "postCode" || keyName == "addrLine")
                {
                    elementMatch = Regex.Matches(frontAffContent, "(?<!<[^>]*)(?<!<span[^>][^<]+)" + Regex.Escape(xmlAffChildText), RegexOptions.RightToLeft | RegexOptions.IgnoreCase);
                }
                if (xmlAffChildText.Length > 0 && elementMatch.Count > 0)
                {
                    frontAffContent = frontAffContent.Insert(elementMatch[0].Index + elementMatch[0].Length, "</span>");
                    frontAffContent = frontAffContent.Insert(elementMatch[0].Index, "<span " + attr + ">");
                    //break;

                }
                //MatchCollection elementMatch = Regex.Matches(frontAffContent, "(?<!<[^>]*)(?<!<span[^>][^<]+)" + Regex.Escape(xmlAffChildText), RegexOptions.RightToLeft | RegexOptions.IgnoreCase);
                //if (xmlAffChildText.Length > 0 && elementMatch.Count > 0)
                //{
                //    frontAffContent = frontAffContent.Insert(elementMatch[elementMatch.Count - 1].Index + elementMatch[elementMatch.Count - 1].Length, "</span>");
                //    frontAffContent = frontAffContent.Insert(elementMatch[elementMatch.Count - 1].Index, "<span " + keyName + ">");
                //    //break;

                //}
            }
            return frontAffContent;
        }

        //public void GetAffList(XmlNodeList affXmlElements, bool isAPI = false)
        //{
        //    //affXmlElements = affApiElems.SelectNodes("//affiliation");
        //    int affIterationId = 0;
        //    foreach (XmlNode affXmlElement in affXmlElements)
        //    {

        //        if (isAPI)
        //        {
        //            affIterationId++;
        //            combinedAffNode.Add("aff" + affIterationId, affXmlElement);
        //            continue;
        //        }
        //        if (affXmlElement.SelectSingleNode("/*[1]") != null && affXmlElement.SelectSingleNode("/*[last()]") != null)
        //        {
        //            var firstChild = affXmlElement.SelectSingleNode("./*[1]").InnerText;
        //            var lastChild = affXmlElement.SelectSingleNode("./*[last()]").InnerText;
        //            if (!combinedAffNode.ContainsKey(firstChild + "-" + lastChild))
        //            {
        //                combinedAffNode.Add(firstChild + "-" + lastChild, affXmlElement);
        //            }
        //        }
        //    }
        //}



        public void affnPreCleanup()
        {
            try
            {


                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
                XmlNode frontAffNode = frontHtmlNode.SelectSingleNode("//div[@class='aff']/list");
                if (frontAffNode != null)
                {
                    //frontAffNode.ParentNode.Attributes.GetNamedItem("class").Value = "affgrp";
                    string frontAffContent = frontAffNode.ParentNode.InnerXml;
                    pattern = "</?(list|para)>";
                    replacement = "";
                    frontAffContent = Regex.Replace(frontAffContent, pattern, replacement);
                    pattern = "<list-item>";
                    replacement = "<div class=\"aff\">";
                    frontAffContent = Regex.Replace(frontAffContent, pattern, replacement).Replace("</list-item>", "</div>");
                    frontAffNode.ParentNode.InnerXml = frontAffContent;
                }
                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }

        public void mergeAuthorAff()
        {
            XmlNode authorGrpElem = this.frontHtmlNode.SelectSingleNode("//div[@class='author-group']");

            //XmlElement affGrpElem = Cnfunctions.CreateNode(ref frontHtmlNode, "div");
            //Cnfunctions.CreateAttribute(ref frontHtmlNode, ref affGrpElem, "class", "affiliations");
            string affGrpContent = "";
            bool isBreak = false;
            if (this.frontHtmlNode.SelectSingleNode("//div[@class='affiliations']") != null)
            {

                affGrpContent = this.frontHtmlNode.SelectSingleNode("//div[@class='affiliations']").InnerText;
            }


            if (authorGrpElem != null && affGrpContent != "")
            {
                while (isBreak == false)
                {

                    if ((authorGrpElem.NextSibling != null && authorGrpElem.NextSibling.InnerText == affGrpContent) || (authorGrpElem.NextSibling != null && authorGrpElem.NextSibling.InnerText.Trim().ToLower().StartWithAny("abstract", "highlight", "Keyw")))
                    {
                        isBreak = true;
                    }
                    if (authorGrpElem.NextSibling != null && authorGrpElem.NextSibling.Name == "div")
                    {

                        authorGrpElem.AppendChild(authorGrpElem.NextSibling);
                    }
                    else
                    {
                        isBreak = true;
                    }

                }

            }

            this.frontHtmlContent = this.frontHtmlNode.OuterXml;
        }

        public void processAbstract()
        {
            try
            {

                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;

                XmlNode frontAbsNode = frontHtmlNode.SelectSingleNode("//div[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'abstract')]");

                //startswith check
                //XmlNode frontAbsNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'abstract')]");
                if (frontAbsNode != null)
                {
                    string abstractContent = frontAbsNode.InnerXml;

                    abstractContent = Regex.Replace(abstractContent, @"(Abstract)", "<div class=\"abshead\">$1</div>", RegexOptions.IgnoreCase);
                    abstractContent = Regex.Replace(Regex.Replace(abstractContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                    if (Regex.IsMatch(abstractContent, @"(Abstract</div>)[\s|.|:|-]+([<A-Za-z0-9])", RegexOptions.IgnoreCase))
                    {
                        abstractContent = Regex.Replace(abstractContent, @"(Abstract</div>)[\s|.|:|-]+([<A-Za-z0-9])", @"$1$2", RegexOptions.IgnoreCase);
                    }
                    if(Regex.IsMatch(abstractContent.Trim(), @"(Abstract</div>)([^<].*)", RegexOptions.IgnoreCase))
                    {
                        abstractContent = Regex.Replace(abstractContent.Trim(), @"(Abstract</div>)([^<].*)", @"$1<div class=""para"">$2</div>", RegexOptions.IgnoreCase);
                    }


                    frontAbsNode.InnerXml = abstractContent;
                    if (frontAbsNode.Attributes.GetNamedItem("class") == null)
                    {
                        frontAbsNode.Attributes.Append(frontHtmlNode.CreateAttribute("class"));
                    }


                    if (frontAbsNode.Attributes.GetNamedItem("class") != null)
                    {
                        frontAbsNode.Attributes.GetNamedItem("class").Value = "abstract";
                        while (frontAbsNode.NextSibling != null && frontAbsNode.NextSibling.Name == "div" && frontAbsNode.NextSibling.Attributes.GetNamedItem("class") != null && frontAbsNode.NextSibling.Attributes.GetNamedItem("class").Value.ToLower() == "abstract")
                        {
                            frontAbsNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                            frontAbsNode.AppendChild(frontAbsNode.NextSibling);

                        }
                    }
                }

                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }

        public void processKeywords()
        {

            try
            {
                XmlNode frontKeywordNode = this.frontHtmlNode.SelectSingleNode("//div[@class='keywordgroup']");

                if (frontKeywordNode != null)
                {
                    if (!frontKeywordNode.InnerText.Trim().ToLower().StartsWith("keyw") && !frontKeywordNode.InnerText.Trim().ToLower().StartsWith("key-w"))
                    {
                        XmlNode frontKeywordTitleNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'keyw') or starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'key-w') and not(@class='keywordgroup')] ");

                        if (frontKeywordTitleNode != null && frontKeywordNode.FirstChild != null)
                        {
                            frontKeywordNode.InsertBefore(frontKeywordTitleNode, frontKeywordNode.FirstChild);

                        }

                    }

                    string frontKeyWordNodeContent = frontKeywordNode.InnerXml;

                    frontKeyWordNodeContent = StringCnfunction.RemoveTagsWithAttributes(frontKeyWordNodeContent);

                    //frontKeyWordNodeContent = Regex.Replace(frontKeyWordNodeContent, @"</?(emphasis|b|i)>", "");
                    //while (Regex.IsMatch(frontKeyWordNodeContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>"))
                    //{
                    //    frontKeyWordNodeContent = Regex.Replace(frontKeyWordNodeContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>", "$2");
                    //}
                    frontKeyWordNodeContent = Regex.Replace(frontKeyWordNodeContent, @"(Keyw[^\s\:<>]+)[\:\s]+", "<div class=\"title\">$1</div><split>", RegexOptions.IgnoreCase);
                    //frontKeyWordNodeContent = Regex.Replace(frontKeyWordNodeContent, @"<div data-stylename=""emphasis"">(.*?)</div><split></div>", "$1</div><split>");

                    var keywordTermArr = frontKeyWordNodeContent.Split("<split>");
                    if (keywordTermArr.Length > 1)
                    {
                        var matches = Regex.Split(keywordTermArr[1], @"[;|,]+");
                        keywordTermArr[1] = "";
                        foreach (var item in matches)
                        {
                            keywordTermArr[1] += "<span class=\"keyword\">" + item + "</span>";
                        }

                        frontKeyWordNodeContent = Regex.Replace(frontKeyWordNodeContent, "<split>.*", keywordTermArr[1]);
                        frontKeywordNode.InnerXml = frontKeyWordNodeContent.Replace("<split>", "");
                    }
                }
                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        //public void processKeywords()
        //{
        //    try
        //    {


        //        //this.applyKeyWordStyleByPattern();
        //        XmlDocument frontHtmlNode = new XmlDocument();
        //        frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
        //        XmlNode frontKeywordNode = frontHtmlNode.SelectSingleNode("//div[@class='keywordgroup']");

        //        string frontKeywordContent = "";
        //        XmlNode xmlFullKeywordNode = this.processHeaderXmlNode.SelectSingleNode("//keywords");

        //        if (xmlFullKeywordNode == null || (xmlFullKeywordNode != null && !xmlFullKeywordNode.InnerXml.Contains("term")))
        //        {
        //            xmlFullKeywordNode = this.processFullTextXmlNode.SelectSingleNode("//keywords");
        //        }


        //        XmlNode frontKeywordTitleNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'keyw') or starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'key-w')] ");
        //        if (frontKeywordTitleNode != null)
        //        {
        //            string frontKeywordTitleContent = frontKeywordTitleNode.InnerText;
        //            frontKeywordTitleContent = Regex.Replace(frontKeywordTitleNode.InnerXml, "</?i>", "");
        //            //frontKeywordTitleContent = Regex.Replace(frontKeywordTitleContent, "</?b>", "");(Key+)[^<>]+
        //            frontKeywordTitleContent = Regex.Replace(frontKeywordTitleContent, "(Keyw[^\\s\\:<>]+)[\\:\\s]+", "<div class=\"title\">$1</div>", RegexOptions.IgnoreCase);

        //            frontKeywordTitleNode.InnerXml = frontKeywordTitleContent;

        //            frontKeywordContent = frontKeywordNode.InnerXml;
        //            frontKeywordContent = Regex.Replace(frontKeywordContent, @"</?(emphasis|b|i)>", "");
        //            frontKeywordContent = Regex.Replace(frontKeywordContent, @"<div data-stylename=""emphasis"">(.*?)</div></div>", "$1</div>");
        //            frontKeywordContent = Regex.Replace(frontKeywordContent, @"\s\s+", " ");
        //            while (Regex.IsMatch(frontKeywordContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>"))
        //            {
        //                frontKeywordContent = Regex.Replace(frontKeywordContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>", "$2");
        //            }
        //            if (Regex.IsMatch(frontKeywordContent, "</div>([^<>]+)<span"))
        //            {

        //                //frontKeywordContent = Regex.Replace(frontKeywordContent, "</div>([^<>]*)<span", "</div><div class=\"keywords\"><span") + "</div>";
        //                frontKeywordContent = Regex.Replace(frontKeywordContent, "</div>([^<>]+)<span", "</div><span class=\"keyword\">$1</span><span");
        //            }


        //            frontKeywordNode.InnerXml = frontKeywordContent;



        //        }

        //        if (frontKeywordNode != null && xmlFullKeywordNode != null)
        //        {
        //            DataMatchFoundModel dataMatch = StringCnfunction.DataMatchFound(frontKeywordNode.InnerText, xmlFullKeywordNode.InnerText);
        //            if (dataMatch.isMatch)
        //            {

        //                frontKeywordNode.InnerXml = Cnfunctions.InsertSpanTags(frontKeywordNode.InnerXml, xmlFullKeywordNode.OuterXml, "*", "keyword");

        //            }
        //        }
        //        else if (frontKeywordNode != null)
        //        {
        //            string[] keyWordArr = frontKeywordNode.InnerXml.Split(',');
        //            for (int i = 0; i < keyWordArr.Length; i++)
        //            {
        //                string item = keyWordArr[i];
        //                if (item.ToLower().Contains("key"))
        //                {
        //                    continue;
        //                }
        //                item = item.Replace(item, "<span class=\"keyword\">" + item + "</span>");
        //                keyWordArr[i] = item;

        //            }
        //            frontKeywordNode.InnerXml = string.Join("", keyWordArr);



        //        }

        //        if (frontKeywordNode!=null)
        //        {
        //            if (frontKeywordNode.SelectSingleNode("./div[@class='title']") == null)
        //            {
        //                XmlNode frontKeywordRefNode = frontKeywordNode.SelectSingleNode("./span[@class='keyword']");
        //                if (frontKeywordRefNode != null)
        //                {

        //                    frontKeywordNode.InsertBefore(frontKeywordTitleNode, frontKeywordRefNode);
        //                }
        //            }
        //            frontKeywordTitleNode = frontKeywordNode.SelectSingleNode(".//div[@class='title']");
        //            if (frontKeywordTitleNode != null)
        //            {
        //                if (frontKeywordTitleNode.ParentNode != null && (frontKeywordTitleNode.ParentNode.Attributes.Count == 0 || frontKeywordTitleNode.ParentNode.Attributes.GetNamedItem("class").Value != "keywordgroup"))
        //                {

        //                    frontKeywordTitleNode.ParentNode.ParentNode.ReplaceChild(frontKeywordTitleNode, frontKeywordTitleNode.ParentNode);
        //                }
        //            }
        //        }

        //        this.frontHtmlContent = frontHtmlNode.OuterXml;
        //        this.frontHtmlNode.LoadXml(this.frontHtmlContent);
        //    }
        //    catch (Exception ex)
        //    {
        //        this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
        //        throw;
        //    }

        //}


        #region Cleanup or Sub Functions 



        public bool applyAbstractStyleByPattern()
        {
            bool isMatched = false;
            try
            {
                XmlNode frontAbsNode = frontHtmlNode.SelectSingleNode("//div[contains(translate(normalize-space(text()),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'abstract')]");

                //startswith check
                //XmlNode frontAbsNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'abstract')]");

                if (frontAbsNode != null)
                {
                    XmlNode currentNode = frontAbsNode.NextSibling;
                    while (currentNode != null && !StringCnfunction.RemoveNonAlphapeticWord(currentNode.InnerText.ToLower().Trim()).StartWithAny("highl", "keyw"))
                    {
                        if (currentNode.Name == "div" && currentNode.InnerText.Trim() != "")
                        {

                            Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref currentNode, "class", "abstract");
                            Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref currentNode, "data-matched", "abstract-pattern");
                            isMatched = true;
                        }

                        currentNode = currentNode.NextSibling;
                    }
                }

                return isMatched;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public bool applyKeyWordStyleByPattern()
        {
            bool isMatched = false;
            try
            {
                XmlNode frontKeywordNode = this.frontHtmlNode.SelectSingleNode("//div[@class='keywordgroup']");

                if (frontKeywordNode != null)
                {

                    return isMatched;
                }

                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
                frontKeywordNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'keyw') or starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'key-w') and not(@class='keywordgroup')] ");

                if (frontKeywordNode != null)
                {
                    if (!keyWordTermCheck(frontKeywordNode.InnerText))
                    {
                        if (frontKeywordNode.NextSibling != null)
                        {
                            frontKeywordNode.AppendChild(frontKeywordNode.NextSibling);

                        }
                    }
                    frontKeywordNode.Attributes.Append(frontHtmlNode.CreateAttribute("class"));
                    frontKeywordNode.Attributes.GetNamedItem("class").Value = "keywordgroup";
                    frontKeywordNode.Attributes.Append(frontHtmlNode.CreateAttribute("data-matched"));
                    frontKeywordNode.Attributes.GetNamedItem("data-matched").Value = "keyword-pattern";
                    isMatched = true;

                }

                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
                return isMatched;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public bool keyWordTermCheck(string keywordNodeContent)
        {
            bool result = false;
            string CopyKeywordNodeContent = Regex.Replace(keywordNodeContent.Trim(), @"(Keyw[^\s\:<>]+)[\:\s]+", "$&<split>", RegexOptions.IgnoreCase);
            var CopyKeywordNodeContentSplit = CopyKeywordNodeContent.Trim().Split("<split>");
            if (CopyKeywordNodeContentSplit.Length < 0)
            {
                if (CopyKeywordNodeContentSplit[1].Trim() != "")
                {

                    result = true;
                }
            }

            return result;
        }




        public void authCleanUp()
        {

            try
            {


                XmlDocument frontHtmlNode = new XmlDocument();
                frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
                XmlNode frontHtmlAuthNode = frontHtmlNode.SelectSingleNode("//div[@class='authors']");
                if (frontHtmlAuthNode != null)
                {
                    string frontHtmlAuthContent = frontHtmlAuthNode.OuterXml;

                    {

                        pattern = "</div>(.*?)<div class=\"author\"";
                        replacement = "$1</div><div class=\"author\"";
                        frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement, RegexOptions.Singleline);


                        pattern = "</div>((?:(?!<div).)*?)</div>";
                        replacement = "$1</div></div>\r\n";
                        frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement);


                        pattern = "</?(sup|i)>";
                        replacement = "";
                        frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement);

                    }
                    pattern = "<div( .*)? class=\"authors\".*?>(.*)</div>";
                    replacement = "$2";
                    frontHtmlAuthNode.InnerXml = Regex.Replace(frontHtmlAuthContent, pattern, replacement);
                }

                this.frontHtmlContent = frontHtmlNode.OuterXml;
                this.frontHtmlNode.LoadXml(this.frontHtmlContent);
                XmlNode authGrpNode = this.frontHtmlNode.SelectSingleNode("//div[@class='authors']");
                if (authGrpNode != null)
                {

                    XmlElement affGrpElem = Cnfunctions.CreateNode(ref this.frontHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.frontHtmlNode, ref affGrpElem, "class", "author-group");
                    affGrpElem.AppendChild(authGrpNode.CloneNode(true));
                    authGrpNode.ParentNode.ReplaceChild(affGrpElem, authGrpNode);
                    this.frontHtmlContent = this.frontHtmlNode.OuterXml;
                    this.frontHtmlNode.LoadXml(this.frontHtmlContent);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        #endregion



        public bool matchFindAndReplace(string findNodeContent, ref XmlNodeList findNodeList, string className = "", bool isTypeCheck = false, bool isBreak = true)
        {
            bool isMatched = false;
            try
            {


                XmlDocument xmlDocument = new XmlDocument();
                findNodeContent = findNodeContent.Replace("><", "> <");
                xmlDocument.PreserveWhitespace = true;
                xmlDocument.LoadXml(findNodeContent); xmlDocument.PreserveWhitespace = true;
                XmlNode findNode = xmlDocument;
                //bool isPattern1 = false;
                //bool isPattern2 = false;
                //bool isPattern3 = false;
                //string attrVal = "";
                foreach (XmlNode item in findNodeList)
                {

                    if (item.PreviousSibling != null && item.PreviousSibling.InnerText.ToLower().Trim().StartsWith("highl"))
                    {
                        continue;
                    }

                    if (item != null && item.InnerText.ToLower().Trim().StartsWith("highl"))
                    {
                        continue;
                    }
                    //string findNodeText = StringCnfunction.RemoveNonAlphapeticWord(findNode.InnerText);
                    //string itemText = StringCnfunction.RemoveNonAlphapeticWord(item.InnerText);
                    string findNodeText = findNode.InnerText;
                    string itemText = item.InnerText;
                    //int similarityPercentage = StringCnfunction.GetSimilarity(findNodeText, itemText);
                    if (findNodeText != "" && itemText != "")
                    {

                        DataMatchFoundModel dataMatchFoundModel = new DataMatchFoundModel();
                        dataMatchFoundModel = StringCnfunction.DataMatchFound(itemText, findNodeText);

                        if (dataMatchFoundModel.isMatch)
                        {
                            if (item.Attributes.GetNamedItem("class") == null)
                                item.Attributes.Append(this.frontHtmlNode.CreateAttribute("class"));

                            if (isTypeCheck)
                            {

                                if (findNode.Attributes.GetNamedItem("type") != null)
                                    item.Attributes.GetNamedItem("class").Value = FMElements.ContainsKey(findNode.Attributes.GetNamedItem("type").Value) ? FMElements[findNode.Attributes.GetNamedItem("type").Value] : "";
                                else
                                    item.Attributes.GetNamedItem("class").Value = FMElements.ContainsKey(findNode.Name.ToString()) ? FMElements[findNode.Name.ToString()] : "";
                            }
                            else if (className != "")
                            {
                                item.Attributes.GetNamedItem("class").Value = className;
                            }

                            if (item.Attributes.GetNamedItem("class").Value != "")
                            {
                                item.Attributes.Append(this.frontHtmlNode.CreateAttribute("data-matched"));
                                item.Attributes.GetNamedItem("data-matched").Value = dataMatchFoundModel.dataMatchedType;
                                isMatched = true;

                            }

                            if (isBreak) break;
                        }


                    }

                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
            return isMatched;
        }


        //final method in HTMLHead API
        public void generateFrontHtml(string DocxFileName = "")
        {
            try
            {
                //this.frontHtmlContent=this.frontHtmlContent.Replace("&amp;","&");
                Cnfunctions.CreateHTML(outPath, this.frontHtmlContent, customConstant.FRONTHTML_NAME, DocxFileName);
                //Cnfunctions.CreateHTML(outPath, this.frontHtmlNode.CreateNavigator().OuterXml, "Front.html");
                this.message = "FrontHtml file generated";
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        #region Set Necessary Files


        //files load
        public void SetFrontHtmlContent()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string frontHtmlContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.HTML_OUTPATH, uniqueNumber, customConstant), customConstant.FRONTHTML_NAME);
                string frontHtmlContent = Regex.Match(Cnfunctions.ReadString(frontHtmlContentPath), "<body>(.*?)</body>", RegexOptions.Singleline).Value;
                if (frontHtmlContent == "")
                {
                    this.message = "[SetFrontHtmlNode] => Check " + customConstant.FRONTHTML_NAME + "file path";
                    return;
                }
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"(<list>(.+?)</list>)", "<div>$1</div>");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"</?b>", "");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"\r|\n|\t", "");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"</(subtleemphasis|b|i|u|emphasis)><\1>", "");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"(?<=<div[^>]*>)<\2>([^<>]+)<\/(b|i|u)>(?=</div>)", "$1", RegexOptions.RightToLeft);
                frontHtmlContent = Regex.Replace(frontHtmlContent, "</?footnotereference>", "", RegexOptions.IgnoreCase);
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"</?xref[^<>]*>", "");
                //frontHtmlContent = frontHtmlContent.Replace("<xref refid=\"fn*\">", "");
                //frontHtmlContent = frontHtmlContent.Replace("</xref>", "");

                xmlDoc.LoadXml(frontHtmlContent); xmlDoc.PreserveWhitespace = true;
                frontHtmlContent = xmlDoc.SelectSingleNode("//body").OuterXml.Replace("<body>", "<article>").Replace("</body>", "</article>");
                this.frontHtmlNode.LoadXml(frontHtmlContent); this.frontHtmlNode.PreserveWhitespace = true;
                frontHtmlContent = frontHtmlNode.InnerXml.Replace("’", "'");
                frontHtmlContent = frontHtmlContent.Replace("’’", "'");
                frontHtmlContent = frontHtmlContent.Replace("<", " <");
                frontHtmlContent = frontHtmlContent.Replace(">", "> ");
                frontHtmlContent = frontHtmlContent.Replace("MACROBUTTON NoMacro", "");
                this.frontHtmlNode.PreserveWhitespace = true;
                this.frontHtmlNode.LoadXml(frontHtmlContent);
                this.frontHtmlContent = frontHtmlContent;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void SetProcessHeaderXmlNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string processHeaderContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant), docxFileName + "-processHeaderDocument.xml");

                string processHeaderContent = Cnfunctions.ReadString(processHeaderContentPath);
                if (processHeaderContent == "")
                {
                    this.message = "[SetProcessHeaderXmlNode] => Check processHeaderDocument.xml file path";
                    return;
                }
                processHeaderContent = Regex.Replace(processHeaderContent, "<lb/>", "");
                processHeaderContent = Regex.Replace(processHeaderContent, "</?fileDesc>", "");
                processHeaderContent = Regex.Replace(processHeaderContent, "</?profileDesc>", "");
                processHeaderContent = Regex.Replace(processHeaderContent, "</?textClass>", "");
                processHeaderContent = Regex.Replace(processHeaderContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                processHeaderContent = Regex.Replace(processHeaderContent, ">[\r\n\t]+", ">");
                processHeaderContent = Regex.Replace(processHeaderContent, "[\r\n\t]+<", "<");
                processHeaderContent = Regex.Replace(processHeaderContent, "><", "> <");
                this.processHeaderXmlNode.PreserveWhitespace = true;
                this.processHeaderXmlNode.LoadXml(processHeaderContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void SetProcessFullTextXmlNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string processFulltextContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant), docxFileName + "-processFulltextDocument.xml");

                string processFullTextContent = Cnfunctions.ReadString(processFulltextContentPath);
                if (processFullTextContent == "")
                {
                    this.message = "[SetprocessFullTextXmlNode] => Check processFulltextDocument.xml file path";
                    return;
                }
                processFullTextContent = Regex.Replace(processFullTextContent, "<lb/>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?fileDesc>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?profileDesc>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "</?textClass>", "");
                processFullTextContent = Regex.Replace(processFullTextContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                processFullTextContent = Regex.Replace(processFullTextContent, ">[\r\n\t]+", ">");
                processFullTextContent = Regex.Replace(processFullTextContent, "[\r\n\t]+<", "<");
                processFullTextContent = Regex.Replace(processFullTextContent, "><", "> <");
                this.processFullTextXmlNode.PreserveWhitespace = true;
                this.processFullTextXmlNode.LoadXml(processFullTextContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        #endregion


        //add fmelements to the list
        public bool GetFrontMatterMappedNames()
        {
            try
            {
                FMElements.Add("titleStmt", "articletitle");
                FMElements.Add("analytic", "authors");
                FMElements.Add("affiliation", "aff");
                FMElements.Add("keyword", "keywordgroup");
                FMElements.Add("abstract", "abstract");
                FMElements.Add("address", "aff");
                FMElements.Add("email", "authornotes");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }
        }
    }
}
