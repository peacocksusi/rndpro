﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Utils.Common;
using static System.Net.Mime.MediaTypeNames;

namespace HTMLHead.Service
{
    public class FnHtmlDocumentByTei
    {
        #region
        private XDocument frontHtmlNode = new XDocument();
        private string frontHtmlContent = "";
        private XDocument headerTeiNode = new XDocument();
        private XDocument authorTeiNode = new XDocument();
        private XDocument affnTeiNode = new XDocument();
        private XDocument processHeaderNode = new XDocument();
        private readonly IConfiguration configuration;
        private string docxFileName = "";
        private string homePath = "";
        private string outPath = "";
        public string message = "";
        public Dictionary<string, string> FMElements = new Dictionary<string, string>();
        #endregion

        public FnHtmlDocumentByTei(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.GetFrontMatterMappedNames();
        }


        //configurations 
        public void StartUp(string uniqueNumber)
        {
            try
            {

                string folderPath = configuration.GetValue<string>("folderPath");
                folderPath = folderPath.Replace("{currentDate}", DateTime.Today.ToString("dd-MM-yyyy")).Replace("{uniqueNumber}", uniqueNumber);
                homePath = folderPath;
            
                outPath = Path.Combine(homePath, "structuredHtml");
                this.docxFileName = Cnfunctions.setDocxFileName(homePath);
                this.SetFrontHtmlContent();
                this.SetHeaderTeiNode();
                this.SetAuthorTeiNode();
                this.SetAffnTeiNode();
                this.SetProcessHeaderNode();
            }
            catch (Exception ex)
            {

                this.message = "[StartUp] => " + ex.Message;
            }
        }


        //process
        public void applyStyles()
        {
            string startWords = "";
            string endWords = "";
            try
            {


                IEnumerable<XElement> FrontHtmlElements = this.frontHtmlNode.XPathSelectElement("//div[@class='front']").Elements();

                foreach (var frontHtmlElement in FrontHtmlElements)
                {

                    startWords = Regex.Match(frontHtmlElement.Value.Trim(), @"^(\S+(?:\s+\S+){0,2})").Value.ToLower();
                    endWords = Regex.Match(frontHtmlElement.Value.Trim(), "[a-zA-Z]+(?:[^a-zA-Z]+[a-zA-Z]+){0,2}[^a-zA-Z]*$").Value.ToLower();

                    if (string.IsNullOrEmpty(startWords) == false)
                    {
                        var headerTeiFrontNode = this.headerTeiNode.Descendants("front").Descendants().Where(e => Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z0-9]+", "") + "")).FirstOrDefault();
                        if (headerTeiFrontNode == null)
                        {
                            headerTeiFrontNode = this.headerTeiNode.Descendants("front").Descendants().Where(e => Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").EndsWith("" + Regex.Replace(endWords.ToLower(), "[^A-Za-z0-9]+", "") + "")).FirstOrDefault();
                        }
                        if (headerTeiFrontNode != null)
                        {
                            if (frontHtmlElement.Attribute("class") == null)
                                frontHtmlElement.Add(new XAttribute("class", ""));
                            if (headerTeiFrontNode.Attribute("type") != null)
                                frontHtmlElement.Attribute("class").Value = FMElements[headerTeiFrontNode.Attribute("type").Value];
                            else
                                frontHtmlElement.Attribute("class").Value = FMElements[headerTeiFrontNode.Name.ToString()];
                        }
                    }

                }
                this.frontHtmlContent = this.frontHtmlNode.ToString();





            }
            catch (Exception ex)
            {

                this.message = "[applyStyles] => " + ex.Message;
            }

        }

        public void processAuthor()
        {

            //insert author class div
            IEnumerable<XElement> authorTeiElements = this.authorTeiNode.XPathSelectElements("//author/persName[forename][surname]");

            foreach (var authorTeiElement in authorTeiElements)
            {
                var foreName = authorTeiElement.Element("forename").Value;
                var surName = authorTeiElement.Element("surname").Value;


                string pattern = foreName + ".*?" + surName;
                string replacement = "<div class=\"author\">$&</div>";

                this.frontHtmlContent = Regex.Replace(this.frontHtmlContent, pattern, replacement);
            }


            //Insert span tags 
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontAuthNode = frontHtmlNode.SelectSingleNode("//div[@class='autgrp']");
            string frontAuthContent = frontAuthNode.CreateNavigator().InnerXml;
            string teiAuthContent = this.authorTeiNode.XPathSelectElement("//author").CreateNavigator().OuterXml;
            frontAuthNode.InnerXml = processAuthorNames(frontAuthContent, teiAuthContent);

            this.frontHtmlContent = frontHtmlNode.OuterXml;




        }

        public string processAuthorNames(string htmlAuthContent, string teiAuthContent)
        {
            XmlDocument teiAuthNode = new XmlDocument();
            XmlNodeList teiAuthNodeElements;
            XmlDocument htmlContentNode = new XmlDocument();
            XmlNodeList htmlContentNodeList;
            string teiContentElementText = "";
            string attrName = "";
            MatchCollection elementMatch;
            if (teiAuthContent != null)
            {
                teiAuthNode.LoadXml(teiAuthContent);
                teiAuthNodeElements = teiAuthNode.SelectNodes("//persName[forename][surname]");
                if (htmlAuthContent != null)
                {
                    htmlContentNode.LoadXml("<root>"+ htmlAuthContent + "</root>");
                    htmlContentNodeList = htmlContentNode.SelectNodes("//div[@class='author']");



                    foreach (XmlNode teiAuthElem in teiAuthNodeElements)
                    {
                        string teiPersNameContent = teiAuthElem.InnerText;
                        foreach (XmlNode htmlAuthorNodeElem in htmlContentNodeList)
                        {
                            string htmlAuthorContent = htmlAuthorNodeElem.InnerText;

                            string teiAuthRegex = Regex.Replace(teiPersNameContent,"[^A-Za-z]+", "");
                            string htmlAuthRegex = Regex.Replace(htmlAuthorContent,"[^A-Za-z]+", "");
                            if (teiAuthRegex==htmlAuthRegex)
                            {
                                htmlAuthorNodeElem.InnerXml = AuthorInsertSpanTags(htmlAuthorNodeElem.InnerXml, teiAuthElem.OuterXml);
                            }
                        }

                    }
                    htmlAuthContent = htmlContentNode.InnerXml;
                }
            }
            return Regex.Replace(htmlAuthContent,"</?root>","");
        }

        public string AuthorInsertSpanTags(string htmlAuthXml,string teiAuthXml)
        {
            XmlDocument teiContentNode = new XmlDocument();
            XmlNodeList teiContentNodeElements;
            string teiContentElementText = "";
            string attrName = "";

            MatchCollection elementMatch;
            if (teiAuthXml != null)
            {
                teiContentNode.LoadXml(teiAuthXml);
                teiContentNodeElements = teiContentNode.SelectNodes("//*");

                foreach (XmlNode teiContentNodeElement in teiContentNodeElements)
                {
                    teiContentElementText = teiContentNodeElement.InnerText;
                    if (teiContentNodeElement.Attributes.Count > 0 && teiContentNodeElement.Attributes["type"] != null)
                    {
                        attrName = "class=\"" + teiContentNodeElement.Attributes.GetNamedItem("type").Value + "\"";
                    }
                    else
                    {
                        attrName = "class=\"" + teiContentNodeElement.Name + "\"";
                    }
                    elementMatch = Regex.Matches(htmlAuthXml, "(?<!(<span[^<>]+>))" + Regex.Escape(teiContentElementText) + "(?!(</span>))", RegexOptions.RightToLeft);
                    if (teiContentElementText.Length > 0 && elementMatch.Count > 0 && teiContentNodeElement.Name != "marker")
                    {

                        htmlAuthXml = htmlAuthXml.Insert(elementMatch[elementMatch.Count - 1].Index + elementMatch[elementMatch.Count - 1].Length, "</span>");
                        htmlAuthXml = htmlAuthXml.Insert(elementMatch[elementMatch.Count - 1].Index, "<span " + attrName + ">");

                    }

                }
            }

                return htmlAuthXml;
        }

        public void processAutAffRef()
        {

            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNodeList frontHtmlAuthNode = frontHtmlNode.SelectNodes("//div[@class='autgrp']/*[not(@class='author')]");

            foreach (XmlNode frontHtmlAutgrpElement in frontHtmlAuthNode)
            {
                var autGrpElemAffRef = Regex.Replace(frontHtmlAutgrpElement.InnerXml, @"(\d|\*|\#)", "<span class=\"affref\">$1</span>");
                frontHtmlAutgrpElement.InnerXml = autGrpElemAffRef;
            }
            this.frontHtmlContent = frontHtmlNode.OuterXml;
            this.authCleanUp();
        }


        public void authCleanUp()
        {
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontHtmlAuthNode = frontHtmlNode.SelectSingleNode("//div[@class='autgrp']");
            string frontHtmlAuthContent = frontHtmlAuthNode.OuterXml;

            {

                string pattern = "</div>(.*?)<div class=\"author\">";
                string replacement = "$1</div><div class=\"author\">";
                frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement, RegexOptions.Singleline);


                pattern = "</div>((?:(?!<div).)*?)</div>";
                //pattern = "</div>((?:(?!<div).)*?)</sup>$";
                replacement = "$1</div></div>\r\n";
                //replacement = "$1</sup></div>\r\n";
                frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement);


                pattern = "</?(sup|i)>";
                replacement = "";
                frontHtmlAuthContent = Regex.Replace(frontHtmlAuthContent, pattern, replacement);

            }
            frontHtmlAuthNode.InnerXml = Regex.Replace(frontHtmlAuthContent, "<div class=\"autgrp\">(.*)</div>", "$1");
            this.frontHtmlContent = frontHtmlNode.OuterXml;
        }


        public void processAffn()
        {
            this.affnPreCleanup();
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;

            // for non list affiliation
            XmlNodeList frontAffNodeList = frontHtmlNode.SelectNodes("//div[@class='front']/div[@class='aff']");
            XmlElement affGrpElem = Cnfunctions.CreateNode(ref frontHtmlNode, "div");
            Cnfunctions.CreateAttribute(ref frontHtmlNode, ref affGrpElem, "class", "affgrp");
            int index = 1;
            foreach (XmlNode frontAffNode in frontAffNodeList)
            {
                if (!(frontAffNode.ParentNode != null && Regex.IsMatch(frontAffNode.ParentNode.OuterXml, "<div class=\"\"affgrp\"\">")))
                {

                    frontAffNode.ParentNode.InsertBefore(affGrpElem, frontAffNode);
                    frontAffNode.Attributes.Append(frontHtmlNode.CreateAttribute("id"));
                    frontAffNode.Attributes.GetNamedItem("id").Value = "aff" + index;
                    affGrpElem.AppendChild(frontAffNode);
                }
                index++;
            }
            string teiAffContent = this.affnTeiNode.XPathSelectElement("//author").CreateNavigator().OuterXml;
            affGrpElem.InnerXml = Cnfunctions.InsertSpanTags(affGrpElem.InnerXml, teiAffContent);

            affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, "<sup>(.*?)</sup>", "<span class=\"afflabel\">$1</span>");
            affGrpElem.InnerXml = Regex.Replace(affGrpElem.InnerXml, "(\b[\\d\\*\\#][.]?[\\s]+)", "<span class=\"afflabel\">$1</span>");

            this.frontHtmlContent = frontHtmlNode.OuterXml;

        }

        public void affnPreCleanup()
        {
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontAffNode = frontHtmlNode.SelectSingleNode("//div[@class='aff']/list");
            if (frontAffNode != null)
            {
                //frontAffNode.ParentNode.Attributes.GetNamedItem("class").Value = "affgrp";
                string frontAffContent = frontAffNode.ParentNode.InnerXml;
                frontAffContent = Regex.Replace(frontAffContent, "</?(list|para)>", "");
                frontAffContent = Regex.Replace(frontAffContent, "<list-item>", "<div class=\"aff\">").Replace("</list-item>", "</div>");
                frontAffNode.ParentNode.InnerXml = frontAffContent;
            }
            this.frontHtmlContent = frontHtmlNode.OuterXml;



        }
        public void processAbstract()
        {
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontAbsNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'abstract')]");
            if (frontAbsNode != null)
            {
                string abstractContent = frontAbsNode.InnerXml;

                abstractContent = Regex.Replace(abstractContent, "(Abst[^\\s\\:<>]+)[\\:\\s]*", "<div class=\"abshead\">$1</div>", RegexOptions.IgnoreCase);
                abstractContent = Regex.Replace(Regex.Replace(abstractContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                frontAbsNode.InnerXml = abstractContent;
                if (frontAbsNode.Attributes.GetNamedItem("class") == null)
                {
                    frontAbsNode.Attributes.Append(frontHtmlNode.CreateAttribute("class"));
                }

                if (frontAbsNode.Attributes.GetNamedItem("class") != null)
                {
                    frontAbsNode.Attributes.GetNamedItem("class").Value = "abstract";
                    while (frontAbsNode.NextSibling != null && frontAbsNode.NextSibling.Name == "div" && frontAbsNode.NextSibling.Attributes.GetNamedItem("class") != null && frontAbsNode.NextSibling.Attributes.GetNamedItem("class").Value.ToLower() == "abstract")
                    {
                        frontAbsNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                        frontAbsNode.AppendChild(frontAbsNode.NextSibling);

                    }
                }
            }

            this.frontHtmlContent = frontHtmlNode.OuterXml;

        }

        public void processHighLights()
        {
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontHighligNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'highlights')]");
            if (frontHighligNode != null)
            {
                string highlightsContent = frontHighligNode.InnerXml;

                highlightsContent = Regex.Replace(highlightsContent, "(Highlight[^\\s\\:<>]+)[\\:\\s]*", "<div class=\"highlightstitle\">$1</div>", RegexOptions.IgnoreCase);
                highlightsContent = Regex.Replace(Regex.Replace(highlightsContent.ToString(), "<(emphasis|b|i)><div", "<div"), "</div></(emphasis|b|i)>", "</div>");
                frontHighligNode.InnerXml = highlightsContent;
                if (frontHighligNode.Attributes.GetNamedItem("class") == null)
                {
                    frontHighligNode.Attributes.Append(frontHtmlNode.CreateAttribute("class"));
                }

                if (frontHighligNode.Attributes.GetNamedItem("class") != null)
                {
                    frontHighligNode.Attributes.GetNamedItem("class").Value = "highlights";
                    while (frontHighligNode.NextSibling != null && frontHighligNode.NextSibling.Name == "div" && frontHighligNode.NextSibling.Attributes.GetNamedItem("class") != null && frontHighligNode.NextSibling.Attributes.GetNamedItem("class").Value.ToLower() == "abstract" && frontHighligNode.NextSibling.SelectSingleNode(".//div[@class='abshead']") == null || (frontHighligNode.NextSibling.FirstChild != null && frontHighligNode.NextSibling.FirstChild.Name == "ul"))
                    {
                        frontHighligNode.NextSibling.Attributes.GetNamedItem("class").Value = "para";
                        frontHighligNode.AppendChild(frontHighligNode.NextSibling);

                    }
                }


                // list formatting 
                highlightsContent = frontHighligNode.InnerXml;

                highlightsContent = Regex.Replace(highlightsContent, "(</?)label(>)", "$1span$2");
                highlightsContent = Regex.Replace(highlightsContent, "(</?)list-item>", "$1li>");

                highlightsContent = Regex.Replace(highlightsContent.ToString(), "</?para>", "");
                highlightsContent = Regex.Replace(Regex.Replace(highlightsContent, "<list>", "<ul style=\"list-style-type:none;\">"), "</list>", "</ul>");
                highlightsContent = Regex.Replace(highlightsContent, "<li>(<span>[^<>]+</span>)<(b|i)>([^<>]+)</2>([^<>]*)</li>", "<li><$2>$1$3</$2>$4</li>");
                frontHighligNode.InnerXml = highlightsContent;
            }

            this.frontHtmlContent = frontHtmlNode.OuterXml;

        }

        public void processKeywords()
        {

            this.keywordPreCleanUp();
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontKeywordNode = frontHtmlNode.SelectSingleNode("//div[@class='keywordgroup']");
            string frontKeywordContent = "";
            string xmlFullHeaderContent = this.processHeaderNode.XPathSelectElement("//keywords").CreateNavigator().OuterXml;
            if (frontKeywordNode != null)
            {
                frontKeywordNode.InnerXml = Cnfunctions.InsertSpanTags(frontKeywordNode.InnerXml, xmlFullHeaderContent);

                frontKeywordNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'keyw') or starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'key-w')] ");

                if (frontKeywordNode != null)
                {
                    frontKeywordContent = frontKeywordNode.InnerXml;
                    frontKeywordContent = Regex.Replace(frontKeywordContent, "(Key[^\\s\\:<>]+)[\\:\\s]+", "<div class=\"kwdtitle\">$1</div>", RegexOptions.IgnoreCase);
                    while (Regex.IsMatch(frontKeywordContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>"))
                    {
                        frontKeywordContent = Regex.Replace(frontKeywordContent, "<(emphasis|b|i)>(<div[^<>]*>(.*?)</div>)</(emphasis|b|i)>", "$2");
                    }

                    frontKeywordContent = Regex.Replace(frontKeywordContent, "</div>([^<>]*)<span", "</div><div class=\"keywords\"><span") + "</div>";

                    frontKeywordNode.InnerXml = frontKeywordContent;



                }

            }

            this.frontHtmlContent = frontHtmlNode.OuterXml;









        }

        public void keywordPreCleanUp()
        {
            XmlDocument frontHtmlNode = new XmlDocument();
            frontHtmlNode.LoadXml(this.frontHtmlContent); frontHtmlNode.PreserveWhitespace = true;
            XmlNode frontKeywordNode = frontHtmlNode.SelectSingleNode("//div[starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'keyw') or starts-with(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'key-w') and not(@class='keywordgroup')] ");

            if (frontKeywordNode != null)
            {
                frontKeywordNode.Attributes.Append(frontHtmlNode.CreateAttribute("class"));
                frontKeywordNode.Attributes.GetNamedItem("class").Value = "keywordgroup";
            }

            this.frontHtmlContent = frontHtmlNode.OuterXml;
        }





        //last method in HTMLHead API
        public void generateFrontHtml()
        {
            Cnfunctions.CreateHTML(outPath, this.frontHtmlContent, "Front.html");
            //Cnfunctions.CreateHTML(outPath, this.frontHtmlNode.CreateNavigator().OuterXml, "Front.html");
            this.message = "FrontHtml file generated";
        }


        //files load
        public void SetFrontHtmlContent()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string frontHtmlContentPath = Path.Combine(homePath, "html", "Front.html");
                string frontHtmlContent = Regex.Match(Cnfunctions.ReadString(frontHtmlContentPath), "<body>(.*?)</body>",RegexOptions.Singleline).Value;
                if (frontHtmlContent == "")
                {
                    this.message = "[SetFrontHtmlNode] => Check Front.Html file path";
                    return;
                }
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"(<list>(.+?)</list>)", "<div>$1</div>");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"\r|\n|\t", "");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"</(subtleemphasis|b|i|u|emphasis)><\1>", "");
                frontHtmlContent = Regex.Replace(frontHtmlContent, @"(?<=<div[^>]*>)<\2>([^<>]+)<\/(b|i|u)>(?=</div>)", "$1", RegexOptions.RightToLeft);
                frontHtmlContent = frontHtmlContent.Replace("<footnotereference><xref refid=\"fn*\">", "");
                frontHtmlContent = frontHtmlContent.Replace("</xref></footnotereference>", "");

                xmlDoc.LoadXml(frontHtmlContent); xmlDoc.PreserveWhitespace = true;
                frontHtmlContent = xmlDoc.SelectSingleNode("//body").OuterXml.Replace("<body>", "<article>").Replace("</body>", "</article>");
                this.frontHtmlNode = XDocument.Parse(frontHtmlContent, LoadOptions.PreserveWhitespace);
                this.frontHtmlContent = frontHtmlContent;
            }
            catch (Exception ex)
            {

                this.message = "[SetFrontHtmlNode] => " + ex.Message;
            }
        }
        public void SetHeaderTeiNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string headerTeiContentPath = Path.Combine(homePath, "tei", docxFileName+".training.header.tei.xml");
                string headerTeiContent = Cnfunctions.ReadString(headerTeiContentPath);
                if (headerTeiContent == "")
                {
                    this.message = "[SetHeaderTeiNode] => Check header.tei.xml file path";
                    return;
                }
                headerTeiContent = Regex.Replace(headerTeiContent, @"<\/?byline>", "");
                headerTeiContent = Regex.Replace(headerTeiContent, @"\r|\n|\t", "");
                headerTeiContent = Regex.Replace(headerTeiContent, "<lb/>", "");
                this.headerTeiNode = XDocument.Parse(headerTeiContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.message = "[SetHeaderTeiNode] => " + ex.Message;
            }
        }
        public void SetAuthorTeiNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string authorTeiContentPath = Path.Combine(homePath, "tei", docxFileName + ".training.header.authors.tei.xml");
                string authorTeiContent = Cnfunctions.ReadString(authorTeiContentPath);
                if (authorTeiContent == "")
                {
                    this.message = "[SetAuthorTeiNode] => Check header.authors.tei.xml file path";
                    return;
                }
                authorTeiContent = Regex.Replace(authorTeiContent, "<lb/>", "");
                authorTeiContent = Regex.Replace(authorTeiContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                authorTeiContent = Regex.Replace(authorTeiContent, "\r|\n|\t", "");
                authorTeiContent = Regex.Replace(authorTeiContent, ">[\r\n\t]+", ">");
                authorTeiContent = Regex.Replace(authorTeiContent, "[\r\n\t]+<", "<");
                this.authorTeiNode = XDocument.Parse(authorTeiContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.message = "[SetAuthorTeiNode] => " + ex.Message;
            }
        }
        public void SetAffnTeiNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string affTeiContentPath = Path.Combine(homePath, "tei", docxFileName + ".training.header.affiliation.tei.xml");
                string affTeiContent = Cnfunctions.ReadString(affTeiContentPath);
                if (affTeiContent == "")
                {
                    this.message = "[SetAffTeiNode] => Check header.affiliation.tei.xml file path";
                    return;
                }
                affTeiContent = Regex.Replace(affTeiContent, "<lb/>", "");
                affTeiContent = Regex.Replace(affTeiContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                affTeiContent = Regex.Replace(affTeiContent, "\r|\n|\t", "");
                affTeiContent = Regex.Replace(affTeiContent, ">[\r\n\t]+", ">");
                affTeiContent = Regex.Replace(affTeiContent, "[\r\n\t]+<", "<");
                this.affnTeiNode = XDocument.Parse(affTeiContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.message = "[SetAffTeiNode] => " + ex.Message;
            }
        }

        public void SetProcessHeaderNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string processHeaderContentPath = Path.Combine(homePath, "xml", docxFileName + "-processHeaderDocument.xml");
                string processHeaderContent = Cnfunctions.ReadString(processHeaderContentPath);
                if (processHeaderContent == "")
                {
                    this.message = "[SetProcessHeaderNode] => Check processHeaderDocument.xml file path";
                    return;
                }
                processHeaderContent = Regex.Replace(processHeaderContent, "<lb/>", "");
                processHeaderContent = Regex.Replace(processHeaderContent, "<(tei) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                processHeaderContent = Regex.Replace(processHeaderContent, ">[\r\n\t]+", ">");
                processHeaderContent = Regex.Replace(processHeaderContent, "[\r\n\t]+<", "<");
                this.processHeaderNode = XDocument.Parse(processHeaderContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.message = "[SetProcessHeaderNode] => " + ex.Message;
            }
        }



        //add fmelements to the list
        public bool GetFrontMatterMappedNames()
        {
            try
            {
                FMElements.Add("docTitle", "articletitle");
                FMElements.Add("docAuthor", "autgrp");
                FMElements.Add("affiliation", "aff");
                FMElements.Add("keyword", "keywordgroup");
                FMElements.Add("abstract", "abstract");
                FMElements.Add("address", "aff");
                FMElements.Add("email", "authornotes");
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
    }
}
