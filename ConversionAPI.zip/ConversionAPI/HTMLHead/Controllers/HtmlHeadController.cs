﻿using HTMLHead.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Utils;
using Utils.Common;
using Utils.Logger;
using Utils.Models;

namespace HTMLHead.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class HtmlHeadController : Controller
    {
        private readonly IConfiguration configuration;
        private readonly ILoggerService logger;
        private readonly ICustomConstant customConstant;
		private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

		private string message;
        private string uniqueNumber;
        private string docxFileName;

        public HtmlHeadController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        [HttpPost]
        public CoreResponseModel structureFrontHTML([FromQuery] string uniqueNumber)
        {

            FnHtmlDocument fnHtmlDoc = new FnHtmlDocument(configuration, logger,customConstant);
				CoreResponseModel coreResponseModel = new CoreResponseModel();
				coreResponseModel.projectName = this.projectName;
            try
            {

				this.uniqueNumber = uniqueNumber;

                //set configurations
                fnHtmlDoc.StartUp(uniqueNumber);
                this.docxFileName = fnHtmlDoc.docxFileName;

                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " file process started.");
                //start process
                fnHtmlDoc.applyStyles();    
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " styles applied");
                fnHtmlDoc.processAritcleTitle();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " article  process completed.");
                fnHtmlDoc.processAuthor();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " author high level process completed.");
                fnHtmlDoc.processAuthorNames();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " author names process completed.");
                fnHtmlDoc.processAutAffRef();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " author aff ref completed");
                fnHtmlDoc.processAffn();
                fnHtmlDoc.mergeAuthorAff();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " affiliation process completed.");
                fnHtmlDoc.processAbstract();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " abstract process completed.");
                fnHtmlDoc.processKeywords();
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " keyword process completed.");

                //final output
                fnHtmlDoc.generateFrontHtml(fnHtmlDoc.docxFileName);
                this.message = this.uniqueNumber + " " + this.docxFileName + " file process completed.";
				coreResponseModel.status = 200;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogInfo(message);

				return coreResponseModel;
			}
            catch (Exception ex)
            {
				message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;

				coreResponseModel.status = 400;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogError(message);

				return coreResponseModel;

			}

        }
    }
}