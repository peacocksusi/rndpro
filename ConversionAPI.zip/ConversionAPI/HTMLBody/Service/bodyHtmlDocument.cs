﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Utils.Common;
using Utils.Logger;

namespace HTMLBody.Service
{
    public class bodyHtmlDocument
    {

        #region
        private XDocument xDocBodyHtmlNode = new XDocument();
        private XmlDocument bodyHtmlNode = new XmlDocument();
        private string bodyHtmlContent = "";
        private XDocument xmlFullTextNode = new XDocument();
        private XDocument figureTeiNode = new XDocument();
        private readonly IConfiguration configuration;
        private readonly ILoggerService logger;
        private readonly ICustomConstant customConstant;
        public string docxFileName = "";
        public string uniqueNumber = "";
        private string homePath = "";
        private string outPath = "";
        public string message = "";
        public Dictionary<string, string> BodyElements = new Dictionary<string, string>();
        #endregion

        public bodyHtmlDocument(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
            this.GetBodyMatterMappedNames();
        }


        //configurations and load files
        public void StartUp(string uniqueNumber)
        {
            try
            {

                this.uniqueNumber = uniqueNumber;

                homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);

                outPath = Cnfunctions.GetModifiedPath(customConstant.STRUCTEDHTML_OUTPATH, uniqueNumber, customConstant);
                this.docxFileName = Cnfunctions.setDocxFileName(homePath);
                this.setBodyHtmlContent();
                this.SetXmlFullTextNode();
                //this.SetFigureTeiNode();
                //this.SetAuthorTeiNode();
                //this.SetAffnTeiNode();
                //this.SetProcessHeaderNode();
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }




        public void applyStyles()
        {
            string startWords = "";
            string endWords = "";
            try
            {


                IEnumerable<XElement> bodyHtmlElements = this.xDocBodyHtmlNode.XPathSelectElement("//div[@class='body']").Elements();

                foreach (var bodyHtmlElement in bodyHtmlElements)
                {
                    string bodyHtmlValue = bodyHtmlElement.Value.Trim();
                    if (Regex.IsMatch(bodyHtmlValue, "\\A([0-9][0-9\\.]+\\s?)"))
                    {
                        bodyHtmlValue = Regex.Replace(bodyHtmlValue, "\\A([0-9][0-9\\.]+\\s?)", "");
                    }

                    startWords = Regex.Match(bodyHtmlValue, @"^(\S+(?:\s+\S+){0,5})").Value.ToLower();
                    endWords = Regex.Match(bodyHtmlValue, "(\\S+(?:\\s+\\S+){0,5})$").Value.ToLower();

                    if (string.IsNullOrEmpty(startWords) == false)
                    {
                        var xmlFullTextBodyNode = this.xmlFullTextNode.XPathSelectElement("//body").Descendants("head").Where(e => Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z0-9]+", "") + "") && Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").EndsWith("" + Regex.Replace(endWords.ToLower(), "[^A-Za-z0-9]+", "") + "")).FirstOrDefault();
                        if (xmlFullTextBodyNode != null)
                        {
                            if (xmlFullTextBodyNode.Attribute("n") != null)
                            {
                                if (bodyHtmlElement.Attribute("id") == null)
                                {


                                    bodyHtmlElement.Add(new XAttribute("id", xmlFullTextBodyNode.Attribute
                                        ("n").Value));
                                }
                                else
                                {
                                    bodyHtmlElement.Attribute("id").Value = xmlFullTextBodyNode.Attribute("n").Value;
                                }
                            }

                            if (bodyHtmlElement.Attribute("class") == null)
                            {
                                bodyHtmlElement.Add(new XAttribute("class", ""));
                            }
                            if (BodyElements.ContainsKey(xmlFullTextBodyNode.Name.ToString()))
                            {

                                bodyHtmlElement.Attribute("class").Value = BodyElements[xmlFullTextBodyNode.Name.ToString()];
                            }
                            continue;
                        }

                        xmlFullTextBodyNode = xmlFullTextNode.XPathSelectElement("//body").Descendants().Where(e =>
                        Regex.Replace(e.Value.ToLower(), "[^A-Za-z]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z]+", "") + "") && Regex.Replace(e.Value.ToLower(), "[^A-Za-z]+", "").EndsWith("" + Regex.Replace(endWords.ToLower(), "[^A-Za-z]+", "") + "")).FirstOrDefault();
                        if (xmlFullTextBodyNode == null)
                        {
                            xmlFullTextBodyNode = xmlFullTextNode.XPathSelectElement("//body").Descendants().Where(e =>
                           Regex.Replace(e.Value.ToLower(), "[^A-Za-z]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z]+", "") + "")).FirstOrDefault();
                        }


                        if (xmlFullTextBodyNode != null)
                        {


                            if (bodyHtmlElement.Attribute("class") == null)
                            {
                                bodyHtmlElement.Add(new XAttribute("class", ""));
                            }
                            if (BodyElements.ContainsKey(xmlFullTextBodyNode.Name.ToString()))
                            {
                                bodyHtmlElement.Attribute("class").Value = BodyElements[xmlFullTextBodyNode.Name.ToString()];
                            }
                        }
                    }

                }

                this.bodyHtmlContent = this.xDocBodyHtmlNode.ToString();
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

                //this.applyStylesPostCleanUp();



            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }

        public void applyStylesPostCleanUp()
        {

            try
            {


                this.bodyHtmlContent = Regex.Replace(this.bodyHtmlContent, "<span type=\"figure\"[^>]+>(.+?)</span>", "$1");

                this.bodyHtmlContent = this.bodyHtmlContent.Replace("<i><b>", "<b><i>").Replace("</b></i>", "</i></b>");
                this.bodyHtmlContent = Cnfunctions.RemoveAllTextFormatting(this.bodyHtmlContent, "b");
                this.bodyHtmlContent = Cnfunctions.RemoveAllTextFormatting(this.bodyHtmlContent, "i");
                this.bodyHtmlContent = Cnfunctions.RemoveAllTextFormatting(this.bodyHtmlContent, "u");
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }


        public void processListInsideSectionTitle()
        {
            try
            {

                XmlNodeList bodySectionTitleHtmlNode;
                XmlNode listSectionTitleElem;
                string listSectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='sectiontitle']");

                for (var i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {
                    if (bodySectionTitleHtmlNode[i].SelectNodes(".//li").Count == 1 && bodySectionTitleHtmlNode[i].SelectSingleNode("./ul") != null)
                    {
                        listSectionTitleElem = bodySectionTitleHtmlNode[i];
                        if (listSectionTitleElem.Attributes.GetNamedItem("id") != null)
                            Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref listSectionTitleElem, "id", bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id").Value);
                        listSectionTitleContent = Regex.Replace(listSectionTitleElem.InnerXml, @"<\/?li>", "");
                        listSectionTitleContent = Regex.Replace(listSectionTitleContent, @"<\/?ul[^<>]*>", "");
                        listSectionTitleContent = Regex.Replace(listSectionTitleContent, "<span class=\"label\">(.+?)</span>", "<span class=\"section-label\">$1</span>");
                        listSectionTitleContent = Regex.Replace(listSectionTitleContent, @"<b>[\s]*<span class=""label"">(.+?)</span>[\s]*<b>(.*?)</b>[\s]*</b>", "<b><span class=\"section-label\">$1</span> $2</b>");
                        listSectionTitleContent = Regex.Replace(listSectionTitleContent, @"<i>[\s]*<span class=""label"">(.+?)</span>[\s]*<i>(.*?)</i>[\s]*</i>", "<i><span class=\"section-label\">$1</span> $2</i>");
                        listSectionTitleElem.InnerXml = listSectionTitleContent;
                        bodySectionTitleHtmlNode[i].ParentNode.ReplaceChild(listSectionTitleElem, bodySectionTitleHtmlNode[i]);
                    }
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void processULSectionTitle()
        {
            try
            {

                XmlNodeList bodySectionTitleHtmlNode;
                XmlNode ulListSectionTitleElem;
                string ulListSectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//ul[@class='sectiontitle']");

                for (var i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {
                    ulListSectionTitleElem = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref ulListSectionTitleElem, "class", "sectiontitle");
                    if (ulListSectionTitleElem.Attributes.GetNamedItem("id") != null)
                        Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref ulListSectionTitleElem, "id", bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id").Value);
                    ulListSectionTitleContent = Regex.Replace(bodySectionTitleHtmlNode[i].InnerXml, @"<\/?li>", "");
                    ulListSectionTitleElem.InnerXml = ulListSectionTitleContent;
                    bodySectionTitleHtmlNode[i].ParentNode.ReplaceChild(ulListSectionTitleElem, bodySectionTitleHtmlNode[i]);
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void processCitationCrossRef()
        {

            try
            {
                XmlNodeList bodySectionTitleHtmlNode;
                XmlNode ulListSectionTitleElem;

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//span[@type='bibr']");
                for (var i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {
                    ulListSectionTitleElem = bodySectionTitleHtmlNode[i];
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref ulListSectionTitleElem, "class", "bibref");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref ulListSectionTitleElem, "href", bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("target").Value.Replace("#b", "bib"));
                    bodySectionTitleHtmlNode[i].Attributes.RemoveNamedItem("type");
                    bodySectionTitleHtmlNode[i].Attributes.RemoveNamedItem("target");
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void processInsertTableId()
        {
            try
            {



                XmlNodeList bodyTableHtmlNode;
                XmlNode ulListSectionTitleElem;
                string ulListSectionTitleContent = "";

                bodyTableHtmlNode = this.bodyHtmlNode.SelectNodes("//table");

                for (int i = 0; i <= bodyTableHtmlNode.Count - 1; i++)
                {
                    bodyTableHtmlNode[i].Attributes.Append(this.bodyHtmlNode.CreateAttribute("id"));
                    bodyTableHtmlNode[i].Attributes.GetNamedItem("id").Value = (i + 1).ToString();
                }

                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }
        public void processHeadingWithList()
        {
            try
            {



                XmlNodeList bodySectionTitleHtmlNode;
                XmlNode listHeadingSectionTitleElem;
                string listHeadingSectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//list[@class='sectiontitle' and @id]");

                for (int i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {
                    listHeadingSectionTitleElem = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref listHeadingSectionTitleElem, "class", "sectiontitle");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref listHeadingSectionTitleElem, "id", bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id").Value);
                    listHeadingSectionTitleContent = Regex.Replace(bodySectionTitleHtmlNode[i].InnerXml, "</?list-item>", "");
                    listHeadingSectionTitleContent = Regex.Replace(listHeadingSectionTitleContent, "<span class=\"label\">(.+?)</span>", "<span class=\"section-label\">$1</span>");
                    listHeadingSectionTitleElem.InnerXml = listHeadingSectionTitleContent;
                    bodySectionTitleHtmlNode[i].ParentNode.ReplaceChild(listHeadingSectionTitleElem, bodySectionTitleHtmlNode[i]);

                }

                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlContent = Regex.Replace(this.bodyHtmlContent,
                    "<div class=\"sectiontitle\" id=\"[^\"\"]+\"></div>", "");
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void processInsertDataSectionLevel()
        {
            try
            {

                XmlNodeList bodySectionTitleHtmlNode;
                XmlElement sectionTitleElem;
                string sectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='sectiontitle' and not(@id)]");

                for (int i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {


                    sectionTitleElem = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionTitleElem, "class", "section");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionTitleElem, "data-section-level", "1");
                    sectionTitleElem.InnerXml = "";
                    bodySectionTitleHtmlNode[i].ParentNode.InsertBefore(sectionTitleElem, bodySectionTitleHtmlNode[i]);
                    sectionTitleElem.AppendChild(bodySectionTitleHtmlNode[i]);

                    while (sectionTitleElem.NextSibling != null)
                    {
                        if (sectionTitleElem.NextSibling != null && sectionTitleElem.NextSibling.OuterXml.Contains("class=\"sectiontitle\"") == false && sectionTitleElem.NextSibling.OuterXml.Contains("<footnote") == false)
                            sectionTitleElem.AppendChild(sectionTitleElem.NextSibling);
                        else if (sectionTitleElem.NextSibling != null & sectionTitleElem.NextSibling.OuterXml.Contains("class=\"sectiontitle\""))
                            break;
                        else
                            break;
                    }

                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void processNumberSections()
        {
            try
            {

                XmlNodeList bodySectionTitleHtmlNode;
                XmlElement sectionTitleElem;
                string sectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='sectiontitle' and string-length(@id)>0]");

                for (int i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {


                    sectionTitleElem = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionTitleElem, "class", "section");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionTitleElem, "data-section-level", bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id").Value.TrimEnd('.').Split(".").Count().ToString());
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionTitleElem, "id", Regex.Replace(bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id").Value, "([^A-Za-z0-9])$", ""));

                    bodySectionTitleHtmlNode[i].ParentNode.InsertBefore(sectionTitleElem, bodySectionTitleHtmlNode[i]);
                    if (bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id") != null)
                        bodySectionTitleHtmlNode[i].Attributes.RemoveNamedItem("id");
                    sectionTitleElem.AppendChild(bodySectionTitleHtmlNode[i]);
                    sectionTitleContent = sectionTitleElem.InnerXml;
                    // Inserting Section label
                    if (Regex.IsMatch(sectionTitleContent, "<label>(.*?)</label>"))
                        sectionTitleContent = Regex.Replace(sectionTitleContent, "<label>(.*?)</label>", "<span class=\"section-label\">$1</span>");
                    else
                        sectionTitleContent = Regex.Replace(sectionTitleContent, @"(?<=<div class=""sectiontitle"">)([^\sA-Z]+)(?=([^<>]+)</div>)", "<span class=\"section-label\">$1</span>");

                    sectionTitleElem.InnerXml = sectionTitleContent;
                    while (sectionTitleElem.NextSibling != null)
                    {
                        if (sectionTitleElem.NextSibling != null & sectionTitleElem.NextSibling.OuterXml.Contains("class=\"sectiontitle\"") == false && sectionTitleElem.NextSibling.OuterXml.Contains("<div class=\"footnote\"") == false && sectionTitleElem.NextSibling.OuterXml.Contains("<div class=\"endnote\"") == false)
                            sectionTitleElem.AppendChild(sectionTitleElem.NextSibling);
                        else
                            break;
                    }

                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }


        public void processNestingSection()
        {
            try
            {



                XmlNodeList bodySectionTitleHtmlNode;
                XmlNode sectionTitleElem;

                XDocument bodyHtmlXDocNode = XDocument.Parse(this.bodyHtmlContent, LoadOptions.PreserveWhitespace);
                int iMax = 0;
                IEnumerable<XElement> elem = bodyHtmlXDocNode.XPathSelectElements("//div[@data-section-level]");
                if (elem.Count()>0)
                {
                    
                 iMax = bodyHtmlXDocNode.XPathSelectElements("//div[@data-section-level]").Max(e => System.Convert.ToInt32(e.Attribute("data-section-level").Value.ToString()));
                }
                for (var i = iMax; i >= 1; i += -1)
                {
                    bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@data-section-level='" + i + "']");
                    for (var j = 0; j <= bodySectionTitleHtmlNode.Count - 1; j++)
                    {
                        sectionTitleElem = bodySectionTitleHtmlNode[j];
                        if (sectionTitleElem != null)
                        {
                            while (sectionTitleElem.NextSibling != null && (sectionTitleElem.NextSibling.Attributes.GetNamedItem("data-section-level") != null && sectionTitleElem.NextSibling.Attributes.GetNamedItem("data-section-level").Value == (i + 1).ToString()))
                                sectionTitleElem.AppendChild(sectionTitleElem.NextSibling);
                        }
                    }
                }

                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void processUnNumberedSections()
        {
            try
            {



                XmlNodeList bodySectionTitleHtmlNode;
                XmlElement sectionTitleElem;
                string sectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='sectiontitle' and (@id and string-length(@id)=0)]");
                for (var i = bodySectionTitleHtmlNode.Count - 1; i >= 0; i += -1)
                {
                    sectionTitleElem = this.bodyHtmlNode.CreateElement("div");
                    sectionTitleElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("class"));
                    sectionTitleElem.Attributes.GetNamedItem("class").Value = "section";
                    sectionTitleElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("data-section-level"));
                    sectionTitleElem.Attributes.GetNamedItem("data-section-level").Value = "1";
                    sectionTitleElem.InnerXml = "";
                    bodySectionTitleHtmlNode[i].ParentNode.InsertBefore(sectionTitleElem, bodySectionTitleHtmlNode[i]);
                    if (bodySectionTitleHtmlNode[i].Attributes.GetNamedItem("id") != null)
                        bodySectionTitleHtmlNode[i].Attributes.RemoveNamedItem("id");
                    sectionTitleElem.AppendChild(bodySectionTitleHtmlNode[i]);

                    while (sectionTitleElem.NextSibling != null)
                    {
                        if (sectionTitleElem.NextSibling != null & sectionTitleElem.NextSibling.OuterXml.Contains("class=\"sectiontitle\"") == false && sectionTitleElem.NextSibling.OuterXml.Contains("<footnote") == false)
                            sectionTitleElem.AppendChild(sectionTitleElem.NextSibling);
                        else if (sectionTitleElem.NextSibling != null & sectionTitleElem.NextSibling.OuterXml.Contains("class=\"sectiontitle\""))
                            break;
                        else
                            break;
                    }

                    if (sectionTitleElem.PreviousSibling != null && sectionTitleElem.PreviousSibling.OuterXml.Contains("class=\"sectiontitle\""))
                        sectionTitleElem.PreviousSibling.AppendChild(sectionTitleElem);
                }


                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



        public void processUnNumberSectionsInsertDataLevel()
        {
            try
            {



                XmlNodeList bodySectionTitleHtmlNode;
                XmlElement sectionTitleElem;
                string sectionTitleContent = "";

                bodySectionTitleHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='section' and @data-section-level]");

                for (var i = 0; i <= bodySectionTitleHtmlNode.Count - 1; i++)
                {
                    foreach (XmlNode N3 in bodySectionTitleHtmlNode)
                        N3.Attributes.GetNamedItem("data-section-level").Value = N3.SelectNodes("ancestor::div[@class='section' and @data-section-level='1']").Count + 1.ToString();
                }


                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);

                throw;
            }

        }


        public void insertSectionId()
        {
            try
            {




                XmlNodeList bodySectionHtmlNode;
                XmlNode sectionElem;

                bodySectionHtmlNode = this.bodyHtmlNode.SelectNodes("//div[@class='section']");
                for (var i = 0; i <= bodySectionHtmlNode.Count - 1; i++)
                {
                    sectionElem = bodySectionHtmlNode[i];
                    if (sectionElem.Attributes.GetNamedItem("id") != null)
                        sectionElem.Attributes.GetNamedItem("id").Value = "s" + (i + 1).ToString();
                    else
                        Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref sectionElem, "id", "s" + (i + 1).ToString());
                }


                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlContent = Regex.Replace(this.bodyHtmlContent, "<b>\\s*</b>|<b/>", "", RegexOptions.Singleline);
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



        public void processFigure()
        {
            try
            {





                this.xDocBodyHtmlNode = XDocument.Parse(this.bodyHtmlContent);
                IEnumerable<XElement> bodyHtmlDivElements = this.xDocBodyHtmlNode.XPathSelectElement("//div").Elements();

                foreach (var bodyHtmlDivElement in bodyHtmlDivElements)
                {
                    string bodyHtmlDivValue = bodyHtmlDivElement.Value.Trim();
                    string startWords = Regex.Match(bodyHtmlDivValue, @"^(\S+(?:\s+\S+){0,5})").Value.ToLower();
                    string endWords = Regex.Match(bodyHtmlDivValue, "(\\S+(?:\\s+\\S+){0,5})$").Value.ToLower();
                    if (string.IsNullOrEmpty(startWords) == false)
                    {
                        var xmlFullTextBodyNode = this.xmlFullTextNode.XPathSelectElements("//figure").Where(e => Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z0-9]+", "") + "")).FirstOrDefault();
                        //var xmlFullTextBodyNode = this.figureTeiNode.XPathSelectElements("//figure").Where(e => Regex.Replace(e.Value.ToLower(), "[^A-Za-z0-9]+", "").StartsWith("" + Regex.Replace(startWords.ToLower(), "[^A-Za-z0-9]+", "") + "")).FirstOrDefault();
                        if (xmlFullTextBodyNode != null && xmlFullTextBodyNode.Value.Trim().ToLower().StartsWith("fig"))
                        {
                            bodyHtmlDivElement.Name = "figure";

                            if (bodyHtmlDivElement.Attribute("class") != null)
                            {
                                bodyHtmlDivElement.Attribute("class").Remove();
                            }

                            if (bodyHtmlDivElement.Attribute("id") == null)
                            {
                                bodyHtmlDivElement.Add(new XAttribute("id", ""));
                            }
                            MatchCollection oMats = Regex.Matches(bodyHtmlDivValue, @"(?<!<span[^<>]+>)([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s([0-9]+))");
                            bodyHtmlDivElement.Attribute("id").Value = "F" + oMats[0].Groups[5].Value;
                            if (bodyHtmlDivElement.Attribute("data-match") == null)
                            {
                                bodyHtmlDivElement.Add(new XAttribute("data-match", ""));
                            }
                            bodyHtmlDivElement.Attribute("data-match").Value = "ML";
                            bodyHtmlDivElement.ReplaceNodes(XElement.Parse("<root>" + figureInsertSpanTags(bodyHtmlDivElement.CreateNavigator().InnerXml, xmlFullTextBodyNode.CreateNavigator().OuterXml) + "</root>").Elements());

                        }

                    }
                }
                this.bodyHtmlContent = this.xDocBodyHtmlNode.ToString();
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void processFigureByPattern()
        {
            try
            {


                XmlNodeList bodyDivHtmlNode;
                XmlNode figureElem;
                string figureElemContent = "";

                bodyDivHtmlNode = this.bodyHtmlNode.SelectNodes("//div");
                //bodyFigureHtmlNode = this.bodyHtmlNode.SelectNodes("//div/text()[starts-with(., 'Fig') or starts-with(., 'FIG')]");

                for (var i = 0; i <= bodyDivHtmlNode.Count - 1; i++)
                {
                    if(bodyDivHtmlNode[i]!=null&&(Regex.Replace(bodyDivHtmlNode[i].InnerText, "[^a-zA-Z]", "").StartsWith("Fig") || Regex.Replace(bodyDivHtmlNode[i].InnerText, "[^a-zA-Z]", "").StartsWith("FIG")))
                    {
                        string bodyDivHtmlContent = bodyDivHtmlNode[i].InnerText.Trim();


                        if (Regex.IsMatch(bodyDivHtmlNode[i].InnerText.Trim(), @"^(F(ig|IG)(ure|URE)?([Ss])?\s+[0-9]+)(?=\s?[\.\:\p{Pd}])"))
                        {
                            figureElem = this.bodyHtmlNode.CreateElement("figure");
                            figureElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("id"));
                            MatchCollection oMats = Regex.Matches(bodyDivHtmlContent, @"(?<!<span[^<>]+>)([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s([0-9]+))");
                            if (oMats.Count()>0)
                            {

                            figureElem.Attributes.GetNamedItem("id").Value = "F" + oMats[0].Groups[5].Value;
                            }
                            figureElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("data-match"));
                            figureElem.Attributes.GetNamedItem("data-match").Value = "Pattern";
                            figureElemContent = bodyDivHtmlNode[i].InnerXml;
                            if (Regex.IsMatch(figureElemContent.Trim(), @"^((<[^<>/]*>[ ]*)?(F(ig|IG)(ure|URE)?([Ss])?\s+[0-9]+)[\.\:\p{Pd}]?\s?(</[^<>]>)?)((\s)[A-Z].*)"))
                            {

                                //<b>figure 1:</b> tgesd adfa d
                                //Figure 1.adfa dafads

                                figureElemContent = Regex.Replace(figureElemContent.Trim(), @"^((<[^<>/]*>[ ]*)?(F(ig|IG)(ure|URE)?([Ss])?\s+[0-9]+)[\.\:\p{Pd}]?\s?(</[^<>]>)?)((\s)[A-Z].*)", "<span class=\"label\">$1</span><figcaption><span class=\"figpara\">$8</span></figcaption>");
                                figureElemContent = Regex.Replace(figureElemContent,"</?u>","");

                                //figureElemContent = figureElemContent + "</span>";
                            }


                            figureElem.InnerXml = figureElemContent;

                            bodyDivHtmlNode[i].ParentNode.ReplaceChild(figureElem, bodyDivHtmlNode[i]);
                        }

                    }
                }


                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
                this.figurePostCleanUp();
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }





        public string figureInsertSpanTags(string bodyFigXml, string teiFigXml)
        {

            try
            {


                XmlDocument teiContentNode = new XmlDocument();
                XmlNode teiContentNodeElement;


                MatchCollection elementMatch;
                if (teiFigXml != null)
                {
                    teiContentNode.LoadXml(teiFigXml);


                    teiContentNodeElement = teiContentNode.SelectSingleNode("//figDesc");


                    string teiContentElementText = teiContentNodeElement.InnerText;
                    elementMatch = Regex.Matches(bodyFigXml, "(<[^<>/]*>[ ]*)*" + teiContentElementText.Split(" ")[0]);
                    if (teiContentElementText.Length > 0 && elementMatch.Count > 0)
                    {

                        bodyFigXml = bodyFigXml.Insert(elementMatch[0].Index, "</span><span class=\"figcaption\">");
                        bodyFigXml = "<span class=\"figlabel\">" + bodyFigXml + "</span>";


                    }


                }

                return bodyFigXml;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void figurePostCleanUp()
        {

            try
            {




                XmlNodeList bodyFigLabelHtmlNodes;
                XmlNode figureElem;
                string figureElemContent = "";

                bodyFigLabelHtmlNodes = this.bodyHtmlNode.SelectNodes("//span[@class='figlabel']");
                foreach (XmlNode bodyFigLabelHtmlNode in bodyFigLabelHtmlNodes)
                {
                    figureElemContent = bodyFigLabelHtmlNode.InnerXml;
                    figureElemContent = Regex.Replace(figureElemContent, @"<\/?(b|i|u)>", "");
                    bodyFigLabelHtmlNode.InnerXml = figureElemContent.Trim();
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }




        public void processTable()
        {
            try
            {


                XmlNodeList bodyTableHtmlNode;
                //XmlNode tableElem;
                string tableElemContent = "";
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent.Trim());
                bodyTableHtmlNode = this.bodyHtmlNode.SelectNodes("//div[starts-with(.,'Table')]");

                int figCount = 0;

                foreach (XmlNode tableElem in bodyTableHtmlNode)
                {



                    if (Regex.IsMatch(tableElem.InnerText, @"(?<=^(<[^<>]+>)?)(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)(?=\s?[\.\:\p{Pd}])"))
                    {
                        tableElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("id"));
                        tableElem.Attributes.GetNamedItem("id").Value = "T" + (figCount + 1).ToString();
                        tableElem.Attributes.Append(this.bodyHtmlNode.CreateAttribute("class"));
                        tableElem.Attributes.GetNamedItem("class").Value = "tablewrap";
                        figCount += 1;
                        tableElemContent = tableElem.InnerXml;
                        //if (Regex.IsMatch(tableElemContent, @"(?<=^(<[^<>]+>)?)(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)(?=\s?[\.\:\p{Pd}])"))
                        //{
                            if (Regex.IsMatch(tableElemContent, @"(?<=^)(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)(?=\s?[\.\:\p{Pd}])"))
                        {

                                tableElemContent = Regex.Replace(tableElemContent, @"(?<=^)((T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)(\s?[\.\:\p{Pd}]))", "<span class=\"label\">$1</span><span class=\"caption\">");
                            tableElemContent = tableElemContent + "</span>";
                        }
                            //else if (Regex.IsMatch(tableElemContent, @"(<[^<>]+>)(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)(?=\s?[\.\:\p{Pd}])"))
                            else if (Regex.IsMatch(tableElemContent, @"((<[^<>]+>)+(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)([\s\.\:\p{Pd}]+(<[^<>]+>)+))"))
                        {

                                tableElemContent = Regex.Replace(tableElemContent, @"((<[^<>]+>)+(T(ab|AB)(le|LE)?([Ss])?\s+[0-9]+)([\s\.\:\p{Pd}]+(<[^<>]+>)+))", "<span class=\"label\">$1</span><span class=\"caption\">");
                            tableElemContent = tableElemContent + "</span>";
                        }
                        //}

                        tableElem.InnerXml = tableElemContent;

                        if (tableElem.SelectSingleNode(".//span[@class='label']") != null)
                        {
                            tableElemContent = tableElem.SelectSingleNode(".//span[@class='label']").InnerXml;
                            tableElemContent = Regex.Replace(tableElemContent, @"<\/?(b|i|u)>", "");
                            tableElem.SelectSingleNode(".//span[@class='label']").InnerXml = tableElemContent.Trim();
                        }


                            XmlNode tableDivElem = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                            Cnfunctions.CreateAttribute(ref this.bodyHtmlNode,ref tableDivElem,"class","tablediv");

                        if ((tableElem.NextSibling != null && tableElem.NextSibling.Name == "table"))
                        {
                            tableDivElem.AppendChild(tableElem.NextSibling);
                            tableElem.AppendChild(tableDivElem);
                            //tableElemContent = tableElem.InnerXml;
                            //tableElemContent = Regex.Replace(tableElemContent, @"<\/?table[^>]*>", "");
                            //tableElem.InnerXml = tableElemContent;
                        }
                        else if (tableElem.NextSibling!=null&&tableElem.NextSibling.NextSibling != null && tableElem.NextSibling.NextSibling.Name == "table")
                        {

                            tableDivElem.AppendChild(tableElem.NextSibling.NextSibling);
                            tableElem.AppendChild(tableDivElem);

                        }
                    }

                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void processFootnote()
        {
            try
            {




                XmlNodeList bodyFootNoteHtmlElements = this.bodyHtmlNode.SelectNodes("//footnote");
                int iterationCount = 1;
                foreach (XmlNode bodyFootNoteHtmlElement in bodyFootNoteHtmlElements)
                {
                    XmlElement divElement = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "div");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref divElement, "class", "footnote");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref divElement, "id", "fn" + iterationCount.ToString());
                    string footNoteContent = bodyFootNoteHtmlElement.InnerXml;
                    footNoteContent = Regex.Replace(footNoteContent, "<label>([^<>]+)</label>", "<span class=\"label\"><sup>$1</sup></span>");
                    footNoteContent = Regex.Replace(footNoteContent, "<div>(.*?)</div>", "<div class=\"footnotepara\">$1</div>");
                    divElement.InnerXml = footNoteContent;
                    bodyFootNoteHtmlElement.ParentNode.ReplaceChild(divElement, bodyFootNoteHtmlElement);
                    iterationCount++;
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }



        }

        public void processFootnoteRef()
        {
            try
            {



                XmlNodeList bodyFootNoteRefHtmlElements = this.bodyHtmlNode.SelectNodes("//footnotereference/xref");
                int iterationCount = 1;
                foreach (XmlNode bodyFootNoteRefHtmlElement in bodyFootNoteRefHtmlElements)
                {
                    XmlElement spanElement = Cnfunctions.CreateNode(ref this.bodyHtmlNode, "span");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref spanElement, "class", "cite");
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref spanElement, "href", bodyFootNoteRefHtmlElement.Attributes.GetNamedItem("refid").Value);
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref spanElement, "id", "fn" + iterationCount.ToString());
                    Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref spanElement, "name", "fn");

                    spanElement.InnerXml = bodyFootNoteRefHtmlElement.InnerXml;
                    bodyFootNoteRefHtmlElement.ParentNode.ReplaceChild(spanElement, bodyFootNoteRefHtmlElement);
                    iterationCount++;
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }

        }


        public void processCitation()
        {
            try
            {
                MatchCollection oMats;
                string xmlFullTextContent = xmlFullTextNode.CreateNavigator().OuterXml;

                XmlNodeList bodyCitationNode = null;



                if (Regex.IsMatch(xmlFullTextContent, @"<ref type=""bibr""[^<>]+>[\[\(][0-9]+[^<>]+</ref>"))
                {
                    // Bibcitation
                    oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<span[^<>]+>)(\[([0-9]+)\])");
                    for (var i = oMats.Count - 1; i >= 0; i += -1)
                    {
                        this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index + oMats[i].Groups[1].Length, "</span>");
                        this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index, "<span class=\"bibref\" href=\"bib" + oMats[i].Groups[2].Value + "\">");
                    }


                    oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<span[^<>]+>)(\[[0-9]([\p{Pd}\,\s0-9])+\])");
                    for (var i = oMats.Count - 1; i >= 0; i += -1)
                    {
                        this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index + oMats[i].Groups[1].Length, "</span>");
                        this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index, "<span class=\"bibref\" href=\"bib0\">");
                    }
                }
                else
                {
                    // Unnumbered
                    this.bodyHtmlContent = Cnfunctions.InsertSpanTags(this.bodyHtmlContent, xmlFullTextContent, "ref[@type='bibr']");
                    this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
                    bodyCitationNode = this.bodyHtmlNode.SelectNodes("//span[@type='bibr' and not(@target='bib0')]");
                    for (var j = 0; j <= bodyCitationNode.Count - 1; j++)
                    {
                        XmlNode bodyCitationNodeElem = bodyCitationNode[j];
                        bodyCitationNodeElem.Attributes.GetNamedItem("type").Value = "bibref";
                        bodyCitationNodeElem.Attributes.RemoveNamedItem("target");
                        Cnfunctions.CreateAttribute(ref this.bodyHtmlNode, ref bodyCitationNodeElem, "href", "bibX");
                    }
                    this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                }

                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
                bodyCitationNode = this.bodyHtmlNode.SelectNodes("//span[@class='bibref' and @href='bib0']");
                for (var j = 0; j <= bodyCitationNode.Count - 1; j++)
                {
                    string sText = "";
                    if (Regex.IsMatch(bodyCitationNode[j].InnerText, @"[0-9]([\p{Pd}\,\s0-9]+)"))
                    {
                        sText = Regex.Match(bodyCitationNode[j].InnerText, @"[0-9]([\p{Pd}\,\s0-9]+)").Value;
                        if (string.IsNullOrEmpty(sText))
                            continue;
                        string[] str = sText.Split(",");
                        string dm = "";
                        for (int k = 0; k <= str.Count() - 1; k++)
                        {
                            str[k] = Regex.Replace(str[k], @"[\p{Pd}]", "-");
                            if (str[k].Contains("-"))
                            {
                                string[] ky = str[k].Replace("-", ",").Split(",");
                                for (int p = Convert.ToInt32(ky[0]); p <= Convert.ToInt32(ky[1]); p++)
                                    dm += "bib" + System.Convert.ToString(p).Trim() + " ";
                            }
                            else
                                dm += "bib" + str[k].Trim() + " ";
                        }
                        sText = dm.Trim();
                    }

                    bodyCitationNode[j].Attributes.GetNamedItem("href").Value = sText;
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void multipleFigureCitation()
        {
            try
            {
                XmlNodeList bodyMultiFigHtmlElements = null;

                MatchCollection oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<span[^<>]+>)([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s[0-9]+([, \p{Pd}]+[0-9]+|\s?(or|and|to|through)\s?[0-9]+)+)\b");
                for (var i = oMats.Count - 1; i >= 0; i += -1)
                {
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index + oMats[i].Groups[1].Length, "</span>");
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index, "<span class=\"cite\" href=\"F0\">");
                }
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

                bodyMultiFigHtmlElements = this.bodyHtmlNode.SelectNodes("//span[@class='cite' and @href='F0']");
                for (var j = 0; j <= bodyMultiFigHtmlElements.Count - 1; j++)
                {
                    string sText = "";
                    if (Regex.IsMatch(bodyMultiFigHtmlElements[j].InnerText, @"([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s([0-9]+([, \p{Pd}]+[0-9]+|\s?(or|and|to|through)\s?[0-9]+)+))\b"))
                    {
                        sText = Regex.Match(bodyMultiFigHtmlElements[j].InnerText, @"([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s([0-9]+([, \p{Pd}]+[0-9]+|\s?(or|and|to|through)\s?[0-9]+)+))\b").Groups[5].Value;
                        if (string.IsNullOrEmpty(sText))
                            continue;

                        string[] str = sText.Split(",");
                        string dm = "";
                        for (int k = 0; k <= str.Count() - 1; k++)
                        {
                            str[k] = Regex.Replace(str[k], @"([\p{Pd}]|or|and|to|through)", "-");
                            if (str[k].Contains("-"))
                            {
                                string[] ky = str[k].Replace("-", ",").Split(",");
                                for (int p = Convert.ToInt32(ky[0]); p <= Convert.ToInt32(ky[1]); p++)
                                    dm += "fig" + System.Convert.ToString(p).Trim() + " ";
                            }
                            else
                                dm += "fig" + str[k].Trim() + " ";
                        }
                        sText = dm.Trim();
                    }

                    bodyMultiFigHtmlElements[j].Attributes.GetNamedItem("href").Value = sText;
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void singleFigureCitation()
        {
            try
            {
                MatchCollection oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<span[^<>]+>)([Ff](ig|IG)(ure|URE)?([Ss\.]+)?\s([0-9]+))");
                for (var i = oMats.Count - 1; i >= 0; i += -1)
                {
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index + oMats[i].Groups[1].Length, "</span>");
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index, "<span class=\"cite\" data-de-type=\"Figure\" href=\"F" + oMats[i].Groups[5].Value + "\">");
                }
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void multipleTableCitation()
        {
            try
            {



                XmlNodeList bodyMultiTabHtmlElements = null;

                MatchCollection oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<span[^<>]+>)([Tt](ab|AB)(le|LE)?([Ss\.]+)?\s[0-9]+([, \p{Pd}]+[0-9]+|\s?(and|to)\s?[0-9]+)+)\b");
                for (var i = oMats.Count - 1; i >= 0; i += -1)
                {
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index + oMats[i].Groups[1].Length, "</span>");
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[1].Index, "<span class=\"cite\" href=\"T0\">");
                }
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
                bodyMultiTabHtmlElements = this.bodyHtmlNode.SelectNodes("//span[@class='cite' and @href='T0']");
                for (var j = 0; j <= bodyMultiTabHtmlElements.Count - 1; j++)
                {
                    string sText = "";
                    if (Regex.IsMatch(bodyMultiTabHtmlElements[j].InnerText, @"([Tt](ab|AB)(le|LE)?([Ss\.]+)?\s([0-9]+([, \p{Pd}]+[0-9]+|\s?(or|and|to|through)\s?[0-9]+)+))\b"))
                    {
                        sText = Regex.Match(bodyMultiTabHtmlElements[j].InnerText, @"([Tt](ab|AB)(le|LE)?([Ss\.]+)?\s([0-9]+([, \p{Pd}]+[0-9]+|\s?(or|and|to|through)\s?[0-9]+)+))\b").Groups[5].Value;
                        if (string.IsNullOrEmpty(sText))
                            continue;

                        string[] str = sText.Split(",");
                        string dm = "";
                        for (int k = 0; k <= str.Count() - 1; k++)
                        {
                            str[k] = Regex.Replace(str[k], @"([\p{Pd}]|or|and|to|through)", "-");
                            if (str[k].Contains("-"))
                            {
                                string[] ky = str[k].Replace("-", ",").Split(",");
                                for (int p = Convert.ToInt32(ky[0]); p <= Convert.ToInt32(ky[1]); p++)
                                    dm += "tab" + System.Convert.ToString(p).Trim() + " ";
                            }
                            else
                                dm += "tab" + str[k].Trim() + " ";
                        }
                        sText = dm.Trim();
                    }

                    bodyMultiTabHtmlElements[j].Attributes.GetNamedItem("href").Value = sText;
                }
                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }




        public void singleTableCitation()
        {
            try
            {
                MatchCollection oMats = Regex.Matches(this.bodyHtmlContent, @"(?<!<(span|table)[^<>]+>)([Tt](ab|AB)(le|LE)?([Ss\.]+)?\s([0-9]+))");
                for (var i = oMats.Count - 1; i >= 0; i += -1)
                {
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[2].Index + oMats[i].Groups[2].Length, "</span>");
                    this.bodyHtmlContent = this.bodyHtmlContent.Insert(oMats[i].Groups[2].Index, "<span class=\"cite\" href=\"T" + oMats[i].Groups[6].Value + "\">");
                }
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }









        public void finalCleanUp()
        {

            try
            {





                XmlNodeList bodyHtmlElements = this.bodyHtmlNode.SelectNodes("//div[not(@*) or not(string-length(@*)) or @class='']");

                foreach (XmlNode bodyHtmlElement in bodyHtmlElements)
                {
                    if (bodyHtmlElement.Attributes.GetNamedItem("class") == null)
                    {
                        bodyHtmlElement.Attributes.Append(this.bodyHtmlNode.CreateAttribute("class"));
                    }
                    bodyHtmlElement.Attributes.GetNamedItem("class").Value = "para";
                }


                this.bodyHtmlContent = this.bodyHtmlNode.OuterXml;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);

                //remove empty tags

                while (Regex.IsMatch(this.bodyHtmlContent, @"<(div|u|i|b)[^<>]*></\1>"))
                    this.bodyHtmlContent = Regex.Replace(this.bodyHtmlContent, @"<(div|u|i|b)[^<>]*></\1>", "");
                while (Regex.IsMatch(this.bodyHtmlContent, @"<(div|u|i|b)+[^/>]*\s*/>"))
                    this.bodyHtmlContent = Regex.Replace(this.bodyHtmlContent, @"<(div|u|i|b)+[^/>]*\s*/>", "");
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
                this.changeSectionTitleElemName();
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void changeSectionTitleElemName()
        {

            XDocument xdoc = new XDocument();
            xdoc = XDocument.Parse(this.bodyHtmlContent);
            IEnumerable<XElement> sectionNodeList = xdoc.XPathSelectElements("//div[@data-section-level]");
            //XmlNodeList sectionTitleNodeList= this.bodyHtmlNode.SelectNodes("//div[@data-section-level]/div[@class='sectiontitle]");

            foreach (XElement sectionNode in sectionNodeList)
            {

                  XElement sectionTitleElem= sectionNode.XPathSelectElement("./div[@class='sectiontitle']");

                sectionTitleElem.Name = "h"+sectionNode.Attribute("data-section-level").Value;

                //clear tags in sectiontitle like b,u etc.
                sectionTitleElem.Value =sectionTitleElem.Value;
                //if (sectionNode.Parent.Attribute("data-section-level")!=null&& sectionNode.Parent.Attribute("data-section-level").Value != "")
                //{
                //    Console.WriteLine(sectionNode.Parent.Attribute("data-section-level").Value);
                //    int level = Convert.ToInt32(sectionNode.Parent.Attribute("data-section-level").Value);
                //    if (level > 6)
                //    {
                //        level = 6;
                //    }
                //    sectionNode.Name = "h" + level;

                //}
            }

            this.bodyHtmlContent = xdoc.ToString();
            this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
        }









        //load files

        public void setBodyHtmlContent()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string bodyHtmlContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.HTML_OUTPATH, uniqueNumber, customConstant), customConstant.BODYHTML_NAME); ;
                string bodyHtmlContent = Regex.Match(Cnfunctions.ReadString(bodyHtmlContentPath), "<body>(.*?)</body>").Value;
                if (bodyHtmlContent == "")
                {
                    this.message = "[SetBodyHtmlNode] => Check body.Html file path";
                    return;
                }
                bodyHtmlContent = Regex.Replace(bodyHtmlContent, @"(<list>(.+?)</list>)", "<div>$1</div>");
                //bodyHtmlContent = Regex.Replace(bodyHtmlContent, @"</(subtleemphasis|b|i|u|emphasis)><\1>", "");
                //bodyHtmlContent = Regex.Replace(bodyHtmlContent, @"(?<=<div[^>]*>)<\2>([^<>]+)<\/(b|i|u)>(?=</div>)", "$1", RegexOptions.RightToLeft);
                //bodyHtmlContent = bodyHtmlContent.Replace("<footnotereference><xref refid=\"fn*\">", "");
                //bodyHtmlContent = bodyHtmlContent.Replace("</xref></footnotereference>", "");
                bodyHtmlContent = bodyHtmlContent.Replace("\r\n|\\s", "");

                xmlDoc.LoadXml(bodyHtmlContent); xmlDoc.PreserveWhitespace = true;
                bodyHtmlContent = xmlDoc.SelectSingleNode("//body").OuterXml.Replace("<body>", "<article>").Replace("</body>", "</article>");
                this.xDocBodyHtmlNode = XDocument.Parse(bodyHtmlContent, LoadOptions.PreserveWhitespace);
                this.bodyHtmlContent = bodyHtmlContent;
                this.bodyHtmlNode.LoadXml(this.bodyHtmlContent);
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void SetXmlFullTextNode()
        {
            try
            {

                XmlDocument xmlDoc = new XmlDocument();
                string xmlFullTextContentPath = Path.Combine(Cnfunctions.GetModifiedPath(customConstant.GXML_OUTPATH, uniqueNumber, customConstant), docxFileName + "-processFulltextDocument.xml");
                string xmlFullTextContent = Cnfunctions.ReadString(xmlFullTextContentPath);
                if (xmlFullTextContent == "")
                {
                    this.message = "[SetXmlFullTextNode] => Check xmlfulltext.xml file path";
                    return;
                }
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, @"<\/?byline>", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<lb/>", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<(tei|div) [^<>/]+>", "<$1>", RegexOptions.IgnoreCase);
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, " xmlns=\"http://www.tei-c.org/ns/1.0\"", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<div\\s?/>", "");
                this.xmlFullTextNode = XDocument.Parse(xmlFullTextContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }


        public void SetFigureTeiNode()
        {
            try
            {
                //AML_Oscillations_MAIN_Response.training.figure.tei

                XmlDocument xmlDoc = new XmlDocument();
                string xmlFullTextContentPath = Path.Combine(homePath, "tei", docxFileName + ".training.figure.tei.xml");
                string xmlFullTextContent = Cnfunctions.ReadString(xmlFullTextContentPath);
                if (xmlFullTextContent == "")
                {
                    this.message = "[SetFigureTeiNode] => Check figure.tei.xml file path";
                    return;
                }
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, @"<\/?byline>", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, @"<head>((?:(?!</head).)*)<head>", "<head>$1");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<lb/>", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<(tei|div) [^<>]+>", "<$1>", RegexOptions.IgnoreCase);
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "<div\\s?/>", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, "/n/n", "");
                xmlFullTextContent = Regex.Replace(xmlFullTextContent, " xmlns=\"http://www.tei-c.org/ns/1.0\"", "");
                this.figureTeiNode = XDocument.Parse(xmlFullTextContent, LoadOptions.PreserveWhitespace);
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }



        public void generateBodyHtml()
        {
            Cnfunctions.CreateHTML(outPath, this.bodyHtmlContent, "Body.html");
            //Cnfunctions.CreateHTML(outPath, this.this.bodyHtmlNode.CreateNavigator().OuterXml, "body.html");
            this.message = "BodyHtml file generated";
        }

        public bool GetBodyMatterMappedNames()
        {
            try
            {
                BodyElements.Add("head", "sectiontitle");
                BodyElements.Add("p", "para");
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }


    }
}
