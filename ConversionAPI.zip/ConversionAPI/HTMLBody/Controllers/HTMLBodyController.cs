﻿using HTMLBody.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Utils;
using Utils.Common;
using Utils.Logger;
using Utils.Models;

namespace HTMLBody.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class HTMLBodyController : Controller
    {
        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

        public HTMLBodyController(IConfiguration configuration,ILoggerService logger,ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }
        [HttpPost]
        public async Task<CoreResponseModel> structureBodyHTML([FromQuery] string uniqueNumber)
        {
            bodyHtmlDocument bodyHtmlDoc = new bodyHtmlDocument(this.configuration, this.logger,this.customConstant);

            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.uniqueNumber = uniqueNumber;
            coreResponseModel.projectName = projectName;

            try
            {

                //set configurations
                bodyHtmlDoc.StartUp(uniqueNumber);
                this.logger.LogInfo(bodyHtmlDoc.docxFileName+" file process started.");
                bodyHtmlDoc.applyStyles();
                bodyHtmlDoc.processListInsideSectionTitle();
                bodyHtmlDoc.processULSectionTitle();
                bodyHtmlDoc.processHeadingWithList();
                bodyHtmlDoc.processInsertDataSectionLevel();
                bodyHtmlDoc.processNumberSections();
                bodyHtmlDoc.processNestingSection();
                bodyHtmlDoc.processUnNumberedSections();
                //bodyHtmlDoc.processUnNumberSectionsInsertDataLevel();//Queries 
                bodyHtmlDoc.insertSectionId();
                bodyHtmlDoc.processFigure();
                bodyHtmlDoc.processFigureByPattern();



                bodyHtmlDoc.processTable();






                bodyHtmlDoc.processCitationCrossRef();


                bodyHtmlDoc.processFootnote();
                bodyHtmlDoc.processFootnoteRef();

                bodyHtmlDoc.processCitation();

                bodyHtmlDoc.singleFigureCitation();
                bodyHtmlDoc.multipleFigureCitation();

                bodyHtmlDoc.multipleTableCitation();
                bodyHtmlDoc.singleTableCitation();




                bodyHtmlDoc.finalCleanUp();
                //final output
                bodyHtmlDoc.generateBodyHtml();
                this.logger.LogInfo(bodyHtmlDoc.docxFileName+" file process completed.");
                this.logger.LogInfo(bodyHtmlDoc.message);
                coreResponseModel.status = 200;
                coreResponseModel.message = bodyHtmlDoc.message;
           
                return coreResponseModel;
            }
            catch (Exception ex)
            {
                coreResponseModel.status = 400;
                coreResponseModel.message = bodyHtmlDoc.message+" "+ex.Message;
                this.logger.LogError(coreResponseModel.message);
                return coreResponseModel;

            }
        }


    }
}
