﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Docx2HTML.Service;
using Microsoft.Extensions.Configuration;
using Utils;
using Utils.Logger;
using Utils.Common;
using Utils.Models;
using System.Reflection;

namespace Doc2HTML.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Doc2HTMLController : ControllerBase
    {
        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
		private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

		private string message;
		private string uniqueNumber;
		private string docxFileName;

		public Doc2HTMLController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        [Route("convertToHtml")]
        [HttpPost]
        public async Task<CoreResponseModel> convertToHtml(string uniqueNumber)
        {
            wdmlDocument wdmlDoc = new wdmlDocument(this.configuration, this.logger,this.customConstant);
			CoreResponseModel coreResponseModel = new CoreResponseModel();
			coreResponseModel.projectName = this.projectName;

			try
            {
                wdmlDoc.StartUp(uniqueNumber);
                this.uniqueNumber = uniqueNumber;
                this.docxFileName = wdmlDoc.docxFileName;
               

                wdmlDoc.MathOperation();
                wdmlDoc.InsertImage();
                wdmlDoc.GetBodyTextStyle();
                wdmlDoc.FormatContent();
                wdmlDoc.FormatHTML();

                //post cleanup
                wdmlDoc.finalPostCleanup();
                //final output
                wdmlDoc.generatePlainHtml();
                this.message = wdmlDoc.uniqueNumber + " " + wdmlDoc.docxFileName + " " + "Doc To plain html converted.";
				coreResponseModel.status = 200;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogInfo(message);

				return coreResponseModel;
			}
            catch (Exception ex)
            {
                this.message = this.uniqueNumber + " " + this.docxFileName + " " + this.message + " " + ex.Message;
				coreResponseModel.status = 400;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = this.message;
				this.logger.LogError(message);

				return coreResponseModel;

			}
        }

        
    }
}
