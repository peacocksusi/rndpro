﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utils.Models;

namespace Doc2HTML.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {

        [HttpGet]

        public ProjectInfo Get()
        {
            ProjectInfo projectInfo = new ProjectInfo();
            projectInfo.Name = "Doc2HTML";
            projectInfo.Version = "0.0.0";
            projectInfo.Description = "This api is helps to convert docx to create plain html";
            return projectInfo;
        }
    }
}
