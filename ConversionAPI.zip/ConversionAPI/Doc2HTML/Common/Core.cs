﻿namespace Doc2HTML.Common
{
    public class Core
    {

        public class CoreResponse
        {
            public int Status { get; set; }
            public string Message { get; set; }
        }
    }
}
