﻿using System.Text.RegularExpressions;
using System.Xml;
using Doc2HTML.Common;
using Utils.Common;
using static Utils.Common.CustomConstant;

namespace Doc2HTML.Service
{
    public class MathOperation
    {

        XmlDocument plainHtmlNode = new XmlDocument();

        CustomConstant customConstant = new CustomConstant();
        string[] mathOperator;
        string fMath = "";
        public Dictionary<string, string> hsEntity = new Dictionary<string, string>();

        public string plainHtmlContent = "";


        public MathOperation(string plainHtmlContent, Dictionary<string, string> hsEntity)
        {
            if (plainHtmlContent != null)
            {
                this.plainHtmlContent = plainHtmlContent;
                this.plainHtmlNode.PreserveWhitespace = true;
                this.plainHtmlNode.LoadXml(plainHtmlContent);
                this.hsEntity = hsEntity;
            }
            else
            {
                throw new Exception(Cnfunctions.GetExceptionMethodName() + "plainHtmlContent is Null");
            }
        }

        public void ConvertOOML2MML()
        {
            int intCnt;

           
            try
            {
                XmlDocument styleMappingNode = new XmlDocument();
                string styleMappingPath = Directory.GetCurrentDirectory() + "//Resources//StyleMapping.xml";
                string styleMappingContent = Cnfunctions.GetContentFromFile(styleMappingPath);
                styleMappingNode.PreserveWhitespace = true; styleMappingNode.LoadXml(styleMappingContent);
                if (styleMappingNode.SelectNodes("//mathOperator") != null)
                    mathOperator = styleMappingNode.SelectSingleNode("//mathOperator").Attributes.GetNamedItem("value").Value.Split("|");
                if (styleMappingNode.SelectNodes("//mathFunction") != null)
                    fMath = "|" + styleMappingNode.SelectSingleNode("//mathFunction").Attributes.GetNamedItem("value").Value + "|";
                else
                    fMath = "|arcsin|arccos|arctan|sin|sinh|cos|cosh|tan|tanh|cot|coth|cov|csc|deg|det|dim|exp|gcd|glb|hom|inf|int|ker|lg|lim|ln|log|lub|max|mod|min|Pr|Re|sgn|sup|var|";


                this.plainHtmlContent = Regex.Replace(this.plainHtmlContent, "<(/)?m:([^<>]+)>", "<$1m_$2>");
                this.plainHtmlContent = this.plainHtmlContent.Replace(" m:val=", " m_val=");
                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(this.plainHtmlContent);

                XmlNodeList htmlBookMarkStartNodeList = this.plainHtmlNode.SelectNodes("//m_oMath//w-bookmarkStart");
                for (intCnt = 0; intCnt <= htmlBookMarkStartNodeList.Count - 1; intCnt++)
                {
                    XmlNode htmlBookMarkStartNode = htmlBookMarkStartNodeList[intCnt].ParentNode;
                    while (htmlBookMarkStartNode.Name != "m_oMath")
                        htmlBookMarkStartNode = htmlBookMarkStartNode.ParentNode;
                    htmlBookMarkStartNode.ParentNode.InsertAfter(htmlBookMarkStartNodeList[intCnt], htmlBookMarkStartNode);
                }

                XmlNodeList htmlOmathNodeList = this.plainHtmlNode.SelectNodes("//m_oMath");
                XmlNode htmlMathElem = this.plainHtmlNode.CreateElement("math");
                for (intCnt = 0; intCnt <= htmlOmathNodeList.Count - 1; intCnt++)
                {
                    if (htmlOmathNodeList[intCnt].ParentNode.Name == "m_oMathPara")
                        htmlMathElem.InnerXml = ProcessMath(htmlOmathNodeList[intCnt].OuterXml, true);
                    else
                        htmlMathElem.InnerXml = ProcessMath(htmlOmathNodeList[intCnt].OuterXml);
                    htmlOmathNodeList[intCnt].ParentNode.ReplaceChild(htmlMathElem.Clone(), htmlOmathNodeList[intCnt]);
                }
                this.plainHtmlContent = this.plainHtmlNode.OuterXml;
            }
            catch (Exception ex)
            {
            }
        }

        private string ProcessMath(string strXml, bool isDisplay = false)
        {
            try
            {
            XmlDocument doc = new XmlDocument();
            int intCnt;
            XmlNodeList ndl;
            string sTmp;
            XmlElement ele;
            string oChr;
            string eChr;
           
                strXml = RemoveEmptyScript(strXml);
                doc.PreserveWhitespace = true; doc.LoadXml(strXml);
                ndl = doc.SelectNodes("//m_r");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    XmlNode ndlNodeList = ndl[intCnt];
                    ProcessMathRow(ref ndlNodeList, ref doc);
                }
                    //ReplaceElement(ref doc, "//m_r", "mrow");
                // this block is for doing math for brackets
                ndl = doc.SelectNodes("//m_d");
                ele = doc.CreateElement("mo");
                ele.InnerXml = "#pipe;";
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].SelectNodes("./m_e").Count > 1)
                    {
                        XmlNodeList ndl1 = ndl[intCnt].SelectNodes("./m_e");
                        for (var intCntcount = 0; intCntcount <= ndl1.Count - 2; intCntcount++)
                            ndl1[intCntcount].ParentNode.InsertAfter(ele.Clone(), ndl1[intCntcount]);
                    }
                }
                ndl = doc.SelectNodes("//m_d");
                ele = doc.CreateElement("mrow");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    oChr = "(";
                    eChr = ")";
                    if (ndl[intCnt].SelectSingleNode("./m_dPr/m_begChr") != null&&ndl[intCnt].SelectSingleNode("./m_dPr/m_endChr") != null)
                    {
                        oChr = ndl[intCnt].SelectSingleNode("./m_dPr/m_begChr").Attributes.GetNamedItem("m_val").Value;
                        eChr = ndl[intCnt].SelectSingleNode("./m_dPr/m_endChr").Attributes.GetNamedItem("m_val").Value;
                    }
                    if (ndl[intCnt].InnerXml.IndexOf("</m_d>", 0) >= 0)
                        ndl[intCnt].InnerXml = ParansInsert(ndl[intCnt].InnerXml);
                    if (oChr != ""&&eChr != "")
                        ele.InnerXml = "<mfenced open=\"" + oChr + "\" close=\"" + eChr + "\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr != ""&&eChr == "")
                        ele.InnerXml = "<mfenced open=\"" + oChr + "\" close=\"\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr == ""&&eChr != "")
                        ele.InnerXml = "<mfenced open=\"\" close=\"" + eChr + "\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr == ""&&eChr == "")
                        ele.InnerXml = ndl[intCnt].InnerXml;
                    if (oChr != ""&&eChr != "")
                        ele.InnerXml = "<mo stretchy=\"true\">" + oChr + "</mo>" + ndl[intCnt].InnerXml + "<mo stretchy=\"true\">" + eChr + "</mo>";
                     else if (oChr != ""&&eChr == "")
                        ele.InnerXml = "<mo stretchy=\"true\">" + oChr + "</mo>" + ndl[intCnt].InnerXml;
                     else if (oChr == ""&&eChr != "")
                        ele.InnerXml = ndl[intCnt].InnerXml + "<mo stretchy=\"true\">" + eChr + "</mo>";
                     else if (oChr == ""&&eChr == "")
                        ele.InnerXml = ndl[intCnt].InnerXml;
                    ndl[intCnt].ParentNode.InsertBefore(ele.Clone(), ndl[intCnt]);
                    ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                }
               // this block is doing for the munder and mover elements

               ndl = doc.SelectNodes("//m_nary/m_naryPr");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_chr") != null)
                        oChr = ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value;
                    else
                        oChr = "#amp;#x0222B;";
                    if (ndl[intCnt].SelectSingleNode("./m_limLoc") != null)
                    {
                        if (ndl[intCnt].SelectSingleNode("./m_limLoc").Attributes.GetNamedItem("m_val").Value == "subSup")
                        {
                            if (ndl[intCnt].ParentNode.SelectSingleNode("./m_sub") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sub").InnerText.Trim() != ""&&ndl[intCnt].ParentNode.SelectSingleNode("./m_sup") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sup").InnerText.Trim() != "")
                                ele = doc.CreateElement("msubsup");
                            else if (ndl[intCnt].ParentNode.SelectSingleNode("./m_sub") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sub").InnerText.Trim() != "")
                                ele = doc.CreateElement("msub"); // coded limits as both and text provided as subscript finial element msubsup changed to msub
                            else if (ndl[intCnt].ParentNode.SelectSingleNode("./m_sup") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sup").InnerText.Trim() != "")
                                ele = doc.CreateElement("msup"); // coded limits as both and text provided as superscript finial element msubsup changed to msup
                            else
                                ele = doc.CreateElement("msubsup");
                        }
                        else if (ndl[intCnt].SelectSingleNode("./m_limLoc").Attributes.GetNamedItem("m_val").Value == "undOvr")
                        {
                            System.Xml.XmlNode tnd;
                            tnd = ndl[intCnt].ParentNode;
                            if (ndl[intCnt].SelectSingleNode("./m_supHide") != null&&ndl[intCnt].SelectSingleNode("./m_subHide") != null)
                                ele = doc.CreateElement("mrow");
                            else if ((tnd.SelectSingleNode("./m_sup") != null && tnd.SelectSingleNode("./m_sup").InnerText.Trim() != "")&&(tnd.SelectSingleNode("./m_sub") != null && tnd.SelectSingleNode("./m_sub").InnerText.Trim() != ""))
                                ele = doc.CreateElement("munderover");
                            else if ((tnd.SelectSingleNode("./m_sup") != null && tnd.SelectSingleNode("./m_sup").InnerText.Trim() != "")&&(tnd.SelectSingleNode("./m_sub") != null && tnd.SelectSingleNode("./m_sub").InnerText.Trim() == ""))
                                ele = doc.CreateElement("mover");
                            else if ((tnd.SelectSingleNode("./m_sup") != null && tnd.SelectSingleNode("./m_sup").InnerText.Trim() == "")&&(tnd.SelectSingleNode("./m_sub") != null && tnd.SelectSingleNode("./m_sub").InnerText.Trim() != ""))
                                ele = doc.CreateElement("munder");
                            else if (ndl[intCnt].SelectSingleNode("./m_supHide") != null|| (ndl[intCnt].ParentNode.SelectSingleNode("./m_sup") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sup").InnerText.Trim() != ""))
                                ele = doc.CreateElement("munder"); // coded limits as both and text provided as under content finial element munderover changed to munder
                            else if (ndl[intCnt].SelectSingleNode("./m_subHide") != null|| (ndl[intCnt].ParentNode.SelectSingleNode("./m_sub") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sub").InnerText.Trim() != ""))
                                ele = doc.CreateElement("mover"); // coded limits as both and text provided as over content finial element munderover changed to mover
                            else
                                ele = doc.CreateElement("munderover");
                        }
                    }
                    else if (isDisplay == true)
                        ele = doc.CreateElement("munderover");
                    else
                        ele = doc.CreateElement("msubsup");
                    if (ndl[intCnt].SelectSingleNode("./m_chr") != null)
                        oChr = Cnfunctions.Hex(Convert.ToString(char.ConvertToUtf32(ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value, 0), 16));
                    ele.InnerXml = "<mo>" + oChr + "</mo>";
                    if (ndl[intCnt].ParentNode.SelectSingleNode("./m_sub") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sub").InnerText.Trim() != "")
                        ele.AppendChild(ndl[intCnt].ParentNode.SelectSingleNode("./m_sub"));
                    if (ndl[intCnt].ParentNode.SelectSingleNode("./m_sup") != null && ndl[intCnt].ParentNode.SelectSingleNode("./m_sup").InnerText.Trim() != "")
                        ele.AppendChild(ndl[intCnt].ParentNode.SelectSingleNode("./m_sup"));
                    ndl[intCnt].ParentNode.InsertBefore(ele.Clone(), ndl[intCnt]);
                    ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                }
                //this is to apply the multiple mover element
                ndl = doc.SelectNodes("//m_acc//m_acc/m_accPr");
                ele = doc.CreateElement("mover");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    oChr = "";
                    if (ndl[intCnt].SelectSingleNode("./m_chr") != null)
                        oChr = Cnfunctions.Hex(Convert.ToString(char.ConvertToUtf32(ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value, 0), 16));
                    else
                        oChr = "#amp;#x002C6;";
                    ele.Attributes.Append(doc.CreateAttribute("accent"));
                    ele.Attributes.GetNamedItem("accent").Value = "true";
                    ele.InnerXml = ndl[intCnt].ParentNode.InnerXml + "<mo>" + oChr + "</mo>";
                    ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                    ndl[intCnt].ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode);
                }
               //this is to apply mover with single level
                ndl = doc.SelectNodes("//m_acc/m_accPr");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    ele = doc.CreateElement("mover");
                    oChr = "";
                    if (ndl[intCnt].SelectSingleNode("./m_chr") != null)
                        oChr = Cnfunctions.Hex(Convert.ToString(char.ConvertToUtf32(ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value, 0), 16));
                    else
                        oChr = "#amp;#x002C6;";
                    ele.Attributes.Append(doc.CreateAttribute("accent"));
                    ele.Attributes.GetNamedItem("accent").Value = "true";
                    ele.InnerXml = ndl[intCnt].ParentNode.InnerXml + "<mo>" + oChr + "</mo>";
                    ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                    ndl[intCnt].ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode);
                }
               // this is to handle the bar characters
               ndl = doc.SelectNodes("//m_bar/m_barPr");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_pos") != null)
                    {
                        if (ndl[intCnt].SelectSingleNode("./m_pos").Attributes.GetNamedItem("m_val").Value.ToLower() == "top")
                        {
                            ele = doc.CreateElement("mover");
                            ele.Attributes.Append(doc.CreateAttribute("accent"));
                            ele.Attributes.GetNamedItem("accent").Value = "true";
                        }
                        else
                        {
                            ele = doc.CreateElement("munder");
                            ele.Attributes.Append(doc.CreateAttribute("accentunder"));
                            ele.Attributes.GetNamedItem("accentunder").Value = "true";
                        }
                    }
                    else
                    {
                        ele = doc.CreateElement("munder");
                        ele.Attributes.Append(doc.CreateAttribute("accentunder"));
                        ele.Attributes.GetNamedItem("accentunder").Value = "true";
                    }
                    oChr = "#amp;#x000AF;";
                    ele.InnerXml = ndl[intCnt].ParentNode.InnerXml + "<mo>" + oChr + "</mo>";
                    ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                    ndl[intCnt].ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode);
                }
                //this is to used for grouping characters for box grouping

                ndl = doc.SelectNodes("//m_e/m_groupChr/m_groupChrPr");

               ndl = doc.SelectNodes("//m_box/m_e/m_groupChr/m_groupChrPr|//m_limLow/m_e/m_groupChr/m_groupChrPr");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_pos|./m_vertJc").Attributes.GetNamedItem("m_val").Value.ToLower() == "top")
                        ele = doc.CreateElement("munder");
                    else
                        ele = doc.CreateElement("mover");
                    ele.Attributes.Append(doc.CreateAttribute("accent"));
                    ele.Attributes.GetNamedItem("accent").Value = "true";
                    oChr = ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value;
                    ele.InnerXml = "<mo>" + oChr + "</mo>" + ndl[intCnt].ParentNode.InnerXml;
                    ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                    ndl[intCnt].ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode);
                }
                ndl = doc.SelectNodes("//m_groupChr/m_groupChrPr");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_pos|./m_vertJc").Attributes.GetNamedItem("m_val").Value.ToLower() == "top")
                        ele = doc.CreateElement("mover");
                    else
                        ele = doc.CreateElement("munder");
                    ele.Attributes.Append(doc.CreateAttribute("accent"));
                    ele.Attributes.GetNamedItem("accent").Value = "true";
                    oChr = ndl[intCnt].SelectSingleNode("./m_chr").Attributes.GetNamedItem("m_val").Value;
                    ele.InnerXml = ndl[intCnt].ParentNode.InnerXml + "<mo stretchy=\"true\">" + oChr + "</mo>";
                    ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                    ndl[intCnt].ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode);
                }
                if (doc.SelectSingleNode("//m_sPre") != null)
                {
                    ndl = doc.SelectNodes("//m_sPre[count(./m_e/m_sSup|./m_e/m_sSub|./m_e/m_sSubSup)>0]");
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        if (ndl[intCnt].ParentNode != null)
                        {
                            ele = doc.CreateElement("mmultiscripts");
                            if (ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup") != null)
                            {
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_e"));
                                if (ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sub") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sub").InnerText != "")
                                    ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sub"));
                                else
                                    ele.AppendChild(doc.CreateElement("none"));
                                if (ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sup") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sup").InnerText != "")
                                    ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSubSup/m_sup"));
                                else
                                    ele.AppendChild(doc.CreateElement("none"));
                            }
                            else if (ndl[intCnt].SelectSingleNode("./m_e/m_sSup") != null)
                            {
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSup/m_e"));
                                ele.AppendChild(doc.CreateElement("none"));
                                if (ndl[intCnt].SelectSingleNode("./m_e/m_sSup/m_sup") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sSup/m_sup").InnerText != "")
                                    ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSup/m_sup"));
                                else
                                    ele.AppendChild(doc.CreateElement("none"));
                            }
                            else if (ndl[intCnt].SelectSingleNode("./m_e/m_sSub") != null)
                            {
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSub/m_e"));
                                if (ndl[intCnt].SelectSingleNode("./m_e/m_sSub/m_sub") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sSub/m_sub").InnerText != "")
                                    ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sSub/m_sub"));
                                else
                                    ele.AppendChild(doc.CreateElement("none"));
                                ele.AppendChild(doc.CreateElement("none"));
                            }
                            if (ndl[intCnt].SelectSingleNode("./m_e") != null) {
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e"));
                            }
                            ele.AppendChild(doc.CreateElement("mprescripts"));
                            if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText != "")
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sub"));
                            else
                                ele.AppendChild(doc.CreateElement("none"));
                            if (ndl[intCnt].SelectSingleNode("./m_sup") != null && ndl[intCnt].SelectSingleNode("./m_sup").InnerText != "")
                                ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sup"));
                            else
                                ele.AppendChild(doc.CreateElement("none"));
                            ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                        }
                    }
                }
                //multiscript coded first post scripts than pre scripts
                ndl = doc.SelectNodes("//m_sSubSup[count(./m_e/m_sPre)>0]|//m_sSub[count(./m_e/m_sPre)>0]|//m_sSup[count(./m_e/m_sPre)>0]");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].ParentNode != null)
                    {
                        ele = doc.CreateElement("mmultiscripts");
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_e"));
                        if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != "")
                            ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sub"));
                        else
                            ele.AppendChild(doc.CreateElement("none"));
                        if (ndl[intCnt].SelectSingleNode("./m_sup") != null && ndl[intCnt].SelectSingleNode("./m_sup").InnerText.Trim() != "")
                            ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sup"));
                        else
                            ele.AppendChild(doc.CreateElement("none"));
                        ele.AppendChild(doc.CreateElement("mprescripts"));
                        if (ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sub") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sub").InnerText.Trim() != "")
                            ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sub"));
                        else
                            ele.AppendChild(doc.CreateElement("none"));
                        if (ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sup") != null && ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sup").InnerText.Trim() != "")
                            ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e/m_sPre/m_sup"));
                        else
                            ele.AppendChild(doc.CreateElement("none"));
                    }
                    ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                }
                //this section decide the subsup element has all parameters or sup or sub is missed it manage respective element
               ndl = doc.SelectNodes("//m_sSubSup");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != ""&&ndl[intCnt].SelectSingleNode("./m_sup") != null && ndl[intCnt].SelectSingleNode("./m_sup").InnerText.Trim() != "")
                        ele = doc.CreateElement("msubsup");
                    else if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != "")
                        ele = doc.CreateElement("msub");
                    else if (ndl[intCnt].SelectSingleNode("./m_sup") != null && ndl[intCnt].SelectSingleNode("./m_sup").InnerText.Trim() != "")
                        ele = doc.CreateElement("msup");
                    else
                        ele = doc.CreateElement("msubsup");
                    if (ndl[intCnt].SelectSingleNode("./m_e") != null)
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e"));
                    if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != "")
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sub"));
                    if (ndl[intCnt].SelectSingleNode("./m_sup") != null && ndl[intCnt].SelectSingleNode("./m_sup").InnerText.Trim() != "")
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sup"));
                    ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                }
                ndl = doc.SelectNodes("//m_f/m_fPr/m_type");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        if (ndl[intCnt].Attributes.GetNamedItem("m_val").Value.ToLower() == "nobar")
                        {
                            sTmp = ndl[intCnt].ParentNode.ParentNode.InnerXml;
                            sTmp = sTmp.Insert(sTmp.IndexOf("<m_den>", 0), "<mo>/</mo>");
                            ele = doc.CreateElement("mfrac");
                            ele.InnerXml = sTmp;
                            ele.Attributes.Append(doc.CreateAttribute("linethickness"));
                            ele.Attributes["linethickness"].Value = "0";
                            ndl[intCnt].ParentNode.ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode.ParentNode);
                            ndl[intCnt].ParentNode.ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode.ParentNode);
                        }
                        else
                        {
                            sTmp = ndl[intCnt].ParentNode.ParentNode.InnerXml;
                            sTmp = sTmp.Insert(sTmp.IndexOf("<m_den>", 0), "<mo>/</mo>");
                            ele = doc.CreateElement("mrow");
                            ele.InnerXml = sTmp;
                            ndl[intCnt].ParentNode.ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode.ParentNode);
                            ndl[intCnt].ParentNode.ParentNode.ParentNode.RemoveChild(ndl[intCnt].ParentNode.ParentNode);
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
               // msqrt and mroot generation
                ndl = doc.SelectNodes("//m_rad");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    try
                    {
                        if (ndl[intCnt].SelectSingleNode("./m_deg") != null && ndl[intCnt].SelectSingleNode("./m_deg").InnerText != "")
                        {
                            ele = doc.CreateElement("mroot");
                            if (Regex.IsMatch(ndl[intCnt].SelectSingleNode("./m_deg").InnerText, "[0-9]+") == true)
                                ele.InnerXml = ndl[intCnt].InnerXml + "<mn>" + ndl[intCnt].SelectSingleNode("./m_deg").InnerText + "</mn>";
                            else
                                ele.InnerXml = ndl[intCnt].InnerXml + "<mi>" + ndl[intCnt].SelectSingleNode("./m_deg").InnerText + "</mi>";
                        }
                        else
                        {
                            ele = doc.CreateElement("msqrt");
                            ele.InnerXml = ndl[intCnt].InnerXml;
                        }
                        ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                ndl = doc.SelectNodes("//m_box");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    try
                    {
                        if (ndl[intCnt].SelectSingleNode("./m_e/m_argPr/m_argSz") != null && ndl[intCnt].SelectSingleNode("./m_e/m_argPr/m_argSz[@m_val='-1']") != null)
                        {
                            ele = doc.CreateElement("mstyle");
                            ele.Attributes.Append(doc.CreateAttribute("displaystyle"));
                            ele.Attributes.GetNamedItem("displaystyle").Value = "false";
                            ele.InnerXml = ndl[intCnt].InnerXml;
                        }
                        else
                        {
                            ele = doc.CreateElement("mrow");
                            ele.InnerXml = ndl[intCnt].InnerXml;
                        }
                        ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                ndl = doc.SelectNodes("//m_sSub");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != "")
                        ele = doc.CreateElement("msub");
                    else
                        ele = doc.CreateElement("mrow");
                    if (ndl[intCnt].SelectSingleNode("./m_e") != null)
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_e"));
                    if (ndl[intCnt].SelectSingleNode("./m_sub") != null && ndl[intCnt].SelectSingleNode("./m_sub").InnerText.Trim() != "")
                        ele.AppendChild(ndl[intCnt].SelectSingleNode("./m_sub"));
                    ndl[intCnt].ParentNode.ReplaceChild(ele.Clone(), ndl[intCnt]);
                }


                //renaming the element from wordml to mathml

                foreach (var item in customConstant.jsonData.mathReplaceElement)
                {

                    ReplaceElement(ref doc,item.findElem.ToString(), item.replaceElem.ToString());
                }
      
                // remove the unwanted tags
                ndl = doc.SelectNodes("//m_argPr|//m_boxPr|//m_groupChrPr|//w-proofErr|//m_sPrePr|//m_barPr|//w-rPr|//m_dPr|//m_rPr|//m_fPr|//w-bookmarkStart|//w-bookmarkEnd|//m_radPr|//m_deg|//m_mPr|//m_ctrlPr|//m_funcPr|//m_limLowPr|//m_eqArrPr|//m_sSubPr|//m_naryPr|//m_sSupPr|//m_accPr|//m_sSubSupPr");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                strXml = doc.OuterXml;
                doc.PreserveWhitespace = true; doc.LoadXml(strXml);
               // to remove the additional mrows within mrows
               ndl = doc.SelectNodes("//mrow");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt] != null)
                    {
                        if (ndl[intCnt].HasChildNodes == true)
                        {
                            if (ndl[intCnt].FirstChild.Name == "mrow"&&ndl[intCnt].FirstChild.OuterXml == ndl[intCnt].InnerXml)
                                ndl[intCnt].InnerXml = ndl[intCnt].FirstChild.InnerXml;
                        }
                        else if (ndl[intCnt].InnerXml == ""&&ndl[intCnt].ParentNode.Name != "munderover"&&ndl[intCnt].ParentNode.Name != "msubsup"&&ndl[intCnt].ParentNode.Name != "mmultiscripts")
                            ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                        else if (ndl[intCnt].InnerXml == ""&&ndl[intCnt].ParentNode.Name != "mmultiscripts")
                            ndl[intCnt].ParentNode.ReplaceChild(doc.CreateElement("none"), ndl[intCnt]);
                    }
                }
                strXml = doc.OuterXml;
                doc.PreserveWhitespace = true; doc.LoadXml(strXml);
                strXml = doc.SelectSingleNode("//m_oMath").InnerXml;
                strXml = Regex.Replace(strXml, "</?(m_e|m_func|m_fName|m_nary|m_sPre|m_r)>", "");
                strXml = Regex.Replace(strXml, @"<(m_e|m_func|m_fName)\s+[^<>]+>", "");
                strXml = strXml.Replace("&gt;", "<mo>#amp;#x0003E;</mo>");
                strXml = Regex.Replace(strXml, "<mi( mathvariant=\"([^<>]+)\")?>'</mi>", "<mo$1>#amp;#x00027;</mo>");
                strXml = Regex.Replace(strXml, @"</mn>(</mrow><mrow>)?<mo>([\.,])</mo>(</mrow><mrow>)?<mn( mathvariant=""([^<>]+)"")?>", "$2");
                strXml = Regex.Replace(strXml, @"<mi( mathvariant=""([^<>]+)"")?>\s+</mi>", "<mi$1>#amp;#x000A0;</mi>");
                strXml = CleanOMath(strXml); // </mn></mrow><mrow><mo>.</mo></mrow><mrow><mn
                strXml = Regex.Replace(strXml, " ((</[^<>]+>)*)$", "$1 ");
                strXml = Regex.Replace(strXml, "^((<[^<>]+>)*) ", " $1");
                strXml = Regex.Replace(strXml, @"(\s*)(</mrow><mrow><mtext>)([^<>]+)(</mtext></mrow><mrow>)(\s*)", "<mtext>$1$3$5</mtext>");
                strXml = strXml.Replace("#amp;gt;", ">").Replace("#amp;lt;", "<");
                strXml = Regex.Replace(strXml, "(</?math[^<>]*>)", "");
            }
            catch (Exception ex)
            {
            }
            return strXml;
        }


        private bool ProcessMathRow(ref XmlNode nd, ref XmlDocument doc)
        {
            int intCnt;
            string tmp = "";
            bool isSym = false;
            bool isScript = false;
            bool brk = false;
            bool algn = false;
            bool bld = false;
            bool it = false;
            string rCol = "";
            string mat = "";
            XmlElement ele = null/* TODO Change to default(_) if this is not a reference type */;
            XmlAttribute att = null/* TODO Change to default(_) if this is not a reference type */;
            try
            {
                for (intCnt = 0; intCnt <= nd.ChildNodes.Count - 1; intCnt++)
                {
                    switch ((nd.ChildNodes[intCnt].Name))
                    {
                        case "m_rPr":
                            {
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./m_sty") != null)
                                {
                                    att = doc.CreateAttribute("mathvariant");
                                    if (nd.ChildNodes[intCnt].SelectSingleNode("./m_sty").Attributes.GetNamedItem("m_val").Value == "bi")
                                        att.Value = "bold-italic";
                                    else if (nd.ChildNodes[intCnt].SelectSingleNode("./m_sty").Attributes.GetNamedItem("m_val").Value == "b")
                                        att.Value = "bold";
                                    else if (nd.ChildNodes[intCnt].SelectSingleNode("./m_sty").Attributes.GetNamedItem("m_val").Value == "p")
                                        att.Value = "normal";
                                }
                                else if (nd.ChildNodes[intCnt].SelectSingleNode("./m_nor") != null)
                                    ele = doc.CreateElement("mtext");
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./m_scr") != null)
                                {
                                    if (att == null)
                                        att = doc.CreateAttribute("mathvariant");
                                    isScript = true;
                                    if (att.Value == "bold")
                                        att.Value = "bold-" + nd.ChildNodes[intCnt].SelectSingleNode("./m_scr").Attributes.GetNamedItem("m_val").Value;
                                    else
                                        att.Value = nd.ChildNodes[intCnt].SelectSingleNode("./m_scr").Attributes.GetNamedItem("m_val").Value;
                                    if (nd.ChildNodes[intCnt].NextSibling.SelectSingleNode("./w-rFonts[@w-cs='Arial Unicode MS']") != null)
                                        att.Value = att.Value + "[MJX-tex-caligraphic]";
                                }
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./m_brk") != null)
                                    brk = true;
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./m_aln") != null)
                                    // tmp = tmp&&"<!--Align-->"
                                    algn = true;
                                break;
                            }

                        case "w-rPr":
                            {
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./w-i") != null)
                                    it = true;
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./w-b") != null)
                                    bld = true;
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./w-color[@w-val]") != null)
                                    rCol = nd.ChildNodes[intCnt].SelectSingleNode("./w-color[@w-val]").Attributes.GetNamedItem("w-val").Value;
                                if (nd.ChildNodes[intCnt].SelectSingleNode("./w-rStyle") != null)
                                {
                                    if (nd.ChildNodes[intCnt].SelectSingleNode("./w-rStyle").Attributes.GetNamedItem("w-val").Value.ToLower() == "mtconvertedequation")
                                    {
                                        mat = nd.SelectSingleNode("./m_t").InnerXml;
                                        // mat = mat.Replace("#amp;lt;", "<").Replace("#amp;gt;", ">")
                                        nd.InnerXml = mat;
                                        return true;
                                    }
                                }
                                break;
                            }

                        case "m_t":
                            {
                                if (nd.ChildNodes[intCnt].InnerXml == " ")
                                    tmp = tmp + "<mspace width=\"1em\"/>";
                                else
                                    tmp = tmp + nd.ChildNodes[intCnt].InnerXml;
                                break;
                            }

                        case "w-sym":
                            {
                                tmp = tmp + Cnfunctions.GetEntity(this.hsEntity,nd.ChildNodes[intCnt].Attributes.GetNamedItem("w-font").Value, nd.ChildNodes[intCnt].Attributes.GetNamedItem("w-char").Value);
                                isSym = true;
                                break;
                            }
                    }
                }
                if (tmp.Trim() != "")
                {
                    if (att == null)
                    {
                        if (it == true&&bld == true)
                        {
                            att = doc.CreateAttribute("mathvariant");
                            att.Value = "bold-italic";
                            ele = null/* TODO Change to default(_) if this is not a reference type */;
                        }
                        else if (bld == true)
                        {
                            att = doc.CreateAttribute("mathvariant");
                            att.Value = "bold";
                            ele = null/* TODO Change to default(_) if this is not a reference type */;
                        }
                        else if (it == true)
                            ele = null/* TODO Change to default(_) if this is not a reference type */;
                    }
                    else if (it == true&&(bld == true|| att.Value == "bold"))
                    {
                        att.Value = "bold-italic";
                        ele = null/* TODO Change to default(_) if this is not a reference type */;
                    }
                    else if (bld == true)
                    {
                        att = doc.CreateAttribute("mathvariant");
                        att.Value = "bold";
                        ele = null/* TODO Change to default(_) if this is not a reference type */;
                    }
                    else if (it == true)
                        ele = null/* TODO Change to default(_) if this is not a reference type */;
                    if (ele == null)
                        ele = doc.CreateElement("mi");
                    // If Regex.IsMatch(tmp, "#amp;lt;mmEquation id=""eqn[0-9]+"" /#amp;gt;", RegexOptions.IgnoreCase) = False Then
                    if (isSym == false)
                    {
                        tmp = GetMathText(tmp, ele.Name);
                        tmp = tmp.Replace("<mspace width<mo>=</mo>\"<mn>1</mn>em\"<mo>/</mo>>", "<mspace width=\"1em\"/>");
                        tmp = tmp.Replace("<mspace width=\"<mn>1</mn>em\"/>", "<mspace width=\"1em\"/>");
                    }
                    if (tmp.Length > 1)
                    {
                        for (intCnt = 0; intCnt <= mathOperator.Length - 1; intCnt++)
                            tmp = tmp.Replace(mathOperator[intCnt], "<mo>" + mathOperator[intCnt] + "</mo>");
                    }
                    // End If
                    ele.InnerXml = tmp;
                    if (att != null&&ele.Name == "mi")
                        ele.Attributes.Append(att);
                    // If ele.Name = "mtext" Then
                    // ele.InnerXml = ele.InnerText
                    // End If
                    ele.InnerXml = ele.InnerXml.Replace("<mo>-</mo>", "<mo>#amp;#x02212;</mo>");
                    nd.InnerXml = ele.OuterXml;
                    for (intCnt = 0; intCnt <= nd.FirstChild.ChildNodes.Count - 1; intCnt++)
                    {
                        if (nd.FirstChild.ChildNodes[intCnt].Name != "mo"&&nd.FirstChild.ChildNodes[intCnt].Name != "mn"&&(nd.FirstChild.ChildNodes[intCnt].NodeType == XmlNodeType.Text|| nd.FirstChild.ChildNodes[intCnt].NodeType == XmlNodeType.Whitespace))
                        {
                            ele.InnerXml = nd.FirstChild.ChildNodes[intCnt].InnerText;
                            nd.FirstChild.ReplaceChild(ele.Clone(), nd.FirstChild.ChildNodes[intCnt]);
                        }
                        else if (ele.Attributes.Count == 1&&att != null&&nd.FirstChild.ChildNodes[intCnt].Name != "mspace")
                            nd.FirstChild.ChildNodes[intCnt].Attributes.Append(att);
                            //nd.FirstChild.ChildNodes[intCnt].Attributes.Append(att.Clone());
                    }
                    tmp = nd.FirstChild.InnerXml;
                    // update script characters
                    if (isScript == true)
                        tmp = ScriptCharactes(tmp);
                    else
                        // to insert mi for all entities
                        tmp = miEntities(tmp);
                    if (algn == true)
                        tmp = "<!--Align-->" + tmp;
                    if (brk == true)
                        tmp = "<!--break-->" + tmp;
                }
                else
                    tmp = " ";
                tmp = tmp.Replace("<mi> </mi>", " ").Replace("<mi></mi>", "");
                if (rCol != "")
                    tmp = AddColorAttr(tmp, rCol);
                tmp = Regex.Replace(tmp, "<mi[^<>]*> </mi>", "<mspace width=\"1em\"/>");
                if (Regex.IsMatch(tmp, "<mi mathvariant=\"normal\">#macamp;cal[A-Z];</mi>") == true)
                    tmp = Regex.Replace(tmp, "<mi mathvariant=\"normal\">(#macamp;cal[A-Z];)</mi>", "$1");
                nd.InnerXml = tmp;
            }
            catch (Exception ex)
            {
            }
            return true;
        }

        private string CleanOMath(string strXml)
        {
            XmlDocument clDoc = new XmlDocument();
            XmlNodeList ndl;
            int intCnt;
            try
            {
                strXml = Regex.Replace(strXml, @"<mi\s*[^>]*>#amp;#x02591;</mi>", "<mspace width=\".25em\"/>");
                strXml = Regex.Replace(strXml, @"<mi\s*[^>]*>#amp;#x02592;</mi>", "<mspace width=\".5em\"/>");
                strXml = Regex.Replace(strXml, @"<mi\s*[^>]*>#amp;#x02593;</mi>", "<mspace width=\"1em\"/>");
                clDoc.PreserveWhitespace = true; clDoc.LoadXml("<tmp>" + strXml + "</tmp>");
                ReplaceElement(ref clDoc, "//m_den", "mrow");
                ndl = clDoc.SelectNodes("//mi[not(@mathvariant)]");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].InnerText.Length > 1)
                    {
                        if (ndl[intCnt].InnerText.IndexOf("#amp;", 0) < 0)
                        {
                            ndl[intCnt].Attributes.Append(clDoc.CreateAttribute("mathvariant"));
                            ndl[intCnt].Attributes.GetNamedItem("mathvariant").Value = "italic";
                        }
                        else if (Regex.Replace(ndl[intCnt].InnerText, "[0-9a-zA-Z]+", "") == "")
                        {
                            ndl[intCnt].Attributes.Append(clDoc.CreateAttribute("mathvariant"));
                            ndl[intCnt].Attributes.GetNamedItem("mathvariant").Value = "italic";
                        }
                    }
                }
                ndl = clDoc.SelectNodes("//mtr");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].SelectNodes("./mtd").Count == 0)
                        ndl[intCnt].InnerXml = "<mtd>" + ndl[intCnt].InnerXml + "</mtd>";
                }
                // ndl = clDoc.SelectNodes("//mi[@mathvariant='normal']|//mo[@mathvariant='normal']|//mn[@mathvariant='normal']")
                ndl = clDoc.SelectNodes("//mo[@mathvariant='normal']|//mn[@mathvariant='normal']");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    if (ndl[intCnt].Name == "mo"|| ndl[intCnt].Name == "mn")
                        ndl[intCnt].Attributes.RemoveNamedItem("mathvariant");
                    else if (ndl[intCnt].Name == "mi"&&ndl[intCnt].InnerText.Length > 1)
                    {
                        if ((ndl[intCnt].InnerText.Length == 13 && (ndl[intCnt].InnerText.Substring(0, 5) == ("#amp;" + ndl[intCnt].InnerText[12] == ";").ToString())))
                        {
                        }
                        else
                            ndl[intCnt].Attributes.RemoveNamedItem("mathvariant");
                    }
                }
                ndl = clDoc.SelectNodes("//mo/mo");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].ParentNode.InnerXml == ndl[intCnt].OuterXml)
                        ndl[intCnt].ParentNode.InnerXml = ndl[intCnt].InnerXml;
                }
                ndl = clDoc.SelectNodes("//msub[name(preceding-sibling::*[1])='mrow']");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].PreviousSibling != null && ndl[intCnt].FirstChild.Name == "mrow" && ndl[intCnt].FirstChild.FirstChild.Name == "mo" && ndl[intCnt].FirstChild.FirstChild.InnerText == ")")
                    {
                        if (ndl[intCnt].PreviousSibling.Name == "mrow" && ndl[intCnt].PreviousSibling.FirstChild.Name == "mo" && ndl[intCnt].PreviousSibling.FirstChild.InnerText == "(")
                        {
                            ndl[intCnt].FirstChild.InnerXml = ndl[intCnt].PreviousSibling.InnerXml + ndl[intCnt].FirstChild.InnerXml;
                            ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt].PreviousSibling);
                        }
                    }
                    else if (ndl[intCnt].PreviousSibling != null && ndl[intCnt].FirstChild.Name == "mrow" && ndl[intCnt].FirstChild.FirstChild.Name == "mo" && ndl[intCnt].FirstChild.FirstChild.InnerText == "]")
                    {
                        if (ndl[intCnt].PreviousSibling.Name == "mrow" && ndl[intCnt].PreviousSibling.FirstChild.Name == "mo" && ndl[intCnt].PreviousSibling.FirstChild.InnerText == "[")
                        {
                            ndl[intCnt].FirstChild.InnerXml = ndl[intCnt].PreviousSibling.InnerXml + ndl[intCnt].FirstChild.InnerXml;
                            ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt].PreviousSibling);
                        }
                    }
                    else if (ndl[intCnt].PreviousSibling != null && ndl[intCnt].FirstChild.Name == "mrow" && ndl[intCnt].FirstChild.FirstChild.Name == "mo" && ndl[intCnt].FirstChild.FirstChild.InnerText == "}")
                    {
                        if (ndl[intCnt].PreviousSibling.Name == "mrow" && ndl[intCnt].PreviousSibling.FirstChild.Name == "mo" && ndl[intCnt].PreviousSibling.FirstChild.InnerText == "{")
                        {
                            ndl[intCnt].FirstChild.InnerXml = ndl[intCnt].PreviousSibling.InnerXml + ndl[intCnt].FirstChild.InnerXml;
                            ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt].PreviousSibling);
                        }
                    }
                }
                ndl = clDoc.SelectNodes("//msup");
                for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                {
                    if (ndl[intCnt].FirstChild.InnerText == ")")
                    {
                        while ((ndl[intCnt].PreviousSibling != null))
                        {
                            if (ndl[intCnt].PreviousSibling.InnerText != "(")
                            {
                                if (ndl[intCnt].FirstChild.Name != "mrow")
                                {
                                    ndl[intCnt].InsertBefore(clDoc.CreateElement("mrow"), ndl[intCnt].FirstChild);
                                    ndl[intCnt].FirstChild.AppendChild(ndl[intCnt].FirstChild.NextSibling);
                                }
                                ndl[intCnt].FirstChild.PrependChild(ndl[intCnt].PreviousSibling);
                            }
                            else
                            {
                                ndl[intCnt].FirstChild.PrependChild(ndl[intCnt].PreviousSibling);
                                break;
                            }
                        }
                    }
                    else if (ndl[intCnt].FirstChild.InnerText == "]")
                    {
                        while ((ndl[intCnt].PreviousSibling != null))
                        {
                            if (ndl[intCnt].PreviousSibling.InnerText != "[")
                            {
                                if (ndl[intCnt].FirstChild.Name != "mrow")
                                {
                                    ndl[intCnt].InsertBefore(clDoc.CreateElement("mrow"), ndl[intCnt].FirstChild);
                                    ndl[intCnt].FirstChild.AppendChild(ndl[intCnt].FirstChild.NextSibling);
                                }
                                ndl[intCnt].FirstChild.PrependChild(ndl[intCnt].PreviousSibling);
                            }
                            else
                            {
                                ndl[intCnt].FirstChild.PrependChild(ndl[intCnt].PreviousSibling);
                                break;
                            }
                        }
                    }
                }
                strXml = clDoc.SelectSingleNode("//tmp").InnerXml;
                // strXml = Regex.Replace(strXml, "<mrow>([\s]+)</mrow>", "$1")
                strXml = Regex.Replace(strXml, @"(<mi mathvariant=""([^"">]+)"">[^<>]+)</mi></mrow><mrow>([\s]+)</mrow><mrow><mi mathvariant=""\2"">", "$1$3");
                strXml = Regex.Replace(strXml, @"(<mi mathvariant=""([^"">]+)"">[^<>]+)</mi></mrow><mrow>([\s]+)</mrow><mrow><mi mathvariant=""\2"">", "$1$3");
            }
            catch (Exception ex)
            {
            }
            return strXml;
        }


        private string ScriptCharactes(string tmp)
        {
            XmlDocument sDoc = new XmlDocument();
            int intCnt;
            XmlNodeList ndl;
            MatchCollection pMatch;
            string tStr = "";
            string att;
            XmlElement ele;
            int intCnt1;
            XmlElement ele1;
            try
            {
                sDoc.PreserveWhitespace = true; sDoc.LoadXml("<temp>" + tmp + "</temp>");
                ndl = sDoc.SelectNodes("//mi[@mathvariant='script']/text()|//mi[@mathvariant='fraktur']/text()|//mi[@mathvariant='double-struck']/text()");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    tStr = ndl[intCnt].Value;
                    att = ndl[intCnt].ParentNode.Attributes.GetNamedItem("mathvariant").Value;
                    tStr = Regex.Replace(tStr, "(#amp;#x[0-9a-zA-Z]+;)", "<mi mathvariant=\"" + att + "\">$1</mi>");
                    ndl[intCnt].ParentNode.InnerXml = tStr;
                }
                ndl = sDoc.SelectNodes("temp/mi[@mathvariant='script']/text()|temp/mi[@mathvariant='fraktur']/text()|temp/mi[@mathvariant='double-struck']/text()");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    tStr = ndl[intCnt].Value;
                    att = ndl[intCnt].ParentNode.Attributes.GetNamedItem("mathvariant").Value;
                    ele = sDoc.CreateElement("mi");
                    ele1 = sDoc.CreateElement("mi");
                    ele.Attributes.Append(sDoc.CreateAttribute("mathvariant"));
                    ele.Attributes.GetNamedItem("mathvariant").Value = att;
                    pMatch = Regex.Matches(tStr, "([a-zA-Z])");
                    for (intCnt1 = pMatch.Count - 1; intCnt1 >= 0; intCnt1 += -1)
                    {
                        tStr = getScriptChar(pMatch[intCnt1].Value, att);
                        if (tStr == pMatch[intCnt1].Value)
                        {
                            ele.InnerXml = pMatch[intCnt1].Value;
                            ndl[intCnt].ParentNode.InsertAfter(ele.Clone(), ndl[intCnt]);
                        }
                        else
                        {
                            ele1.InnerXml = tStr;
                            ndl[intCnt].ParentNode.InsertAfter(ele1.Clone(), ndl[intCnt]);
                        }
                    }
                    ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                }
                ndl = sDoc.SelectNodes("//mi[@mathvariant]/mi");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        if (ndl[intCnt].ParentNode.ChildNodes.Count == 1)
                            ndl[intCnt].ParentNode.ParentNode.ReplaceChild(ndl[intCnt], ndl[intCnt].ParentNode);
                        else if (ndl[intCnt].ParentNode.ChildNodes.Count > 1)
                            ndl[intCnt].ParentNode.ParentNode.InsertBefore(ndl[intCnt], ndl[intCnt].ParentNode);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                tmp = sDoc.SelectSingleNode("//temp").InnerXml;
            }
            catch (Exception ex)
            {
            }
            return tmp;
        }






        private string ParansInsert(string strTxt)
        {
            XmlDocument doc = new XmlDocument();
            XmlElement ele;
            string oChr;
            string eChr;
            XmlNodeList ndl;
            int intCnt;

            try
            {
                doc.PreserveWhitespace = true; doc.LoadXml("<temp>" + strTxt + "</temp>");
                ndl = doc.SelectNodes("//m_d");
                ele = doc.CreateElement("mrow");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    oChr = "(";
                    eChr = ")";
                    if (ndl[intCnt].SelectSingleNode("./m_dPr/m_begChr") != null&&ndl[intCnt].SelectSingleNode("./m_dPr/m_endChr") != null)
                    {
                        oChr = ndl[intCnt].SelectSingleNode("./m_dPr/m_begChr").Attributes.GetNamedItem("m_val").Value;
                        eChr = ndl[intCnt].SelectSingleNode("./m_dPr/m_endChr").Attributes.GetNamedItem("m_val").Value;
                    }
                    if (ndl[intCnt].InnerXml.IndexOf("</m_d>", 0) >= 0)
                        ndl[intCnt].InnerXml = ParansInsert(ndl[intCnt].InnerXml);
                    if (oChr != ""&&eChr != "")
                        ele.InnerXml = "<mfenced open=\"" + oChr + "\" close=\"" + eChr + "\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr != ""&&eChr == "")
                        ele.InnerXml = "<mfenced open=\"" + oChr + "\" close=\"\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr == ""&&eChr != "")
                        ele.InnerXml = "<mfenced open=\"\" close=\"" + eChr + "\">" + ndl[intCnt].InnerXml + "</mfenced>";
                    else if (oChr == ""&&eChr == "")
                        ele.InnerXml = ndl[intCnt].InnerXml;
                    ndl[intCnt].ParentNode.InsertBefore(ele.Clone(), ndl[intCnt]);
                    ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                }
                strTxt = doc.OuterXml;
                strTxt = strTxt.Replace("<temp>", "").Replace("</temp>", "");
            }
            catch (Exception ex)
            {
            }
            return strTxt;
        }

        private string miEntities(string tmp)
        {
            XmlDocument sDoc = new XmlDocument();
            int intCnt;
            XmlNodeList ndl;
            string tStr = "";
            string att;
            XmlElement ele;
            try
            {
                sDoc.PreserveWhitespace = true; sDoc.LoadXml("<temp>" + tmp + "</temp>");
                ndl = sDoc.SelectNodes("//mi/text()");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    tStr = ndl[intCnt].Value;
                    if (ndl[intCnt].ParentNode.Attributes.GetNamedItem("mathvariant") != null)
                    {
                        att = ndl[intCnt].ParentNode.Attributes.GetNamedItem("mathvariant").Value;
                        tStr = Regex.Replace(tStr, "(#amp;#x[0-9a-zA-Z]+;)", "<mi mathvariant=\"" + att + "\">$1</mi>");
                    }
                    else
                        tStr = Regex.Replace(tStr, "(#amp;#x[0-9a-zA-Z]+;)", "<mi>$1</mi>");
                    ndl[intCnt].ParentNode.InnerXml = tStr;
                }
                ndl = sDoc.SelectNodes("//mi/mi");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        if (ndl[intCnt].ParentNode.ChildNodes.Count == 1)
                            ndl[intCnt].ParentNode.ParentNode.ReplaceChild(ndl[intCnt], ndl[intCnt].ParentNode);
                        else if (ndl[intCnt].ParentNode.ChildNodes.Count > 1)
                        {
                            if (ndl[intCnt].PreviousSibling != null && ndl[intCnt].PreviousSibling.NodeType != XmlNodeType.Element)
                            {
                                ele = sDoc.CreateElement("mi");
                                ele.InnerXml = ndl[intCnt].PreviousSibling.InnerText;
                                foreach (XmlAttribute att1 in ndl[intCnt].Attributes)
                                {
                                    ele.Attributes.Append(sDoc.CreateAttribute(att1.Name));
                                    ele.Attributes.GetNamedItem(att1.Name).Value = att1.Value;
                                }
                                ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt].PreviousSibling);
                                ndl[intCnt].ParentNode.ParentNode.InsertBefore(ele.Clone(), ndl[intCnt].ParentNode);
                            }
                            ndl[intCnt].ParentNode.ParentNode.InsertBefore(ndl[intCnt], ndl[intCnt].ParentNode);
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
                tmp = sDoc.SelectSingleNode("//temp").InnerXml;
            }
            catch (Exception ex)
            {
            }
            return tmp;
        }





        //small functions

        private string getScriptChar(string chr, string type)
        {
            switch ((type + type))
            {
                case "script":
                    {
                        switch ((chr))
                        {
                            case "B":
                                {
                                    return "#amp;#x0212C;";
                                }

                            case "E":
                                {
                                    return "#amp;#x02130;";
                                }

                            case "F":
                                {
                                    return "#amp;#x02131;";
                                }

                            case "H":
                                {
                                    return "#amp;#x0210B;";
                                }

                            case "I":
                                {
                                    return "#amp;#x02110;";
                                }

                            case "L":
                                {
                                    return "#amp;#x02112;";
                                }

                            case "M":
                                {
                                    return "#amp;#x02133;";
                                }

                            case "R":
                                {
                                    return "#amp;#x0211B;";
                                }

                            case "l":
                                {
                                    return "#amp;#x02113;";
                                }
                        }
                        break;
                    }

                case "fraktur":
                    {
                        switch ((chr))
                        {
                            case "C":
                                {
                                    return "#amp;#x0212D;";
                                }

                            case "H":
                                {
                                    return "#amp;#x0210C;";
                                }

                            case "I":
                                {
                                    return "#amp;#x02111;";
                                }

                            case "R":
                                {
                                    return "#amp;#x0211C;";
                                }

                            case "Z":
                                {
                                    return "#amp;#x02128;";
                                }
                        }
                        break;
                    }

                case "double-struck":
                    {
                        switch ((chr))
                        {
                            case "C":
                                {
                                    return "#amp;#x2102;";
                                }

                            case "H":
                                {
                                    return "#amp;#x0210D;";
                                }

                            case "N":
                                {
                                    return "#amp;#x02115;";
                                }

                            case "P":
                                {
                                    return "#amp;#x02119;";
                                }

                            case "Q":
                                {
                                    return "#amp;#x0211A;";
                                }

                            case "R":
                                {
                                    return "#amp;#x0211D;";
                                }
                        }
                        break;
                    }
            }
            return chr;
        }

        public string GetMathText(string strText, string eleName)
        {
            try
            {
                // Dim fMath As String = "|arcsin|arccos|arctan|sin|sinh|cos|cosh|tan|tanh|cot|coth|cov|csc|deg|det|dim|exp|gcd|glb|hom|inf|int|ker|lg|lim|ln|log|lub|max|mod|min|Pr|Re|sgn|sup|var|"
                MatchCollection pMatch = Regex.Matches(strText, @"[\u0100-\uFFFF]");
                strText = Regex.Replace(strText, @"([:∠∡∢⊾⊿⋕∤∦∶∷∎≁≭≨≩⊀⊁⋠⋡∌⊄⊅⊈⊉⊊⊋⋢⋣⋦⋧⋨⋩⋪⋫⋬⋭⊬⊭⊮⊯√%°∀∁∃∄∇←↑→↓↔⋯⋰⋱~\/\!\.,\(\)\[\]\{\}\+\-÷×±∓∝∕\*∘∙⋅∩∪⊎⊓⊔∧∨=≠≤≥≮≰≯≱≡∼≃≈≅≢≄≉≇∝≪≫∈∋∉⊂⊃⊆⊇≺≻≼≽⊏⊐⊑⊒∥⊥⊢⊣⋈≍∑∫∬∭∮∯∰∱∲∳∏∐⋂⋃⋀⋁⨀⨂⨁⨄⨃∔∸∖⋒⋓⊟⊠⊡⊞⋇⋉⋊⋋⋌⋏⋎⊝⊺⊕⊖⊗⊘⊙⊛⊚†‡⋆⋄≀△⋀⋁⨀⨂⨁⨅⨆⨄⨃∴∵⋘⋙≦≧≲≳⋖⋗≶⋚≷⋛≑≒≓∽≊⋍≼≽⋞⋟≾≿⋜⋝⊆⊇⊲⊳⊴⊵⊨⋐⋑⊏⊐⊩⊪≖≗≜≏≎∝≬⋔≐⋈])", "<mo>$1</mo>");
                strText = Regex.Replace(strText, "([↕⇐⇒⇑⇓⇔⇕⟵⟶⟷⟸⟹⟺↗↖↘↙↚↛↮⇍⇏⇎⇠⇢↤↦⟻⟼↩↪↼↽⇀⇁↿↾⇃⇂⇋⇌⇇⇉⇈⇊⇆⇄↫↬↢↣↰↱↲↳⇚⇛↞↠↶↷↺↻⊸↭↜↝⇜⇝])", "<mo>$1</mo>");
                strText = Regex.Replace(strText, "([0-9]+)", "<mn>$1</mn>");
                strText = Regex.Replace(strText, @"([\*])", "<mo>#amp;#x0002A;</mo>");
                // strText = Regex.Replace(strText, "([\*])", "<mo>#amp;#x0204E;</mo>")
                for (int pos = 0; pos <= pMatch.Count - 1; pos++)
                    strText = strText.Replace(pMatch[pos].Value, Cnfunctions.Hex(Convert.ToString(char.ConvertToUtf32(pMatch[pos].Value, 0), 16)));
                strText = strText.Replace("#amp;lt;", "<mo>#amp;#x0003C;</mo>").Replace("#amp;gt;", "<mo>#amp;#x0003E;</mo>");
                pMatch = Regex.Matches(strText, "[a-z]{2,}");
                for (int pos = pMatch.Count - 1; pos >= 0; pos += -1)
                {
                    if (fMath.IndexOf("|" + pMatch[pos].Value + "|", 0) >= 0)
                    {
                        strText = strText.Remove(pMatch[pos].Index, pMatch[pos].Length);
                        strText = strText.Insert(pMatch[pos].Index, "<mi>" + pMatch[pos].Value + "</mi>");
                    }
                }
                strText = strText.Replace("<<", "<mo>#amp;#x0003C;</mo><");
                if (eleName == "mi")
                    strText = strText.Replace("'", "#amp;#x02032;");
                else if (eleName == "mtext")
                    strText = Regex.Replace(strText, "</?mo>", "");
            }
            catch (Exception ex)
            {
            }
            return strText;
        }
        private string RemoveEmptyScript(string strXml)
        {
            XmlDocument xmlDoc = new XmlDocument();
            int intCnt;
            XmlNodeList m_supNodeList;
            try
            {
                xmlDoc.PreserveWhitespace = true; xmlDoc.LoadXml(strXml);
                m_supNodeList = xmlDoc.SelectNodes("//m_sup/m_e");
                for (intCnt = 0; intCnt <= m_supNodeList.Count - 1; intCnt++)
                {
                    if (m_supNodeList[intCnt].InnerXml == "")
                    {
                        if (m_supNodeList[intCnt].ParentNode.ParentNode.SelectSingleNode("./m_e") != null)
                            m_supNodeList[intCnt].ParentNode.ParentNode.ParentNode.ReplaceChild(m_supNodeList[intCnt].ParentNode.ParentNode.SelectSingleNode("./m_e"), m_supNodeList[intCnt].ParentNode.ParentNode);
                    }
                }
                if (m_supNodeList.Count == 0)
                {
                    m_supNodeList = xmlDoc.SelectNodes("//m_sup");
                    for (intCnt = 0; intCnt <= m_supNodeList.Count - 1; intCnt++)
                    {
                        if (m_supNodeList[intCnt].InnerXml.IndexOf("</m_e>", 0) < 0&&m_supNodeList[intCnt].InnerXml.IndexOf("</m_r>", 0) < 0&&m_supNodeList[intCnt].ParentNode.Name != "m_nary"&&m_supNodeList[intCnt].ParentNode.Name != "m_sSubSup")
                            m_supNodeList[intCnt].ParentNode.ParentNode.ReplaceChild(m_supNodeList[intCnt].ParentNode.SelectSingleNode("./m_e"), m_supNodeList[intCnt].ParentNode);
                    }
                }
                strXml = xmlDoc.OuterXml;
            }
            catch (Exception ex)
            {
            }
            return strXml;
        }
        private bool ReplaceElement(ref XmlDocument xmlDoc, string sFindElement, string sReplaceElement)
        {
            XmlNodeList findElemodeList;
            XmlElement replaceElem;
            int intCnt;
            findElemodeList = xmlDoc.SelectNodes(sFindElement);
            replaceElem = xmlDoc.CreateElement(sReplaceElement);
            for (intCnt = findElemodeList.Count - 1; intCnt >= 0; intCnt += -1)
            {
                replaceElem.InnerXml = findElemodeList[intCnt].InnerXml;
                findElemodeList[intCnt].ParentNode.InsertBefore(replaceElem.Clone(), findElemodeList[intCnt]);
                findElemodeList[intCnt].ParentNode.RemoveChild(findElemodeList[intCnt]);
            }
            return true;
        }
        public string AddColorAttr(string tmp, string rCol)
        {
            XmlDocument cDoc = new XmlDocument();
            try
            {
                cDoc.PreserveWhitespace = true; cDoc.LoadXml("<tmp>" + tmp + "</tmp>");
                XmlNodeList ndl = cDoc.SelectNodes("//tmp/*");
                for (var intCntcount = 0; intCntcount <= ndl.Count - 1; intCntcount++)
                {
                    if ((rCol != "000000"&&rCol != "auto"))
                    {
                        ndl[intCntcount].Attributes.Append(cDoc.CreateAttribute("mathcolor"));
                        ndl[intCntcount].Attributes.GetNamedItem("mathcolor").Value = "#" + rCol;
                    }
                }
                tmp = cDoc.OuterXml.Replace("<tmp>", "").Replace("</tmp>", "");
            }
            catch (Exception ex)
            {
            }
            return tmp;
        }

       

       

       





    }
}
