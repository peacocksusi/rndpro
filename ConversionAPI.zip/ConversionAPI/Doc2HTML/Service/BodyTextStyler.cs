﻿using Doc2HTML.Common;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using Utils.Common;

namespace Doc2HTML.Service
{
    public class BodyTextStyler
    {

        XmlDocument plainHtmlNode = new XmlDocument();

        public Dictionary<string, string> hStyleIDTag = new Dictionary<string, string>();
        public Dictionary<string, string> hStyleTag = new Dictionary<string, string>();
        public Dictionary<string, string> _ListHeading = new Dictionary<string, string>();
        public Dictionary<string, int> _outlevelValue = new Dictionary<string, int>();
        public Dictionary<string, string> fnHash = new Dictionary<string, string>();
        public Dictionary<string, string> fnHashbk = new Dictionary<string, string>();
        public Dictionary<string, string> enHash = new Dictionary<string, string>();
        public Dictionary<string, string> enHashbk = new Dictionary<string, string>();
        public Dictionary<string, int> hCharStyle = new Dictionary<string, int>();
        public Dictionary<string, string> hsEntity = new Dictionary<string, string>();
        public Dictionary<string, string> hShadeTag = new Dictionary<string, string>();
        public Dictionary<string, string> hBorderTag = new Dictionary<string, string>();
        public Dictionary<string, string> hsfont = new Dictionary<string, string>();
        public Dictionary<string, string> _fontTags = new Dictionary<string, string>();
        public Dictionary<string, string> hsList = new Dictionary<string, string>();
        public int intSymCnt = 0;
        public int intTimes = 0;
        public string headingId = "";
        public string headingInitalLable = "";
        public string headingLabledelim = "";
        XmlNode lst = null;
        public Dictionary<int, HeadingListStruct> _headingStructHash = new Dictionary<int, HeadingListStruct>();
        private bool isFnStory = false;
        public struct HeadingListStruct
        {
            public string name;
            public string headingLabel;
            public string numId;
            public int level;
            public string numFrmt;
            public int start;
            public int current;
            public string text;
            public string initalLabel;
            public string listformat;
            public string numFrmtLable;
            public string uppletterLabel;
            public string lowerLetterLabel;
            public string upperRomanLabel;
            public string lowerRomanLabel;
            public string delim;
        }

        public string plainHtmlContent = "";
        public BodyTextStyler(string plainHtmlContent, Dictionary<string, string> hsEntity)
        {
            if (plainHtmlContent != null)
            {
                this.plainHtmlContent = plainHtmlContent;
                this.plainHtmlNode.PreserveWhitespace = true;
                this.plainHtmlNode.LoadXml(plainHtmlContent);
                this.hsEntity = hsEntity;
            }
            else
            {
                throw new Exception(Cnfunctions.GetExceptionMethodName() + "plainHtmlContent is Null");
            }
        }

        public string GetBodyTextStyle(string xmlText, string xmlList, string xmlFootnote, string xmlEndnote, string xmlStyles)
        {
            string str = xmlText;
            XmlElement xEle;
            int i;
            int cnt = 0;
            int intCnt = 0;
            XmlDocument doc = new XmlDocument();
            XmlDocument xTmpDoc = new XmlDocument();
            XmlNodeList ndl;
            XmlNode nd;
            string tmp = string.Empty;
            string sDoc = xmlText;
            xmlText = sDoc;
            try
            {
                str = str.Replace("|", "#pipe;");
                str = str.Replace("<pkg:", "<pkg-").Replace("</pkg:", "</pkg-");
                str = str.Replace("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">", "<Relationships>");
                doc.PreserveWhitespace = true;
                doc.LoadXml(str);
                // Load styles information
                if (string.IsNullOrEmpty(xmlStyles) == false)
                {
                    xTmpDoc.PreserveWhitespace = true; xTmpDoc.LoadXml(xmlStyles);
                    ndl = xTmpDoc.SelectNodes("//w-styles");
                    try
                    {
                        for (i = 0; i <= ndl.Count - 1; i++)

                            doc.DocumentElement.PrependChild(doc.ImportNode(ndl[i], true));// importing from styles.xml
                    }
                    catch (Exception e)
                    {
                    }
                }

                // Load footnote information
                if (string.IsNullOrEmpty(xmlFootnote) == false)
                {
                    xTmpDoc.PreserveWhitespace = true; xTmpDoc.LoadXml(xmlFootnote);
                    ndl = xTmpDoc.SelectNodes("//w-footnotes");
                    try
                    {
                        for (i = 0; i <= ndl.Count - 1; i++)
                            doc.DocumentElement.AppendChild(doc.ImportNode(ndl[i], true));// importing from footnotes.xml
                    }
                    catch (Exception e)
                    {
                    }
                }


                // Load endnote information
                if (string.IsNullOrEmpty(xmlEndnote) == false)
                {
                    xTmpDoc.PreserveWhitespace = true; xTmpDoc.LoadXml(xmlEndnote);

                    ndl = doc.SelectNodes("//w-endnotes");
                    try
                    {
                        for (i = 0; i <= ndl.Count - 1; i++)
                            doc.DocumentElement.AppendChild(doc.ImportNode(ndl[i], true));// importing from endnotes.xml
                    }
                    catch
                    {
                    }
                }

                str = doc.OuterXml;

                // Handling Emphasis tag
                XmlNode xmlNode;
                nd = null;

                try
                {
                    doc.PreserveWhitespace = true; doc.LoadXml(str);
                    xmlNode = doc.SelectSingleNode("//w-style[@w-styleId=\"Emphasis\"]/w-rPr");
                    ndl = doc.SelectNodes("//w-rStyle[@w-val=\"Emphasis\"]");
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        foreach (XmlNode nod in xmlNode.ChildNodes)
                        {
                            if (ndl[intCnt].ParentNode.SelectSingleNode(".//" + nod.Name) == null)
                                ndl[intCnt].ParentNode.InsertAfter(nod.Clone(), ndl[intCnt]);
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                str = doc.OuterXml;

                doc.PreserveWhitespace = true; doc.LoadXml(str);
                // Styles in the wordxml file read here
                ndl = doc.SelectNodes("//w-styles/w-style");
                hStyleIDTag.Clear();
                hStyleTag.Clear();
                try
                {
                    for (i = 0; i <= ndl.Count - 1; i++)
                    {
                        if (hStyleIDTag.ContainsKey("[" + ndl.Item(i).Attributes.GetNamedItem("w-styleId").Value + "]") == false)
                        {
                            if (ndl.Item(i).SelectSingleNode("./w-name") != null)
                                hStyleIDTag.Add("[" + ndl.Item(i).Attributes.GetNamedItem("w-styleId").Value + "]", ndl.Item(i).SelectSingleNode("./w-name").Attributes.GetNamedItem("w-val").Value);
                        }
                        if (hStyleTag.ContainsKey("[" + ndl.Item(i).Attributes.GetNamedItem("w-styleId").Value + "]") == false)
                        {
                            string sTmptext = "";
                            bool bFormat = false;
                            if (ndl.Item(i).SelectSingleNode("./w-name") != null && ndl.Item(i).SelectSingleNode("./w-rPr") != null)
                            {
                                for (var j = 0; j <= ndl.Item(i).SelectSingleNode("./w-rPr").ChildNodes.Count - 1; j++)
                                {
                                    string matchName = ndl.Item(i).SelectSingleNode("./w-rPr").ChildNodes[j].Name;
                                    switch (matchName)
                                    {
                                        case "w-b":
                                            {
                                                sTmptext = "<b>|</b>";
                                                bFormat = true;
                                                break;
                                            }

                                        case "w-i":
                                            {
                                                sTmptext = sTmptext.Contains("|") ? sTmptext.Replace("|", "<i>|</i>") : "<i>|</i>";
                                                //sTmptext = sTmptext + "<i>|</i>";
                                                bFormat = true;
                                                break;
                                            }
                                    }
                                }
                                string stylename = ndl.Item(i).SelectSingleNode("./w-name").Attributes.GetNamedItem("w-val").Value.ToLower();
                                string styleType = ndl.Item(i).Attributes.GetNamedItem("w-type").Value.ToLower();
                                

                                stylename = Regex.Replace(stylename, "[^A-Za-z0-9]+", "");
                                stylename = Regex.Replace(stylename, "^[0-9].*", "");

                                if (stylename!="")
                                {

                                    if (stylename.StartsWith("head"))
                                    {
                                        sTmptext = "<" + stylename + ">" + sTmptext + "</" + stylename + ">";

                                    }
                                    else
                                    {
                                        string tagName = "div";
                                        if (styleType== "character")
                                        {
                                            tagName = "span";
                                        }
                                        sTmptext = $"<{tagName} data-stylename=\" { stylename } \" > { sTmptext } </{tagName}>";

                                    }
                                    //sTmptext = "<" + stylename + ">" + sTmptext + "</" + stylename + ">";


                                    //sTmptext = "<" + Regex.Replace(ndl.Item(i).SelectSingleNode("./w-name").Attributes.GetNamedItem("w-val").Value.ToLower(), "[^A-Za-z0-9]+", "") + ">" + sTmptext + "</" + Regex.Replace(ndl.Item(i).SelectSingleNode("./w-name").Attributes.GetNamedItem("w-val").Value.ToLower(), "[^A-Za-z0-9]+", "") + ">";
                                    if (bFormat)
                                    hStyleTag.Add("[" + ndl.Item(i).Attributes.GetNamedItem("w-styleId").Value.ToLower() + "]", sTmptext.ToLower());
                            }
                           }

                        }
                    }
                }
                catch
                {
                }

                if (xmlList!="")
                {

                xTmpDoc.LoadXml(xmlList); xTmpDoc.PreserveWhitespace = true;
                lst = ListXMLGeneration(xTmpDoc.SelectSingleNode("//w-numbering"));
                }
                // Load list information from numbering.xml files

                XDocument wdmldoc = XDocument.Parse(doc.OuterXml);
                List<XElement> _headingStyles = wdmldoc.Descendants("w-style").Where(e => e.Descendants("w-name").Count() > 0).Where(a => Regex.IsMatch(a.Descendants("w-name").First().Attribute("w-val").Value.ToLower(), "head(ing)? ")).InDocumentOrder().ToList();

                string _headingName;
                string _numid;
                string outlistlevel;
                // loop through each heading stye and check the heading style is in Listformat and store the heading names in the the hash
                foreach (XElement _heading in _headingStyles)
                {
                    try
                    {
                        // check  the numId element and also the outlinelvl elements are present
                        if (_heading.Descendants("w-numId").Count() > 0&&_heading.Descendants("w-outlineLvl").Count() > 0)
                        {
                            if ((_heading.Descendants("w-link").Count() > 0&&(_heading.Descendants("w-ilvl").Count() > 0 || _heading.Descendants("w-numPr").Count() > 0)) || _heading.Descendants("w-link").Count() == 0)
                            {
                                _headingName = _heading.Descendants("w-name").First().Attribute("w-val").Value;
                                // check the style name is heading 1,2,3 etc
                                if (Regex.IsMatch(_headingName, @"heading[\s]?[0-9]") == true)
                                {
                                    _numid = _heading.Descendants("w-numId").First().Attribute("w-val").Value;
                                    outlistlevel = _heading.Descendants("w-outlineLvl").First().Attribute("w-val").Value;
                                    HeadingListStruct _headingObj = new HeadingListStruct();
                                    // store the style details here
                                    if (_ListHeading.ContainsKey(_headingName) == false)
                                    {
                                        _headingObj.name = _headingName;
                                        _headingObj.level = Convert.ToInt32(outlistlevel);
                                        _headingObj.numId = _numid;
                                        _headingStructHash.Add(_headingObj.level, _headingObj);
                                        _ListHeading.Add(_headingName, _numid);
                                        _outlevelValue.Add(_headingName.Replace(" ", ""), Convert.ToInt32(outlistlevel));
                                    }
                                }
                            }
                        }
                        else if (_heading.Descendants("w-numId").Count() == 0&&_heading.Descendants("w-outlineLvl").Count() > 0)
                        {
                            if ((_heading.Descendants("w-link").Count() > 0&&(_heading.Descendants("w-ilvl").Count() > 0 || _heading.Descendants("w-numPr").Count() > 0)) || _heading.Descendants("w-link").Count() == 0)
                            {
                                _headingName = _heading.Descendants("w-name").First().Attribute("w-val").Value;
                                // check the style name is heading 1,2,3 etc
                                if (Regex.IsMatch(_headingName, @"heading[\s]?[0-9]") == true)
                                {
                                    tmp = _heading.Attribute("w-styleId").Value;
                                    _numid = doc.SelectSingleNode("//w-pStyle[@w-val='" + tmp + "']").ParentNode.SelectSingleNode(".//w-numId").Attributes.GetNamedItem("w-val").Value;
                                    outlistlevel = _heading.Descendants("w-outlineLvl").First().Attribute("w-val").Value;
                                    HeadingListStruct _headingObj = new HeadingListStruct();
                                    // store the style details here
                                    if (_ListHeading.ContainsKey(_headingName) == false)
                                    {
                                        _headingObj.name = _headingName;
                                        _headingObj.level = Convert.ToInt32(outlistlevel);
                                        _headingObj.numId = _numid;
                                        _headingStructHash.Add(_headingObj.level, _headingObj);
                                        _ListHeading.Add(_headingName, _numid);
                                        _outlevelValue.Add(_headingName.Replace(" ", ""), Convert.ToInt32(outlistlevel));
                                    }
                                }
                            }
                            else if (_heading.Descendants("w-link").Count() > 0)
                            {
                                _headingName = _heading.Descendants("w-name").First().Attribute("w-val").Value;
                                // check the style name is heading 1,2,3 etc
                                if (Regex.IsMatch(_headingName, @"heading[\s]?[0-9]") == true)
                                {
                                    tmp = _heading.Attribute("w-styleId").Value;
                                    _numid = doc.SelectSingleNode("//w-pStyle[@w-val='" + tmp + "']").ParentNode.SelectSingleNode(".//w-numId").Attributes.GetNamedItem("w-val").Value;
                                    outlistlevel = _heading.Descendants("w-outlineLvl").First().Attribute("w-val").Value;
                                    HeadingListStruct _headingObj = new HeadingListStruct();
                                    // store the style details here
                                    if (_ListHeading.ContainsKey(_headingName) == false)
                                    {
                                        _headingObj.name = _headingName;
                                        _headingObj.level = Convert.ToInt32(outlistlevel);
                                        _headingObj.numId = _numid;
                                        _headingStructHash.Add(_headingObj.level, _headingObj);
                                        _ListHeading.Add(_headingName, _numid);
                                        _outlevelValue.Add(_headingName.Replace(" ", ""), Convert.ToInt32(outlistlevel));
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
                GetStartlableforHeadings();
                LoadFootEndNotes(doc);

                XmlNodeList xmlNodeList; // , xmlNode As Xml.XmlNode
                xmlNodeList = doc.SelectNodes("//w-p");
                for (intCnt = 0; intCnt <= xmlNodeList.Count - 1; intCnt++)
                {
                    xmlNode = xmlNodeList[intCnt].ParentNode;
                    xmlNode.ReplaceChild(GetListLabel(xmlNodeList[intCnt],ref doc), xmlNodeList[intCnt]);
                }


                // loop through the childnodes of footnote, end note and body  to the fetch the details of bookmark, paras and table
                xmlText = "";
                doc.LoadXml(str); doc.PreserveWhitespace = true;
                ndl = doc.SelectNodes("//w-body|//w-footnote|//w-endnote");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        tmp = "";
                        str = "";
                        if (ndl[intCnt].Name == "w-footnote")
                            isFnStory = true;
                        else
                            isFnStory = false;
                        for (var j = 0; j <= ndl[intCnt].ChildNodes.Count - 1; j++)
                        {
                           
                            if (j % 500 == 0 && j > 0)
                            {
                                System.Threading.Thread.Sleep(50000);
                            }
                            switch (ndl[intCnt].ChildNodes[j].Name)
                            {
                                case "w-sdt":
                                    {
                                        XmlNodeList ndl1 = ndl[intCnt].ChildNodes[j].SelectNodes("./w-sdtContent/w-p");
                                        for (int k = 0; k <= ndl1.Count - 1; k++)
                                            str = str + GetStyleColorText(ndl1[k].OuterXml, false, false, false);
                                        break;
                                    }

                                case "w-p":
                                    {
                                        Console.WriteLine(j);
                                        str = str + GetStyleColorText(ndl[intCnt].ChildNodes[j].OuterXml, false, false, false);
                                        break;
                                    }

                                case "w-tbl":
                                    {
                                        str = str + ProcessTable(ndl[intCnt].ChildNodes[j]);
                                        str = str + "</tbody></tgroup>";
                                        break;
                                    }
                            }
                        }
                        // checkt the footnote tag and get the details of bookmark, id, and the text with in
                        if (ndl[intCnt].Name == "w-footnote")
                        {

                            // check the id value here
                            if (str != ""&&Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("w-id").Value) > 0)
                            {
                                if (fnHash.ContainsKey(ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()))
                                {
                                    // check the bookmark is a footnote bookamrk
                                    if (str.IndexOf("<bkid id=\"fn", 0) > 0)
                                    {
                                        tmp = "<label>" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "</label>";
                                        str = Regex.Replace(str, "<footnote>(<bkid id=\"[^<>]+></bkid>)?<cross-ref>(<sup>)?" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString().Replace("*", @"\*") + "(</sup>)?</cross-ref>", "<footnote>$1");
                                        // Update suhail
                                        str = str.Replace("<bkid id=\"fn" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString(), "<bkid id=\"fn" + ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString());
                                        xmlText = xmlText.Replace("<cr refid=\"fn" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()] + "\">" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()] + "</cr>", "<cr refid=\"fn" + ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString() + "\">" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()] + "</cr>");
                                    }
                                    else
                                        // get the lable here using the footnoteref
                                        if (ndl[intCnt].SelectSingleNode("./w-p/w-r/w-footnoteRef") != null || ndl[intCnt].SelectSingleNode("./w-p/w-sdt/w-sdtContent/w-r/w-footnoteRef") != null)
                                    {
                                        if (fnHashbk.Count() == 0)
                                            tmp = "<label>" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "</label>";
                                        else
                                            tmp = "<label>" + fnHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "</label><bkid id=\"fn" + fnHashbk[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "\"></bkid>";
                                    }
                                    else
                                    {
                                        // get the text in the footnotes here
                                        tmp = GetText(ndl[intCnt].SelectSingleNode(".//w-p/w-r"), false, "", "");
                                        if (str.IndexOf(tmp, 0) >= 0)
                                        {
                                            if (str.IndexOf("<", 0) == 0&&str.IndexOf(">" + tmp, 0) >= 0)
                                                str = str.Remove(str.IndexOf(">" + tmp, 0) + 1, tmp.Length).Trim();
                                            else
                                                str = str.Remove(str.IndexOf(tmp, 0), tmp.Length).Trim();
                                        }
                                        tmp = Regex.Replace(tmp, "(</?[^<>]+>)", "");
                                        // make the entity as bookmark id here
                                        if (tmp.Contains("#x02606"))
                                            tmp = "<label>" + tmp + "</label><bkid id=\"fnx02606\"></bkid>";
                                        else
                                            // otherwise footnoteref as id
                                            tmp = "<label>" + tmp + "</label><bkid id=\"fn" + fnHashbk[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "\"></bkid>";
                                    }
                                }
                                else
                                    tmp = "";
                            }
                            else if (Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("w-id").Value) <= 0)
                                str = "";
                            // if the label was found then replace the footnote tags with para
                            if (tmp != "")
                            {
                                if (str.IndexOf("<footnote>", 0) >= 0)
                                {
                                    string _firstPara;
                                    string _nextparas;

                                    // Replace  footnote tag if end footnote tag was found
                                    if (str.IndexOf("</footnote>") > 0)
                                    {
                                        _firstPara = str.Substring(0, str.IndexOf("</footnote>") + Strings.Len("</footnote>"));
                                        _nextparas = str.Substring(_firstPara.Length);
                                        _nextparas = _nextparas.Replace("<footnote>", "<div>").Replace("</footnote>", "</div>");
                                        _firstPara = _firstPara.Replace("<footnote>", "<div>").Replace("</footnote>", "</div>");
                                        str = _firstPara + _nextparas;
                                    }
                                    if (str.IndexOf("<footnote>", 0) >= 0)
                                        str = str.Replace("<footnote>", "<footnote>" + tmp);
                                    else
                                        str = "<footnote>" + tmp + str;
                                }
                                else
                                {
                                    // Replace the opening footnote tag here
                                    str = str.Replace("<footnote>", "");
                                    str = "<footnote>" + tmp + str.Trim();
                                }

                                str = str.Replace("</footnote>", "");
                                str = str + "</footnote>";
                            }
                        }
                        else if (ndl[intCnt].Name == "w-endnote")
                        {
                            if (str != ""&&Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("w-id").Value) > 0)
                            {
                                if (enHash.ContainsKey(ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()))
                                {
                                    // check the bookmark is a footnote bookamrk
                                    if (str.IndexOf("<bkid id=\"en", 0) > 0)
                                        tmp = "<label>" + enHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "</label>";
                                    else
                                        // get the lable here using the footnoteref
                                        if (ndl[intCnt].SelectSingleNode("./w-p/w-r/w-endnoteRef") != null || ndl[intCnt].SelectSingleNode("./w-p/w-sdt/w-sdtContent/w-r/w-endnoteRef") != null)
                                        tmp = "<label>" + enHash[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "</label><bkid id=\"en" + enHashbk[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "\"></bkid>";
                                    else
                                    {
                                        // get the text in the footnotes here
                                        tmp = GetText(ndl[intCnt].SelectSingleNode(".//w-p/w-r"), false, "", "");
                                        if (str.IndexOf(tmp, 0) >= 0)
                                            str = str.Remove(str.IndexOf(tmp, 0), tmp.Length);
                                        tmp = Regex.Replace(tmp, "(</?[^<>]+>)", "");
                                        // make the entity as bookmark id here
                                        if (tmp.Contains("#x02606"))
                                            tmp = "<label>" + tmp + "</label><bkid id=\"enx02606\"></bkid>";
                                        else
                                            // otherwise footnoteref as id
                                            tmp = "<label>" + tmp + "</label><bkid id=\"en" + enHashbk[ndl[intCnt].Attributes.GetNamedItem("w-id").Value.ToString()].ToString() + "\"></bkid>";
                                    }
                                }
                                else
                                    tmp = "";
                            }
                            else if (Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("w-id").Value) <= 0)
                                str = "";
                            // if the label was found then replace the footnote tags with para
                            if (tmp != "")
                            {
                                if (str.IndexOf("<endnote>", 0) >= 0)
                                {
                                    string _firstPara;
                                    string _nextparas;

                                    // Replace  footnote tag if end footnote tag was found
                                    if (str.IndexOf("</endnote>") > 0)
                                    {
                                        _firstPara = str.Substring(0, str.IndexOf("</endnote>") + Strings.Len("</endnote>"));
                                        _nextparas = str.Substring(_firstPara.Length);
                                        _nextparas = _nextparas.Replace("<endnote>", "<div>").Replace("</endnote>", "</div>");
                                        _firstPara = _firstPara.Replace("<endnote>", "<div>").Replace("</endnote>", "</div>");
                                        str = _firstPara + _nextparas;
                                    }
                                    if (str.IndexOf("<endnote>", 0) >= 0)
                                        str = str.Replace("<endnote>", "<endnote>" + tmp);
                                    else
                                        str = "<endnote>" + tmp + str;
                                }
                                else
                                {

                                    // Replace the opening footnote tag here
                                    str = str.Replace("<endnote>", "");
                                    str = "<endnote>" + tmp + str;
                                }

                                str = str.Replace("</endnote>", "") + "</endnote>";
                            }
                        }
                        xmlText = xmlText + str;
                        str = "";
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    xmlText = xmlText + str;
                    xmlText = Regex.Replace(xmlText, "</?[0-9].*?>","");
                }

                xmlText = "<article>" + xmlText + "</article>";

                doc.PreserveWhitespace = true; doc.LoadXml(xmlText);
                ndl = doc.SelectNodes("//w-p|//w-bookmarkStart|//w-tbl[not(ancestor::w-tbl)]|//aml-annotation");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    tmp = ndl[intCnt].InnerText;
                    switch (ndl[intCnt].Name)
                    {
                        case "w-bookmarkStart":
                            {
                                ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                                break;
                            }

                        case "aml-annotation":
                            {
                                if (ndl[intCnt].OuterXml.IndexOf("w-type=\"Word.Bookmark.Start", 0) >= 0)
                                {
                                    if (ndl[intCnt].Attributes.GetNamedItem("w-name") != null && ndl[intCnt].Attributes.GetNamedItem("w-name").Value.StartsWith("_") == false&&ndl[intCnt].Attributes.GetNamedItem("w-name").Value.StartsWith("MEP_L_") == false)
                                    {
                                        xEle = doc.CreateElement("bkid");
                                        xEle.Attributes.Append(doc.CreateAttribute("id"));
                                        xEle.Attributes.GetNamedItem("id").Value = ndl[intCnt].Attributes.GetNamedItem("w-name").Value;
                                        ndl[intCnt].InnerXml = xEle.OuterXml;
                                    }
                                }
                                break;
                            }
                    }
                }

                // Remove Inserted text
                ndl = doc.SelectNodes("//w-instrText");
                for (i = ndl.Count - 1; i >= 0; i += -1)
                {
                    nd = ndl[i].ParentNode;
                    if (ndl[i].InnerText.Trim().StartsWith("ADDIN EN.CITE") || ndl[i].InnerText.Trim().StartsWith("ADDIN EN.REFLIST") || ndl[i].InnerText.Trim().StartsWith("ADDIN ZOTERO_ITEM CSL_CITATION"))
                        nd.RemoveChild(ndl[i]);
                    else
                        nd.ReplaceChild(GetTextStyle(ndl[i]), ndl[i]);
                }

                // Remove Images
                XmlNode xPar;
                ndl = doc.SelectNodes("//w-pict//v-textbox//w-p");
                for (i = ndl.Count - 1; i >= 0; i += -1)
                {
                    xPar = ndl[i].ParentNode;
                    while (xPar != null && xPar.Name != "w-pict")
                        xPar = xPar.ParentNode;
                    if (xPar != null)
                    {
                        if (xPar.ParentNode.Name == "w-r")
                            xPar.ParentNode.ParentNode.InsertAfter(ndl[i], xPar.ParentNode);
                        else
                            xPar.ParentNode.InsertAfter(ndl[i], xPar);
                    }
                }

                ndl = doc.SelectNodes("//aml-annotation[@w-type='Word.Bookmark.Start']");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    if (ndl[i].Attributes.GetNamedItem("w-name").Value.StartsWith("_") == false&&ndl[i].Attributes.GetNamedItem("w-name").Value.StartsWith("MEP_L_") == false)
                    {
                        xEle = doc.CreateElement("bkid");
                        xEle.Attributes.Append(doc.CreateAttribute("id"));
                        xEle.Attributes.GetNamedItem("id").Value = ndl[i].Attributes.GetNamedItem("w-name").Value;
                        ndl[i].ParentNode.ReplaceChild(xEle.Clone(), ndl[i]);
                    }
                    else
                        ndl[i].ParentNode.RemoveChild(ndl[i]);
                }
                ndl = doc.SelectNodes("//aml-annotation[@w-type='Word.Comment']");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    xEle = doc.CreateElement("query");
                    xEle.InnerXml = ndl[i].InnerXml;
                    ndl[i].ParentNode.ReplaceChild(xEle.Clone(), ndl[i]);
                }
                ndl = doc.SelectNodes("//w-hyperlink[@w-anchor]");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    xEle = doc.CreateElement("link");
                    xEle.Attributes.Append(doc.CreateAttribute("ref"));
                    xEle.Attributes.GetNamedItem("ref").Value = ndl[i].Attributes.GetNamedItem("w-anchor").Value;
                    xEle.InnerXml = ndl[i].InnerXml;
                    ndl[i].ParentNode.ReplaceChild(xEle.Clone(), ndl[i]);
                }
                ndl = doc.SelectNodes("//w-hyperlink");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    if (string.IsNullOrEmpty(ndl[i].InnerText))
                        ndl[i].ParentNode.RemoveChild(ndl[i]);
                }

                ndl = doc.SelectNodes("//w-hlink[@w-bookmark]");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    xEle = doc.CreateElement("link");
                    xEle.Attributes.Append(doc.CreateAttribute("ref"));
                    xEle.Attributes.GetNamedItem("ref").Value = ndl[i].Attributes.GetNamedItem("w-bookmark").Value;
                    xEle.InnerXml = ndl[i].InnerXml;
                    ndl[i].ParentNode.ReplaceChild(xEle.Clone(), ndl[i]);
                }
                ndl = doc.SelectNodes("//w-instrText");

                for (i = ndl.Count - 1; i >= 0; i += -1)
                {
                    if (ndl[i].InnerText.StartsWith(" HYPERLINK ")&&ndl[i].InnerText.Contains(@" \l "))
                    {
                        xEle = doc.CreateElement("link-ins");
                        tmp = ndl[i].InnerText.Substring(ndl[i].InnerText.IndexOf(@"\l ") + 2);
                        if (tmp.Contains(@" \o "))
                        {
                            tmp = tmp.Substring(0, tmp.IndexOf(@"\o ")).Trim();
                            tmp = tmp.Trim('\"');
                        }
                        xEle.Attributes.Append(doc.CreateAttribute("ref"));
                        xEle.Attributes.GetNamedItem("ref").Value = tmp;
                        ndl[i].ParentNode.ParentNode.ReplaceChild(xEle.Clone(), ndl[i].ParentNode);
                    }
                }
                ndl = doc.SelectNodes("//link-ins");
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    while (ndl[i].NextSibling != null)
                    {
                        if (ndl[i].NextSibling.SelectSingleNode(".//w-fldChar[@w-fldCharType='end']") == null)
                            ndl[i].AppendChild(ndl[i].NextSibling);
                        else
                            break;
                    }
                }


                ndl = doc.SelectNodes("//w-bookmarkEnd|//w-rPr|//w-annotationRef|//aml-annotation[@w-type='Word.Comment.Start']|//aml-annotation[@w-type='Word.Comment.End']|//w-pPr|//w-sectPr|//w-proofErr|//w-bookmarkStart|//w-smartTag|//wx-borders|//aml-annotation[@w-type='Word.Bookmark.End']");
                for (i = ndl.Count - 1; i >= 0; i += -1)
                    ndl[i].ParentNode.RemoveChild(ndl[i]);



                ndl = doc.SelectNodes("//w-tbl");
                for (i = ndl.Count - 1; i >= 0; i += -1)
                {
                    xEle = doc.CreateElement("table");
                    str = ndl[i].InnerXml.ToString();
                    str = Regex.Replace(str, @"<(\/)?(tgroup[^<>]*|colspec[^<>]*|tbody|thead)>", "");
                    str = Regex.Replace(str, @"<(\/)?row>", "<$1tr>");
                    str = Regex.Replace(str, @"<(\/)?entry([^<>]*)>", "<$1td$2>");
                    xEle.InnerXml = str;
                    ndl[i].ParentNode.ReplaceChild(xEle, ndl[i]);
                }



                str = doc.OuterXml;
                str = Regex.Replace(str, "(<w-r [^<>]+>)|(</w-r>)|(<w-r>)|</?wx-pBdrGroup>|</?aml-content>|<wx-margin-left[^<>]+>|<w-hlink[^<>]+>|</w-hlink>", "");
                str = str.Replace("<link-ins ref=", "<link ref=").Replace("</link-ins>", "</link>");


                try
                {
                    doc.PreserveWhitespace = true; doc.LoadXml(str);
                    ndl = doc.SelectNodes("//link");
                    for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                    {
                        if (ndl[intCnt].PreviousSibling != null&&ndl[intCnt].ChildNodes.Count == 1)
                        {
                            if (ndl[intCnt].PreviousSibling.Name == ndl[intCnt].ChildNodes[0].Name)
                            {
                                ndl[intCnt].InnerXml = ndl[intCnt].ChildNodes[0].InnerXml;
                                ndl[intCnt].PreviousSibling.AppendChild(ndl[intCnt]);
                            }
                        }
                    }
                    ndl = doc.SelectNodes("//para");
                    for (intCnt = ndl.Count - 1; intCnt >= 0; intCnt += -1)
                    {
                        if (ndl[intCnt].InnerXml == "")
                            ndl[intCnt].ParentNode.RemoveChild(ndl[intCnt]);
                    }


                    str = doc.OuterXml;

                    CleanUp(ref str);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
            catch (Exception e)
            {
                throw;
            }
            this.plainHtmlContent = str;
            return str;
        }


        public XmlNode GetTextStyle(XmlNode nd)
        {
            XmlDocument wrDoc = new XmlDocument();
            int intCnt;
            XmlNodeList ndl;
            string txt = "";
            try
            {
                wrDoc.PreserveWhitespace = true; wrDoc.LoadXml(nd.OuterXml);
                ndl = wrDoc.SelectNodes("//w-r[not(ancestor::query or ancestor::w-footnote)]");
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    txt = txt + GetSubText(ndl[intCnt]);
                nd.InnerXml = txt;
            }
            catch (Exception ex)
            {
                return nd;
            }
            wrDoc = null/* TODO Change to default(_) if this is not a reference type */;
            return nd.Clone();
        }

        public string GetSubText(XmlNode nd)
        {
            XmlDocument wrDoc = new XmlDocument();
            XmlNode nds;
            XmlNodeList ndl;
            string txt = "";
            int intCnt;
            try
            {
                wrDoc.PreserveWhitespace = true; wrDoc.LoadXml(nd.OuterXml);
                nds = wrDoc.SelectSingleNode("//w-footnote|//w-endnote|//w-p"); // Get the footnote content
                if (nds != null)
                    txt = nds.OuterXml;
                else if (nd.InnerXml.IndexOf("<query>", 0) >= 0 || nd.InnerXml.IndexOf("<!--Comment:AQ", 0) >= 0 || nd.InnerXml.IndexOf("<!--Comment:RQ", 0) >= 0 || nd.InnerXml.IndexOf("<!--Comment:TI", 0) >= 0)
                    txt = nd.InnerXml;
                else
                {
                    ndl = wrDoc.SelectNodes("//w-t|//w-instrText|//w-noBreakHyphen");
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        if (ndl[intCnt].Name.ToLower() == "w-nobreakhyphen")
                            txt = txt + "-";
                        else if (ndl[intCnt].OuterXml.Contains("<w-instrText>HYPERLINK") == false&&ndl[intCnt].OuterXml.Contains("<w-instrText>ADVANCE") == false)
                            txt = txt + ndl[intCnt].InnerText;
                        else if (ndl[intCnt].OuterXml.Contains("<w-instrText>ADVANCE") == true)
                            txt = txt;
                    }
                    // This is to get the equalent entity for the symbol
                    nds = wrDoc.SelectSingleNode("//w-sym");
                    if (nds != null)
                        txt = GetSymbol(nds, "w");
                    nds = wrDoc.SelectSingleNode("//wx-sym");
                    if (nds != null)
                        txt = GetSymbol(nds, "wx");
                    if (txt != ""&&nd.InnerXml.IndexOf("</w-rPr>", 0) >= 0)
                    {
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-rStyle[@w-val]");
                        string tag = "";
                        if (nds != null)
                        {
                            if (nds.Attributes.GetNamedItem("w-val").Value != "")
                            {
                                tag = nds.Attributes.GetNamedItem("w-val").Value;
                                tag = Regex.Replace(tag, "^[0-9]+", "");
                                txt = "<" + tag + ">" + txt + "</" + tag + ">";
                                if (hCharStyle.ContainsKey(tag) == false)
                                    hCharStyle.Add(tag, 1);
                            }
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-outline"); // This is to get the outline font tag
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<outline>" + txt + "</outline>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-smallCaps"); // This is to identify the small-caps font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<small-caps>" + txt + "</small-caps>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-u"); // This is to identify the undeline font
                        if (nds != null)
                        {
                            if (IsUnderline(nds) == true)
                                txt = "<u>" + txt + "</u>";
                            if ((nds.Attributes["w-val"] != null && nds.Attributes["w-val"].Value == "double"))
                                txt = "<u>" + txt + "</u>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-strike"); // This is to identify the strike through font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<cross-out>" + txt + "</cross-out>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-b"); // 'This is to identify the bold font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<b>" + txt + "</b>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-i"); // This is to identify the italic font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<i>" + txt + "</i>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-vertAlign[@w-val='superscript']"); // This is to identify the superscript font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<sup>" + txt + "</sup>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-vertAlign[@w-val='subscript']"); // This is to identify the subscript font
                        if (nds != null)
                        {
                            if (ReadAttributeValue(nds, "w-val") != "off"&&ReadAttributeValue(nds, "w-val") != "none")
                                txt = "<sub>" + txt + "</sub>";
                        }
                        nds = wrDoc.SelectSingleNode("//w-rPr//wx-font[@wx-val='Courier']"); // 'This is to identify the monospace font
                        if (nds != null)
                            txt = "<monospace>" + txt + "</monospace>";
                        nds = wrDoc.SelectSingleNode("//w-rPr//wx-font[@wx-val='Microsoft Sans Serif']"); // This is to identify the sans serif font
                        if (nds != null)
                            txt = "<sans-serif>" + txt + "</sans-serif>";
                        nds = wrDoc.SelectSingleNode("//w-rPr//w-shd[@w-fill='FFCBFF']"); // This is to identify the role font
                        if (nds != null)
                            txt = "<role>" + txt + "</role>";
                    }
                }
            }
            catch (Exception ex)
            {
                return nd.InnerXml;
            }
            return txt;
        }

        public string GetText(XmlNode nd, bool tbl, string level, string tmp1, bool fnr = false)
        {
            string color = "";
            string txt = "";
            string cstyle = "";
            string bdr = "";
            string shd = "";
            string dsup = "";
            string label = "";
            string typ = "";
            string align = "";
            string fnt = "";
            int i;
            int r = 0;
            int g = 0;
            int b = 0;
            string utype = "";
            bool itc = false;
            bool bld = false;
            bool sc = false;
            bool allcap = false;
            bool fntsym = false;
            bool uline = false;
            bool strike = false;

            // loop through each child node and then
            for (i = 0; i <= nd.ChildNodes.Count - 1; i++)
            {
                switch (nd.ChildNodes[i].Name)
                {
                    case "w-t":
                        {
                            if (fntsym == false)
                                txt = txt + nd.ChildNodes[i].InnerXml;
                            fntsym = false;
                            break;
                        }

                    case "w-delText":
                        {
                            txt = txt + nd.ChildNodes[i].InnerXml;
                            break;
                        }

                    case "w-instrText":
                        {
                            // txt = txt + nd.ChildNodes[i].InnerXml
                            break;
                        }

                    case "w-sym":
                        {
                            label = nd.ChildNodes[i].Attributes.GetNamedItem("w-font").Value;
                            typ = nd.ChildNodes[i].Attributes.GetNamedItem("w-char").Value;
                            if (Cnfunctions.GetEntity(this.hsEntity, label, typ) != "&undeclared;")
                                txt = txt + Cnfunctions.GetEntity(this.hsEntity, label, typ);
                            else
                                txt = txt + Cnfunctions.GetEntity(this.hsEntity, "0" + label.Substring(1), typ);

                            if (fnt != "")
                                fnt = "";
                            break;
                        }

                    case "w-tab":
                        {
                            txt = txt + "<tab></tab>";
                            break;
                        }

                    case "w-noBreakHyphen":
                        {
                            txt = txt + "-";
                            break;
                        }

                    case "w-rPr":
                        {
                            if (nd.ChildNodes[i].HasChildNodes)
                            {
                                for (int k = 0; k <= nd.ChildNodes[i].ChildNodes.Count - 1; k++)
                                {
                                    switch (nd.ChildNodes[i].ChildNodes[k].Name)
                                    {
                                        case "w-eastAsianLayout":
                                            {
                                                try
                                                {
                                                    if (nd.InnerText.EndsWith(" "))
                                                    {
                                                        nd.SelectNodes(".//w-t")[nd.SelectNodes(".//w-t").Count - 1].InnerXml = nd.SelectNodes(".//w-t")[nd.SelectNodes(".//w-t").Count - 1].InnerXml.TrimEnd();
                                                        align = "<sup>|</sup>";
                                                    }
                                                    else
                                                        align = "<sub>|</sub>";
                                                }
                                                catch (Exception ex)
                                                {
                                                }
                                                break;
                                            }

                                        case "w-color":
                                            {
                                                // color = nd.ChildNodes[i].ChildNodes(k).Attributes.GetNamedItem("w-val").Value
                                                // If color.ToLower() = "auto" Then
                                                // color = "000000"
                                                // End If
                                                // r = Convertodec(color.Substring(0, 2))
                                                // g = Convertodec(color.Substring(2, 2))
                                                // b = Convertodec(color.Substring(4, 2))
                                                // color = "[\red"&&r.ToString()&&"\green"&&g.ToString()&&"\blue"&&b.ToString()&&"]"
                                                break;
                                            }

                                        case "w-bdr":
                                            {
                                                // Try
                                                // label = nd.ChildNodes[i].ChildNodes(k).Attributes.GetNamedItem("w-color").Value
                                                // If nd.ChildNodes[i].ChildNodes(k).OuterXml.IndexOf(" w-val=", 0) >= 0 Then
                                                // If nd.ChildNodes[i].ChildNodes(k).Attributes.GetNamedItem("w-val").Value = "none" Then
                                                // Exit Select
                                                // End If
                                                // End If
                                                // If label.ToLower() = "auto" Then
                                                // label = "000000"
                                                // End If
                                                // r = Convertodec(label.Substring(0, 2))
                                                // g = Convertodec(label.Substring(2, 2))
                                                // b = Convertodec(label.Substring(4, 2))
                                                // bdr = "[\red"&&r.ToString()&&"\green"&&g.ToString()&&"\blue"&&b.ToString()&&"]"
                                                // Catch ex As Exception
                                                // End Try
                                                break;
                                            }

                                        case "w-shd":
                                            {
                                                // Try
                                                // label = nd.ChildNodes[i].ChildNodes(k).Attributes.GetNamedItem("w-fill").Value
                                                // If label.ToLower() = "auto" Then
                                                // label = "000000"
                                                // End If
                                                // r = Convertodec(label.Substring(0, 2))
                                                // g = Convertodec(label.Substring(2, 2))
                                                // b = Convertodec(label.Substring(4, 2))
                                                // shd = "[\red"&&r.ToString()&&"\green"&&g.ToString()&&"\blue"&&b.ToString()&&"]"
                                                // Catch ex As Exception
                                                // End Try
                                                break;
                                            }

                                        case "w-imprint":
                                            {
                                                // cstyle = GetTags("[\impr]")
                                                break;
                                            }

                                        case "w-rStyle":
                                            {
                                                cstyle = "[" + nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value + "]";
                                                cstyle = GetTags(cstyle);
                                                break;
                                            }

                                        case "w-vertAlign":
                                            {
                                                align = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value;
                                                // If dsup = "" Then
                                                align = GetTags(@"[\" + align + "]");
                                                // align = GetTags("["&&align&&"]")
                                                // Else
                                                // align = ""
                                                // End If
                                                break;
                                            }

                                        case "w-position":
                                            {
                                                dsup = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value;
                                                if (dsup == "-6")
                                                    dsup = "<dsub>|</dsub>";
                                                else if (dsup == "6")
                                                    dsup = "<dsup>|</dsup>";
                                                else if (Convert.ToInt32(dsup, 10) > 0)
                                                    dsup = "<sup>|</sup>";
                                                else if (Convert.ToInt32(dsup, 10) < 0)
                                                    dsup = "<sub>|</sub>";
                                                else
                                                    dsup = "";
                                                break;
                                            }

                                        case "w-rFonts":
                                            {
                                                XmlDocument doc1 = new XmlDocument();
                                                doc1.PreserveWhitespace = true;
                                                doc1.LoadXml(nd.ChildNodes[i].ChildNodes[k].OuterXml);
                                                XmlElement elm = doc1.DocumentElement;
                                                if (elm.HasAttribute("w-ascii") == true)
                                                {
                                                    fnt = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-ascii").Value;
                                                    if (_fontTags.ContainsKey(fnt.Replace(" ", "-")) == false)
                                                        _fontTags.Add(fnt.Replace(" ", "-"), "");
                                                    fnt = GetFontTag(fnt);
                                                }
                                                else if (elm.HasAttribute("w-fareast") == true)
                                                {
                                                    fnt = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-fareast").Value;
                                                    fnt = GetFontTag(fnt);
                                                }
                                                break;
                                            }

                                        case "wx-font":
                                            {
                                                if (fnt == "")
                                                {
                                                    XmlDocument doc2 = new XmlDocument();
                                                    doc2.PreserveWhitespace = true;
                                                    doc2.LoadXml(nd.ChildNodes[i].ChildNodes[k].OuterXml);
                                                    XmlElement elm1 = doc2.DocumentElement;
                                                    if (elm1.HasAttribute("wx-val") == true)
                                                    {
                                                        fnt = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("wx-val").Value;
                                                        fnt = GetFontTag(fnt);
                                                    }
                                                }
                                                break;
                                            }

                                        case "wx-sym":
                                            {
                                                label = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("wx-font").Value;
                                                typ = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("wx-char").Value;
                                                if (Cnfunctions.GetEntity(this.hsEntity, label, typ) != "&undeclared;")
                                                    txt = txt + Cnfunctions.GetEntity(this.hsEntity, label, typ);
                                                else
                                                    txt = txt + Cnfunctions.GetEntity(this.hsEntity, "0" + label.Substring(1), typ);
                                                fntsym = true;
                                                break;
                                            }

                                        case "w-b":
                                            {
                                                if (nd.ChildNodes[i].ChildNodes[k].Attributes.Count > 0)
                                                {
                                                    try
                                                    {
                                                        if (nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value != "0")
                                                            bld = true;
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                    }
                                                }
                                                else
                                                    bld = true;
                                                break;
                                            }

                                        case "w-i":
                                            {
                                                if (nd.ChildNodes[i].ChildNodes[k].Attributes.Count > 0)
                                                {
                                                    try
                                                    {
                                                        if (nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value != "0")
                                                            itc = true;
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                    }
                                                }
                                                else
                                                    itc = true;
                                                break;
                                            }

                                        case "w-smallCaps":
                                            {
                                                sc = true;
                                                break;
                                            }

                                        case "w-caps":
                                            {
                                                allcap = true;
                                                break;
                                            }

                                        case "w-u" // this is to validate the underline is applied or only color selected for underline.
                                 :
                                            {
                                                if (nd.ChildNodes[i].ChildNodes[k].Attributes.Count > 0)
                                                {
                                                    if (nd.ChildNodes[i].ChildNodes[k].OuterXml.IndexOf(" w-val", 0) >= 0)
                                                    {
                                                        utype = nd.ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value;
                                                        uline = true;
                                                    }
                                                }
                                                else
                                                    uline = true;
                                                break;
                                            }

                                        case "w-strike":
                                            {
                                                strike = true;
                                                break;
                                            }

                                        case "w-dstrike":
                                            {
                                                strike = true;
                                                break;
                                            }
                                    }
                                }

                                // based on the above info like color, border, style etc get the respective tags here
                                if (shd != "" || bdr != "" || color != "")
                                {
                                    if (bdr != "")
                                    {
                                        if (cstyle.Length > 1)
                                            bdr = "|";
                                        else
                                            bdr = GetBorderTags(bdr);
                                    }
                                    else
                                        bdr = "|";
                                    if (shd != "")
                                        shd = GetShadeTags(shd);
                                    else
                                        shd = "|";
                                    if (color != "")
                                    {

                                        if (cstyle.Length > 1&&GetTags(color).ToLower() == GetTags(cstyle).ToLower())
                                            color = "|";
                                        else
                                            color = GetTags(color);
                                        if (color == cstyle || cstyle.IndexOf(color, 0) >= 0)
                                            color = "|";
                                    }
                                    else
                                        color = "|";
                                }
                            }
                            break;
                        }

                    case "w-footnoteReference":
                        {
                            if (fnr == false)
                            {
                                // get the custom footnote ref details
                                if ((nd.ChildNodes[i].OuterXml.IndexOf("w-customMarkFollows", 0) > 0))
                                {
                                    string strTmp;
                                    strTmp = GetText(nd, tbl, level, tmp1, true);
                                    strTmp = Regex.Replace(strTmp, "(</?[^<>]+>)", "");
                                    // check the footnote hash has the id value already, othersiese add the value
                                    if (fnHash.ContainsKey(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value.ToString()) == false)
                                    {
                                        // if the ref is an author note then take the entity
                                        if (strTmp.Contains("x02606"))
                                            strTmp = "x02606";
                                        fnHash.Add(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value.ToString(), strTmp.Replace("&amp;#", "").Replace(";", ""));
                                    }
                                    // if cstyle has the sup tag then replace those tags
                                    if (cstyle.Contains("<sup>") == true)
                                    {
                                        cstyle = cstyle.Replace("<sup>", "").Replace("</sup>", "");
                                        // create a cr tag for the crossref
                                        if (strTmp.Contains("x02606"))
                                            txt = txt + "<cr refid=\"fnx02606\"><sup>" + strTmp + "</sup></cr>";
                                        else
                                            txt = txt + "<cr refid=\"fn" + fnHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "\"><sup>" + strTmp + "</sup></cr>";
                                    }
                                    else
                                        // create a cr tag for the crossref
                                        if (strTmp.Contains("x02606"))
                                        txt = txt + "<cr refid=\"fnx02606\">" + strTmp + "</cr>";
                                    else
                                        txt = txt + "<cr refid=\"fn" + fnHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "\">" + strTmp + "</cr>";
                                    // if the reference was authornote then get thext by altering the format as below
                                    // If strTmp.Contains("x02606") Then
                                    // txt = GetText(nd, tbl, level, tmp1, True).Replace("<sup>#macamp;#"&&strTmp&&";</sup>", txt)
                                    // txt = txt.Replace("<cross-ref>", "<cross-ref><cr refid=""fnx02606"">").Replace("</cross-ref>", "</cr></cross-ref>")
                                    // Else
                                    // 'otherwse simply get the text
                                    // txt = GetText(nd, tbl, level, tmp1, True).Replace(">"&&strTmp&&"<", ">"&&txt.Replace("<sup>", "").Replace("</sup>", "")&&"<")
                                    // End If
                                    return txt;
                                }
                                else
                                    // if the hash table has the id value then add the cr tag with the id value.
                                    if (fnHash.ContainsKey(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value))
                                {
                                    if (cstyle == "")
                                        cstyle = "<cross-ref>|</cross-ref>";
                                    if (cstyle.Contains("<sup>") == true)
                                    {
                                        cstyle = cstyle.Replace("<sup>", "").Replace("</sup>", "");
                                        txt = txt + "<cr refid=\"fn" + fnHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "\"><sup>" + fnHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "</sup></cr>";
                                    }
                                    else
                                        try
                                        {
                                            txt = txt + "<cr refid=\"fn" + fnHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "\">" + fnHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "</cr>";
                                        }
                                        catch (Exception ex)
                                        {
                                            txt = txt + "<cr refid=\"fn" + fnHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "\"><sup>" + fnHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value] + "</sup></cr>";
                                        }
                                }
                            }
                            break;
                        }

                    case "w-endnoteReference":
                        {
                            if (fnr == false)
                            {
                                // if the endnote has the custom mark then
                                if ((nd.ChildNodes[i].OuterXml.IndexOf("w-customMarkFollows", 0) > 0))
                                {
                                    string strTmp;
                                    strTmp = GetText(nd, tbl, level, tmp1, true);
                                    strTmp = Regex.Replace(strTmp, "(</?[^<>]+>)", "");
                                    // check the footnote hash has the id value already, othersiese add the value
                                    if (enHash.ContainsKey(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value.ToString()) == false)
                                    {
                                        // if the ref is an author note then take the entity
                                        if (strTmp.Contains("x02606"))
                                            strTmp = "x02606";
                                        enHash.Add(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value.ToString(), strTmp.Replace("&amp;#", "").Replace(";", ""));
                                    }
                                    // if cstyle has the sup tag then replace those tags
                                    if (cstyle.Contains("<sup>") == true)
                                    {
                                        cstyle = cstyle.Replace("<sup>", "").Replace("</sup>", "");
                                        // create a cr tag for the crossref
                                        if (strTmp.Contains("x02606"))
                                            txt = txt + "<cr refid=\"enx02606\"><sup>" + strTmp + "</sup></cr>";
                                        else
                                            txt = txt + "<cr refid=\"en" + enHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "\"><sup>" + strTmp + "</sup></cr>";
                                    }
                                    else
                                        // create a cr tag for the crossref
                                        if (strTmp.Contains("x02606"))
                                        txt = txt + "<cr refid=\"enx02606\">" + strTmp + "</cr>";
                                    else
                                        txt = txt + "<cr refid=\"en" + enHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "\">" + strTmp + "</cr>";
                                    // if the reference was authornote then get thext by altering the format as below
                                    if (strTmp.Contains("x02606"))
                                    {
                                        txt = GetText(nd, tbl, level, tmp1, true).Replace("<sup>#macamp;#" + strTmp + ";</sup>", txt);
                                        txt = txt.Replace("<cross-ref>", "<cross-ref><cr refid=\"enx02606\">").Replace("</cross-ref>", "</cr></cross-ref>");
                                    }
                                    else
                                        // otherwse simply get the text
                                        txt = GetText(nd, tbl, level, tmp1, true).Replace(strTmp, txt.Replace("<sup>", "").Replace("</sup>", ""));
                                    return txt;
                                }
                                else
                                    // if the hash table has the id value then add the cr tag with the id value.
                                    if (enHash.ContainsKey(nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value))
                                {
                                    if (cstyle == "")
                                        cstyle = "<cross-ref>|</cross-ref>";
                                    if (cstyle.Contains("<sup>") == true)
                                    {
                                        cstyle = cstyle.Replace("<sup>", "").Replace("</sup>", "");
                                        txt = txt + "<cr refid=\"en" + enHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "\"><sup>" + enHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "</sup></cr>";
                                    }
                                    else
                                        txt = txt + "<cr refid=\"en" + enHashbk[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "\">" + enHash[nd.ChildNodes[i].Attributes.GetNamedItem("w-id").Value].ToString() + "</cr>";
                                }
                            }
                            break;
                        }

                    case "w-commentReference":
                        {
                            break;
                        }

                    default:
                        {
                            if (nd.ChildNodes[i].Name.IndexOf("w-ruby", 0) == 0)
                                txt = txt + wrow(nd.ChildNodes[i], tbl);
                            break;
                        }
                }
            }
            // in the below conditions add the font tags here like, all-caps, small-caps etc
            if (allcap == true&&txt != "")
                txt = "<all-caps>" + txt + "</all-caps>";
            if (sc == true&&txt != "")
                txt = "<small-caps>" + txt + "</small-caps>";
            if (uline == true&&txt != "")
            {
                if (utype == "wave")
                    txt = "<u type=\"wave\">" + txt + "</u>";
                else if (utype == "dotDotDash")
                    txt = "<u type=\"dot-dot-dash\">" + txt + "</u>";
                else if (utype == "dotDash")
                    txt = "<u type=\"dot-dash\">" + txt + "</u>";
                else if (utype == "dotted")
                    txt = "<u type=\"dotted\">" + txt + "</u>";
                else if (utype == "dash")
                    txt = "<u type=\"dashed\">" + txt + "</u>";
                else if (utype == "double")
                    txt = "<u type=\"double\">" + txt + "</u>";
                else if (utype == "none")
                    txt = txt;
                else
                    txt = "<u>" + txt + "</u>";
            }
            if (strike == true&&txt != "")
                txt = "<cross-out>" + txt + "</cross-out>";
            if (bld == true&&txt != "")
                txt = "<b>" + txt + "</b>";
            if (itc == true&&txt != "")
                txt = "<i>" + txt + "</i>";
            if (dsup != ""&&txt != "")
                txt = dsup.Replace("|", txt);
            //if (fnt != ""&&txt != "")
            //    txt = fnt.Replace("|", txt);
            if (align != ""&&txt != "")
                txt = align.Replace("|", txt);
            if (color != ""&&txt != "")
                txt = color.Replace("|", txt);
            if (cstyle != ""&&txt != "")
                txt = cstyle.Replace("|", txt);
            if (shd != ""&&txt != "")
                txt = shd.Replace("|", txt);
            if (bdr != ""&&txt != "")
                txt = bdr.Replace("|", txt);
            bdr = shd = "";
            tmp1 = txt;
            txt = "";
            cstyle = "";
            color = "";
            align = "";
            fnt = "";
            shd = "";
            bdr = "";
            dsup = "";
            bld = false;
            itc = false;
            sc = false;
            allcap = false;
            return tmp1;
        }

        public string ProcessTable(System.Xml.XmlNode nd)
        {
            string str = "";
            string tmp = "";
            int colnum;
            int[] intColCnt;
            int j = 0;
            int i = 0;
            int cnt1 = 0;
            int col = 1;
            int intMoreRows = 0;
            bool thead = false;
            intColCnt = new int[0] { };
            // loop through each child node of the table
            for (i = 0; i <= nd.ChildNodes.Count - 1; i++)
            {
                switch (nd.ChildNodes[i].Name)
                {
                    case "w-tblPr":
                        {
                            break;
                        }

                    case "w-tblGrid":
                        {
                            colnum = nd.ChildNodes[i].SelectNodes("./w-gridCol").Count;
                            str = (str + "<tgroup cols=\"") + colnum + "\">";
                            // loop through each childnode of tablegrid and the colspec tags
                            for (j = 0; j <= colnum - 1; j++)
                                str = str + "<colspec colname=\"col" + (j + 1) + "\"/>";
                            str = str + "<tbody>";
                            intColCnt = new int[nd.ChildNodes[i].ChildNodes.Count - 1 + 1];
                            break;
                        }

                    case "w-tr":
                        {
                            str = str + "<tr>";
                            thead = false;
                            col = 1;
                            // loop through each childnodes of row and get the column info
                            for (j = 0; j <= nd.ChildNodes[i].ChildNodes.Count - 1; j++)
                            {
                                // if the chilnode is w-tc then proces the entry
                                if (nd.ChildNodes[i].ChildNodes[j].Name == "w-tc")
                                {
                                    tmp = ProcessEntry(nd.ChildNodes[i].ChildNodes[j], ref col, ref intColCnt, ref intMoreRows);
                                    str = str + tmp;
                                }
                                // if the childnode is trpr then read the row properties like headear
                                if (nd.ChildNodes[i].ChildNodes[j].Name == "w-trPr")
                                {
                                    // loop through each childnode and then ge the head tag if the tblHeader found
                                    for (int k = 0; k <= nd.ChildNodes[i].ChildNodes[j].ChildNodes.Count - 1; k++)
                                    {
                                        if (nd.ChildNodes[i].ChildNodes[j].ChildNodes[k].Name == "w-tblHeader")
                                        {
                                            str = str.Insert(str.LastIndexOf("<tr>"), "<thead>");
                                            thead = true;
                                        }
                                    }
                                }
                            }
                            str = str + "</tr>";
                            // if the thead was found then add the end tag for thead
                            if (thead == true)
                                str = str + "</thead>";
                            break;
                        }
                }
                cnt1 += 1;
            }
            str = str.Replace("</thead><thead>", "");
            if (str.IndexOf("<tbody><thead>", 0) >= 0)
            {
                str = str.Replace("<tbody><thead>", "<thead>");
                str = str.Insert(str.IndexOf("</thead>", 0) + 8, "<tbody>");
            }
            return str;
        }

        private string ProcessEntry(System.Xml.XmlNode nd, ref int col, ref int[] intColCnt, ref int intMoreRows)
        {
            XmlDocument xmlEnt = new XmlDocument();
            System.Xml.XmlNode nd1;
            string chstyle = "";
            string tmp = "";
            try
            {
                xmlEnt.PreserveWhitespace = true;
                xmlEnt.LoadXml("<td></td>");
                nd1 = xmlEnt.SelectSingleNode("//td");

                // loop through the each node inside the entry
                for (int k = 0; k <= nd.ChildNodes.Count - 1; k++)
                {
                    // process the para tag here
                    if (nd.ChildNodes[k].Name == "w-p")
                        tmp = tmp + GetStyleColorText(nd.ChildNodes[k].OuterXml, false, true, false);
                    // process the table here
                    if (nd.ChildNodes[k].Name == "w-tbl")
                    {
                        tmp = tmp + ProcessTable(nd.ChildNodes[k]);
                        tmp = tmp + "</tbody></tgroup>";
                    }
                    // process the colum properties here
                    if (nd.ChildNodes[k].Name == "w-tcPr")
                    {
                        // loop through each colum properties and get the details as....
                        for (int a = 0; a <= nd.ChildNodes[k].ChildNodes.Count - 1; a++)
                        {
                            // get the gridspan here
                            if (nd.ChildNodes[k].ChildNodes[a].Name == "w-gridSpan")
                            {
                                chstyle = nd.ChildNodes[k].ChildNodes[a].Attributes.GetNamedItem("w-val").Value;
                                col = col + Convert.ToInt32(chstyle);
                                nd1.Attributes.Append(xmlEnt.CreateAttribute("namest"));
                                nd1.Attributes.GetNamedItem("namest").Value = "col" + (col - Convert.ToInt32(chstyle));
                                nd1.Attributes.Append(xmlEnt.CreateAttribute("nameend"));
                                nd1.Attributes.GetNamedItem("nameend").Value = "col" + (col - 1);
                                col -= 1;
                            }
                            else if (nd.ChildNodes[k].ChildNodes[a].Name.ToLower() == "w-vmerge")
                            {
                                if (GetAttribVal(nd.ChildNodes[k].ChildNodes[a], "w-val").ToLower() == "restart")
                                {
                                    intMoreRows = intMoreRows + 1;
                                    intColCnt[col - 1] = intMoreRows;
                                }
                                nd1.Attributes.Append(xmlEnt.CreateAttribute("morerows"));
                                nd1.Attributes.GetNamedItem("morerows").Value = intColCnt[col - 1].ToString();
                            }
                            // get the column borders here like top, bottom etc
                            if (nd.ChildNodes[k].ChildNodes[a].Name == "w-tcBorders")
                            {
                                // loop through each chilnode of tcBorders and get the details here
                                foreach (System.Xml.XmlNode _childNode in nd.ChildNodes[k].ChildNodes[a].ChildNodes)
                                {
                                    try
                                    {
                                        if (_childNode.Name == "w-top")
                                        {
                                            nd1.Attributes.Append(xmlEnt.CreateAttribute("top"));
                                            nd1.Attributes.GetNamedItem("top").Value = "true";
                                            try
                                            {
                                                nd1.Attributes.Append(xmlEnt.CreateAttribute("tbtype"));
                                                nd1.Attributes.GetNamedItem("tbtype").Value = _childNode.Attributes["w-val"].Value;
                                            }
                                            catch (Exception ex)
                                            {
                                            }
                                        }
                                        else if (_childNode.Name == "w-bottom")
                                        {
                                            nd1.Attributes.Append(xmlEnt.CreateAttribute("bottom"));
                                            nd1.Attributes.GetNamedItem("bottom").Value = "true";
                                            try
                                            {
                                                nd1.Attributes.Append(xmlEnt.CreateAttribute("bbtype"));
                                                nd1.Attributes.GetNamedItem("bbtype").Value = _childNode.Attributes["w-val"].Value;
                                            }
                                            catch (Exception ex)
                                            {
                                            }
                                        }
                                        else if (_childNode.Name == "w-left")
                                        {
                                            nd1.Attributes.Append(xmlEnt.CreateAttribute("left"));
                                            nd1.Attributes.GetNamedItem("left").Value = "true";
                                            try
                                            {
                                                nd1.Attributes.Append(xmlEnt.CreateAttribute("lbtype"));
                                                nd1.Attributes.GetNamedItem("lbtype").Value = _childNode.Attributes["w-val"].Value;
                                            }
                                            catch (Exception ex)
                                            {
                                            }
                                        }
                                        else if (_childNode.Name == "w-right")
                                        {
                                            nd1.Attributes.Append(xmlEnt.CreateAttribute("right"));
                                            nd1.Attributes.GetNamedItem("right").Value = "true";
                                            try
                                            {
                                                nd1.Attributes.Append(xmlEnt.CreateAttribute("rbtype"));
                                                nd1.Attributes.GetNamedItem("rbtype").Value = _childNode.Attributes["w-val"].Value;
                                            }
                                            catch (Exception ex)
                                            {
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                    }
                                }
                            }
                        }
                    }
                }
                chstyle = "";

                // This blok need to confrim with vengal
                if (tmp.IndexOf("<chstyle>", 0) >= 0)
                {
                    chstyle = GetSubString(tmp, "<chstyle>", "</chstyle>", false);
                    tmp = tmp.Replace("<chstyle>", "").Replace("</chstyle>", "");
                    chstyle = chstyle.Replace("#colon;", ":");
                }
                else if (tmp.IndexOf("<char>", 0) >= 0)
                {
                    chstyle = ".";
                    tmp = tmp.Replace("<char>", "").Replace("</char>", "");
                }
                if (chstyle != "")
                {
                    nd1.Attributes.Append(xmlEnt.CreateAttribute("align"));
                    nd1.Attributes.GetNamedItem("align").Value = "char";
                    nd1.Attributes.Append(xmlEnt.CreateAttribute("char"));
                    nd1.Attributes.GetNamedItem("char").Value = chstyle;
                    tmp = tmp.Replace(GetSubString(tmp, "<ealign>", "</ealign>", true), "");
                }
                else if (tmp.IndexOf("<ealign>", 0) >= 0)
                {
                    chstyle = GetSubString(tmp, "<ealign>", "</ealign>", false);
                    tmp = tmp.Replace("<ealign>" + chstyle + "</ealign>", "");
                    nd1.Attributes.Append(xmlEnt.CreateAttribute("align"));
                    nd1.Attributes.GetNamedItem("align").Value = chstyle;
                }
                try
                {
                    nd1.InnerXml = tmp;
                    tmp = xmlEnt.OuterXml;
                }
                catch (Exception ex)
                {
                    if (xmlEnt.OuterXml != "")
                        tmp = xmlEnt.OuterXml.Replace("</td>", tmp + "</td>");
                    else
                        tmp = "<td>" + tmp + "</td>";
                }
                col += 1;
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
            return tmp;
        }



        public string GetStyleColorText(string tmp, bool sec, bool tbl, bool recv)
        {
            string tst = "";
            string pstyle = "";
            string tmp1 = "";
            string color = "";
            bool itc = false;
            bool bld = false;
            string label = "";
            string typ = "";
            string level = "";
            string listItem = "";
            int i;
            int j;
            int l;
            string headStyle = "";
            bool list = false;
            bool flg = false;
            bool lblflag = false;
            XmlDocument doc = new XmlDocument();
            System.Xml.XmlNode nd = null;
            string _headingLabel = "";
            try
            {


                // loop through each w-p tag and then get the text based on color and style
                while (tmp.IndexOf("<w-p>", 5) >= 0)
                {
                    tst = tmp.Substring(tmp.IndexOf("<w-p>", 5), tmp.IndexOf("</w-p>", tmp.IndexOf("<w-p>", 5)) - tmp.IndexOf("<w-p>", 5) + 6);
                    tmp = tmp.Replace(tst, GetStyleColorText(tst, sec, tbl, true));
                    tmp = tmp.Replace("<m:", "<m-").Replace("</m:", "</m-");
                    flg = true;
                }
                // loop through each w-p tag and then get the text based on color and style where tmp is stars with a comment
                while (tmp.IndexOf("<w-p ", 5) >= 0&&tmp.StartsWith("<w-comment") == false)
                {
                    tst = tmp.Substring(tmp.IndexOf("<w-p ", 5), tmp.IndexOf("</w-p>", tmp.IndexOf("<w-p ", 5)) - tmp.IndexOf("<w-p ", 5) + 6);
                    tmp = tmp.Replace(tst, GetStyleColorText(tst, sec, tbl, true));
                    tmp = tmp.Replace("<m:", "<m-").Replace("</m:", "</m-");
                    flg = true;
                }
                tmp = tmp.Replace("&", "&amp;");
                doc.PreserveWhitespace = true;
                doc.LoadXml(tmp);
                nd = doc.SelectSingleNode("//w-p");

                // loop through each para tag
                for (l = 0; l <= nd.ChildNodes.Count - 1; l++)
                {
                    switch (nd.ChildNodes[l].Name)
                    {
                        case "w-pPr":
                            {
                                // read the paragraph properties here using for loop
                                for (i = 0; i <= nd.ChildNodes[l].ChildNodes.Count - 1; i++)
                                {
                                    switch (nd.ChildNodes[l].ChildNodes[i].Name)
                                    {
                                        case "w-pStyle":
                                            {
                                                pstyle = nd.ChildNodes[l].ChildNodes[i].Attributes.GetNamedItem("w-val").Value;
                                                if (Regex.IsMatch(pstyle, @"head(ing)?[\s]?[0-9]", RegexOptions.IgnoreCase) == true)
                                                {
                                                    headStyle = pstyle.ToLower();
                                                    if (nd.ChildNodes[l].SelectSingleNode("./w-numPr/w-ilvl[@w-val='0']") != null&&nd.ChildNodes[l].SelectSingleNode("./w-numPr/w-numId[@w-val='0']") != null)
                                                        lblflag = false;
                                                    else
                                                    {
                                                        _headingLabel = GetLableforHeadings(pstyle.ToLower());
                                                        lblflag = true;
                                                    }
                                                }

                                                pstyle = GetTags("[" + pstyle + "]", true);
                                                if (Regex.IsMatch(pstyle, "<b>"))
                                                    bld = true;
                                                if (Regex.IsMatch(pstyle, "<i>"))
                                                    itc = true;

                                                break;
                                            }

                                        case "w-listPr":
                                            {
                                                if (nd.ChildNodes[l].ChildNodes[i].HasChildNodes)
                                                {
                                                    list = true;
                                                    for (j = 0; j <= nd.ChildNodes[l].ChildNodes[i].ChildNodes.Count - 1; j++)
                                                    {
                                                        if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Name == "wx-t")
                                                            label = nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Attributes.GetNamedItem("wx-val").Value;
                                                        if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Name == "wx-font")
                                                            typ = nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Attributes.GetNamedItem("wx-val").Value;
                                                        if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Name == "w-ilvl")
                                                            level = nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Attributes.GetNamedItem("w-val").Value;
                                                    }
                                                    if (typ == "Symbol")
                                                        tmp1 = tmp1 + "<list type=\"Bulleted\" level=\"" + level + "\"><list-item><label>&bull;</label>";
                                                    else
                                                        tmp1 = tmp1 + "<list type=\"Ordered\" level=\"" + level + "\"><list-item><label>" + label + "</label>";
                                                }
                                                break;
                                            }

                                        case "w-numPr":
                                            {
                                                if (nd.ChildNodes[l].ChildNodes[i].HasChildNodes)
                                                {
                                                    list = true;
                                                    for (j = 0; j <= nd.ChildNodes[l].ChildNodes[i].ChildNodes.Count - 1; j++)
                                                    {
                                                        if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Name == "w-numId")
                                                        {
                                                            label = nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Attributes.GetNamedItem("w-val").Value;
                                                            if (label == "0")
                                                            {
                                                                list = false;
                                                                if (lblflag == true)
                                                                    _headingLabel = GetLableforHeadings(headStyle, true);
                                                                headStyle = "";
                                                                _headingLabel = "";
                                                                break;
                                                            }
                                                            typ = label;
                                                        }
                                                        // If nd.ChildNodes(l).ChildNodes[i].ChildNodes(j).Name = "wx-font" Then
                                                        // typ = nd.ChildNodes(l).ChildNodes[i].ChildNodes(j).Attributes.GetNamedItem("wx-val").Value
                                                        // End If
                                                        if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Name == "w-ilvl")
                                                            level = nd.ChildNodes[l].ChildNodes[i].ChildNodes[j].Attributes.GetNamedItem("w-val").Value;
                                                    }
                                                    try
                                                    {
                                                        string id;
                                                        id = "numId=\"" + label + "\"";
                                                        try
                                                        {
                                                            label = lst.SelectSingleNode("//list[@id=" + label + "]/level[@id=" + level + "]").OuterXml;
                                                        }
                                                        catch (Exception ex)
                                                        {
                                                            label = "";
                                                        }
                                                        label = label.Replace("<level ", "<level " + id + " ");
                                                        if (label.Contains("numfmt=\"none\" text=\"%1\"") == true)
                                                            label = label.Replace("numfmt=\"none\" text=\"%1\"", "numfmt=\"none\" text=\"\"");
                                                        if (pstyle.IndexOf("<sectiontitle>", 0) >= 0)
                                                            list = false;
                                                        else
                                                        {
                                                            try
                                                            {
                                                                if (hsList.ContainsKey(level) == false)
                                                                    hsList.Add(level, typ);
                                                                else if (hsList.ContainsKey(level) == true&&hsList[level] != typ)
                                                                    hsList[level] = typ;
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                            }
                                                            listItem = "<list type=\"" + typ + "\" level=\"" + level + "\"><list-item><label>" + label + "</label><tab></tab><para>|</para></list-item></list>";
                                                            // listItem = "<list type="""&&typ&&""" level="""&&level&&"""><list-item><label>"&&label&&"</label><para>|</para></list-item></list type="""&&typ&&""" level="""&&level&&""">"
                                                            if (Convert.ToInt16(level, 10) > 0)
                                                            {
                                                                for (int lvl = Convert.ToInt16(level, 10) - 1; lvl >= 0; lvl += -1)
                                                                    // listItem = "<list type="""&&hsList(lvl.ToString())&&""" level="""&&lvl.ToString()&&""">"&&listItem&&"</list type="""&&hsList(lvl.ToString())&&""" level="""&&lvl&&""">"
                                                                    listItem = "<list type=\"" + hsList[lvl.ToString()] + "\" level=\"" + lvl.ToString() + "\">" + listItem + "</list>";
                                                            }
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        list = false;
                                                    }
                                                }

                                                break;
                                            }

                                        case "w-rPr":
                                            {
                                                if (nd.ChildNodes[l].ChildNodes[i].HasChildNodes)
                                                {
                                                    bld = false; itc = false;
                                                    // loop through each character property and get the details as below
                                                    for (int k = 0; k <= nd.ChildNodes[l].ChildNodes[i].ChildNodes.Count - 1; k++)
                                                    {
                                                        switch (nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Name)
                                                        {
                                                            case "w-rStyle":
                                                                {
                                                                    if (Regex.IsMatch(GetTags("[" + nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value + "]", false), "<b>"))
                                                                        bld = true;
                                                                    if (Regex.IsMatch(GetTags("[" + nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value + "]", false), "<i>"))
                                                                        itc = true;
                                                                    break;
                                                                }

                                                            case "w-b":
                                                                {
                                                                    if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.Count > 0)
                                                                    {
                                                                        try
                                                                        {
                                                                            if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value != "0")
                                                                                bld = true;
                                                                        }
                                                                        catch (Exception ex)
                                                                        {
                                                                        }
                                                                    }
                                                                    else
                                                                        bld = true;

                                                                    break;
                                                                }

                                                            case "w-i":
                                                                {
                                                                    if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.Count > 0)
                                                                    {
                                                                        try
                                                                        {
                                                                            if (nd.ChildNodes[l].ChildNodes[i].ChildNodes[k].Attributes.GetNamedItem("w-val").Value != "0")
                                                                                itc = true;
                                                                        }
                                                                        catch (Exception ex)
                                                                        {
                                                                        }
                                                                    }
                                                                    else
                                                                        itc = true;

                                                                    break;
                                                                }

                                                            case "w-color":
                                                                {
                                                                    // color = nd.ChildNodes(l).ChildNodes[i].ChildNodes(k).Attributes.GetNamedItem("w-val").Value
                                                                    // If color.ToLower() = "auto" Then
                                                                    // color = "000000"
                                                                    // End If
                                                                    // color = "[\red"&&Convertodec(color.Substring(0, 2)).ToString()&&"\green"&&Convertodec(color.Substring(2, 2)).ToString()&&"\blue"&&Convertodec(color.Substring(4, 2)).ToString()&&"]"
                                                                    // color = GetTags(color)
                                                                    // If color = "|" Then
                                                                    // color = ""
                                                                    // End If
                                                                    break;
                                                                }
                                                        }
                                                    }
                                                }
                                                break;
                                            }

                                        case "w-jc":
                                            {
                                                if (nd.ChildNodes[l].ChildNodes[i].Attributes.GetNamedItem("w-val").Value != "both" && tbl == true)
                                                    tmp1 = "<ealign>" + nd.ChildNodes[l].ChildNodes[i].Attributes.GetNamedItem("w-val").Value + "</ealign>" + tmp1;
                                                break;
                                            }
                                    }
                                }
                                break;
                            }

                        case "w-r":
                            {
                                tmp1 = tmp1 + GetText(nd.ChildNodes[l], tbl, level, tmp1);
                                break;
                            }

                        case "w-bookmarkStart":
                            {
                                try
                                {
                                    if ((nd.ChildNodes[l].Attributes["w-name"].Value.StartsWith("MEP_L_")))
                                    {
                                        // san on 16th
                                        if (tmp1.LastIndexOf("<") >= 0)
                                            tmp1 = tmp1.Insert(tmp1.LastIndexOf("<"), "<bkid id=\"" + nd.ChildNodes[l].Attributes[" w-name"].Value + "\"></bkid>");
                                        else
                                            tmp1 = tmp1 + "<bkid id=\"" + nd.ChildNodes[l].Attributes[" w-name"].Value + "\"></bkid>";
                                        tmp1 = Regex.Replace(tmp1, @"(<bkid id=""[^"">]+""></bkid>)(</cross-ref>\s*)", "$2$1");
                                    }
                                }
                                catch (Exception ex)
                                {
                                }
                                break;
                            }

                        case "m_oMathPara":
                            {
                                for (i = 0; i <= nd.ChildNodes[l].ChildNodes.Count - 1; i++)
                                {
                                    switch (nd.ChildNodes[l].ChildNodes[i].Name)
                                    {
                                        case "math":
                                            {
                                                tmp1 = tmp1 + nd.ChildNodes[l].ChildNodes[i].OuterXml;
                                                break;
                                            }
                                    }
                                }
                                break;
                            }

                        case "math":
                            {
                                tmp1 = tmp1 + nd.ChildNodes[l].OuterXml;
                                break;
                            }

                        case "w-dir":
                            {
                                tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
                                break;
                            }

                        case "w-ins":
                            {
                                tmp1 = tmp1 + "<!--ins-->" + wrow(nd.ChildNodes[l], tbl) + "<!--/ins-->";
                                break;
                            }

                        case "w-del":
                            {
                                tmp1 = tmp1 + "<!--del-->" + wrow(nd.ChildNodes[l], tbl) + "<!--/del-->";
                                break;
                            }
                        case "img":
                            {
                                tmp1 = tmp1 + nd.ChildNodes[l].OuterXml;
                                break;
                            }
                        default:
                            {
                                if (nd.ChildNodes[l].Name.IndexOf("st1-", 0) == 0)
                                    tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
                                else if (nd.ChildNodes[l].SelectNodes("//w-r").Count > 0)
                                    tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
                                break;
                            }
                    }
                }
                if (pstyle == "|"&&list == false)
                    pstyle = "";
                // if there is no color style and not a list or table then make it as a para
                if (color == ""&&pstyle == ""&&list == false&&tbl == false)
                    pstyle = "<div>|</div>";
                // if the list is true then remove "|" character
                if (list == true)
                {
                    if (bld == true)
                        pstyle = pstyle.Replace("|", "<b>|</b>");
                    if (itc == true)
                        pstyle = pstyle.Replace("|", "<i>|</i>");
                    tmp1 = listItem.Replace("|", tmp1);
                    if (pstyle == "<para>|</para>")
                        pstyle = "";
                }
            }
            catch (Exception e)
            {
                tmp1 = tmp;
            }
            // if the color was found the repalce the|| with the text
            if (tmp1 == ""&&color != "")
                tmp1 = color.Replace("|", tmp1);
            // if the para style was found the repalce the|| with the text
            if (tmp1 != ""&&pstyle != "")
            {
                if (bld == false && Regex.IsMatch(pstyle, "<b>|</b>"))
                    pstyle = pstyle.Replace("<b>|</b>", "|");
                if (itc == false && Regex.IsMatch(pstyle, "<i>|</i>"))
                    pstyle = pstyle.Replace("<i>|</i>", "|");
                tmp1 = pstyle.Replace("|", tmp1.Trim());
            }
            else if (pstyle != ""&&pstyle != "<div>|</div>"&&tmp1 == "")
                tmp1 = pstyle.Replace("|", tmp1.Trim());
            // this is to generate the section labels
            if (_headingLabel.Length > 0)
            {
                if (tmp1.IndexOf("<label>", 0) < 0)
                {
                    tmp1 = Regex.Replace(tmp1, "(<head(ing)?[0-9]>)", "$1<label>" + _headingLabel + "</label><tab></tab>");
                    if (bld)
                        tmp1 = Regex.Replace(tmp1, "(<head(ing)?[0-9]>)(.*?)(</head(ing)?[0-9]>)", "$1<b>$3</b>$4");
                    if (itc)
                        tmp1 = Regex.Replace(tmp1, "(<head(ing)?[0-9]>)(.*?)(</head(ing)?[0-9]>)", "$1<i>$3</i>$4");
                }
            }
            bld = false;
            itc = false;
            // tmp1.Replace("</label><div></div></list-item>", "</label><div></div></list-item>")
            return tmp1;
        }

        public string GetLableforHeadings(string headingName, bool isReduct = false)
        {
            try
            {
                string label = "";

                HeadingListStruct _headingObj = new HeadingListStruct();
                HeadingListStruct tempHeadingObj = new HeadingListStruct();
                int headingLevel;
                if (headingName == "")
                    return "";
                if (_outlevelValue.ContainsKey(headingName) == true)
                    headingLevel = _outlevelValue[headingName];
                else
                    return "";
                if (_headingStructHash.ContainsKey(headingLevel) == true)
                    _headingObj = _headingStructHash[headingLevel];
                else
                    return "";
                // _headingObj = _headingStructHash(headingLevel)
                if (isReduct == true)
                {
                    _headingObj.current = _headingObj.current - 1;
                    _headingStructHash[headingLevel] = _headingObj;
                    // ResetHeadingLevels(headingLevel + 1, 8)
                    return "";
                }
                string tempLabel = "";
                tempLabel = _headingObj.text;

                if (_headingStructHash.Count == 0)
                    return label;

                // if the heading level is 0 then it will get the heading lable details and will reset the below levels
                if (_headingObj.level == 0)
                {
                    // label = _headingObj.initalLabel&&_headingObj.delim&&ChecktheFormatandGetLabel(ref _headingObj)
                    // tempLabel = tempLabel.Substring(tempLabel.LastIndexOf("%"))
                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%1", _headingObj.headingLabel); // .text.Substring(0, _headingObj.text.IndexOf("%"))&&Regex.Replace(tempLabel, "%[a-zA-Z0-9]+", ChecktheFormatandGetLabel(ref _headingObj))

                    ResetHeadingLevels(1, 8);
                }
                else if (_headingObj.level == 1)
                {
                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = _headingObj.text.Replace("%1", tempHeadingObj.headingLabel);
                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%2", _headingObj.headingLabel);
                    ResetHeadingLevels(2, 8);
                }
                else if (_headingObj.level == 2)
                {
                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = _headingObj.text.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%3", _headingObj.headingLabel);
                    ResetHeadingLevels(3, 8);
                }
                else if (_headingObj.level == 3)
                {
                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = _headingObj.text.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%4", _headingObj.headingLabel);
                    ResetHeadingLevels(4, 8);
                }
                else if (_headingObj.level == 4)
                {
                    tempHeadingObj = _headingStructHash[3];
                    tempLabel = _headingObj.text.Replace("%4", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = tempLabel.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%5", _headingObj.headingLabel);
                    ResetHeadingLevels(5, 8);
                }
                else if (_headingObj.level == 5)
                {
                    tempHeadingObj = _headingStructHash[4];
                    tempLabel = _headingObj.text.Replace("%5", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[3];
                    tempLabel = tempLabel.Replace("%4", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = tempLabel.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%6", _headingObj.headingLabel);
                    ResetHeadingLevels(5, 8);
                }
                else if (_headingObj.level == 6)
                {
                    tempHeadingObj = _headingStructHash[5];
                    tempLabel = _headingObj.text.Replace("%6", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[4];
                    tempLabel = tempLabel.Replace("%5", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[3];
                    tempLabel = tempLabel.Replace("%4", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = tempLabel.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%7", _headingObj.headingLabel);
                    ResetHeadingLevels(7, 8);
                }
                else if (_headingObj.level == 7)
                {
                    tempHeadingObj = _headingStructHash[6];
                    tempLabel = _headingObj.text.Replace("%7", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[5];
                    tempLabel = tempLabel.Replace("%6", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[4];
                    tempLabel = tempLabel.Replace("%5", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[3];
                    tempLabel = tempLabel.Replace("%4", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = tempLabel.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%8", _headingObj.headingLabel);
                    ResetHeadingLevels(8, 8);
                }
                else if (_headingObj.level == 8)
                {
                    tempHeadingObj = _headingStructHash[7];
                    tempLabel = _headingObj.text.Replace("%8", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[6];
                    tempLabel = tempLabel.Replace("%7", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[5];
                    tempLabel = tempLabel.Replace("%6", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[4];
                    tempLabel = tempLabel.Replace("%5", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[3];
                    tempLabel = tempLabel.Replace("%4", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[2];
                    tempLabel = tempLabel.Replace("%3", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[1];
                    tempLabel = tempLabel.Replace("%2", tempHeadingObj.headingLabel);

                    tempHeadingObj = _headingStructHash[0];
                    tempLabel = tempLabel.Replace("%1", tempHeadingObj.headingLabel);

                    _headingObj.headingLabel = ChecktheFormatandGetLabel(ref _headingObj);
                    label = tempLabel.Replace("%9", _headingObj.headingLabel);
                }
                _headingStructHash[headingLevel] = _headingObj;

                return label;
            }
            catch (Exception ex)
            {
            }
            return "";
        }

        public XmlElement GetListLabel(XmlNode node, ref XmlDocument doc)
        {
            int intCnt;
            int intCount;
            int intCnt1;
            bool isLabelExist = false;
            bool isLabel = true;
            XmlElement elem = doc.CreateElement("label"); // Creating label element into DOM
            for (intCnt = 0; intCnt <= node.ChildNodes.Count - 1; intCnt++)
            {
                if (node.ChildNodes[intCnt].Name == "w-pPr")
                {
                    for (intCount = 0; intCount <= node.ChildNodes[intCnt].ChildNodes.Count - 1; intCount++)
                    {
                        if (node.ChildNodes[intCnt].ChildNodes[intCount].Name == "w-listPr")
                        {
                            for (intCnt1 = 0; intCnt1 <= node.ChildNodes[intCnt].ChildNodes[intCount].ChildNodes.Count - 1; intCnt1++)
                            {
                                if (node.ChildNodes[intCnt].ChildNodes[intCount].ChildNodes[intCnt1].Name == "wx-t")
                                {
                                    elem.Attributes.Append(doc.CreateAttribute("val")); // Create the val attribute for label element
                                    isLabelExist = true;
                                }
                                else if (node.ChildNodes[intCnt].ChildNodes[intCount].ChildNodes[intCnt1].Name == "wx-font")
                                    elem.Attributes.Append(doc.CreateAttribute("font"));// Create font attribut for label element
                            }
                        }
                    }
                }
                else if (isLabelExist == true&&node.ChildNodes[intCnt].Name == "label")
                {
                    elem.InnerXml = node.ChildNodes[intCnt].InnerXml;
                    node.ReplaceChild(elem, node.ChildNodes[intCnt]); // Replace the wordml tag element with schema element
                    isLabel = false;
                    break;
                }
            }
            if (isLabel == true&&isLabelExist == true)
            {
                string val = string.Empty;
                // Change the utf32 character to unicode entity character
                string fnt = string.Empty;
                // val = GlobalFunctions.ReadAttributeValue(elem, "val")

                if (val.Length == 1&&Strings.Trim(val) != "")
                {
                    // fnt = GlobalFunctions.ReadAttributeValue(elem, "font")
                    if (fnt != "Times New Roman"&&fnt != "Arial Unicode MS")
                        fnt = Cnfunctions.GetEntity(this.hsEntity, fnt, char.ConvertToUtf32(val, 0).ToString());
                    else if (Regex.IsMatch(val, "[0-9a-zA-Z]", RegexOptions.Singleline) == false)
                        fnt = Conversion.Hex(Convert.ToString(char.ConvertToUtf32(val, 0), 16));
                    else
                        fnt = val;
                    elem.InnerXml = fnt.Replace("&", "#amp;");
                    try
                    {
                        elem.Attributes.RemoveNamedItem("val");
                        elem.Attributes.RemoveNamedItem("font");
                    }
                    catch (Exception ex)
                    {
                    }
                }
                if (node.ChildNodes.Count > 0)
                    node.InsertBefore(elem, node.FirstChild);
                else
                    node.AppendChild(elem);
            }
            return node as XmlElement;
        }

        public void LoadFootEndNotes(XmlDocument doc)
        {
            XmlNodeList ndl;
            System.Xml.XmlNode nd;
            int i;
            int id = 1;
            string format = "";
            string tmp = "";
            int startNum = 1;
            try
            {
                fnHash.Clear();
                enHash.Clear();
                nd = doc.SelectSingleNode("//w-footnotePr/w-numFmt");

                // get the footnote format here
                if (nd != null)
                    format = nd.Attributes.GetNamedItem("w-val").Value;
                if (doc.SelectSingleNode("//w-footnotePr/w-numStart") != null)
                    startNum = Convert.ToInt32(doc.SelectSingleNode("//w-footnotePr/w-numStart").Attributes.GetNamedItem("w-val").Value);
                ndl = doc.SelectNodes("//w-footnote");
                // Dim _chicagoCount As Integer = 0
                string bkid = "";
                int normalfootCount = 1;
                int customfootCount = 1;
                // fnHashbk.Clear()
                // enHashbk.Clear()
                if (startNum > 1)
                    normalfootCount = startNum;
                // loop trhough each footnote and ....
                for (i = 0; i <= ndl.Count - 1; i++)
                {

                    // if the footnoteRef was found then....
                    if (ndl[i].SelectSingleNode(".//w-footnoteRef") != null)
                    {
                        // check the w-d attribute is present then
                        if (Convert.ToInt32(ndl[i].Attributes.GetNamedItem("w-id").Value) > 0)
                        {
                            bkid = "";
                            if (Regex.IsMatch(ndl[i].InnerXml, @"<w-bookmarkStart w-id=""[0-9]+"" w-name=""fn[0-9a-z]+""\s?/\s?>") == true)
                                bkid = Regex.Match(ndl[i].InnerXml, @"<w-bookmarkStart w-id=""[0-9]+"" w-name=""fn([0-9a-z]+)""\s?/\s?>").Groups[1].Value;
                            // check the format, like lower, upper , roman etc and then load the id values in to the hash table
                            if (format == "lowerLetter")
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetAlphaFootnote(normalfootCount).ToLower());
                            else if (format == "upperLetter")
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetAlphaFootnote(normalfootCount));
                            else if (format == "upperRoman")
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, Cnfunctions.ConvertToRoman(normalfootCount));
                            else if (format == "lowerRoman")
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, Cnfunctions.ConvertToRoman(normalfootCount).ToLower());
                            else if (format == "chicago")
                                // _chicagoCount += 1
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetSymbolFootnote(normalfootCount));
                            else
                                fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, normalfootCount.ToString());
                            // If bkid <> "" Then
                            // fnHashbk.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, bkid)
                            // Else
                            // fnHashbk.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, id)
                            // End If
                            normalfootCount += 1;
                            id += 1;
                        }
                    }
                    else if (Convert.ToInt32(ndl[i].Attributes.GetNamedItem("w-id").Value) > 0 && ndl[i].OuterXml.IndexOf(" w-type=\"continuationNotice\" ", 0) < 0)
                    {
                        if (fnHash.ContainsKey(ndl[i].Attributes.GetNamedItem("w-id").Value) == false)
                        {
                            tmp = "";
                            try
                            {
                                tmp = ndl[i].SelectSingleNode("./w-p/w-r/w-rPr/w-rStyle[@w-val='FootnoteReference']").ParentNode.ParentNode.InnerText;
                            }
                            catch (Exception ex)
                            {
                                if (tmp == "")
                                {
                                    try
                                    {
                                        tmp = ndl[i].SelectSingleNode("./w-p/w-r[1]").InnerText;
                                    }
                                    catch (Exception ex1)
                                    {
                                        tmp = customfootCount.ToString();
                                    }
                                }
                            }
                            fnHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, tmp);
                            // fnHashbk.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, id)
                            id += 1;
                            customfootCount += 1;
                        }
                    }
                }
                id = 1;
                nd = doc.SelectSingleNode("//w-endnotePr/w-numFmt");
                // get the endnote format here
                if (nd != null)
                    format = nd.Attributes.GetNamedItem("w-val").Value;
                if (doc.SelectSingleNode("//w-endnotePr/w-numStart") != null)
                    startNum = Convert.ToInt32(doc.SelectSingleNode("//w-endnotePr/w-numStart").Attributes.GetNamedItem("w-val").Value);
                normalfootCount = 1;
                customfootCount = 1;
                ndl = doc.SelectNodes("//w-endnote");
                if (startNum > 1)
                    normalfootCount = startNum;
                for (i = 0; i <= ndl.Count - 1; i++)
                {
                    // if the w-endoteref element is found then
                    if (ndl[i].SelectSingleNode(".//w-endnoteRef") != null)
                    {
                        // check the format, like lower, upper ,and then load the id values in to the hash table
                        if (Convert.ToInt32(ndl[i].Attributes.GetNamedItem("w-id").Value) > 0)
                        {
                            bkid = "";
                            if (Regex.IsMatch(ndl[i].InnerXml, @"<w-bookmarkStart w-id=""[0-9]+"" w-name=""en[0-9a-z]+""\s?/\s?>") == true)
                                bkid = Regex.Match(ndl[i].InnerXml, @"<w-bookmarkStart w-id=""[0-9]+"" w-name=""en([0-9a-z]+)""\s?/\s?>").Groups[1].Value;
                            // check the format, like lower, upper , roman etc and then load the id values in to the hash table
                            if (format == "lowerLetter")
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetAlphaFootnote(normalfootCount).ToLower());
                            else if (format == "upperLetter")
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetAlphaFootnote(normalfootCount));
                            else if (format == "upperRoman")
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, Cnfunctions.ConvertToRoman(normalfootCount));
                            else if (format == "lowerRoman")
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, Cnfunctions.ConvertToRoman(normalfootCount).ToLower());
                            else if (format == "chicago")
                                // _chicagoCount += 1
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, GetSymbolFootnote(normalfootCount));
                            else
                                enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, normalfootCount.ToString());
                            if (bkid != "")
                            {
                            }
                            else
                            {
                            }
                            normalfootCount += 1;
                            id += 1;
                        }
                    }
                    else if (Convert.ToInt32(ndl[i].Attributes.GetNamedItem("w-id").Value) > 0 && ndl[i].OuterXml.IndexOf(" w-type=\"continuationNotice\" ", 0) < 0)
                    {
                        if (enHash.ContainsKey(ndl[i].Attributes.GetNamedItem("w-id").Value) == false)
                        {
                            tmp = "";
                            try
                            {
                                tmp = ndl[i].SelectSingleNode("./w-p/w-r/w-rPr/w-rStyle[@w-val='EndnoteReference']").ParentNode.ParentNode.InnerText;
                            }
                            catch (Exception ex)
                            {
                                if (tmp == "")
                                {
                                    try
                                    {
                                        tmp = ndl[i].SelectSingleNode("./w-p/w-r[1]").InnerText;
                                    }
                                    catch (Exception ex1)
                                    {
                                        tmp = customfootCount.ToString();
                                    }
                                }
                            }
                            enHash.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, tmp);
                            // enHashbk.Add(ndl[i].Attributes.GetNamedItem("w-id").Value, id)
                            id += 1;
                            customfootCount += 1;
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }


        public bool GetStartlableforHeadings()
        {
            try
            {
                string initalLable = string.Empty;
                XDocument _lstDoc=new XDocument();

				if (lst != null)
                {



                   _lstDoc = XDocument.Parse(lst.OuterXml);
                    headingId = _ListHeading["heading 1"];
                    headingInitalLable = _lstDoc.Descendants("list").Where(k => k.Attribute("id").Value == headingId).First().Descendants("level").Where(e => e.Attribute("id").Value == _outlevelValue["heading1"].ToString()).First().Attribute("text").Value;
                }

                    headingInitalLable = headingInitalLable.Substring(0, headingInitalLable.IndexOf("%"));

                    // get the delim between the lables(h1 and h2 etc)
                    if (headingInitalLable.EndsWith(" "))
                    {
                        headingLabledelim = " ";
                        headingInitalLable = headingInitalLable.Trim();
                    }
                    else if (headingInitalLable.EndsWith("."))
                    {
                        headingLabledelim = ".";
                        headingInitalLable = headingInitalLable.Replace(".", "");
                    }

                    ICollection keys = _headingStructHash.Keys;
                    int[] keysArray = new int[_headingStructHash.Count - 1 + 1];
                    keys.CopyTo(keysArray, 0);

                    string headingleveltext = string.Empty;
                    HeadingListStruct headingObj;

                    // loop through each heading details and store in the structure varialbe..
                    for (int level = 0; level <= Information.UBound(keysArray); level++)
                    {
                        try
                        {
                            headingObj = _headingStructHash[keysArray[level]];

                            headingObj.text = _lstDoc.Descendants("list").Where(k => k.Attribute("id").Value == headingId).First()
                                                 .Descendants("level").Where(e => e.Attribute("id").Value == headingObj.level.ToString()).First()
                                                 .Attribute("text").Value;

                            headingObj.start = Convert.ToInt32(_lstDoc.Descendants("list").Where(k => k.Attribute("id").Value == headingId).First()
                                                .Descendants("level").Where(e => e.Attribute("id").Value == headingObj.level.ToString()).First()
                                                .Attribute("start").Value);

                            headingObj.numFrmt = _lstDoc.Descendants("list").Where(k => k.Attribute("id").Value == headingId).First()
                                               .Descendants("level").Where(e => e.Attribute("id").Value == headingObj.level.ToString()).First()
                                               .Attribute("numfmt").Value;

                            headingObj.initalLabel = headingObj.text.Substring(0, headingObj.text.IndexOf("%")).Replace("%", "");
                            if (headingObj.initalLabel == "")
                            {
                                if (headingObj.text.Substring(1) == "." || headingObj.text.Substring(1) == "," || headingObj.text.Substring(1) == " " || headingObj.text.Substring(1) == ";" || headingObj.text.Substring(1) == ":")
                                    headingObj.initalLabel = headingObj.text.Substring(1);
                            }

                            headingObj.current = headingObj.start;

                            // get the delim between the lables(h1 and h2 etc)
                            if (headingObj.initalLabel.EndsWith(" "))
                            {
                                headingObj.delim = " ";
                                headingObj.initalLabel = headingObj.initalLabel.Trim();
                            }
                            else if (headingObj.initalLabel.EndsWith("."))
                            {
                                headingObj.delim = ".";
                                headingObj.initalLabel = headingObj.initalLabel.Replace(".", "");
                            }
                            _headingStructHash[keysArray[level]] = headingObj;
                        }
                        // HeadingListStartNumber.Add(headinglevel, CInt(initalLable))
                        // HeadingOccurance.Add(headinglevel.Replace(" ", ""), CInt(initalLable))
                        // _headingLabel.Add(headinglevel.Replace(" ", ""), "")
                        catch (Exception ex)
                        {
                        }
                    }
                
            }
            catch (Exception ex)
            {
            }
            return true;
        }

        public System.Xml.XmlNode ListXMLGeneration(System.Xml.XmlNode ndr1)
        {
            string str = "";
            XmlDocument lst = new XmlDocument();
            XmlDocument lstout = new XmlDocument();
            XmlNodeList ndl;
            XmlNodeList nds;
            System.Xml.XmlNode nd = null;
            System.Xml.XmlNode n1;
            XmlElement ele;
            XmlElement ele1;
            int intCnt;
            int intCount;
            lst.PreserveWhitespace = true;
            if (ndr1 != null)
            {
                try
                {
                    lst.PreserveWhitespace = true; lst.LoadXml(ndr1.OuterXml);
                    lstout.LoadXml("<lists></lists>");
                    ndl = lst.SelectNodes("//w-num/w-abstractNumId");
                    nd = lstout.SelectSingleNode("//lists");

                    // loop through the each list and create id attribute and ....
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        ele = lstout.CreateElement("list");
                        ele.Attributes.Append(lstout.CreateAttribute("id"));
                        ele.Attributes.GetNamedItem("id").Value = ndl[intCnt].ParentNode.Attributes.GetNamedItem("w-numId").Value;
                        if (ndl[intCnt].ParentNode.SelectNodes("./w-lvlOverride").Count > 0&&ndl[intCnt].ParentNode.SelectNodes("./w-lvlOverride/w-lvl").Count > 0)
                            nds = ndl[intCnt].ParentNode.SelectNodes("./w-lvlOverride/w-lvl");
                        else
                            nds = lst.SelectNodes("//w-abstractNum[@w-abstractNumId=" + ndl[intCnt].Attributes.GetNamedItem("w-val").Value + "]/w-lvl");
                        try
                        {
                            if (nds.Count == 0&&lst.SelectSingleNode("//w-numStyleLink") != null)
                            {
                                n1 = ndr1.SelectSingleNode("//w-styles/w-style[@w-styleId='" + lst.SelectSingleNode("//w-numStyleLink").Attributes.GetNamedItem("w-val").Value + "']//w-numPr/w-numId");
                                n1 = lst.SelectSingleNode("//w-num[@w-numId='" + n1.Attributes.GetNamedItem("w-val").Value + "']/w-abstractNumId");
                                nds = lst.SelectNodes("//w-abstractNum[@w-abstractNumId=" + n1.Attributes.GetNamedItem("w-val").Value + "]/w-lvl");
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                        // loop through each node and create level element and...
                        for (intCount = 0; intCount <= nds.Count - 1; intCount++)
                        {
                            ele1 = lstout.CreateElement("level");
                            ele1.Attributes.Append(lstout.CreateAttribute("id"));
                            ele1.Attributes.GetNamedItem("id").Value = nds[intCount].Attributes.GetNamedItem("w-ilvl").Value;

                            // loop through each child node...
                            foreach (System.Xml.XmlNode nd1 in nds[intCount].ChildNodes)
                            {

                                // if thechild node is w-start then create attribute of start
                                if (nd1.LocalName == "w-start")
                                {
                                    ele1.Attributes.Append(lstout.CreateAttribute("start"));
                                    ele1.Attributes.GetNamedItem("start").Value = nd1.Attributes.GetNamedItem("w-val").Value;
                                }
                                else if (nd1.LocalName == "w-numFmt")
                                {
                                    ele1.Attributes.Append(lstout.CreateAttribute("numfmt"));
                                    ele1.Attributes.GetNamedItem("numfmt").Value = nd1.Attributes.GetNamedItem("w-val").Value;
                                }
                                else if (nd1.LocalName == "w-lvlText")
                                {
                                    ele1.Attributes.Append(lstout.CreateAttribute("text"));
                                    ele1.Attributes.GetNamedItem("text").Value = nd1.Attributes.GetNamedItem("w-val").Value;
                                }
                                else if (nd1.LocalName == "w-rPr")
                                {
                                    // loop through each child node and...
                                    foreach (System.Xml.XmlNode nd2 in nd1.ChildNodes)
                                    {
                                        // If the child node is w-rFonts then create a attribute of font...
                                        if (nd2.LocalName == "w-rFonts")
                                        {
                                            ele1.Attributes.Append(lstout.CreateAttribute("font"));
                                            // if the ascii is found in the childnote then set the font vale
                                            if (nd2.OuterXml.IndexOf(" w-ascii=", 0) >= 0)
                                                ele1.Attributes.GetNamedItem("font").Value = nd2.Attributes.GetNamedItem("w-ascii").Value;
                                        }
                                    }
                                }
                                if (ele1.OuterXml.Contains(" font=") == false)
                                    ele1.Attributes.Append(lstout.CreateAttribute("font"));
                            }
                            if (ele1.HasAttribute("start") == false)
                            {
                                ele1.Attributes.Append(lstout.CreateAttribute("start"));
                                ele1.Attributes.GetNamedItem("start").Value = "1";
                            }
                            ele.InnerXml = ele.InnerXml + ele1.OuterXml;
                        }
                        nd.InnerXml = nd.InnerXml + ele.OuterXml;
                    }
                    str = lstout.OuterXml;
                }
                catch (Exception e)
                {
                }
            }
            return nd;
        }










        //small functions 

        public string GetSymbolFootnote(int intFoot)
        {
            string strTemp = "";
            int intCnt;
            try
            {
                string[] arr = new string[4];
                arr[0] = "#macamp;#x002A;";
                arr[1] = "#macamp;#x2020;";
                arr[2] = "#macamp;#x2021;";
                arr[3] = "#macamp;#x00A7;";
                if (intFoot <= 4)
                    strTemp = arr[intFoot - 1].ToString();
                else
                {
                    string tmp = "";
                    if (((intSymCnt + 1) % 5) == 0)
                        intTimes = intTimes + 1;
                    intFoot = intFoot % 4;
                    if ((intFoot == 0))
                        intFoot = 4;
                    tmp = arr[intFoot - 1].ToString();
                    for (intCnt = 0; intCnt <= intTimes; intCnt++)
                        strTemp = strTemp + tmp;
                    intSymCnt = intSymCnt + 1;
                }
            }
            catch
            {
            }
            return strTemp;
        }


        public bool ResetHeadingLevels(int st, int ed)
        {
            try
            {
                HeadingListStruct _headingObj;
                HeadingListStruct tempHeadingObj = _headingStructHash[0];

                // loop through each heading and set the start value to the predefind value
                for (int i = st; i <= ed; i++)
                {
                    try
                    {
                        _headingObj = _headingStructHash[i];
                        if (tempHeadingObj.initalLabel == _headingObj.initalLabel)
                        {
                            _headingObj.current = _headingObj.start;
                            _headingStructHash[i] = _headingObj;
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return true;
        }


        public string ChecktheFormatandGetLabel(ref HeadingListStruct _headingObj)
        {
            try
            {

                // In the below conditions it will check that, the format was upper, lower lettet or upper , lower Roman or decimal and will create the label accordingly
                string _label = "";
                _label = _headingObj.current.ToString();
                if (_headingObj.numFrmt == "upperLetter")
                    _label = GetAlphaFootnote(_headingObj.current);
                else if (_headingObj.numFrmt == "lowerLetter")
                    _label = GetAlphaFootnote(_headingObj.current).ToLower();
                else if (_headingObj.numFrmt == "lowerRoman")
                    _label = Cnfunctions.ConvertToRoman(_headingObj.current).ToLower();
                else if (_headingObj.numFrmt == "upperRoman")
                    _label = Cnfunctions.ConvertToRoman(_headingObj.current);
                else if (_headingObj.numFrmt == "decimal")
                    _label = _headingObj.current.ToString();
                _headingObj.current = _headingObj.current + 1;
                return _label;
            }
            catch (Exception ex)
            {
            }
            return "";
        }
        public string GetAlphaFootnote(int intFoot)
        {
            string strTemp = "";
            int intTimes;
            int intCnt;

            // if the number is < then convert to char
            if (intFoot <= 26)
                strTemp = Convert.ToChar(intFoot + 64).ToString();
            else
            {
                // otherwise get the value by dividing the number by 26 and getting the reminder of the number
                string tmp = "";
                intTimes = Convert.ToInt32(intFoot / (double)26);
                intFoot = intFoot % 26;
                tmp = Convert.ToChar(intFoot + 64).ToString();
                // loop the number of thimes that was divided and add th char value that many times
                for (intCnt = 0; intCnt <= intTimes; intCnt++)
                    strTemp = strTemp + tmp;
            }
            return strTemp;
        }



        public string GetAttribVal(System.Xml.XmlNode nd, string strAttrib)
        {
            // loop through each attribute and match with the required one and return
            for (int intCnt = 0; intCnt <= nd.Attributes.Count - 1; intCnt++)
            {
                if (nd.Attributes[intCnt].Name.ToLower() == strAttrib.ToLower())
                    return nd.Attributes[intCnt].Value;
            }
            return "";
        }


        public string GetSubString(string SR1, string StartTag, string EndTag, bool inclu)
        {
            string temp = "";
            string temp1 = "";
            bool flg = false;

            // loop through each character and find the starttag
            for (int i = 0; i <= SR1.Length - 1; i++)
            {

                // if the starttag was found first time then make the flag true
                if (temp1 == StartTag&&flg == false)
                {
                    temp = "";
                    flg = true;
                }
                temp1 += SR1[i];
                temp += SR1[i];
                // If the current char is "<" then make temp1 as "<"
                if (SR1[i] == '<')
                    temp1 = "<";

                // If temp1 is the end tag char then replace the endtag char with empty in temp
                if (temp1 == EndTag)
                {
                    temp = temp.Replace(EndTag, "");
                    break;
                }

                // If  temp has the charset of ">>>" then throw error
                if (temp.IndexOf(">>>", 0) >= 0)
                {
                }
            }
            if (inclu == true)
                return StartTag + temp + EndTag;
            else
                return temp;
        }


        public string GetFontTag(string cstyle)
        {
            string tmp = "";

            // get the font tag details here
            if (hsfont.ContainsKey(cstyle) == true)
                tmp = hsfont[cstyle].ToString();
            else
                // if the fontname was not times new roman and cstyle has  alpha charecters then return the fotname as error tag
                if (cstyle != "Times New Roman"&&System.Text.RegularExpressions.Regex.IsMatch(cstyle, "[^a-zA-Z0-9 ]") == false)
            {
                // If frmMain.isBlackBox <> 1 And XmlParam.isBB = False Then
                // tmp = "<Fonterror-"&&cstyle.Replace(" \", "")&&">|</Fonterror-"&&cstyle.Replace("\", "")&&">"
                tmp = "<" + cstyle.Replace(@"\", "") + ">|</" + cstyle.Replace(@"\", "") + ">";
                tmp = tmp.Replace("[", "").Replace("]", "");
            }
            tmp = tmp.Replace(" ", "-");
            return tmp;
        }


        public string GetBorderTags(string cstyle)
        {
            string tmp = "";
            cstyle = cstyle.ToLower();

            // if the border value was found the return the tags
            if (hBorderTag.ContainsKey(cstyle) == true)
                tmp = hBorderTag[cstyle].ToString();
            else
            {
            }
            tmp = tmp.Replace(" ", "-");
            return tmp;
        }


        public string GetShadeTags(string cstyle)
        {
            string tmp = "";
            cstyle = cstyle.ToLower();

            // if the shade applied was found in the hashtable will return the tag
            if (hShadeTag.ContainsKey(cstyle) == true)
                tmp = hShadeTag[cstyle].ToString();
            else
            {
            }
            tmp = tmp.Replace(" ", "-");
            return tmp;
        }


        public string GetTags(string cstyle, bool isPara = false)
        {
            string tmp = "";
            string tempstyle = "";

            // get the cstyle ID based on the paramete passed
            if (hStyleIDTag.ContainsKey(cstyle) == true)
                cstyle = hStyleIDTag[cstyle];


            // If the styleid was present in the hash table then
            if (hStyleTag.ContainsKey("[" + Regex.Replace(cstyle.ToLower(), "[^A-Za-z0-9]", "") + "]") == true)
            {
                cstyle = System.Text.RegularExpressions.Regex.Replace(cstyle, @"[^a-zA-Z0-9\-_]", "");
                if (isPara == true)
                {
                    if (cstyle.ToLower().Contains("head"))
                    {
                        tmp = hStyleTag["[" + cstyle.ToLower() + "]"];
                        tmp = tmp.Replace("[", "").Replace("]", "");
                    }
                    else
                    {
                        tmp = hStyleTag["[" + cstyle.ToLower() + "]"];
                        tmp = tmp.Replace("[", "").Replace("]", "");
                        //tmp = Regex.Replace(Regex.Replace(tmp, @"[^a-zA-Z0-9<>|/\-_]", "").ToLower(), @"(<\/?)" + Regex.Replace(cstyle, @"[^a-zA-Z0-9\-_]", "").ToLower() + ">", "cstylediv>");
                    }
                }
                else
                {
                    // tmp = "<errortag-"&&cstyle.Replace("\", "").Replace(" ", "")&&">|</errortag-"&&cstyle.Replace("\", "").Replace(" ", "")&&">"
                    // tmp = "<"&&cstyle.Replace("\", "").Replace(" ", "")&&">|</"&&cstyle.Replace("\", "").Replace(" ", "")&&">"
                    // tmp = tmp.Replace("[", "").Replace("]", "")
                    tmp = hStyleTag["[" + cstyle.ToLower() + "]"];
                    tmp = tmp.Replace("[", "").Replace("]", "");
                }
            }
            else if (cstyle.Contains(@"[\superscript]"))
                tmp = "<sup>|</sup>";
            else if (cstyle.Contains(@"[\subscript]"))
                tmp = "<sub>|</sub>";
            else
            {
                cstyle = System.Text.RegularExpressions.Regex.Replace(cstyle, @"[^a-zA-Z0-9\-_]", "");
                if (isPara == true)
                {
                    if (cstyle.ToLower().Contains("head"))
                        tmp = "<" + cstyle + ">|</" + cstyle + ">";
                    else
                        tmp = "<div>|</div>";
                }
                else
                {
                    // tmp = "<errortag-"&&cstyle.Replace("\", "").Replace(" ", "")&&">|</errortag-"&&cstyle.Replace("\", "").Replace(" ", "")&&">"

                    //commented by logesh need to confirm 27-06-2023
                    //tmp = "<" + cstyle.Replace(@"\", "").Replace(" ", "") + ">|</" + cstyle.Replace(@"\", "").Replace(" ", "") + ">";
                    //tmp = tmp.Replace("[", "").Replace("]", "");
                }
            }
            // make the tagdetails empty here if the tag contains below details
            if (tmp.Contains("annotation text") || tmp.Contains("annotationtext"))
                tmp = "";
            // If tmp.Contains("<errortag-red") And XmlParam.tblclr = False Then
            // tmp = ""
            // End If
            // If tmp.IndexOf(" pos=""float""", 0) < 0 Then
            // tmp = tmp.Replace(" ", "-")
            // End If
            return tmp;
        }


        public string wrow(XmlNode nd, bool tbl)
        {
            // Picking the addressess from the wordxml file
            string tmp1 = "";
            int l;
            for (l = 0; l <= nd.ChildNodes.Count - 1; l++)
            {
                if (nd.ChildNodes[l].Name.IndexOf("st1-", 0) == 0)
                    tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
                else if (nd.ChildNodes[l].Name == "w-r")
                    tmp1 = tmp1 + GetText(nd.ChildNodes[l], tbl, "", "");
                else if (nd.ChildNodes[l].Name == "w-ruby")
                    tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
                else
                    tmp1 = tmp1 + wrow(nd.ChildNodes[l], tbl);
            }
            return tmp1;
        }


        public string GetSymbol(XmlNode nd, string wdType)
        {
            string str = "";
            string label = "";
            string typ = "";
            if (nd != null)
            {
                if (wdType == "wx")
                {
                    label = nd.Attributes.GetNamedItem("wx-font").Value;
                    typ = nd.Attributes.GetNamedItem("wx-char").Value;
                }
                else if (wdType == "w")
                {
                    label = nd.Attributes.GetNamedItem("w-font").Value;
                    typ = nd.Attributes.GetNamedItem("w-char").Value;
                }
                if ((Cnfunctions.GetEntity(this.hsEntity, label, typ) != "&undeclared;"))
                    str = str + Cnfunctions.GetEntity(this.hsEntity, label, typ);
                else
                    str = str + Cnfunctions.GetEntity(this.hsEntity, "0" + label.Substring(1), typ);
            }
            return str.Replace("&", "#amp;");
        }


        private bool IsUnderline(XmlNode xmlEle)
        {
            try
            {
                if (xmlEle.Attributes.Count == 0)
                    return true;
                else if ((xmlEle.Attributes.Count == 1))
                {
                    if (xmlEle.Attributes[0].Name == "w-color")
                        return false;
                    else if (ReadAttributeValue(xmlEle, "w-val") != "off"&&ReadAttributeValue(xmlEle, "w-val") != "none")
                        return true;
                }
                else if (ReadAttributeValue(xmlEle, "w-val") != "off"&&ReadAttributeValue(xmlEle, "w-val") != "none")
                    return true;
            }
            catch (Exception ex)
            {
            }
            return false;
        }


        public static string ReadAttributeValue(XmlNode xmlNode, string attribName)
        {
            string attribValue = "";
            try
            {
                foreach (XmlAttribute attribute in xmlNode.Attributes)
                {
                    if (attribute.Name.ToLower() == attribName.ToLower())
                    {
                        attribValue = attribute.Value.ToString();
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return attribValue;
        }


        private bool CleanUp(ref string str)
        {
            try
            {
                str = Regex.Replace(str, @"<div\s?/>", "");
                str = str.Replace("</b><b>", "").Replace("</i><i>", "");
                str = str.Replace("</sup><sup>", "").Replace("</sub><sub>", "");
                foreach (string key in hCharStyle.Keys)
                {
                    str = str.Replace("</" + key + "><" + key + ">", "");
                    str = str.Replace("</" + key + "> <" + key + ">", " ");
                }
                str = Regex.Replace(str, @"(<\/?([Hh]yperlink|w-hyperlink)[^<>]*>)", "");

                str = Regex.Replace(str, @"(<\/?)w-", "$1"); // Remove all w- in all tags
            }

            catch (Exception ex)
            {
            }
            return true;
        }



    }
}
