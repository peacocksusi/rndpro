﻿using Doc2HTML.Common;
using Doc2HTML.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Reflection.Metadata;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Utils.Common;
using Utils.Logger;
using static Utils.Common.CustomConstant;

namespace Docx2HTML.Service
{


    public class wdmlDocument
    {

        private readonly IConfiguration configuration;
        private readonly ILoggerService logger;
        private readonly ICustomConstant customConstant;
        public wdmlDocument(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        private XDocument xDocBodyHtmlNode = new XDocument();
        private XmlDocument plainHtmlNode = new XmlDocument();
        private string plainHtmlContent = "";
        private string listContent = "";
        private string styleContent = "";
        private string footNoteContent = "";
        private string endNoteContent = "";
        private string assetLinksContent = "";
        private XDocument xmlFullTextNode = new XDocument();
        private XDocument figureTeiNode = new XDocument();
        public string docxFileName = "";
        private string homePath = "";
        private string outPath = "";
        public string message = "";
        public string uniqueNumber = "";
        public Dictionary<string, string> BodyElements = new Dictionary<string, string>();
        public Dictionary<string, string> hsEntity = new Dictionary<string, string>();



        public void StartUp(string uniqueNumber)
        {
            //new CustomConstant();
            this.uniqueNumber = uniqueNumber;

            homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);

            outPath = Cnfunctions.GetModifiedPath(customConstant.HTML_OUTPATH, uniqueNumber, customConstant);
            this.docxFileName = Cnfunctions.setDocxFileName(homePath);

            try
            {
                

                this.docxFileName = Cnfunctions.setDocxFileName(this.homePath);

                setDocXmlContents();
                generalCleanup();
               



            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }

        }



        public void MathOperation()
        {
            try
            {
                MathOperation mathOperation = new MathOperation(this.plainHtmlContent,this.hsEntity);
                mathOperation.ConvertOOML2MML();
                this.plainHtmlContent = mathOperation.plainHtmlContent;
                this.plainHtmlNode.LoadXml(this.plainHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }
        }

        public void InsertImage() {

            try
            {
                XmlDocument assetsLinksDoc = new XmlDocument();
                assetsLinksDoc.LoadXml(this.assetLinksContent);

                XmlNodeList imageNodeList = this.plainHtmlNode.SelectNodes("//w-p/w-r[w-drawing]");
                foreach (XmlNode imageNode in imageNodeList)
                {

                    string content = Regex.Replace(imageNode.InnerXml, @"(</?[a-z0-9]*):[a-zA-Z0-9]*([ >/])", "$1$2");
                    content = content.Replace("xmlns:", "xmlns-");
                    content = content.Replace("r:", "r-");
                    //content = Cnfunctions.RemoveAttributes(content, "xmlns");
                    //content = Cnfunctions.RemoveAttributes(content, "xmlns-r");
                    imageNode.InnerXml = content;
                    if (imageNode.SelectSingleNode("//pic/a[@r-embed]") != null)
                    {
                    string imgId = imageNode.SelectSingleNode("//pic/a[@r-embed]").Attributes.GetNamedItem("r-embed").Value;

                    string imgPath = assetsLinksDoc.SelectSingleNode("//*[@Id='"+imgId+"']").Attributes.GetNamedItem("Target").Value;

                    imgPath = (imgPath.StartsWith("/") ? "../wordml" : "../wordml/word/")+imgPath;

                    XmlNode newImgNode =Cnfunctions.CreateNode(ref this.plainHtmlNode,"img");

                    Cnfunctions.CreateAttribute(ref this.plainHtmlNode, ref newImgNode, "src",imgPath);
                    Cnfunctions.CreateAttribute(ref this.plainHtmlNode, ref newImgNode, "class", "displaygraphic");

                    imageNode.ParentNode.ReplaceChild(newImgNode, imageNode);
                    }


                }
                imageNodeList = this.plainHtmlNode.SelectNodes("//img");
                foreach (XmlNode imageNode in imageNodeList)
                {
                    if (imageNode.ParentNode.NextSibling != null)
                    {

                    imageNode.ParentNode.NextSibling.InsertBefore(imageNode, imageNode.ParentNode.NextSibling.FirstChild); 
                    }
                }

                this.plainHtmlContent = this.plainHtmlNode.OuterXml;
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + ex.Message);
                throw;
            }
        }

        public void GetBodyTextStyle()
        {
            try
            {

           
            BodyTextStyler bodyTextStyler = new BodyTextStyler(this.plainHtmlContent,this.hsEntity);
           bodyTextStyler.GetBodyTextStyle(this.plainHtmlContent,this.listContent,this.footNoteContent,this.endNoteContent,this.styleContent);
            this.plainHtmlContent = bodyTextStyler.plainHtmlContent;
            this.plainHtmlNode.LoadXml(this.plainHtmlContent);
            }
            catch (Exception ex)
            {

                this.logger.LogError(ex.Message);
            }

        }   
        
        public void FormatContent()
        {
            FormatContent formatContent = new FormatContent(this.plainHtmlContent,this.hsEntity);
            formatContent.formatContent(ref this.plainHtmlContent);
            this.plainHtmlNode.LoadXml(this.plainHtmlContent);

        }


        public void FormatHTML()
        {
            string str = this.plainHtmlContent;
            XmlElement xEle;
            string sTmp;
            XmlNodeList xTmpElesLst;

            try
            {
                // Table formating
                str = Regex.Replace(str, @"<colspec[^<>\/]+\s?/>", "");
                str = Regex.Replace(str, @"<tbody>([\s\S]*?)</tbody>", "<table>$1</table>");
                str = Regex.Replace(str, @"<\/?tgroup[^<>]*>", "");
                str = Regex.Replace(str, "<td[^<>]+>", "<td>");
                str = Regex.Replace(str, @"<!--\/?[^<>]+>", "");

                // Replace headings class
                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//*[starts-with(name(),'head')]");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                {
                    if (Regex.IsMatch(xTmpElesLst[i].Name, @"head[^0-9]*[0-9]+\b") == false)
                        continue;
                    xEle = this.plainHtmlNode.CreateElement("div");
                    xEle.Attributes.Append(this.plainHtmlNode.CreateAttribute("class"));
                    xEle.Attributes.GetNamedItem("class").Value = "sectiontitle";
                    xEle.Attributes.Append(this.plainHtmlNode.CreateAttribute("id"));
                    xEle.Attributes.GetNamedItem("id").Value = Regex.Match(xTmpElesLst[i].Name, "head([^0-9]*)([0-9]+)").Groups[2].Value;
                    xEle.InnerXml = xTmpElesLst[i].InnerXml;
                    xTmpElesLst[i].ParentNode.ReplaceChild(xEle, xTmpElesLst[i]);
                }
                str = this.plainHtmlNode.OuterXml;

                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//*[starts-with(name(),'head')][descendant::label]");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                {
                    xEle = this.plainHtmlNode.CreateElement("div");
                    xEle.Attributes.Append(this.plainHtmlNode.CreateAttribute("class"));
                    xEle.Attributes.GetNamedItem("class").Value = "sectiontitle";
                    xEle.Attributes.Append(this.plainHtmlNode.CreateAttribute("id"));
                    xEle.Attributes.GetNamedItem("id").Value = xTmpElesLst[i].SelectSingleNode(".//label").InnerXml.ToString();
                    xTmpElesLst[i].ParentNode.ReplaceChild(xEle, xTmpElesLst[i]);
                }
                str = this.plainHtmlNode.OuterXml;

                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//div[@class='sectiontitle'][not(descendant::label)]");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                {
                    if (!Regex.IsMatch(xTmpElesLst[i].InnerText.Trim(), "^[0-9]+"))
                    {
                        if (xTmpElesLst[i].Attributes.GetNamedItem("id") != null)
                            xTmpElesLst[i].Attributes.RemoveNamedItem("id");
                        if (xTmpElesLst[i].Attributes.GetNamedItem("class") != null)
                            xTmpElesLst[i].Attributes.GetNamedItem("class").Value = "";
                    }
                }
                str = this.plainHtmlNode.OuterXml;

                // Para class
                str = Regex.Replace(str, "<div>(.+)</div>", "<div class=\"para\">$1</div>");

                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//div[@class='sectiontitle']/list");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                    xTmpElesLst[i].ParentNode.InnerXml = Regex.Replace(xTmpElesLst[i].ParentNode.InnerXml, @"<\/?(list-item|list)>", "");
                str = this.plainHtmlNode.OuterXml;

                // Merge the list-item for first list
                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//div/list");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                {
                    try
                    {
                        if (xTmpElesLst[i].ParentNode.NextSibling.FirstChild != null && xTmpElesLst[i].ParentNode.NextSibling.FirstChild.Name == "list")
                            xTmpElesLst[i].ParentNode.InsertAfter(this.plainHtmlNode.CreateComment("dellist"), xTmpElesLst[i]);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                str = this.plainHtmlNode.OuterXml;
                str = Regex.Replace(str,"<!--dellist--></div><div>", "<!--dellist-->",RegexOptions.Singleline);
                str = str.Replace("</list><!--dellist--><list>", "");

                this.plainHtmlNode.PreserveWhitespace = true; this.plainHtmlNode.LoadXml(str);
                xTmpElesLst = this.plainHtmlNode.SelectNodes("//list");
                for (var i = 0; i <= xTmpElesLst.Count - 1; i++)
                {
                    try
                    {
                        xEle = Cnfunctions.CreateNode(ref this.plainHtmlNode, "ul");
                        Cnfunctions.CreateAttribute(ref this.plainHtmlNode, ref xEle, "style", "list-style-type:none");
                        sTmp = xTmpElesLst[i].InnerXml;
                        sTmp = Regex.Replace(sTmp, @"(<\/?)list-item(>)", "$1li$2");
                        sTmp = Regex.Replace(sTmp, "<label>(.+?)</label>", "<span class=\"label\">$1</span>");
                        sTmp = Regex.Replace(sTmp, @"<\/?para>", "");
                        xEle.InnerXml = sTmp;
                        xTmpElesLst[i].ParentNode.ReplaceChild(xEle, xTmpElesLst[i]);
                    }
                    catch (Exception ex)
                    {
                    }
                }
                str = this.plainHtmlNode.OuterXml;


                str = Regex.Replace(str, @"<\/?(head[^char]+char>)", "");
                str = Regex.Replace(str, @"<\/?(emphasis|grek|subtleemphasis)>", "");
                str = Regex.Replace(str, "<cr( [^<>]+)>(.+?)</cr>", "<xref$1>$2</xref>");
                str = Regex.Replace(str, "<(div|u|b)[^>]+/>", "");
                str = Regex.Replace(str, "</?tab>", " ");
                str = Regex.Replace(str, @"</(u|i|b)><\1>", " ");
                while (Regex.IsMatch(str, @"<(div|u|i|b)[^<>]*></\1>"))
                    str = Regex.Replace(str, @"<(div|u|i|b)[^<>]*></\1>", "");
                while (Regex.IsMatch(str, "<(div|u|i|b)\b[^>]*/>"))
                    sTmp = Regex.Replace(str, "<(div|u|i|b)\b[^>]*/>", "");

                str = Regex.Replace(str, "(</?)Heading1>", "$1div>");

				this.plainHtmlContent = str;
				this.plainHtmlNode.LoadXml(this.plainHtmlContent);
			}
            catch (Exception ex)
            {
                throw;
            }
            
        }


        public void FinalCleanUp()
        {
            try
            {
            this.plainHtmlContent = Regex.Replace(this.plainHtmlContent, "(</[a-z]+)[^>]*>","$1>");
                this.plainHtmlNode.LoadXml(this.plainHtmlContent);
            }
            catch (Exception ex)
            {
                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }

        }





        public void setDocXmlContents()
        {
            try
            {
                string documentXmlFilePath = getWordFolderPath(this.homePath) + @"\word\document.xml";
                string ListFilePath = getWordFolderPath(this.homePath) + @"\word\numbering.xml";
                string StylesFilePath = getWordFolderPath(this.homePath) + @"\word\styles.xml";
                string FootnoteFilePath = getWordFolderPath(this.homePath) + @"\word\footnotes.xml";
                string EndNoteFilePath = getWordFolderPath(this.homePath) + @"\word\endnotes.xml";
                string AssetLinksFilePath = getWordFolderPath(this.homePath) + @"\word\_rels\document.xml.rels";

                this.plainHtmlContent = Cnfunctions.GetContentFromFile(documentXmlFilePath);
                this.plainHtmlNode.LoadXml(this.plainHtmlContent);
                LoadEntities();
                this.listContent = Cnfunctions.GetContentFromFile(ListFilePath);
                this.styleContent = Cnfunctions.GetContentFromFile(StylesFilePath);
                this.footNoteContent = Cnfunctions.GetContentFromFile(FootnoteFilePath);
                this.endNoteContent = Cnfunctions.GetContentFromFile(EndNoteFilePath);
                this.assetLinksContent = Cnfunctions.GetContentFromFile(AssetLinksFilePath);
                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " set document xml files content completed");
            }
            catch (Exception ex)
            {

                this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
                throw;
            }
        }

        public void generalCleanup()
        {
            this.plainHtmlContent = this.plainHtmlContent.Replace("|", "#pipe;");
            this.plainHtmlContent = this.plainHtmlContent.Replace("<pkg:", "<pkg-").Replace("< pkg:", "</pkg-");
            this.plainHtmlContent = this.plainHtmlContent.Replace("<Relationships xmlns=\" http: schemas.openxmlformats.org package 2006 relationships\">", "<Relationships>");

            //this.plainHtmlContent = Regex.Replace(this.plainHtmlContent, @"(</?\w+):", "$1-");
            //while (Regex.IsMatch(this.plainHtmlContent, @"(<[^>]+ \w+):"))
            //{

            //    this.plainHtmlContent = Regex.Replace(this.plainHtmlContent, @"(<[^>]+ \w+):", "$1-");
            //}

            this.plainHtmlContent = commonReplace(this.plainHtmlContent);


            //custom cleanup 

            this.plainHtmlContent = Regex.Replace(this.plainHtmlContent, @"(<w-p\s[^>]+)/>", "$1></w-p>");

            //this.plainHtmlContent = Cnfunctions.RemoveNameSpace(this.plainHtmlContent);
            //due to comment document 111 contains instrText conatains json (need to check)
            {
                //XDocument xdoc = new XDocument();
                //xdoc = XDocument.Parse(this.plainHtmlContent);
                //IEnumerable<XElement> fileTextElements = xdoc.XPathSelectElements("//w-p[.//w-fldChar]//w-instrText");
                //foreach (XElement fileTextElement in fileTextElements)
                //{
                //    fileTextElement.Name = "w-t";
                //}
                //this.plainHtmlContent = xdoc.ToString();
            }
            //this.plainHtmlContent = this.plainHtmlContent.Replace("MACROBUTTON NoMacro","");
            this.listContent = commonReplace(this.listContent);
            this.footNoteContent = commonReplace(this.footNoteContent);
            this.endNoteContent = commonReplace(this.endNoteContent);
            this.styleContent = commonReplace(this.styleContent);
        }

        public void finalPostCleanup()
        {
            XDocument plainHtmlXNode = new XDocument();
            plainHtmlXNode = XDocument.Parse(this.plainHtmlContent);

            IEnumerable<XElement> divElements = plainHtmlXNode.XPathSelectElements("//article/*");

            foreach (XElement item in divElements)
            {
                string tagName = item.Name.ToString().ToLower();
                if (tagName != "div"&&tagName!="table"&&!tagName.StartsWith("fig"))
                {
                    item.Name = "div";
                }
            }

            this.plainHtmlContent=plainHtmlXNode.ToString();
            this.plainHtmlNode.LoadXml(this.plainHtmlContent);

        }
        public bool LoadEntities()
        {
            if (hsEntity.Count > 0)
                return true;

            try
            {
                hsEntity.Clear();
                XmlDocument styleMappingNode = new XmlDocument();
                string styleMappingPath = Directory.GetCurrentDirectory() + "//Resources//StyleMapping.xml";
                string styleMappingContent = Cnfunctions.GetContentFromFile(styleMappingPath);
                styleMappingNode.PreserveWhitespace = true; styleMappingNode.LoadXml(styleMappingContent);
                XDocument doc = new XDocument();
                if (styleMappingNode.SelectSingleNode("//entitygroup") != null)
                {
                    doc = XDocument.Parse(styleMappingNode.SelectSingleNode("//entitygroup").OuterXml);
                    foreach (XElement xEle in doc.Descendants().Where(p => p.HasElements == false))
                    {
                        int keyint = 0;
                        string keyname = xEle.Attribute("FontName").Value + "|" + xEle.Attribute("Position").Value;
                        while (hsEntity.ContainsKey(keyname))
                        {
                            keyname = xEle.Attribute("FontName").Value + "|" + xEle.Attribute("Position").Value + keyint;
                            keyint += 1;
                        }
                        hsEntity.Add(keyname, xEle.Attribute("HexaDecimal").Value);
                    }
                }
              


                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string commonReplace(string xmlContent)
        {
            for (int i = 0; i < customConstant.COMMON_REPLACE_TEXT_LIST.ToArray().Length; i++)
            {
                ReplaceTextArrayModel elem = customConstant.COMMON_REPLACE_TEXT_LIST.ToArray()[i];
                xmlContent = xmlContent.Replace(elem.findValue, elem.replaceValue);
            }
            return xmlContent;
        }


       





        public string getWordFolderPath(string path)
        {
            string returnVal = Path.Combine(path,"wordml"); return returnVal;
        }







        public void generatePlainHtml()
        {
            
            Cnfunctions.CreateHTML(this.outPath, this.plainHtmlContent, "Plain_Html.html");
            //Cnfunctions.CreateHTML(outPath, this.this.bodyHtmlNode.CreateNavigator().OuterXml, "body.html");
            this.message = this.uniqueNumber + " " + this.docxFileName + " Plain_Html file generated";
        }


    }
}
