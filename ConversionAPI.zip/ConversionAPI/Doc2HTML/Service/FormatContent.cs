﻿using Microsoft.VisualBasic;
using System.Collections;
using System.Text.RegularExpressions;
using System.Xml;
using Utils.Common;

namespace Doc2HTML.Service
{
    public class FormatContent
    {
        public string plainHtmlContent = "";
        public Dictionary<string, string> hsEntity = new Dictionary<string, string>();

        Hashtable DeleteTags = new Hashtable();
        Hashtable _fontTags = new Hashtable();

        public struct ListLevel
        {
            public int startNo;
            public string format;
            public int currentValue;
            public int ListId;
            public string numfrmt;
        }

        public struct ListItems
        {
            public int numId;
            public ListLevel[] level;
        }


        public FormatContent(string plainHtmlContent, Dictionary<string, string> hsEntity)
        {



            if (plainHtmlContent != null)
            {
                this.plainHtmlContent = plainHtmlContent;
                this.hsEntity = hsEntity;
            }
            else
            {
                throw new Exception(Cnfunctions.GetExceptionMethodName() + "plainHtmlContent is Null");
            }
        }

        public void formatContent(ref string xmlContent)
        {
            try
            {
                Listorder(ref xmlContent);
                xmlContent = ChangeFontTagsToEntities(xmlContent);
            }
            catch (Exception ex)
            {
            }
        }



        public string Listorder(ref string xmlContent)
        {
            XmlDocument secdoc = new XmlDocument();
            // This function will read List in wordML and create list ordering and continuation
            XmlNodeList ndl;
            int intCnt;
            string tmp = "";
            Hashtable ListOccurance = new Hashtable();
            string ListId;
            int level;
            secdoc.PreserveWhitespace = true;
            try
            {
                xmlContent = xmlContent.Replace("<tablist>", "<list>").Replace("</tablist>", "</list>");
                xmlContent = GroupingListItem(xmlContent);
                secdoc.PreserveWhitespace = true; secdoc.LoadXml(xmlContent);
                // Dim _levelHash As New Hashtable
                ndl = secdoc.SelectNodes("//label/level[@numfmt='bullet']");
                // loop through each level with numfrmt is bullet
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    // add the try catch for exception handling
                    try
                    {
                        // get the entity value if the font is not Times new roman and ArialUnicodeMS
                        if (ndl[intCnt].Attributes.GetNamedItem("font").Value != "Times New Roman"&&ndl[intCnt].Attributes.GetNamedItem("font").Value != "Arial Unicode MS")
                            tmp =Cnfunctions.GetEntity(this.hsEntity,ndl[intCnt].Attributes.GetNamedItem("font").Value, Convert.ToString(char.ConvertToUtf32(ndl[intCnt].Attributes.GetNamedItem("text").Value, 0), 16).ToUpper());
                        else
                            try
                            {
                                // Otherwise get the text value in Hexadecimal format, if the text attr vaue > 0
                                if (ndl[intCnt].Attributes.GetNamedItem("text").Value.Length > 0)
                                    tmp =Cnfunctions.Hex(Convert.ToString(char.ConvertToUtf32(ndl[intCnt].Attributes.GetNamedItem("text").Value, 0), 16));
                                else
                                    // otherswise get the entity through function
                                    tmp =Cnfunctions.GetEntity(this.hsEntity,ndl[intCnt].Attributes.GetNamedItem("font").Value, Convert.ToString(char.ConvertToUtf32(ndl[intCnt].Attributes.GetNamedItem("text").Value, 0), 16).ToUpper());
                            }
                            catch (Exception ex)
                            {
                                tmp =Cnfunctions.GetEntity(this.hsEntity,ndl[intCnt].Attributes.GetNamedItem("font").Value, Convert.ToString(char.ConvertToUtf32(ndl[intCnt].Attributes.GetNamedItem("text").Value, 0), 16).ToUpper());
                            }
                        tmp = tmp.Replace("&", "#macamp;");
                        // If _levelHash.ContainsKey(ndl(pos).OuterXml.Trim) = False Then
                        // _levelHash.Add(ndl(pos).OuterXml.Trim, tmp)
                        // End If
                        ndl[intCnt].ParentNode.InnerXml = tmp;
                    }
                    catch (Exception ex)
                    {
                    }
                }


                ndl = secdoc.SelectNodes("//list/list-item/label/level[@numfmt='none']|//list/list-item/label/level[@numfmt='decimal']|//list/list-item/label/level[@numfmt='lowerRoman']|//list/list-item/label/level[@numfmt='upperRoman']|//list/list-item/label/level[@numfmt='lowerLetter']|//list/list-item/label/level[@numfmt='upperLetter']");
                // Store the list label information list number wise as well as level wise for each list
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    try
                    {
                        ListId = ndl[intCnt].Attributes.GetNamedItem("numId").Value;
                        level = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("id").Value);
                        // check the listId is already present in the has table, if not add the id and mark it as first list
                        if (ListOccurance.ContainsKey(ListId) == false)
                        {
                            ListItems lstItem = new ListItems();
                            lstItem.level=new ListLevel[1];

                            lstItem.numId = Convert.ToInt32(ListId);
                            lstItem.level[level].ListId = Convert.ToInt32(ListId);
                            lstItem.level[level].currentValue = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                            lstItem.level[level].format = ndl[intCnt].Attributes.GetNamedItem("text").Value;
                            lstItem.level[level].startNo = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                            lstItem.level[level].numfrmt = ndl[intCnt].Attributes.GetNamedItem("numfmt").Value;
                            ListOccurance.Add(ListId, lstItem);
                        }
                        else
                        {
                            // othrwise mark it as last with the attribute
                            ListItems lstItem;
                            lstItem =(ListItems) ListOccurance[ListId];
                            lstItem.level[level].ListId = Convert.ToInt32(ListId);
                            lstItem.level[level].currentValue = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                            lstItem.level[level].format = ndl[intCnt].Attributes.GetNamedItem("text").Value;
                            lstItem.level[level].startNo = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                            lstItem.level[level].numfrmt = ndl[intCnt].Attributes.GetNamedItem("numfmt").Value;
                            ListOccurance[ListId] = lstItem;
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
                // loop through each level with numfrmt as decimal or roman or letters and add the text value as innerxml for the parent
                for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                {
                    ListId = ndl[intCnt].Attributes.GetNamedItem("numId").Value;
                    level = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("id").Value);
                    // check the listId is already present in the has table, if not add the id and mark it as first list
                    if (ListOccurance.ContainsKey(ListId) == true)
                    {
                        ListItems lstItem;
                        lstItem = (ListItems)ListOccurance[ListId];
                        if (ndl[intCnt].Attributes.GetNamedItem("numfmt").Value.ToLower() == "none")
                        {
                            if (ndl[intCnt].Attributes.GetNamedItem("font").Value != ""&&ndl[intCnt].Attributes.GetNamedItem("font").Value != "Times New Roman")
                                tmp =Cnfunctions.GetEntity(this.hsEntity,ndl[intCnt].Attributes.GetNamedItem("font").Value, Convert.ToString(char.ConvertToUtf32(ndl[intCnt].Attributes.GetNamedItem("text").Value, 0), 16).ToUpper());
                            else
                                tmp = ndl[intCnt].Attributes.GetNamedItem("text").Value.Trim();
                            if (Regex.Match(tmp, "%[0-9]").Success == false)
                                tmp = tmp.Replace("&", "#macamp;");
                            else
                                tmp = "";
                        }
                        else
                            tmp = getLabelText(ref lstItem, level);
                        lstItem.level[level].currentValue = lstItem.level[level].currentValue + 1;
                        ResetNextLevel(ref lstItem, level);
                    }
                    else
                    {
                        // othrwise mark it as last with the attribute
                        ListItems lstItem;
                        lstItem =(ListItems) ListOccurance[ListId];
                        if (lstItem.numId.ToString() == ListId)
                            lstItem.level[level].currentValue = lstItem.level[level].currentValue + 1;
                        else
                        {
                            lstItem.level[level].currentValue = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                            lstItem.level[level].format = ndl[intCnt].Attributes.GetNamedItem("text").Value;
                            lstItem.level[level].startNo = Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("start").Value);
                        }
                        ListOccurance[ListId] = lstItem;
                    }
                    ndl[intCnt].ParentNode.InnerXml = tmp;
                }
                xmlContent = secdoc.OuterXml;
            }
            catch (Exception ex)
            {
            }
            xmlContent = Regex.Replace(xmlContent, @"<list\s[^>]+>", "<list>");
            xmlContent = xmlContent.Replace("<list></list>", "");
            return xmlContent;
        }


        public string GroupingListItem(string xmlContent)
        {
            XmlDocument secdoc = new XmlDocument();
            XmlNodeList ndl;
            System.Xml.XmlNode nd;
            System.Xml.XmlNode nds = null;
            int intCnt;
            bool sublistend;
            int cnt;
            bool flgmove;
            int level;
            secdoc.PreserveWhitespace = true;

            try
            {
                for (level = 0; level <= 8; level++)
                {
                    secdoc.PreserveWhitespace = true; secdoc.LoadXml(xmlContent);
                    ndl = secdoc.SelectNodes("//list[@level='" + level + "' and @type]");
                    // to process each list with the same level items collect and count the nodes
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        cnt = 0;
                        sublistend = false;
                        flgmove = false;
                        if (ndl[intCnt].NextSibling != null)
                            nds = ndl[intCnt].NextSibling;
                        else
                            nds = null;
                        while (nds != null)
                        {
                            // checking the next sibling of nodes related to move inside list item
                            if (nds.Name == "list")
                            {
                                try
                                {
                                    if (ndl[intCnt].Attributes.GetNamedItem("type").Value == nds.Attributes.GetNamedItem("type").Value&&System.Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("level").Value) == System.Convert.ToInt32(nds.Attributes.GetNamedItem("level").Value))
                                    {
                                        // to validate the list level and the type of list has to match
                                        flgmove = true;
                                        break;
                                    }
                                    else if (System.Convert.ToInt32(ndl[intCnt].Attributes.GetNamedItem("level").Value) < System.Convert.ToInt32(nds.Attributes.GetNamedItem("level").Value))
                                        cnt = cnt + 1;
                                    else
                                        break;
                                }
                                catch (Exception ex)
                                {
                                }
                            }
                            else
                                break;

                            if (nds.NextSibling != null)
                                nds = nds.NextSibling;
                            else
                                break;
                        }

                        if (flgmove == true&&cnt > 0)
                        {
                            // move the siblings inside the list item
                            nds = ndl[intCnt].NextSibling;
                            while (nds != null)
                            {
                                if (nds.Name == "list"|| cnt > 0)
                                {
                                    ndl[intCnt].InsertAfter(nds.Clone(), ndl[intCnt].LastChild);
                                    nds.ParentNode.RemoveChild(nds);
                                    cnt = cnt - 1;
                                }
                                else
                                    break;
                                if (ndl[intCnt].NextSibling != null)
                                    nds = ndl[intCnt].NextSibling;
                                else
                                    break;
                                if (cnt <= 0)
                                    break;
                            }
                        }
                    }
                    xmlContent = secdoc.OuterXml;

                    try
                    {
                        secdoc.PreserveWhitespace = true; secdoc.LoadXml(xmlContent);
                        ndl = secdoc.SelectNodes("//list[@level='" + level + "' and @type]");
                        // to make the single list if the sequence of list items
                        for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                        {
                            nds = ndl[intCnt];
                            while (nds.NextSibling != null)
                            {
                                nds = nds.NextSibling;
                                if (nds.NodeType == XmlNodeType.Element)
                                {
                                    if (nds.Name == "list"&&nds.Attributes.Count > 1)
                                    {
                                        if (ndl[intCnt].Attributes.GetNamedItem("level").Value == nds.Attributes.GetNamedItem("level").Value&&ndl[intCnt].Attributes.GetNamedItem("type").Value == nds.Attributes.GetNamedItem("type").Value)
                                        {
                                            if (nds.InnerText != "")
                                            {
                                                foreach (XmlNode xnd in nds.ChildNodes)
                                                {

                                                    ndl[intCnt].InsertAfter(xnd.Clone(), ndl[intCnt].LastChild);
                                                }
                                                nds.ParentNode.RemoveChild(nds);
                                            }
                                            else if (nds.InnerXml.IndexOf("<label>", 0) >= 0)
                                            {
                                                foreach (XmlNode xnd in nds.ChildNodes)
                                                {
                                                    ndl[intCnt].InsertAfter(xnd.Clone(), ndl[intCnt].LastChild);

                                                }
                                                nds.ParentNode.RemoveChild(nds);
                                            }
                                            nds = ndl[intCnt];
                                        }
                                        else
                                            break;
                                    }
                                    else
                                        break;
                                }
                                else
                                    break;
                            }
                        }
                        xmlContent = secdoc.OuterXml;
                    }
                    catch (Exception ex)
                    {
                    }
                }
                try
                {
                    secdoc.PreserveWhitespace = true; secdoc.LoadXml(xmlContent);
                    ndl = secdoc.SelectNodes("//li");
                    // to make the single list if the sequence of list items
                    for (intCnt = 0; intCnt <= ndl.Count - 1; intCnt++)
                    {
                        while (ndl[intCnt].NextSibling != null)
                        {
                            if (ndl[intCnt].NextSibling.Name != "li")
                                ndl[intCnt].InsertAfter(ndl[intCnt].NextSibling, ndl[intCnt].LastChild);
                            else
                                break;
                        }
                    }
                    xmlContent = secdoc.OuterXml;
                }
                catch (Exception ex)
                {
                }
            }
            catch (Exception ex)
            {
            }
            return xmlContent;
        }




        public string ChangeFontTagsToEntities(string xmlcontent)
        {
            XmlDocument _xmldoc = new XmlDocument();
            string tmp = "";
            _xmldoc.PreserveWhitespace = true;
            _xmldoc.LoadXml(xmlcontent);

            foreach (string _key in _fontTags.Keys)
            {
                try
                {
                    XmlNodeList keyNodes = _xmldoc.SelectNodes("//" + _key);
                    foreach (System.Xml.XmlNode symbNode in keyNodes)
                    {
                        try
                        {
                            foreach (System.Xml.XmlNode xnd in symbNode.SelectNodes(".//text()"))
                            {
                                if (xnd.NodeType == XmlNodeType.Text)
                                {
                                    tmp = "";
                                    for (int intCnt = 0; intCnt <= xnd.InnerText.Length - 1; intCnt++)
                                        tmp = tmp +Cnfunctions.GetEntityFont(this.hsEntity,_key, Convert.ToString(char.ConvertToUtf32(xnd.InnerText[intCnt], '0'), 16).ToUpper());
                                    xnd.InnerText = tmp;
                                }
                            }
                            if (DeleteTags.ContainsKey("<" + _key + ">") == false)
                                DeleteTags.Add("<" + _key + ">", "");
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            xmlcontent = _xmldoc.OuterXml;
            foreach (string _deleteTag in DeleteTags.Keys)
                xmlcontent = xmlcontent.Replace(_deleteTag, "").Replace(_deleteTag.Replace("<", "</"), "");
            return xmlcontent;
        }




        //small functions


        public string getLabelText(ref ListItems lstItem, int level)
        {
            int intCnt;
            string frmt;
            int label;
            string lblText = "";
            string type = "";
            frmt = lstItem.level[level].format;
            if (frmt.IndexOf("%", 0) < frmt.LastIndexOf("%"))
            {
                for (intCnt = 0; intCnt <= level - 1; intCnt++)
                {
                    if (lstItem.level[intCnt].currentValue > 0)
                    {
                        label = lstItem.level[intCnt].currentValue - 1;
                        type = lstItem.level[intCnt].numfrmt;
                        if (type == "upperLetter")
                            lblText =Cnfunctions.GetLetter(label);
                        else if (type == "lowerLetter")
                            lblText = Cnfunctions.GetLetter(label).ToLower();
                        else if (type == "upperRoman")
                            lblText = Cnfunctions.GetRomanNum(label);
                        else if (type == "lowerRoman")
                            lblText = Cnfunctions.GetRomanNum(label).ToLower();
                        else
                            lblText = label.ToString() == "0"?"1":label.ToString();
                    }
                    else
                        lblText = "";
                    frmt = Regex.Replace(frmt, "(%" + (intCnt + 1) + ")", lblText);
                }
            }
            label = lstItem.level[level].currentValue;
            type = lstItem.level[level].numfrmt;
            if (type == "upperLetter")
                lblText = Cnfunctions.GetLetter(label);
            else if (type == "lowerLetter")
                lblText = Cnfunctions.GetLetter(label).ToLower();
            else if (type == "upperRoman")
                lblText = Cnfunctions.GetRomanNum(label);
            else if (type == "lowerRoman")
                lblText = Cnfunctions.GetRomanNum(label).ToLower();
            else
                lblText = label.ToString();
            lblText = Regex.Replace(frmt, "(%[0-9]+)", lblText);
            return lblText;
        }


        public void ResetNextLevel(ref ListItems lstItem, int level)
        {
            int intCnt;
            for (intCnt = level + 1; intCnt <= 8; intCnt++)
                lstItem.level[intCnt].currentValue = lstItem.level[intCnt].startNo;
        }


    }
}
