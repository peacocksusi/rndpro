﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Docx2HTML.Service
{
    public class EnvironmentService
    {

        public static IConfiguration _configuration;
        public static IWebHostEnvironment _hostEnv;
        public static IConfiguration GetEnvironmentConfiguration()
        {
            return _configuration;
        }

        public static IWebHostEnvironment GetHostConfiguration()
        {
            return _hostEnv;
        }
    }
}
