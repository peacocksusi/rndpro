﻿using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;
using Utils.Common;
using Utils.Logger;
using Utils.Models;
using static Utils.Common.CustomConstant;

namespace DocToPdf.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class PDFConverterController : ControllerBase
	{

		private readonly IConfiguration configuration;
		private readonly ILoggerService logger;
		private readonly ICustomConstant customConstant;
		public readonly string projectName = "Doc2Pdf";


		public string docxFileName = "";
		private string homePath = "";
		private string outPath = "";
		public string uniqueNumber = "";
		public string message = "";

		public PDFConverterController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
		{
			this.configuration = configuration;
			this.logger = logger;
			this.customConstant = customConstant;
		}

		[Route("convert")]
		[HttpPost]
		public async Task<CoreResponseModel> convert(string uniqueNumber)
		{

			CoreResponseModel coreResponseModel = new CoreResponseModel();

			coreResponseModel.projectName = this.projectName;
			try
			{


				this.uniqueNumber = uniqueNumber;

				homePath = Cnfunctions.GetModifiedPath(customConstant.HOME_PATH, uniqueNumber, customConstant);

				this.docxFileName = Cnfunctions.setDocxFileName(homePath);

				if (this.docxFileName!=""&&this.docxFileName.Contains(" "))
				{
                    coreResponseModel.status = 488;
                    coreResponseModel.uniqueNumber = this.uniqueNumber;
                    coreResponseModel.message = "Your docx file name contains space please rename and check again";
					this.message=coreResponseModel.message;
                    this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + this.message);
                    return coreResponseModel;
                }

				this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " docToPdf process started.");
				outPath = Cnfunctions.GetModifiedPath(customConstant.PDF_OUTPATH, uniqueNumber, customConstant);

				homePath = Cnfunctions.GetModifiedPath(customConstant.DOCX_OUTPATH, uniqueNumber, customConstant);
				Process word2pdfprocess = new Process();
				word2pdfprocess.StartInfo.CreateNoWindow = true;
				word2pdfprocess.StartInfo.FileName = @"C:\Program Files\LibreOffice\program\soffice.exe";
				word2pdfprocess.StartInfo.Arguments = "--headless --convert-to pdf " + Path.Combine(homePath, docxFileName + ".docx") + " --outdir " + outPath;
				word2pdfprocess.Start();
				word2pdfprocess.WaitForExit();
				word2pdfprocess.Close();

                coreResponseModel.uniqueNumber = this.uniqueNumber;
				Thread.Sleep(1000);

                if (!System.IO.File.Exists(outPath+"\\"+ docxFileName+".pdf"))
                {
                    this.message = "Not Converted";
                    coreResponseModel.status = 400;
                    coreResponseModel.message = this.message;
                    this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " " + this.message);
                }
                else
                {
                    this.message = "Doc To Pdf Converted";
                    coreResponseModel.status = 200;
                    coreResponseModel.message = this.message;
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " " + this.message);
                }




                return coreResponseModel;
			}
			catch (Exception ex)
			{
				coreResponseModel.status = 400;
				coreResponseModel.uniqueNumber = this.uniqueNumber;
				coreResponseModel.message = ex.Message;
				this.logger.LogError(this.uniqueNumber+" "+this.docxFileName+" "+ex.Message);
				return coreResponseModel;
			}



		}
	}
}
