﻿using HTMLMain.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using Utils.Common;

namespace HTMLMain.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HTMLMainController : ControllerBase
    {

        [HttpPost]
        public async Task<ActionResult> FinalizeHtml()
        {
            finalHtmlDocument finalhtml = new finalHtmlDocument();
            finalhtml.mergeHTMLFiles();
            finalhtml.generateIds();
            finalhtml.validate();
            // create final html file from the obj finalhtml
            string path = Cnfunctions.GetPath();
            byte[] bytes = Cnfunctions.DownloadFile(Path.Combine(path, "FinalHTML.html"));
            return File(bytes, "application/html", "FinalHTML.html");
        }



    }
}
