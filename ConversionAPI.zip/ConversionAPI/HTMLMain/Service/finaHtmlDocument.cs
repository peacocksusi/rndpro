﻿using System.Threading;
using Utils.Common;

namespace HTMLMain.Service
{
    public class finalHtmlDocument
    {

        public string content = "";
        public string path = "";
        public string getContent()
        {
            return content;
        }
        public void setContent(string value)
        {
            content = value;
        }
        public void setPath(string value)
        {
            path = value;
        }


        public void mergeHTMLFiles()
        {
            string frontContent = getFrontData();
            string bodyContent = getBodyData();
            string backContent = getBackData();
            string finalhtml = frontContent + bodyContent + backContent;
            Cnfunctions.CreateHTML(this.path, "FinalHTML.html", finalhtml);
            this.content = Cnfunctions.GetContentFromFile("path");
        }
        public string generateIds()
        {
            return "";
        }
        public string validate()
        {
            return "";
        }

        public string getFrontData()
        {
            return "";
        }

        public string getBodyData()
        {
            return "";
        }
        public string getBackData()
        {
            return "";
        }


    }
}
