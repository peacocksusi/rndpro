﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.PortableExecutable;
using System.Xml;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Text.RegularExpressions;
using Utils.Common;
using Utils.Logger;
using System.Reflection;
using Utils.Models;
using System.Xml.Linq;
using System.Xml.XPath;

namespace JSONCreation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JSONConverterController : ControllerBase
    {
        private readonly ILoggerService logger;
        private readonly IConfiguration configuration;
        private readonly ICustomConstant customConstant;
        private readonly string projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];

        private string message;
        private string uniqueNumber;
        private string docxFileName;

        public JSONConverterController(IConfiguration configuration, ILoggerService logger, ICustomConstant customConstant)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.customConstant = customConstant;
        }

        [HttpPost]
        public async Task<CoreResponseModel> convert(string uniqueNumber)
        {
            Header headerobj = new Header();
            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.projectName = this.projectName;
            try
            {
                this.uniqueNumber = uniqueNumber;
                string htmlpath = Cnfunctions.GetModifiedPath(this.customConstant.STRUCTEDHTML_OUTPATH, uniqueNumber, this.customConstant);
                string homePath = Cnfunctions.GetModifiedPath(this.customConstant.HOME_PATH, uniqueNumber, this.customConstant);
                docxFileName = Cnfunctions.setDocxFileName(homePath);
                htmlpath += "\\" + customConstant.FRONTHTML_NAME;
                //string htmlpath = configuration.GetValue<string>("filePath");

                this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " json creation process started.");
                string content = Regex.Match(Cnfunctions.ReadString(htmlpath), "<body>(.*?)</body>").Value;
                //string resultJSON = String.Empty;
                if (content != null)
                {
                    XmlDocument frontdocNode = new XmlDocument();
                    frontdocNode.LoadXml(content);

                    headerElements headerobject = new headerElements();
                    List<Affiliation> affiliationlist = headerobject.getAffiliations(frontdocNode);
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " aff process completed.");
                    List<Author> authorlist = headerobject.getAuthors(frontdocNode);
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " author process completed.");
                    List<Abspara> absparalist = headerobject.getAbsParagraphs(frontdocNode);
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " abstract process completed.");
                    List<KwdTerm> keywordlist = headerobject.getKeywords(frontdocNode);
                    this.logger.LogInfo(this.uniqueNumber + " " + this.docxFileName + " keyword process completed.");
                    headerobj.articletype = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='articlecategories']/div[@class='subjectgroup']/div[@class='subject']");
                    //headerobj.articletitle = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='articletitle']");
                    headerobj.titlegroup =headerobject.GetTitleGroup(frontdocNode);
                    headerobj.authors = authorlist.ToArray();
                    headerobj.affiliations = affiliationlist.ToArray();
                    headerobj.abshead = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='abshead']");
                    headerobj.absparas = absparalist.ToArray();
                    headerobj.kwdtitle = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='keywordgroup']/div[@class='title']");
                    headerobj.keywords = keywordlist.ToArray();



                    string jsonString = JsonConvert.SerializeObject(headerobj);
                    string jsonOutpath = Cnfunctions.GetModifiedPath(this.customConstant.JSON_OUTPATH, uniqueNumber, this.customConstant);
                    Cnfunctions.CreateFile(jsonOutpath, jsonString, customConstant.HEADERJSON_NAME);

                    this.message = this.uniqueNumber + " " + this.docxFileName + " header json created.";
                    this.logger.LogInfo(this.message);
                }
                else
                {
                    this.logger.LogError(this.uniqueNumber + " " + this.docxFileName + " content null");
                    throw new Exception(this.uniqueNumber + " " + this.docxFileName + " content null");
                }
                coreResponseModel.status = 200;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogInfo(message);

                return coreResponseModel;
            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;

                coreResponseModel.status = 400;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogError(message);

                return coreResponseModel;
            }
        }

        [HttpPost]

        [Route("UpdateHeader")]
        public async Task<CoreResponseModel> UpdateHeader(UpdateHeaderModel updateHeaderModel)
        {
            CoreResponseModel coreResponseModel = new CoreResponseModel();
            coreResponseModel.projectName = this.projectName;
            this.uniqueNumber = updateHeaderModel.uniqueNumber;
            string tx2FilePath =Path.Combine(Cnfunctions.GetModifiedPath(customConstant.DIGIHTML_OUTPATH, updateHeaderModel.uniqueNumber, customConstant),customConstant.DIGIHTML_NAME);



            try
            {

                XmlDocument headerxml = JsonConvert.DeserializeXmlNode(JsonConvert.SerializeObject(updateHeaderModel.metadata), "root");

                Dictionary<string, string[]> tagName = new Dictionary<string, string[]>();
                tagName = AddDictionary(tagName);




                var document = XDocument.Parse(headerxml.OuterXml);
                document.Descendants()
                        .Where(e => e.IsEmpty || String.IsNullOrWhiteSpace(e.Value))
                        .Remove();


                foreach (var element in document.Descendants())
                {
                    if (tagName.ContainsKey(element.Name.ToString()))
                    {
                        element.SetAttributeValue("class", tagName[element.Name.ToString()][1]);
                        element.Name = tagName[element.Name.ToString()][0];
                    }
                }
                //string metaDataPath = AppDomain.CurrentDomain.BaseDirectory + "//Resources//MetadataTemplate.xml";
                //string metaDataStr = Cnfunctions.ReadString(metaDataPath);


                


                //create element authors
                XElement articleType = document.Root.XPathSelectElement("//p[@class='subject']");
                //XElement articleTitleElem = document.Root.XPathSelectElement("//div[@class='articletitle']");
                XElement titleGroupElem = document.Root.XPathSelectElement("//div[@class='titlegroup']");
                XElement authorsElem = GroupElems(document, "div", "authors", @"//div[@class='author']");
                XElement affiliationsElem = GroupElems(document, "div", "affiliations", @"//div[@class='aff']");
                XElement abshead = document.Root.XPathSelectElement("//div[@class='abshead']");
                XElement abstractElem = GroupElems(document, "div", "abstract", @"//div[@class='para']", abshead);
                XElement keywordTitle = document.Root.XPathSelectElement("//div[@class='title']");
                XElement keywordElem = GroupElems(document, "div", "keywordgroup", @"//span[@class='keyword']", keywordTitle);

                string tx2String = System.IO.File.ReadAllText(tx2FilePath);


                //Replace elems from jsonxml to tx2.xhtml
                XDocument tx2Document = XDocument.Parse(tx2String);
                if (articleType!=null)
                {
                    XmlDocument xdoc = new XmlDocument();
                    XElement articleCategoriesElem = tx2Document.XPathSelectElement("//div[@class='articlecategories']");

                    if (articleCategoriesElem==null)
                    {
                        articleCategoriesElem = XElement.Parse("<div class=\"articlecategories\"><div class=\"subjectgroup\"><p class=\"subject\" id=\"MPS_d1e25\"> </p></div></div>");
                        if (tx2Document.XPathSelectElement("//div[@class='articlemeta']") != null)
                        {

                        tx2Document.XPathSelectElement("//div[@class='articlemeta']").AddFirst(articleCategoriesElem);
                        }

                    }

                    //XmlNode articleCategoriesNode = Cnfunctions.CreateNode(ref tx2Document, "div");

                ReplaceElems(ref tx2Document, @"//p[@class='subject']", articleType);

                }
                ReplaceElems(ref tx2Document, @"//div[@class='titlegroup']", titleGroupElem);
                ReplaceElems(ref tx2Document, @"//div[@class='authors']", authorsElem);
                ReplaceElems(ref tx2Document, @"//div[@class='affiliations']", affiliationsElem);
                ReplaceElems(ref tx2Document, @"//div[@class='abstract']", abstractElem);
                ReplaceElems(ref tx2Document, @"//div[@class='keywordgroup']", keywordElem);

                string revisedFileName = Path.GetFileNameWithoutExtension(tx2FilePath) + DateTime.Now.ToString("_dd_MM_yyy_hh_mm_ss") + Path.GetExtension(tx2FilePath);

                System.IO.File.Copy(tx2FilePath, tx2FilePath.Replace(customConstant.DIGIHTML_NAME, revisedFileName));

                System.IO.File.WriteAllText(tx2FilePath, tx2Document.CreateNavigator().OuterXml);


                this.message = this.uniqueNumber + " " + this.docxFileName + " DigiHtml updated.";
                coreResponseModel.status = 200;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogInfo(message);

                return coreResponseModel;
            }
            catch (Exception ex)
            {
                message = uniqueNumber + " " + this.docxFileName + " " + message + " " + ex.Message;

                coreResponseModel.status = 400;
                coreResponseModel.uniqueNumber = this.uniqueNumber;
                coreResponseModel.message = this.message;
                this.logger.LogError(message);

                return coreResponseModel;
            }
        }



        public static XElement GroupElems(XDocument document, string elemName, string groupClassName, string xpath, XElement firstChild = null)
        {
            XElement newElem = new XElement(elemName);
            newElem.SetAttributeValue("class", groupClassName);
            if (firstChild != null)
            {
                newElem.Add(firstChild);
            }
            IEnumerable<XElement> elemList = document.Root.XPathSelectElements(xpath);
            foreach (XElement elem in elemList.ToArray())
            {
                newElem.Add(elem);
            }

            return newElem;
        }


        public static void ReplaceElems(ref XDocument pDocument, string oldElemXPath, XElement newElem)
        {
            XElement tx2AuthorsElem = pDocument.XPathSelectElement(oldElemXPath);
            tx2AuthorsElem.ReplaceWith(newElem);
        }


        public static Dictionary<string, string[]> AddDictionary(Dictionary<string, string[]> tagName)
        {
            tagName.Add("authors", new string[] { "div", "author" });
            //tagName.Add("articletitle", new string[] { "div", "articletitle" });
            tagName.Add("fname", new string[] { "span", "given-name" });
            tagName.Add("mname", new string[] { "span", "middlename" });
            tagName.Add("sname", new string[] { "span", "surname" });
            tagName.Add("affref", new string[] { "span", "cite" });
            tagName.Add("affiliations", new string[] { "div", "aff" });
            tagName.Add("afflabel", new string[] { "span", "label" });
            tagName.Add("department", new string[] { "span", "department" });
            tagName.Add("institution", new string[] { "span", "institution" });
            tagName.Add("city", new string[] { "span", "city" });
            tagName.Add("state", new string[] { "span", "state" });
            tagName.Add("country", new string[] { "span", "country" });
            tagName.Add("postalcode", new string[] { "span", "postcode" });
            tagName.Add("abshead", new string[] { "div", "abshead" });
            tagName.Add("para", new string[] { "div", "para" });
            tagName.Add("isCorres", new string[] { "span", "corres" });
            tagName.Add("kwdtitle", new string[] { "div", "title" });
            tagName.Add("term", new string[] { "span", "keyword" });
            tagName.Add("metadata", new string[] { "div", "front" });
            tagName.Add("titlegroup", new string[] { "div", "titlegroup" });
            tagName.Add("articletitle", new string[] { "div", "title" });
            tagName.Add("runningtitle", new string[] { "div", "rrh" });
            tagName.Add("articletype", new string[] { "p", "subject" });
            tagName.Add("orcid", new string[] { "span", "orcid" });
            tagName.Add("suffix", new string[] { "span", "suffix" });
            tagName.Add("degree", new string[] { "span", "degree" });

            return tagName;
        }


    }
}
