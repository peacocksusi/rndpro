﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Utils.Models;

namespace JSONCreation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {

        [HttpGet]

        public ProjectInfo Get()
        {
            ProjectInfo projectInfo = new ProjectInfo();
            projectInfo.Name = "JSONCreation";
            projectInfo.Version = "0.0.0";
            projectInfo.Description = "This api is helps to create a json from front.html";
            return projectInfo;
        }
    }
}
