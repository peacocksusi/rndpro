﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Utils.Common;
using Utils.Models;

namespace JSONCreation
{
    internal class headerElements
    {
        private List<string> affLabelList = new List<string>(); 


        public TitleGroup GetTitleGroup(XmlDocument frontdocNode)
        {
            TitleGroup titleGroup = new TitleGroup();
            titleGroup.articletitle = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='titlegroup']/div[@class='title']");
            titleGroup.runningtitle = Cnfunctions.GetInnerText(frontdocNode, "//div[@class='titlegroup']/div[@class='rrh']");
            return titleGroup;
        }

        public List<Author> getAuthors(XmlDocument frontdocNode)
        {
            List<Author> authors = new List<Author>();
            XmlNodeList authorNodes = frontdocNode.SelectNodes("//div[@class='author-group']/div[@class='authors']/div[@class='author']");
            foreach (XmlNode authorNode in authorNodes)
            {
               Author author = new Author();
                    author.fname = Cnfunctions.GetInnerText(authorNode, "./span[@class='given-name']");
                    author.mname = Cnfunctions.GetInnerText(authorNode, "./span[@class='middlename']");
                    author.sname = Cnfunctions.GetInnerText(authorNode, "./span[@class='surname']");
                    author.orcid = Cnfunctions.GetInnerText(authorNode, "./span[@class='orcid']");
                    author.suffix = Cnfunctions.GetInnerText(authorNode, "./span[@class='suffix']");
                    author.degree = Cnfunctions.GetInnerText(authorNode, "./span[@class='degree']");
                    author.affref = getAffRef(authorNode);


                //old value set method

                //if (authorNode.SelectSingleNode("./span[@class='given-name']") != null)
                //    author.fname = authorNode.SelectSingleNode("./span[@class='given-name']").InnerText; 
                //if (authorNode.SelectSingleNode("./span[@class='middlename']") != null)
                //    author.mname = authorNode.SelectSingleNode("./span[@class='middlename']").InnerText;
                //if (authorNode.SelectSingleNode("./span[@class='surname']") != null)
                //    author.sname = authorNode.SelectSingleNode("./span[@class='surname']").InnerText;
                //if (authorNode.SelectSingleNode("./span[@class='cite']") != null)
                //    author.affref = getAffRef(authorNode);
                authors.Add(author);
            }
            return authors;
        }

        public List<Affiliation> getAffiliations(XmlDocument frontdocNode)
        {
            List<Affiliation> affiliations = new List<Affiliation>();
            XmlNodeList affNodes = frontdocNode.SelectNodes("//div[@class='affiliations']/div[@class='aff']");
            foreach (XmlNode affNode in affNodes)
            {
                Affiliation affiliation = new Affiliation();

                    affiliation.afflabel = Cnfunctions.GetInnerText(affNode, "./span[@class='label']");
                    this.affLabelList.Add(affiliation.afflabel);
                    affiliation.institution = Cnfunctions.GetInnerText(affNode, "./span[@class='institution']");
                    affiliation.department = Cnfunctions.GetInnerText(affNode, "./span[@class='department']"); 
                    affiliation.city = Cnfunctions.GetInnerText(affNode, "./span[@class='settlement']");
                    affiliation.state = Cnfunctions.GetInnerText(affNode, "./span[@class='region']");
                    affiliation.country = Cnfunctions.GetInnerText(affNode, "./span[@class='country']");
                    affiliation.postalcode = Cnfunctions.GetInnerText(affNode, "./span[@class='postCode']");


                ////old value set method
                //if (affNode.SelectSingleNode("./span[@class='label']") != null)
                //    affiliation.afflabel = affNode.SelectSingleNode("./span[@class='label']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='institution']") != null)
                //    affiliation.institution = affNode.SelectSingleNode("./span[@class='institution']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='department']") != null)
                //    affiliation.department = affNode.SelectSingleNode("./span[@class='department']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='settlement']") != null)
                //    affiliation.city = affNode.SelectSingleNode("./span[@class='settlement']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='region']") != null)
                //    affiliation.state = affNode.SelectSingleNode("./span[@class='region']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='country']") != null)
                //    affiliation.country = affNode.SelectSingleNode("./span[@class='country']").InnerText;
                //if (affNode.SelectSingleNode("./span[@class='postCode']") != null)
                //    affiliation.postalcode = affNode.SelectSingleNode("./span[@class='postCode']").InnerText;
                affiliations.Add(affiliation);
            }
            return affiliations;
        }

        public List<Abspara> getAbsParagraphs(XmlDocument frontdocNode)
        {
            List<Abspara> absparagraphs = new List<Abspara>();
            XmlNodeList absparaNodes = frontdocNode.SelectNodes("//div[@class='abstract']/div[@class='para']");
            foreach (XmlNode absparaNode in absparaNodes)
            {
                Abspara absparagraph = new Abspara();
                    absparagraph.para = Cnfunctions.GetInnerText(absparaNode);


                ////old value set method
                //if (absparaNode.SelectSingleNode(".") != null)
                //    absparagraph.para =  absparaNode.SelectSingleNode(".").InnerText;
                absparagraphs.Add(absparagraph);
            }
            return absparagraphs;
        }

        public List<KwdTerm> getKeywords(XmlDocument frontdocNode)
        {
            List<KwdTerm> keywords = new List<KwdTerm>();
            XmlNodeList kwdTermNodes = frontdocNode.SelectNodes("//div[@class='keywordgroup']/span[@class='keyword']");
            foreach (XmlNode kwdTermNode in kwdTermNodes)
            {
                KwdTerm keywordterm = new KwdTerm();
                    keywordterm.term = Cnfunctions.GetInnerText(kwdTermNode);
                
                //if (kwdTermNode.SelectSingleNode(".") != null)
                //    keywordterm.term = kwdTermNode.SelectSingleNode(".").InnerText;
                keywords.Add(keywordterm);
            }
            return keywords;
        }


        private string[] getAffRef(XmlNode authorNode)
        {
            List<string> result =new List<string>();
            if (authorNode!=null)
            {

            XmlNodeList authorAffRefList = authorNode.SelectNodes("./span[@class='cite']");
                int index = 0;

                foreach (XmlNode authorAffRef in authorAffRefList)
                {

                    string affRefInnerText = Cnfunctions.GetInnerText(authorAffRef);
                    if (this.affLabelList.Contains(affRefInnerText))
                    {

                    result.Add(affRefInnerText);
                    }
                    //result += (index==0?"":",")+ authorAffRef.InnerText;

                    index++;
                }
            }



            return result.ToArray();
        }

    }
}
