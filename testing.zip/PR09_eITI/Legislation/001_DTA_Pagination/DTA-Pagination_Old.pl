
###\\amnet-fs2\journals\eArmour\Test\JFS_001-015

use XML::Twig;


main();
sub main

{
    $t = initializeTwig();   					# Twig Initialization
    $t = processInputFile();
    $out = $t->sprint();
    printout();
}


sub initializeTwig {
   my $t = new XML::Twig(twig_handlers =>
     {	
     	
## Root Namespace add
# xmlns:aid="http://ns.adobe.com/AdobeInDesign/4.0/" xmlns:aid5="http://ns.adobe.com/AdobeInDesign/5.0/" 
     	  'part'					 							        		=> sub {$_->set_att('xmlns:aid'=>'http://ns.adobe.com/AdobeInDesign/4.0/','xmlns:aid5'=>'http://ns.adobe.com/AdobeInDesign/5.0/') }, 
     	
## Paragraph Style
     	
     	  'part-num'					 							        => sub {$_->set_att('aid:pstyle'=>'*Part No.') }, 
     		'part-title'												      => sub {$_->set_att('aid:pstyle'=>'*Part Name') }, 
     		'chapter-num'												      => sub {$_->set_att('aid:pstyle'=>'*Chap Name2') }, 
     	#	'section-heading/num/amending-acts'       => sub {$_->set_att('aid:pstyle'=>'*Legislative Refs') },
     		'section-heading'									        => sub {$_->set_att('aid:pstyle'=>'Section and Chapter Number') }, 
     	#	'section-refs/h1'                         => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic') },
     		 
     		
     		#'section-heading'						            => sub {$_->set_att('aid:pstyle'=>'Section and Chapter Number') },      
     		
			# Footnote Style
      'dt-footnotes/case-law/h1'		              => sub {$_->set_att('aid:pstyle'=>' *Ref Hd') }, 
      'dt-footnotes/uk/h1'		              			=> sub {$_->set_att('aid:pstyle'=>'*Footnote Head') }, 
      'dt-footnotes/section-refs/h1'		          => sub {$_->set_att('aid:pstyle'=>'*Footnote Head') }, 
      'dt-footnotes/case-law/p'		          			=> sub {$_->set_att('aid:pstyle'=>'*Footnote Text') }, 
      'dt-footnotes/uk/p'			              			=> sub {$_->set_att('aid:pstyle'=>'*Footnote Text') }, 
      'dt-footnotes/section-refs/p'	 	          	=> sub {$_->set_att('aid:pstyle'=>'*Footnote Text') }, 
      
      'footnotes/dt-footnotes/amendments/h1'     => sub {$_->set_att('aid:pstyle'=>'*Ref Hd') },  'new
      
      
     ## 'case-law/h1'		                          => sub {$_->set_att('aid:pstyle'=>'*Ref Hd') }, 
 
 			'amending-acts'															=> sub {$_->set_att('aid:pstyle'=>'*Legislative Refs') }, 
 			
     	#'p'	                                      => sub {$_->set_att('aid:pstyle'=>'*Footnote Text') }, 
     	#'uk/h1'	                                  => sub {$_->set_att('aid:pstyle'=>'*Footnote Head') }, 
     	'p[@left="0"]'    			              			=> sub { $_->set_att('aid:pstyle'=>'*Col 02') },
     	'p[@left="0"]/num'    			              	=> sub { $_->set_att('aid:pstyle'=>'*Col 03') },
      'p[@left="1"]/dfn'    			              	=> sub { $_->set_att('aid:pstyle'=>'*Col 04') },	
      'p[@left="1"]/num'    				              => sub { $_->set_att('aid:pstyle'=>'*Col 05') },      
      'p[@left="2"]/num'    			              	=> sub { $_->set_att('aid:pstyle'=>'*Col 07') },	      	
      
      'p[@left="3"]/dfn/num'    		              => sub { $_->set_att('aid:pstyle'=>'*Col 08') },	      	
      
      #'p[@left="2"]'    				                  => sub { $_->set_att('aid:cstyle'=>'*Col 06') },	      	
      
      'p[@align="center"]'    	              		=> sub { $_->set_att('aid:pstyle'=>'*Col 04 SCHEDULE') },
     	'p[@left="3"]/num'    				              => sub { $_->set_att('aid:pstyle'=>'*Col 09') },	      	
     	'p[@left="4"]/num'    			              	=> sub { $_->set_att('aid:pstyle'=>'*Col 10') },	
     	
     	
     #<p left="3">�<dfn><num>
     #<p left="0"><start/><ellipsis/><end id="y1997-a39-s22-1" fm="1"/></p></ins> *col 02
     #<p left="1"><num>(a)</num> Subject to paragraph (b), subsection (1) applies as respects an individual who ceases to be
     #<p left="2"><start/>
     #*Legislative Refs indd pstyle
 
 
 ## Character Style
 
     'i'                                         => sub {$_->set_att('aid:cstyle'=>'Italic') },
     'b'                                         => sub {$_->set_att('aid:cstyle'=>'Bold') },

 ## Table Style
 
     'td/p[@align="left"]'                      => sub {$_->set_att('aid:pstyle'=>'*Table Left') },
     'td/p[@align="center"]'                    => sub {$_->set_att('aid:pstyle'=>'*Table Cent') },
     'td/p[@align="right"]'                     => sub {$_->set_att('aid:pstyle'=>'*Table Rigt') },
    #'td/p[@aid:pstyle]'                     	=> sub {$_->erase_att('aid:pstyle') },

      },
   keep_encoding => 'true');
   return $t;
}


sub processInputFile {
    open (FIN, "< $ARGV[0] ") || die "can't open input file";
    my $filecont = join "", <FIN>;
    close FIN;
    $t->parse($filecont);
    return $t;
}


sub printout {
    $outfile = $ARGV[0];
    $outfile =~s/\.xml/_out.xml/i;
	open(FOUT, "> $outfile") || die "can't open output file";

	$out=~s/(<p left=\"0\") aid:pstyle=\"[^>]+\"([^>]*><num aid:pstyle)/$1$2/g;
	$out=~s/(<td[^>]+><p [^>]*) aid:pstyle=\"\*C[^\">]+\"([^>]*>)/$1$2/g;
	$out=~s/(\<\/num>)/$1\t/g;
	$out=~s/(\<[^\/]+ aid:pstyle|<tr>)/\n$1/g;

	print FOUT $out;
	close FOUT;
}