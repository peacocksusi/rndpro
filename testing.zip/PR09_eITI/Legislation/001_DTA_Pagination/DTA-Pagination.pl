use XML::Twig;

my $rCnt, $cCnt;
main();
sub main
{
    $t = initializeTwig();             # Twig Initialization
    $t = processInputFile();
    $t = processTables();
    $t = processFN();
    $out = $t->sprint();
    printout();
}

sub initializeTwig {
  my $t = new XML::Twig(twig_handlers =>
  {

# Paragraph Style
  'part-num'                          => sub {$_->set_att('aid:pstyle'=>'*Part No.','aid:cstyle'=>'Running Head Inside Top A') }, 
  'part-title'                        => sub {$_->set_att('aid:pstyle'=>'*Part Name','aid:cstyle'=>'Running Head Inside Top B') }, 
  'chapter-num'                       => sub {$_->set_att('aid:pstyle'=>'*Chap Name2') }, 
  'chapter-title'                     => sub {$_->set_att('aid:cstyle'=>'Running Head Inside Bottom B') }, 
  'section-heading'                   => sub {$_->set_att('aid:pstyle'=>'Section and Chapter Number') }, 
  'section-heading/num'               => sub {$_->set_att('aid:cstyle'=>'Running Head Outside') }, 
  'amending-acts'                     => sub {$_->set_att('aid:pstyle'=>'*Legislative Refs') }, 

# Paragraph Styles
  'p[@left="0"]'                      => sub {$_->set_att('aid:pstyle'=>'*Col 02')},
  'p[@left="0"]/num'                  => sub {$_->set_att('aid:pstyle'=>'*Col 03')},
  'p[@left="1"]'                      => sub {$_->set_att('aid:pstyle'=>'*Col 04')},
  'p[@left="1"]/num'                  => sub {$_->set_att('aid:pstyle'=>'*Col 05')},
  'p[@left="2"]'                      => sub {$_->set_att('aid:pstyle'=>'*Col 06')},
  'p[@left="2"]/num'                  => sub {$_->set_att('aid:pstyle'=>'*Col 07')},
  'p[@left="3"]'                      => sub {$_->set_att('aid:pstyle'=>'*Col 08')},
  'p[@left="3"]/num'                  => sub {$_->set_att('aid:pstyle'=>'*Col 09')},
  'p[@left="4"]/num'                  => sub {$_->set_att('aid:pstyle'=>'*Col 10')},
  'p[@align="center"]'                => sub {$_->set_att('aid:pstyle'=>'*Col 04 SCHEDULE') },

# Footnote Style                      # GoTo end & add Bold-Italic for the Headings
  'dt-footnotes/case-law/h1'          => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/amendments/h1'        => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/uk/h1'                => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/section-refs/h1'      => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/cross-refs/h1'        => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/new-amendments/h1'    => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/related/h1'           => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/tax-briefs/h1'        => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 
  'dt-footnotes/precedents/h1'        => sub {$_->set_att('aid:pstyle'=>'*Footnote Spc Italic')}, 

  'dt-footnotes/case-law/p'           => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/amendments/p'         => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/uk/p'                 => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/section-refs/p'       => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/cross-refs/p'         => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/new-amendments/p'     => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/new-amendments/note'  => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/related/p'            => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/tax-briefs/p'         => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 
  'dt-footnotes/precedents/p'         => sub {$_->set_att('aid:pstyle'=>'*Footnote Text')}, 

# Character Style
  'i'                                 => sub {$_->set_att('aid:cstyle'=>'Italic') },
  'b'                                 => sub {$_->set_att('aid:cstyle'=>'Bold') },
  'sup'                               => sub {$_->set_att('aid:cstyle'=>'superscript') },
  'sub'                               => sub {$_->set_att('aid:cstyle'=>'subscript') },

# Table Style
  'table'                             => sub {$_->set_att('aid:table'=>'table', 'aid5:tablestyle'=>'TABL' ) },
  'thead/tr/td'                       => sub {$_->set_att('aid5:cellstyle'=>'TCH', 'aid:table'=>'cell')}, # 'aid:pstyle'=>'TCH'
  'thead/tr/th'                       => sub {$_->set_att('aid5:cellstyle'=>'TCH', 'aid:table'=>'cell')}, # 'aid:pstyle'=>'TCH'
  'tbody/tr/th'                       => sub {$_->set_att('aid5:cellstyle'=>'TB', 'aid:table'=>'cell')},  # 'aid:pstyle'=>'TB'
  'tbody/tr/td'                       => sub {$_->set_att('aid5:cellstyle'=>'TB', 'aid:table'=>'cell')},  # 'aid:pstyle'=>'TB'
  'th'                                => sub {$_->set_tag('td')},
  'thead'                             => sub {$_->erase;},
  'tbody'                             => sub {$_->erase;},
  'colgroup'                          => sub {$_->delete;},
  'col'                               => sub {$_->delete;},

# TOC Style
  'toc/title'                         => sub {$_->set_att('aid:pstyle'=>'Z_TOC TITLE')},
  'tocact/tocentry'                   => sub {$_->set_att('aid:pstyle'=>'TOCHEAD')},
  'tocfront/tocentry'                 => sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 1')},
  'tocpart/tocentry'                  => sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 1')},
  'tocchap/tocentry'                  => sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 5')},
  'tocact/tocact/tocentry/tocactTitle'=> sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 3')},
  'tocsection/tocentry'               => sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 3')},
  'tocschedule/tocentry'              => sub {$_->set_att('aid:pstyle'=>'Z_TOC LVL 3')},

  },

   keep_encoding => 'true');
   return $t;
}

sub processTables
{
# Table P:Style apply
  my @cellPara=$t->get_xpath('//td/p');
  foreach my $cell(@cellPara)
  {
    $cell->del_att('aid:pstyle');
# $cell->set_att('aid5:cellstyle'=>'TB', 'aid:pstyle'=>'TB', 'aid:table'=>'cell');
    $chkTDalign = $cell->att('align');
    if ($chkTDalign eq "left")
    {
      $cell->set_att('aid:pstyle'=>'*Table Left');
    }
    elsif ($chkTDalign eq "center")
    {
      $cell->set_att('aid:pstyle'=>'*Table Cent');
    }
    elsif ($chkTDalign eq "right")
    {
      $cell->set_att('aid:pstyle'=>'*Table Rigt');
    }
    else
    {
      $cell->set_att('aid:pstyle'=>'*Table Left');
    }
  }
  
  my @td=$t->get_xpath('//td');
  foreach my $td(@td)
  {
    $td->del_att('aid:pstyle');
# $cell->set_att('aid5:cellstyle'=>'TB', 'aid:pstyle'=>'TB', 'aid:table'=>'cell');
    $TDalign = $td->att('align');
    if ($TDalign eq "left")
    {
      $td->set_att('aid:pstyle'=>'*Table Left');
    }
    elsif ($TDalign eq "center")
    {
      $td->set_att('aid:pstyle'=>'*Table Cent');
    }
    elsif ($TDalign eq "right")
    {
      $td->set_att('aid:pstyle'=>'*Table Rigt');
    }
    else
    {
      $td->set_att('aid:pstyle'=>'*Table Left');
    }
  }
  
# Table RowStart & RowEnd Apply
  my @firstcell=$t->get_xpath('//tr/td[1]');
  foreach my $tmp(@firstcell)
  {
    $tmp->set_att('pos'=>'rowstart');
  }
  my @lastcell=$t->get_xpath('//tr/td[last()]');
  foreach my $tmp(@lastcell)
  {
    $tmp->set_att('pos'=>'rowend') ;
  }

# Get Row-Count & Col-Count of each Table
  my @tables=$t->get_xpath('//table');
  foreach my $table(@tables)
  {
    my $rCnt= $table->children_count('tr');
     $table->set_att('aid:trows'=>$rCnt);
# print "$rCnt\n";
     if ($table->get_xpath('tr'))
     {
       my @tr=$table->get_xpath('tr');
       foreach my $tr(@tr)
       {  $count=$cCnt;
         $cCnt= $tr->children_count('td');

# Table RowStartEnd Apply for 1-Column
         if($cCnt=="1")
         {
           my @tdfl=$tr->get_xpath('td');
           foreach my $tdfl(@tdfl)
           {
             $tdfl->set_att('pos'=>'rowstartend');
           }
         }
         if( $cCnt ge $count ){ $count = $cCnt } else { $cCnt = $count };
# Remove all TR in a Table
         $tr->erase;
       }
     }

# Calculate Column Width
    $table->set_att('aid:tcols'=>"$cCnt");
    $cWidth=(315/$cCnt);
    my @td=$table->get_xpath('//td');
    foreach my $td(@td)
    {
# Column Width Apply to each TD
      $td->set_att('aid:ccolwidth'=>"$cWidth");  #."%");
# Get Span value
      $cSpn=$td->att('colspan');
      $rSpn=$td->att('rowspan');
# Apply COLUMN Span value
     if ($cSpn ge 1)
     {
       $tWidth=$cWidth*$cSpn;
       $td->set_att('aid:ccols'=>"$cSpn",'aid:ccolwidth'=>"$tWidth");
     }
     else
     {
       $td->set_att('aid:ccols'=>'1','aid:ccolwidth'=>"$cWidth");
     }
# Apply ROW Span value
     if ($rSpn ge 1)
     {
       $td->set_att('aid:crows'=>"$rSpn");
     }
     else
     {
       $td->set_att('aid:crows'=>'1');
     }
    }
  }

# Return to main Sub
  return $t;
}

sub processFN
{
  my @fntx=$t->get_xpath('dt-footnotes//p[@left="1"]/num');
  foreach my $fntx(@fntx)
  {
    $fntx->set_att('aid:pstyle'=>' *Footnote Dash');  #."%");
  }
  return $t;
}

sub processInputFile
{
  open (FIN, "< $ARGV[0] ") || die "can't open input file";
  my $filecont = join "", <FIN>;
  close FIN;
  $t->parse($filecont);
  my $root= $t->root;
  $root->set_att('xmlns:aid'=>'http://ns.adobe.com/AdobeInDesign/4.0/','xmlns:aid5'=>'http://ns.adobe.com/AdobeInDesign/5.0/');
  return $t;
}

sub printout
{
  $outfile = $ARGV[0];
  $outfile =~s/\.xml/_out.xml/i;
  open(FOUT, "> $outfile") || die "can't open output file";

# remove <p>'s pstyle where <num>, <dfn> occurs in <p>
  $out=~s/(<p) aid:pstyle=\"[^>]+\"( left=\"[0-9]+\"[^>]*>(<[^<>]+\/>)?<(num|dfn) aid:pstyle)/$1$2/g;
  $out=~s/(<chapter-num [^>]+>Chapter )([0-9]+)(<\/chapter-num>)/$1<cnum aid:cstyle="Chapter No.">$2<\/cnum>$3/g;
  $out=~s/(<dt-footnotes>(<[^<>]+>)*<h1 aid:pstyle=\")\*Footnote Spc Italic(\">)/$1 \*Ref Hd$3/g;
  $out=~s/(<p [^\n>]*aid:pstyle=\"\*Footnote Text\"[^\n>]*>)(?!\<num\>)/$1\t/g;  # add tab for all fn-text
  $out=~s/(<\/chapter-num>)/$1<del>&\#x00A0;&\#x2013; <\/del>/g;                 # add tab after <num>
  $out=~s/(\<\/num>)\s*/$1\t/g;                                                  # add tab after <num>
  $out=~s/(\<[^\/]+ aid:pstyle|<tr>)/\n$1/g;                                     # break paragraphs
  $out=~s/(<part [^\n]+)\n/$1/g;                                                 # Remove First Break
  $out=~s/(<td [^>]+>)\n/$1/g;                                                   # remove <p> from '<td><p>'
#  $out=~s/(<td [^>]+)><p /$1 /g;                                                # remove <p> from '<td><p>'
#  $out=~s/(<td [^>]+)>(<[^>]+>)\n*<p /$2$1 /g;                                  # remove <p> from '<td><p>'
#  $out=~s/<\/p>(<\/td>)/$1/g;                                                   # remove </p> from '</p></td>'
  $out=~s/\n(<td)/$1/g;                                                          # remove break before <td>
  $out=~s/<ellipsis\/>/<ellipsis>...<\/ellipsis>/g;
  $out=~s#(<(case-law|amendments|uk|section-refs|cross-refs|new-amendments|related|tax-briefs|precedents)><h1 aid:pstyle=\"[^\"]+\">(<[^>]+>\s*)?<i aid:cstyle=\")Italic(\">)#$1bold italic$4<boldremove/>#g;
  $out=~s#(<start/>(<[^>]+>)?)\n(<num[^>]+>)#\n$3$1#g;
  $out=~s#<start/>#<start><del>\[</del></start>#g;
  $out=~s#(<end[^<]* fm="([^"]+)[^<]*")/>#$1\/><del>\]<sup aid:cstyle="superscript">$2</sup></del>#g;
  $out=~s#(<\/num>\t)\n(<num) aid:pstyle=\"[^\"]+\"([^>]*>)#$1$2$3#g;
  $out=~s#((<\/section-heading>|<\/amending-acts>)(<[^<>]+>)*)<p>#$1\n<p aid:pstyle=\"*Col 02\" left="0">#g;
  $out=~s#(<tocentry[^>]*) aid:pstyle=\"TOCHEAD\"([^>]*><tocactTitle aid)#$1$2#g;

# $out=~s/<\/?tr>//g;  # remove all <tr>

  print FOUT $out;
  close FOUT;
}