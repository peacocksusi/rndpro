$src=$ARGV[0];

use XML::Twig;
my $rCnt,$cCnt;

main();

sub main
{
  $t = initializeTwig();  # Twig Initialization
  $t = processInputFile();
  $t = processTables();
#  $t = processMisc();
  $out = $t->sprint();
  printout();
}

sub initializeTwig {
  my $t = new XML::Twig(twig_handlers =>
  {
# Meta Part Styles
  'book/head/title'                          => sub {$_->set_att('aid:pstyle'=>'Tite 2lines')},
  'book/head/subtitle'                       => sub {$_->set_att('aid:pstyle'=>' *Title2')},
  'book/head/keywords'                       => sub {$_->set_att('aid:pstyle'=>' *Title3')},
  'book/head/authors/author'                 => sub {$_->set_att('aid:pstyle'=>'Authors')},
  'book/head/editors/editor'                 => sub {$_->set_att('aid:pstyle'=>'Authors')},
  'book/head/publication-date'               => sub {$_->set_att('aid:pstyle'=>'Prelim body')},
  'book/head/subject-headings'               => sub {$_->set_att('aid:pstyle'=>'Prelim body')},
  'book/head/description'                    => sub {$_->set_att('aid:pstyle'=>'Prelim body')},

# Front-Matter Styles
  'xhtml[0]/p'                  => sub {$_->set_att('aid:pstyle'=>'Prelim body1')},
  'xhtml/title'                 => sub {$_->set_att('aid:pstyle'=>'Prelim body head')},
  'xhtml/h1'                    => sub {$_->set_att('aid:pstyle'=>'Prelim body head')},
  'xhtml/p'                     => sub {$_->set_att('aid:pstyle'=>'Prelim body1')},
  'xhtml/xhtml/title'           => sub {$_->set_att('aid:pstyle'=>'TN')},
  'xhtml/xhtml/h1'              => sub {$_->set_att('aid:pstyle'=>'TT')},
  'xhtml/xhtml/p'               => sub {$_->set_att('aid:pstyle'=>'Normal')},

# Body-Matter Styles
  'chapter'                             => sub {$_->set_att('aid:pstyle'=>'Chap Title')},
  'chapter/topic'                       => sub {$_->set_att('aid:pstyle'=>'*Sub1')},
  'chapter/topic/subtopic'              => sub {$_->set_att('aid:pstyle'=>'*Sub2')},
  'chapter//p'                          => sub {$_->set_att('aid:pstyle'=>'Body Text')},
  'citation'                            => sub {$_->set_att('aid:pstyle'=>'*Legislative References')},
  'ul[@type="emdash"]//li'              => sub {$_->set_att('aid:pstyle'=>'*Bullet Dash Indent')},
  'ul[@type="disc"]//li'                => sub {$_->set_att('aid:pstyle'=>'*Bullet')},
  'li//p'                               => sub {$_->del_att('aid:pstyle')},
  'p[@left="1"]/num'                    => sub {$_->set_att('aid:pstyle'=>'*Col (i) or (a) indented no italics')},
  'p[@left="2"]/num'                    => sub {$_->set_att('aid:pstyle'=>'*Col (ii) or (b) indented no italics')},

# Character Styles
  'i'                                       => sub {$_->set_att('aid:cstyle'=>'Italic')},
  'b'                                       => sub {$_->set_att('aid:cstyle'=>'Bold')},
  'sup'                                     => sub {$_->set_att('aid:cstyle'=>'superscript')},
  'sub'                                     => sub {$_->set_att('aid:cstyle'=>'subscript')},
  'br'                                      => sub {$_->set_att('aid:cstyle'=>'break')},

# IMAGE Styles
  'img'                                     => sub {$_->set_att('aid:cstyle'=>'IMG')},

# Table Styles
  'table'                                   => sub {$_->set_att('aid:table'=>'table','aid5:tablestyle'=>'TABL' )},
  'thead/tr/td'                             => sub {$_->set_att('aid5:cellstyle'=>'TCH','aid:table'=>'cell')},
  'thead/tr/th'                             => sub {$_->set_att('aid5:cellstyle'=>'TCH','aid:table'=>'cell')},
  'tbody/tr/th'                             => sub {$_->set_att('aid5:cellstyle'=>'TB','aid:table'=>'cell')},
  'tbody/tr/td'                             => sub {$_->set_att('aid5:cellstyle'=>'TB','aid:table'=>'cell')},
  'table/tr/th'                             => sub {$_->set_att('aid5:cellstyle'=>'TB','aid:table'=>'cell')},
  'table/tr/td'                             => sub {$_->set_att('aid5:cellstyle'=>'TB','aid:table'=>'cell')},
  'th'                                      => sub {$_->set_tag('td')},
  'thead'                                   => sub {$_->erase;},
  'tbody'                                   => sub {$_->erase;},
  'colgroup'                                => sub {$_->delete;},
  'col'                                     => sub {$_->delete;},
  'beginpage'                               => sub {$_->erase;},

# TOC Styles
  'toc/title'                               => sub {$_->set_att('aid:pstyle'=>'Prelim body head')},
  'tocfront/tocentry'                       => sub {$_->set_att('aid:pstyle'=>'Toc1')},
#  'tocpart/tocentry/num'                    => sub {$_->set_att('aid:pstyle'=>'Chap_Name')},
#  'tocpart/tocentry/tocpartTitle'           => sub {$_->set_att('aid:pstyle'=>'PART_TITLE')},
  'tocchap/tocentry'                        => sub {$_->set_att('aid:pstyle'=>'Toc Head')},
  'tocchap/toctopic/tocentry'               => sub {$_->set_att('aid:pstyle'=>'Toc1')},
#  'tocscheduleTitle'                        => sub {$_->set_att('aid:pstyle'=>'Toc_level_1')},
  'tocback/tocentry'                        => sub {$_->set_att('aid:pstyle'=>'Toc2')},

  },
  keep_encoding => 'true');
  return $t;
}

sub processTables
{
# Table RowStart & RowEnd Apply
  my @firstcell=$t->get_xpath('//tr/td[1]');
  foreach my $tmp(@firstcell)
  {
    $tmp->set_att('pos'=>'rowstart');
  }

  my @lastcell=$t->get_xpath('//tr/td[last()]');
  foreach my $tmp(@lastcell)
  {
    $tmp->set_att('pos'=>'rowend') ;
  }

# Set Style for All <TD>
  my @td=$t->get_xpath('//td');
  foreach my $td(@td)
  {
    $td->set_att('aid:pstyle'=>'Default');
  }

# Get Row-Count & Col-Count of each Table
  my @tables=$t->get_xpath('//table');
  foreach my $table(@tables)
  {
    my $rCnt= $table->children_count('tr');
    $table->set_att('aid:trows'=>$rCnt);
    if ($table->get_xpath('tr'))
    {
      my @tr=$table->get_xpath('tr');
      foreach my $tr(@tr)
      {  $count=$cCnt;
        $cCnt= $tr->children_count('td');
#  Table RowStartEnd Apply for 1-Column
        if($cCnt=="1")
        {
	        my @tdfl=$tr->get_xpath('td');
	        foreach my $tdfl(@tdfl)
	        {
	            $tdfl->set_att('pos'=>'rowstartend');
	        }
        }
        if( $cCnt ge $count ){ $count = $cCnt } else { $cCnt = $count };
# Remove all TR in a Table
        $tr->erase;
      }
    }

# Calculate Column Width
    $table->set_att('aid:tcols'=>"$cCnt");
    $cWidth="330"/$cCnt;
    my @td=$table->get_xpath('td');
    foreach my $td(@td)
    {
# Column Width Apply to each TD

      $td->set_att('aid:ccolwidth'=>"$cWidth");  #."%");
# Get Span value
      $cSpn=$td->att('colspan');
      $rSpn=$td->att('rowspan');
# Apply COLUMN Span value
      if ($cSpn ge 1)
      {
        $tWidth=$cWidth*$cSpn;
        $td->set_att('aid:ccols'=>"$cSpn",'aid:ccolwidth'=>"$tWidth");
      }
      else
      {
        $td->set_att('aid:ccols'=>'1','aid:ccolwidth'=>"$cWidth");
      }
# Apply ROW Span value
      if ($rSpn ge 1)
      {
        $td->set_att('aid:crows'=>"$rSpn");
      }
      else
      {
        $td->set_att('aid:crows'=>'1');
      }
    }
  }

# Return to main Sub
  return $t;
}

sub processInputFile
{
  open (FIN, "<$src") || die "can't open Merged XML file";
  my $filecont = join "", <FIN>;
  close FIN;
  $filecont=~s#(<title[^>]+>)([^a-z0-9]+</title>\s*)(<h1[^>]*>(?!</h1>)(.*?)</h1>)#$1$3$2#gsi;
  $filecont=~s#( encoding=\"[^\"]+\"|<\?xml-stylesheet[^>]+>)##gis;
  $filecont=~s# # #g;
  $filecont=~s#  +# #gi;
  $filecont=~s# \n#\n#gi;
  $filecont=~s#\n #\n#gi;
  $filecont=~s#\n\n+#\n#gi;
  $filecont=~s#(<br/>)+#$1#gi;
  $t->parse($filecont);
  my $root= $t->root;
  $root->set_att('xmlns:aid'=>'http://ns.adobe.com/AdobeInDesign/4.0/','xmlns:aid5'=>'http://ns.adobe.com/AdobeInDesign/5.0/');
  return $t;
}

sub printout
{
  $outfile = $src;
  $outfile =~s/\.xml/_out\.xml/i;
  open(FOUT,">$outfile")||die "can't open output file";

# remove <p>'s pstyle where <num>,<dfn> occurs in <p>
  $out=~s# # #g;
  $out=~s#  +# #gi;
  $out=~s#\n##gi;
  $out=~s#(<br/>)+#$1#gi;
  $out=$out;
  $out=~s/(<p) aid:pstyle=\"[^>]+\"( left=\"[0-9]+\"[^>]*>(<[^<>]+\/>)?<(num|dfn) aid:pstyle)/$1$2/g;
  $out=~s/(<\/[^>]*num>)/$1\t/g;
  $out=$out;
  $out=~s/(<dt-footnotes>(<[^<>]+>)*<h1 aid:pstyle=\")\*Footnote Spc Italic(\">)/$1 \*Ref Hd$3/g;
  $out=~s/(<p [^\n>]*aid:pstyle=\"\*Footnote Text\"[^\n>]*>)(?!\<num\>)/$1\t/g; # add tab for all fn-text
  $out=~s/<p aid:pstyle=\"Body Text\"><num>/<p aid:pstyle=\"\*Col (i) or (a) indented no italics\"><num>/g;
  $out=~s/(\<\/num>)\s*/$1\t/g; # add tab after <num>
  $out=~s/(\<[^\/]+ aid:pstyle|<tr>)/\n$1/g; # break paragraphs
  $out=~s/(^[^\n]*)\n/$1/; # Remove First Break
#  $out=~s/(<td [^>]+)><p /$1 /g; # remove <p> from '<td><p>'
#  $out=~s/(<td [^>]+)>(<[^>]+>)\n*<p /$2$1 /g; # remove <p> from '<td><p>'
#  $out=~s/<\/p>(<\/td>)/$1/g; # remove </p> from '</p></td>'
#  $out=~s/\n(<td)/$1/g; # remove break before <td>
  $out=~s#</td>\n<td#</td><td#g; # remove break before <td>
  $out=~s/<ellipsis\/>/<ellipsis>...<\/ellipsis>/g;
  $out=~s#(<(case-law|amendments|uk|section-refs|cross-refs|new-amendments|related|tax-briefs|precedents)><h1 aid:pstyle=\"[^\"]+\">(<[^>]+>\s*)?<i aid:cstyle=\")Italic(\">)#$1bold italic$4<boldremove/>#g;
  $out=~s#(<start/>(<[^>]+>)?)\n(<num[^>]+>)#\n$3$1#g;
  $out=~s#<start/>#<start><del>\[</del></start>#g;
  $out=~s#(<end[^<]* fm="([^"]+)[^<]*")/>#$1\/><del>\]<sup aid:cstyle="superscript">$2</sup></del>#g;
  $out=~s#(<\/num>\t)\n(<num) aid:pstyle=\"[^\"]+\"([^>]*>)#$1$2$3#g;
  $out=~s#((<\/section-heading>|<\/amending-acts>)(<[^<>]+>)*)<p>#$1\n<p aid:pstyle=\"*Col 02\" left="0">#g;

  print FOUT $out;
  close FOUT;
}
