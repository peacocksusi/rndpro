#!c:\perl\bin\perl

use XML::Twig;
use Tie::IxHash;    # necessary for perlapp build
use Getopt::Std;
use Win32;

$|=1;                # PRE-PROCESSING

# ----------------------------------------------------------------------
# GLOBALS
my (%opts);         # stores all command-line options
my $infile = "";    # stores the complete input file's contents
my $t;              # twig object
# ----------------------------------------------------------------------

($jcode, $artid) = $ARGV[0]=~m/_xml\\([A-Z]+)\\(\d+)\\/gis;

open(SYSPATH, "C:\\WINDOWS\\SystemPath.ini")||Win32::MsgBox("SysptemPath.ini missing",0|MB_ICONSTOP,"Warning");
$syscont = join "", <SYSPATH>;
($basedir) = $syscont=~m/X2 ?= ?([^\n]+)\n/;
$parentdir=$basedir=~s/\\01_FirstProof//gsi;
$imgdir="$parentdir\\AppFiles\\$jcode\\$artid\\Web\\";
$imglink="file:\/\/..\/..\/..\/..\/AppFiles\/$jcode\/$artid\/Web\/";
$eqnlink="file:\/\/..\/..\/..\/..\/AppFiles\/$jcode\/$artid\/Equation\/";

close SYSPATH;

main();
exit 0;

# The main function
sub main
{
    print "Step - 0 : Completed\n";
    $t = initializeTwig();          # Twig Initialization
    print "Step - 1 : Completed\n";
    processInputFile();             # Processing Input files
    print "Step - 2 : Completed\n";
    $t = lists();                   # |
    print "Step - 3 : Completed\n";
    $t = secfp();
    print "Step - 4 : Completed\n";
    $t = applystyles();             # |= Lists
    print "Step - 5 : Completed\n";
    $t = figcref();                 # |
    print "Step - 6 : Completed\n";
    $t = tabcref();                 # }
    print "Step - 7 : Completed\n";
    $t = inlinegraphlink();         #/
    print "Step - 8 : Completed\n";
    $infile = replacements();       # Replacements in XML coding
    print "Step - 9 : Completed\n";
    processOutput();                # Processing output file
    print "Step - 10 : Completed\n";
}

# Twig initialization
sub initializeTwig {
  my $t = new XML::Twig  ( twig_handlers =>
     {  'journal-id'                               => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'issn'                                     => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'publisher-name'                           => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'publisher-loc'                            => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-id'                               => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'subject'                                  => sub{$_->set_att('aid:pstyle'=>'AT')},
        'article-meta/pub-date/month'              => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/pub-date/year'               => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/pub-date/string-date'        => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/volume'                      => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/issue'                       => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/fpage'                       => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/lpage'                       => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/copyright-statement'         => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'article-meta/copyright-year'              => sub{$_->set_att('val'=>$_->text()); $_->set_text()},
        'alt-title'                                => sub{$_->set_att('val'=>$_->text())}, # ; $_->set_text()
        'article-meta//article-title'              => sub{$_->set_att('aid:pstyle'=>'CT')},
        'sub-title'                                => sub{$_->set_att('aid:pstyle'=>'CST')},
        'series-title'                             => sub{$_->set_att('aid:pstyle'=>'Focus')},
        'abstract/title'                           => sub{$_->set_att('aid:pstyle'=>'ABS_H')},
        'abstract/p'                               => sub{$_->set_att('aid:pstyle'=>'ABS_TXT')},
        'body/p'                                   => sub{$_->set_att('aid:pstyle'=>'TXI')},
        'sec/p'                                    => sub{$_->set_att('aid:pstyle'=>'TXI')},
        'ack/p'                                    => sub{$_->set_att('aid:pstyle'=>'TXI')},
        'note/p'                                   => sub{$_->set_att('aid:pstyle'=>'TXI')},
        'fig/p/fn/p'                               => sub{$_->set_att('aid:pstyle'=>'FC Note')},
        'abstract/p/italic'                        => sub{$_->set_att('aid:cstyle'=>'ABS_ITALIC')},
        'contrib-group'                            => sub{$_->set_att('aid:pstyle'=>'AU')},
        'abbrev-journal-title'                     => sub{$_->set_att('aid:pstyle'=>'Expert')},
        'ref'                                      => sub{$_->set_att('aid:pstyle'=>'Ref')},
        'ref-list/p'                               => sub{$_->set_att('aid:pstyle'=>'REF_Ann')},
        'kwd-group/title'                          => sub{$_->set_att('aid:cstyle'=>'Keyword')},
        'kwd-group'                                => sub{$_->set_att('aid:pstyle'=>'Keywords')},
        'body/sec/title'                           => sub{$_->set_att('aid:pstyle'=>'H1')},
        'body/sec/sec/title'                       => sub{$_->set_att('aid:pstyle'=>'H2')},
        'body/sec/sec/sec/title'                   => sub{$_->set_att('aid:pstyle'=>'H3')},
        'body/sec/sec/sec/sec/title'               => sub{$_->set_att('aid:pstyle'=>'H4')},
        'back/sec/title'                           => sub{$_->set_att('aid:pstyle'=>'H1')},

        'sc/sub/i'                                 => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_italic')},
        'sc/sub/b'                                 => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold')},
        'sc/sub/bi'                                => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sc/sub/b/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sc/sub/i/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/sc/i'                                 => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_italic')},
        'sub/sc/b'                                 => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold')},
        'sub/sc/bi'                                => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/sc/b/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/sc/i/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/b/sc/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/i/sc/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'b/sub/sc/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'i/sub/sc/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/i/sc'                                 => sub{$_->set_att('aid:cstyle'=>'SC_sub_italic')},
        'sub/b/sc'                                 => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold')},
        'sub/bi/sc'                                => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/b/i/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sub/i/b/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'b/sub/i/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'i/sub/b/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sub_bold_italic')},
        'sc/sup/i'                                 => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_italic')},
        'sc/sup/b'                                 => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold')},
        'sc/sup/bi'                                => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sc/sup/b/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sc/sup/i/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/sc/i'                                 => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_italic')},
        'sup/sc/b'                                 => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold')},
        'sup/sc/bi'                                => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/sc/b/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/sc/i/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/b/sc/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/i/sc/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'b/sup/sc/i'                               => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'i/sup/sc/b'                               => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/i/sc'                                 => sub{$_->set_att('aid:cstyle'=>'SC_sup_italic')},
        'sup/b/sc'                                 => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold')},
        'sup/bi/sc'                                => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/b/i/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'sup/i/b/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'b/sup/i/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},
        'i/sup/b/sc'                               => sub{$_->set_att('aid:cstyle'=>'SC_sup_bold_italic')},

        'sub/i'                                    => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sub_italic')},
        'sub/b'                                    => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sub_bold')},
        'sub/bi'                                   => sub{$_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'sub/b/i'                                  => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'sub/i/b'                                  => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'i/sub'                                    => sub{$_->set_att('aid:cstyle'=>'sub_italic')},
        'b/sub'                                    => sub{$_->set_att('aid:cstyle'=>'sub_bold')},
        'bi/sub'                                   => sub{$_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'b/i/sub'                                  => sub{$_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'i/b/sub'                                  => sub{$_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'i/sub/b'                                  => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'b/sub/i'                                  => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sub_bold_italic')},
        'sup/i'                                    => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sup_italic')},
        'sup/b'                                    => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sup_bold')},
        'sup/bi'                                   => sub{$_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'sup/b/i'                                  => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'sup/i/b'                                  => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'i/sup'                                    => sub{$_->set_att('aid:cstyle'=>'sup_italic')},
        'b/sup'                                    => sub{$_->set_att('aid:cstyle'=>'sup_bold')},
        'bi/sup'                                   => sub{$_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'b/i/sup'                                  => sub{$_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'i/b/sup'                                  => sub{$_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'b/sup/i'                                  => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'i/sup/b'                                  => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'sup_bold_italic')},
        'sc/i'                                     => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_italic')},
        'sc/b'                                     => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_bold')},
        'sc/bi'                                    => sub{$_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'sc/b/i'                                   => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'sc/i/b'                                   => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'i/sc'                                     => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_italic')},
        'b/sc'                                     => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_bold')},
        'bi/sc'                                    => sub{$_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'b/i/sc'                                   => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'i/b/sc'                                   => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'b/sc/i'                                   => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'i/sc/b'                                   => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'SC_bold_italic')},
        'sc/sub'                                   => sub{$_->set_att('aid:cstyle'=>'SC_sub')},
        'sc/sup'                                   => sub{$_->set_att('aid:cstyle'=>'SC_sup')},

        'i'                                        => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'italic')},
        'b'                                        => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'bold')},
        'bi'                                       => sub{$_->set_tag("bi"); $_->set_att('aid:cstyle'=>'bold_italic')},
        'b/i'                                      => sub{$_->set_tag('italic'); $_->set_att('aid:cstyle'=>'bold_italic')},
        'i/b'                                      => sub{$_->set_tag('bold'); $_->set_att('aid:cstyle'=>'bold_italic')},
        'sub'                                      => sub{$_->set_att('aid:cstyle'=>'sub')},
        'sup'                                      => sub{if ($_->text() eq '*'||$_->text() eq '**'||$_->text() eq '&#x002A;'||$_->text() eq '&#x002A;&#x002A;') { $_->set_att('aid:cstyle'=>'Symbol') } else { $_->set_att('aid:cstyle'=>'sup') } },
        'sc'                                       => sub{$_->set_att('aid:cstyle'=>'SC')},

        'xref[@ref-type="bibr"]'                   => sub{$_->set_att('aid:cstyle'=>'Ref-num')},
        'xref[@ref-type="table"]'                  => sub{$_->set_att('aid:cstyle'=>'Citation')},
        'xref[@ref-type="fig"]'                    => sub{$_->set_att('aid:cstyle'=>'Citation')},
        'fig/label/bold'                           => sub{$_->set_tag('bold'); $_->set_tag('b')},
        'contrib-group/aff'                        => sub{$_->set_att('aid:pstyle'=>'Address')},
        'body/sec/label'                           => sub{$_->set_att('aid:cstyle'=>'H1 num')},
        'body/sec/sec/label'                       => sub{$_->set_att('aid:cstyle'=>'H2 num')},
        'body/sec/sec/sec/label'                   => sub{$_->set_att('aid:cstyle'=>'H3 num')},
        'body/sec/sec/sec/sec/label'               => sub{$_->set_att('aid:cstyle'=>'H4 num')},
        'formaltable/title'                        => sub{$_->set_att('aid:pstyle'=>'TT')},
        'fig/label'                                => sub{$_->set_att('aid:pstyle'=>'FC')},
        'ref-list/title'                           => sub{$_->set_att('aid:pstyle'=>'H1')},
        'ack/title'                                => sub{$_->set_att('aid:pstyle'=>'H1')},
        'table-wrap/caption'                       => sub{$_->set_att('aid:pstyle'=>'TT')},
        'oasis:table'                              => sub{$_->set_att('aid:table'=>'table', 'aid:trows'=>'', 'aid:tcols'=>'', 'aid5:tablestyle'=>'TABL')},
        'oasis:thead/oasis:row/oasis:entry'        => sub{$_->set_att('aid5:cellstyle'=>'TCH','aid:pstyle'=>'TCH','aid:ccolwidth'=>'','aid:table'=>'cell')},
        'oasis:tbody/oasis:row/oasis:entry'        => sub{$_->set_att('aid5:cellstyle'=>'TB','aid:pstyle'=>'TB','aid:ccolwidth'=>'','aid:table'=>'cell')},
        'oasis:table/oasis:tgroup'                 => sub{$_->erase},
        'oasis:tgroup/oasis:thead'                 => sub{$_->erase},
        'oasis:entry[@aid:crows="continue"]'       => sub{$_->erase},   # Added by SaRaVaNaN.N
        'table-wrap-foot/fn/p'                     => sub{$_->set_att('aid5:cellstyle'=>'TFN', 'aid:pstyle'=>'TFN')},
      },
   keep_encoding=>'true');
return $t;
}

# Processing input file
sub processInputFile {
    local *FIN;
    open (FIN, "< $ARGV[0] ")||Win32::MsgBox("Cannot Open file: $ARGV[0]",0|MB_ICONSTOP,"Warning");
    my $infile = join "", <FIN>;
    $infile=~s/\&lt\;(\/?)(bi|i|sup|sub|b|sc|u)\&gt\;/<$1$2>/gsi;

    $infile=~s/\&amp;\#x003C\;(eqn)\-([0-9])\/\&amp;\#x003E\;/"<".$1."00".$2."\/>"/gsie;
    $infile=~s/\&amp;\#x003C\;(eqn)\-([0-9][0-9])\/\&amp;\#x003E\;/"<".$1."0".$2."\/>"/gsie;
    $infile=~s/\&amp;\#x003C\;(eqn)\-([0-9][0-9][0-9]+)\/\&amp;\#x003E\;/"<".$1.$2."\/>"/gsie;

#    $infile=~s#<bi>#<b><bi>#gsi;    $infile=~s#<\/bi>#<\/bi></b>#gsi;
    close FIN;
    open (FIN, "> $ARGV[0] ")||die "Can't Open Input File";     # FOR DEBUGGING
    print FIN $infile;
    close FIN;
    $t->parse($infile);
    return $t;
}

# Lists
sub lists
{
  bulletedlist();
  numberedlist();
}

# Bulleted list item
sub bulletedlist
{
  my @firstlistitem=$t->get_xpath('//list[@list-type="bullet"]/list-item/p');
  my $i=0;
  foreach my $tmp(@firstlistitem)
  {
    $i++;
    $tmp->set_att('aid:pstyle'=>'BL');
    $tmp->set_att('aid:pstyle'=>'BLF') if $i==1;
    $tmp->set_att('aid:pstyle'=>'BLL') if $i==($#firstlistitem+1);
  }
  return $t;
}

sub secfp
{
  my @firstpara=$t->get_xpath('//sec/p[1]');
  my $i=0;
  foreach my $tmp(@firstpara)
  {
    if ($tmp->prev_sibling('title'))
    {
      $tmp->set_att('aid:pstyle'=>'TXT');
    }
  }
  return $t;
}
# $tmp->first_child('given-names')

# Numbered list item
sub numberedlist
{
  my @firstlistitem=$t->get_xpath('//list[@list-type="numbered"]/list-item/p');
  my $i=0;
  foreach my $tmp(@firstlistitem)
  {
    $i++;
    $tmp->set_att('aid:pstyle'=>'NL');
    $tmp->set_att('aid:pstyle'=>'NLF') if $i==1;
    $tmp->set_att('aid:pstyle'=>'NLL') if $i==($#firstlistitem+1);
  }
  return $t;
}

# First page authors and correspondense address
sub firstpageauthor
{
  my $afftag=$t->get_xpath('//contrib-group', 0);
  $tmp = $afftag->copy;
  my $deltag= new XML::Twig::Elt('authordel', $tmp);
  my $articleend=$t->get_xpath('//contrib-group', 0);
  $deltag->paste('before',$articleend);
  @contrib = $t->get_xpath('//authordel//contrib');
  foreach (@contrib)
  {
    $_->set_att('aid:pstyle'=>'AU');
  }
  @aff = $t->get_xpath('//authordel//aff');
  foreach (@aff)
  {
    $checkatt = $_->{'att'}->{id};
    if ($checkatt eq "cadd")                     #if it is correspondense address
    {
      $_->set_tag('delaff');
      $_->set_att('aid:pstyle'=>'Address');
    }
    else                        #otherwise delete the aff part in First page
    {
      $_->delete;
    }
  }
  @affs = $t->get_xpath('//contrib-group//aff');
  foreach (@affs)
  {
    $checkatt = $_->{'att'}->{id};
    if ($checkatt eq "cadd")                     #if it is correspondense address then delete in Last page aff part
    {
      $_->delete;
    }
  }
return $t;
}

sub applystyles
{
    my @firstfn=$t->get_xpath('//table-wrap-foot/fn/p[1]');
    foreach my $tmp(@firstfn)
    {
      $tmp->set_att('aid:pstyle'=>'TFN1');
    }
    print "TFN1\n";

    my @first_fig_fn=$t->get_xpath('//fig/p/fn/p[1]');
    foreach my $tmp(@first_fig_fn)
    {
      $tmp->set_att('aid:pstyle'=>'FC Note1');
    }
    print "FC Note\n";

    my @lastrow=$t->get_xpath('//oasis:tbody/oasis:row[last()]/oasis:entry');
    foreach my $tmp(@lastrow)
    {
      $tmp->set_att('aid5:cellstyle'=>'TBL') ;
    print "TBL\n";
    }
    print "Last TBL\n";

    my @firstrow=$t->get_xpath('//oasis:tbody/oasis:row[1]/oasis:entry');
    foreach my $tmp(@firstrow)
    {
      $tmp->set_att('aid5:cellstyle'=>'TBF');
    }
    print "TBF\n";

    my @allrows=$t->get_xpath('//oasis:row');
    foreach my $row(@allrows){
      if ($row->get_xpath('oasis:entry[last()]'))
      {
        my @lastcell=$row->get_xpath('oasis:entry[last()]');
        foreach my $tmp(@lastcell)
        {
          $tmp->set_att('pos'=>'rowend') ;
    print "row\n";
        }
      } # if
    }
    print "rowend\n";

    my @firstcell=$t->get_xpath('//oasis:row/oasis:entry[1]');
    foreach my $tmp(@firstcell)
    {
      if ($tmp->next_sibling('oasis:entry'))                   # Condition Added by SaRaVaNaN.N
      { $tmp->set_att('pos'=>'rowstart'); }
      else
      { $tmp->set_att('pos'=>'rowstartend'); }                 # Added by SaRaVaNaN.N
    print "rowstart\n";
    }

    my @titleital=$t->get_xpath('//title/italic');
    foreach my $tmp(@titleital)
    {
     $tmp->set_att('aid:cstyle'=>'head-boldital');
    }
    print "head\n";

=comment
    my @abital=$t->get_xpath('//abstract/p/italic');
    foreach my $tmp(@abital)
    {
     $tmp->set_att('aid:cstyle'=>'italic');
    }

    my @fcital=$t->get_xpath('//caption/title/italic');
    foreach my $tmp(@fcital)
    {
     $tmp->set_att('aid:cstyle'=>'italic');
    }

    my @fcbold=$t->get_xpath('//caption/title/bold');
    foreach my $tmp(@fcbold)
    {
     $tmp->set_att('aid:cstyle'=>'bold');
    }

    my @fcbold=$t->get_xpath('//table-wrap/label/bold');
    foreach my $tmp(@fcbold)
    {
     $tmp->set_att('aid:cstyle'=>'bold');
    }

    my @fcbold=$t->get_xpath('//bold/italic');
    foreach my $tmp(@fcbold)
    {
     $tmp->set_att('aid:cstyle'=>'bold_italic');
    }

    my @fcbold=$t->get_xpath('//oasis:entry/bold');
    foreach my $tmp(@fcbold)
    {
     $tmp->set_att('aid:cstyle'=>'bold');
    }

    my @fcbold=$t->get_xpath('//oasis:entry/bold/italic');
    foreach my $tmp(@fcbold)
    {
     $tmp->set_att('aid:cstyle'=>'boldital');
    }

    my @fcboldital=$t->get_xpath('//caption/title/bold/italic');
    foreach my $tmp(@fcboldital)
    {
     $tmp->set_att('aid:cstyle'=>'boldital');
    }

    my @tblital=$t->get_xpath('//table-wrap//italic');
    foreach my $tmp(@tblital)
    {
     $tmp->set_att('aid:cstyle'=>'italic');
    }
=cut

    return $t;
}

# cref="yes" for figure placements

sub figcref
{
  my @media=$t->get_xpath('//fig');
  $figcount = scalar(@media);
  for ($i=1;$i<=$figcount;$i++)
  {
    my $j = "fig-".$i;
    my @xtgs = $t->get_xpath('//xref[@rid="'.$j.'"]');
    $xtgs[0]->set_att('cref'=>"yes") if (scalar(@xtgs) > 0);
  }
  return $t;
}

# cref="yes" for table cross-ref / placements
sub tabcref
{
  my @tables=$t->get_xpath('//table-wrap');
  $tabcount = scalar(@tables);
  for ($i=1;$i<=$tabcount;$i++)
  {
    my $j = "tab-".$i;
    my @xtgs = $t->get_xpath('//xref[@rid="'.$j.'"]');
    $xtgs[0]->set_att('cref'=>"yes") if ($#xtgs >= 0);
  }
  return $t;
}

# Inlinegraphic link
sub inlinegraphlink
{
  my @inlinegraphics = $t->get_xpath('//inline-graphic');
  foreach (@inlinegraphics)
  {
    $xlinkhref = $_->{'att'}->{'xlink:href'};
    if ($opts{'m'})
    {
       $imgpath = $opts{'m'};
      $imgpath=~s/\\/\//gsi;
      $_->set_att(href=>"file:///".$imgpath."/".$xlinkhref);
    }
  }

  my @tablegraphics = $t->get_xpath('//table-wrap//graphic');
  foreach (@tablegraphics)
  {
    $xlinkhref = $_->{'att'}->{'xlink:href'};
    if ($opts{'m'})
    {
      $imgpath = $opts{'m'};
      $imgpath=~s/\\/\//gsi;
      $_->set_att(href=>"file:///".$imgpath."/".$xlinkhref);
    }
  }
  return $t;
}

$t = &sectionpara();

sub replacements
{
  $infile=$t->sprint;
  process_doi();                                                                # Added by SaRaVaNaN.N
#  $infile=~s/(<!DOCTYPE article SYSTEM \")(archivearticle.dtd\">)/$1\\\\openstore\\firstproofs\\journals\\indesign\\client-33\\nlm-dtd\\$2/gsi;
  $infile=~s/(<\/title-group>)\n/$1/g;
  $infile=~s/[\n]+/\n/g;
  $infile=~s/(<contrib .*?<\/contrib>)/&removecr($1)/ges;
  $infile=~s#(<\/[^>]+>)<x>, <\/x>(<\/name><\/contrib><aff )#$1$2#gs;
  $infile=~s#(<\/[^>]+>)<x>, <\/x>(<\/name><\/contrib><contrib><name>(<[^>]+>[^<>]+<\/[^>]+>)*<\/name><\/contrib><aff )#$1<x> &\#x0026; <\/x>$2#g;
  $infile=~s/(<kwd-group .*?<\/kwd-group>)/&removecr($1)/ges;
  $infile=~s/(<\/kwd>)([^<>]+)(<kwd>)/$1<x>$2<\/x>$3/gs;
  $infile=~s/(<ref .*?<\/ref>)/&removecr($1)/ges;
  $infile=~s/(<ref .*?<\/ref>)/&note_newline($1)/ges;
  $infile=~s/(<fig .*?<\/fig>)/&removecr($1)/ges;
  $infile=~s/(<title>.*?<\/title>)/&removecr($1)/ges;
  $infile=~s/(<oasis:row.*?<\/oasis:row>)/&removecr($1)/ges;
  $infile=~s/(<\/oasis:entry>)\s*(<oasis:entry)/$1\t$2/g;
  $infile=~s/(<\/title>\s*<p aid:pstyle=\"TX)I\">/$1T\">/g;
  $infile=~s/(<oasis:table .*?<\/oasis:table>)/&changecitations($1)/ges;
  $infile=~s/(<fn.*?<\/fn>)/&changecitations_fn($1)/ges;
  $infile=~s/(<caption.*?<\/caption>)/&changecitations_tblcap($1)/ges;
  $infile=~s/(<fig .*?<\/fig>)/&changecitations($1)/ges;
  $infile=~s/<\/?oasis:tbody>//gsi;
  $infile=~s/\s*(<\/label>)\s*(<title)/$1$2/gs;
  $infile=~s/(\&nbsp;)?(?:\.?\t?)(<\/label><cit)/.\t$2/g;
  $infile=~s/(<xref.*?<\/xref>)/&removebold($1)/ges;
  $infile=~s/ (<xref aid:cstyle="Ref-num")/\&nbsp;\&\#x200A;$1/g;
  $infile=~s/(<title aid:pstyle=")BIB\-Head(">(Website|Patent))/$1AFF\-Head$2/;
  $infile=~s/XML::Twig=HASH.*$//gi;
  $infile=~s/(<article .*?<\/article-categories>)/&removecr($1)/gse;
  $infile=~s/(<title-group>.*?<\/title-group>)/&removecr($1)/gse;
  $infile=~s/(<contrib-group>.*?<\/contrib-group>)/&removecr($1)/gse;
  $infile=~s/(<author-notes .*?<\/author-notes>)/&removecr($1)/gse;
  $infile=~s/\s*(<\/given-names>)<x>\s*<\/x>(<surname>)/$1<x> <\/x>$2/g;
  $infile=~s/\s*(<\/given-names>)(<surname>)/$1<x> <\/x>$2/g;
  $infile=~s/(<\/contrib>)(<contrib contrib-type="author">)/$1, $2/g;
  my $abbrevtitle=$1 if $infile=~s/(<abbrev-journal-title .*?<\/abbrev-journal-title>)/<abbrevtitle\/>/gs;
  $infile=~s/(<\/article-meta>)/$abbrevtitle$1/g;
  my $otheraff=$1 if $infile=~s/(<otheraff>.*?<\/otheraff>)//gs;
  $infile=~s/(<\/article>)/$otheraff\n$1/gs;
  $infile=~s/(<abstract>\s*<p aid:pstyle=\")([a-zA-Z]+)(\">)/$1ABS-TXT$3/gs;
  $infile=~s/( \d+) (patient|year|day|week[s]?)/$1\&nbsp;$2/gsi;
  $infile=~s/( \d+) (nm|mm|cm|h|min|hour|m|hr[s]?|nM|kDa|mg|ml|g|kg|\&mu\;|l)([;:.,\) ])/$1\&nbsp;$2$3/gs;
  $infile=~s/(phase|class|type) (\d+)/$1\&nbsp;$2/gsi;
  $infile=~s/ = /\&nbsp;=\&nbsp;/gsi;
  $infile=~s#(in|ex|et) (vivo|vitro|suit|silico|al)#$1\&nbsp;$2#gsi;
  $infile=~s/(<\/label>)(<title aid:pstyle=\"H)/$1\&\#x02002;$2/g;
  $infile=~s/<\/body>(<back>)/$1/g;
  $infile=~s/<\/back>/<\/back><\/body>/g;

#  $infile=&entities; moved to below by SaRaVaNaN.N

#  $infile=~s/(\&\#x\w{5};)/<entity aid:cstyle="Symbol">$1<\/entity>/g;
  $infile=~s/(<\/label>)\s*(<p )/$1\t$2/gs;
  $infile=~s/(<fn>.*?<\/fn>)/&removefncr($1)/ges;
  $infile=~s/(<note>)\s*(<p aid:pstyle="REF-BULL">)/$1\t$2/gs;
    # Graphic, Images
  while ($infile=~m/<graphic xlink:href=\"([^"]+)"/g)
  {
    $flname = $1;
    if (-e "$imgdir$flname\.eps")
    {
      $infile=~s/<graphic (xlink:href=\"${flname}\")/<graphic href=\"$imglink$flname\.eps\" $1/s;
    }
    elsif (-e "$imgdir$flname\.tif")
    {
      $infile=~s/<graphic (xlink:href=\"${flname}\")/<graphic href=\"$imglink$flname\.tif\" $1/s;
    }
  }
  $infile=~s/<fig([^>]+>)(.*?<graphic xlink:href=\"([^\"]+)\"[^>]+>)/<fig aid:pstyle="IMG"$1$3\n\n$2/g;

  $infile=~s/(<p[^>]*>)\s*<(eqn[0-9]+)\/>\s*([\[\(]?([-0-9.]+)[\]\)])?\s*<\/p>/$1<disp-formula aid:pstyle="MathEqn" id="$2"><graphic href=\"$eqnlink$2\.eps\" xlink:href=\"$2\.eps\"\/>$3<\/disp-formula><\/p>/g;
  $infile=$infile;
  $infile=~s/<(eqn[0-9]+)\/>/<inline-formula id="$1"><graphic href=\"$eqnlink$1\.eps\" xlink:href=\"$1\.eps\"\/><\/inline-formula>/g;

  $infile=~s#(<oasis:table.*?</oasis:table>)#&tablcol($1)#gesi;
  $infile=~s#</?oasis:row[^>]*>##gsi;
  $infile=~s#<oasis:colspec[^>]*>\n?##gsi;
  $infile=~s#(<authordel.*?</authordel>)#&authrdel($1)#gesi;
  ##################### Problem found ###############################
  $infile=~s#(<title[^>]+></title>)#&titlesymbol($1)#gesi;
  ###################################################################
  $infile=~s/(italic>)(<xref)/$1 $2/gsi;
  $infile=~s#<b aid:cstyle="Bold">#<b aid:cstyle="bold">#gsi;
  $infile=~s#</p><p aid5:cellstyle="TFN"#</p>\n<p aid5:cellstyle="TFN"#gsi;
  $infile=~s/(pstyle=\"H3\"((?!pstyle).)+pstyle=)\"H4\"/$1\"H4-H3\"/gsi;
  $infile=~s/(pstyle=\"H2\"((?!pstyle).)+pstyle=)\"H3\"/$1\"H3-H2\"/gsi;
  $infile=~s/(pstyle=\"H1\"((?!pstyle).)+pstyle=)\"H2\"/$1\"H2-H1\"/gsi;

  ### Affiliation Headings
  $infile=~s/<( |\d)/\&\#x003C;$1/g;
  $infile=~s/( |\d)>/$1\&\#x003E;/g;
  $infile=~s/  / /g;
  $infile=~s/\n+/\n/g;
  $infile=~s/(<\/series-title><\/article-categories><title-group>)(<article-title aid:pstyle=\"CT\">)/$1\n$2/g;
  $infile=~s#((?:<aff.*?</aff>\s*)+</contrib-group>\s*)(<author-notes[^>]*>.*?(?:</history>|<history\s*/>))#<footer>$2</footer>\n$1#gsi;
#  $infile=~s#(<author-notes[^>]*>)#$1<sup aid:cstyle=\"sup\">&\#x2020;</sup>#gi;
  $infile=~s/(<\/source>)(<year>)/$1 $2/g;
  $infile=~s/\&amp\;\#x([^\;]+)\;/"\&\#x".uc($1)."\;"/egi;    # changed lowercase to uppercase by SaRaVaNaN.N
  $infile=~s/\&nbsp\;/ /g;

  # Entities & Newline para ----------
  $infile=&entities;       # This Line brought down by SaRaVaNaN.N
  process_newlinetags();

  $infile=~s/(<body>[^\n]+)(\n)/$2$1/sg;

  # References
  $infile=~s/(<citation type="journal">)[\[\(]?\d+[\]\)]?\.?\s?/$1/g;
if ($infile=~m/(Declaration of interest|Statement of interest)/gi)
{
 $infile=~s/  / /g;
 $infile=~s#<p aid:pstyle=\"TXI\">(<bold aid:cstyle=\"bold\"><italic aid:cstyle=\"bold_italic\">(Declaration of interest|Statement of interest))#<p aid:pstyle=\"Declaration\">$1#gi;
}
else
{
  $infile=~s/<\/ack>/\n<p aid:pstyle=\"Declaration\"><bold aid:cstyle=\"bold\"><italic aid:cstyle=\"bold_italic\">Declaration of interest:<\/italic><\/bold> The authors report no conflicts of interest. The authors alone are responsible for the content and writing of the paper.<\/p><\/ack>/g;
}
  if($infile=~m#<ref aid:pstyle=\"Ref\" id=\"CIT0010\">#g)
  {
    $infile=~s/(<ref aid:pstyle=\"Ref)(\" id=\"CIT000[1-9]\">)/$1."1".$2/ge;                         # Added by SaRaVaNaN.N
  }

#Table Processes              # Added by SaRaVaNaN.N
  {
    $infile=~s/aid:crows=\"([0-9]+)\"/"aid:crows=\"".($1+1)."\" morerows=\"".($1)."\""/ge;      # Added by SaRaVaNaN.N
    $infile=~s#(<oasis:entry [^>]+aid:pstyle=\"[^\"]+)(\"[^>]+>)\[\@0\]#$1_L$2#g;
    $infile=~s#(<oasis:entry [^>]+aid:pstyle=\"[^\"]+)(\"[^>]+>)\[\@1\]#$1_C$2#g;
    $infile=~s#(<oasis:entry [^>]+aid:pstyle=\"[^\"]+)(\"[^>]+>)\[\@2\]#$1_R$2#g;
    $infile=~s#(<oasis:entry [^>]+colname=\"col([0-9]+)\"[^>]*)(colspan=\"([0-9]+)\"[^>]*)>#"".$1.$3." namest=\"col".$2."\" nameend=\"col".(($4+$2)-1)."\">"#ge;
  }

  return $infile;
}

sub entities
{
  $infile=~s/\n+/\n/g;
  $infile=~s/(&\#(x[^;]+);)/<entity val=\"$2\">$1<\/entity>/gi;
  $saro_ent=$infile;        # Assigned by SaRaVaNaN.N

my %math_ent_exceptions=(
  "&#x22E6;"=>"&#xE026;",	# less than not similar
  "&#x2266;"=>"&#xE025;",	# equal below less than
  "&#x2267;"=>"&#xE05E;",	# equal below greater than
  "&#x2264;"=>"&#xE023;",	# less than or equal
  "&#x2265;"=>"&#xE024;",	# greater than or equal
  "&#x003D;"=>"&#xE035;",	# equals
  "&#x003C;"=>"&#xE02C;",	# less than
  "&#x003E;"=>"&#xE02E;",	# greater than
  "&#x002B;"=>"&#xE031;",	# plus
  "&#x2212;"=>"&#xE032;",	# minus
  "&#x00B1;"=>"&#xE036;",	# plus or minus
  "&#x00D7;"=>"&#xE033;",	# times
  );
map{$saro_ent=~s/(<entity val=\"[^"]+\")>$_/$1 aid:cstyle=\"MathPi1\">$math_ent_exceptions{$_}/g } keys %math_ent_exceptions;
my %symb_ent_exceptions=(
  "&#x03A6;"=>"&#x0046;",	# Phi
  "&#x0393;"=>"&#x0047;",	# Greek
  "&#x03D1;"=>"&#x004A;",	# Grk-Theta-Symbol
  "&#x039B;"=>"&#x004C;",	# Lambda
  "&#x03A0;"=>"&#x0050;",	# Pi
  "&#x0398;"=>"&#x0051;",	# Theta
  "&#x03C2;"=>"&#x0056;",	# final sigma
  "&#x03A9;"=>"&#x0057;",	# Omega
  "&#x039E;"=>"&#x0058;",	# Xi
  "&#x03A8;"=>"&#x0059;",	# Psi
  "&#x03B1;"=>"&#x0061;",	# alpha
  "&#x03B2;"=>"&#x0062;",	# beta
  "&#x03C7;"=>"&#x0063;",	# chi
  "&#x03B4;"=>"&#x0064;",	# delta
  "&#x03B5;"=>"&#x0065;",	# epsi
  "&#x03D5;"=>"&#x0066;",	# Grk-phi-Symbol
  "&#x03B3;"=>"&#x0067;",	# gamma
  "&#x03B7;"=>"&#x0068;",	# eta
  "&#x03B9;"=>"&#x0069;",	# iota
  "&#x03C6;"=>"&#x006A;",	# phi
  "&#x03BA;"=>"&#x006B;",	# kappa
  "&#x03BB;"=>"&#x006C;",	# lambda
  "&#x03BC;"=>"&#x006D;",	# mu
  "&#x00B5;"=>"&#x006D;",	# micro
  "&#x03BD;"=>"&#x006E;",	# nu
  "&#x03BF;"=>"&#x006F;",	# omicron
  "&#x03C0;"=>"&#x0070;",	# pi
  "&#x03B8;"=>"&#x0071;",	# theta
  "&#x03C1;"=>"&#x0072;",	# rho
  "&#x03C3;"=>"&#x0073;",	# sigma
  "&#x03C4;"=>"&#x0074;",	# tau
  "&#x03C5;"=>"&#x0075;",	# upsi
  "&#x03C9;"=>"&#x0077;",	# omega
  "&#x03BE;"=>"&#x0078;",	# xi
  "&#x03C8;"=>"&#x0079;",	# psi
  "&#x03B6;"=>"&#x007A;",	# zeta
  "&#x03B6;"=>"&#x007A;",	# zeta
  "&#x223C;"=>"&#x223C;",	# Sim
  );
map{$saro_ent=~s/(<entity val=\"[^"]+\")>$_/$1 aid:cstyle=\"Symbol\">$symb_ent_exceptions{$_}/g } keys %symb_ent_exceptions;

  $infile=$saro_ent;          # Assigned by SaRaVaNaN.N
  return $infile;
}

#  Add DOI                    # Added by SaRaVaNaN.N
sub process_doi
{
  print "\n Welcome to DOI Processor:\n\n";
  # Reed DOI Number from CATs.xml
  my $cats, $doi, $doinum, $doiin;
  $cats="$basedir\\A_INPUT\\$jcode\\$artid\\cats.xml";
  if (-e "$cats"){
  open (CATSIN, "<$cats")||Win32::MsgBox("Cannot Open CATS.XML File:\n\n$cats",0|MB_ICONSTOP,"ERROR");
  $doi = join "", <CATSIN>;
  $doinum=$1 if($doi=~m#<doi>(.*?)</doi>#g);
  print "\t$doinum\n\n";
  close(CATSIN);
  } else { Win32::MsgBox("Cannot Open CATS.XML File:\n\n$cats",0|MB_ICONSTOP,"ERROR"); };
  $infile=~s#(<article-id pub-id-type="doi" val=")[^"]+(">)#$1.$doinum.$2#ge;
  return $infile;
}

#create newline (paras) in InDesign
sub process_newlinetags
{  my @tags = (
  "<article-title ",
  "<subtitle",
  "<contrib-group",
  "<address",
#  "<aff ",
  "<abbrev-journal-title",
  "<p ",
  "<ref ",
  "<lrh>",
  "<rrh>",
  "<del",
  "<fig ",
  "<table-wrap ",
  "<oasis:table",
  "<table-wrap-foot",
  "<aff",
  "<email",
  "<title aid:pstyle",
  "<kwd-group",
  "<history test=\"mv_b4_cpyrt\">",
  );

  foreach (@tags)
  { $infile=~s/$_/\n$_/g; }
  return $infile;
}

# print to file

sub processOutput
{  my $outfile;
  $outfile = $ARGV[0];
  $outfile=~s/\.xml/_idd\.xml/gsi;
  open(FXML, "> $outfile")||die "cannot open xml file $outfile: $!";
  $infile=~s/[  ]+/ /g;
  $infile=~s# (</[^>]+>)#$1 #g;
  $infile=~s# \n#\n#g;
  $infile=~s#\n #\n#g;
  $infile=~s/\n+/\n/g;
  $infile=~s/(\/eqn)[0]+([0-9][0-9][0-9]\.eps)/$1$2/g;
  while($infile=~m# val="[^"]*\<entity val="([^"]+)"[^>]*>([^<]*)<\/entity>#g) { $infile=~s#( val="[^"]*)\<entity val="([^"]+)"[^>]*>([^<]*)<\/entity>#$1\@\@\#$2\;#gsi; }
  print FXML $infile;
  close FXML;
}

# Subroutines

sub tablcol
{
  ($inline) = @_;
  $colcount = @colcount = $inline=~m/<oasis:colspec/gsi;
  $rowcount = @rowcount = $inline=~m/(<oasis:row)/gsi;
  $inline=~s/aid:tcols=\"\"/aid:tcols=\"$colcount\"/gsi;
  $inline=~s/aid:trows=\"\"/aid:trows=\"$rowcount\"/gsi;
  # print "$colcount";
  $colwidth = int(480/$colcount);
  $inline=~s/aid:ccolwidth=\"\"/aid:ccolwidth=\"$colwidth\"/gsi;
  return $inline;
}

sub authrdel
{
  ($inline) = @_;
  $inline=~s#(</contrib>),*\s*(<contrib )#$1, $2#gsi;
  $inline=~s#(.+</contrib>), (<contrib )#$1 \&\#x0026\; $2#gsi;
  $inline=~s#<sup aid:cstyle="sup">(\d+),?</sup>##;
  return $inline;
}

sub change_focus{
  my ($instr,$flag)=(@_);
  open(FINI,">$infile.log")|| print "Cannot create $infile.log for storing Journal meta info\n";
  print FINI $instr;
  $instr=~s/(<(issn|publisher-name|publisher-loc)[^>]*?>).*?(<\/\2>)/$1$3/g;
  $instr=~s/(<journal-id)/$1 aid:pstyle="Focus"/;
  return $instr if (!$flag);
  $instr=~s/(<journal\-id[^>]*?>).*?(<\/journal\-id>)/$1$2/;
  return $instr;
}

sub removelistpara{
  my $instr=shift;
  $instr=~s/<p aid:pstyle=\"TXI\"/<p/gs;
  return $instr;
}

sub removecr{
  my $instr=shift;
  $instr=~s/[\n\t]//gs;
  $instr=~s/ +/ /gs;
  $instr=~s/> </></gs;
  return $instr;
}

sub removefncr{
  my $instr=shift;
  $instr=~s/[\n\t]//gs;
  $instr=~s/ +/ /gs;
  $instr=~s/> </></gs;
  $instr=~s/aid:pstyle=\"TXI\"/aid:pstyle=\"TFN\"/gsi;
  return $instr;
}

sub note_newline{
  my $instr=shift;
  $instr=~s/(<note>)/\n$1/gs;
  $instr=~s/(<p aid:pstyle=\")TXI(\">)/$1REF-BULL$2/gs;
  return $instr;
}

sub titlesymbol{
  my $instr=shift;
  $instr=~s/\"Symbol\"/\"Symbol-bold\"/gs;
  return $instr;
}

sub removebold{
  my $instr=shift;
  $instr=~s/<bold[^>]*?>//gs;
  $instr=~s/<\/bold>//gs;
  return $instr;
}

sub changecitations{
  my $instr=shift;
  $instr=~s/(aid:cstyle=\")Ref-num\"/$1T-ref no\"/g;
  return $instr;
}

sub changecitations_fn{
  my $instr=shift;
  $instr=~s/(aid:cstyle=\")Ref-num\"/$1TFN_BOXFN_REF_No\"/g;
  return $instr;
}

sub changecitations_tblcap{
  my $instr=shift;
  $instr=~s/(aid:cstyle=\")Ref-num\"/$1BOX_Ref No\"/g;
  return $instr;
}
